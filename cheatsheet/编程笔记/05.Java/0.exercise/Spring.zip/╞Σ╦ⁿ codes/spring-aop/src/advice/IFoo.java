package advice;

public interface IFoo {
	void doA();
	void doB();
	void doC();
}
