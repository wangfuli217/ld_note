package advice;

public class Foo implements IFoo {

	public void doA() {
		System.out.println("doA~~~");
	}

	public void doB() {
		System.out.println("doB~~~");
	}

	public void doC() {
		System.out.println("doC~~~");
	}

}
