package proxy;

public interface Actable {
	void act();
}
