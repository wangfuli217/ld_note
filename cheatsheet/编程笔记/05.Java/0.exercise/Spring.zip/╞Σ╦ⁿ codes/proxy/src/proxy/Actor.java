package proxy;

public class Actor implements Actable {

	public void act() {
		System.out.println("��Ա����ϰ~~~");
	}

}
