package dynaproxy;

public interface IFoo {
	void doA();
	void doB();
	void doC();
}
