package model;

public interface IAccount {
	String getData();
}
