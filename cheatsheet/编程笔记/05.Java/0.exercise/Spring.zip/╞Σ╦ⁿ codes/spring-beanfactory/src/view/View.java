package view;

public interface View {
	String render();
}
