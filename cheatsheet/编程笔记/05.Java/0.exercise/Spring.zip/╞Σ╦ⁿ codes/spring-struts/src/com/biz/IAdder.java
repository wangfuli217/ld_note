package com.biz;

public interface IAdder {
	double add(double a,double b);
}
