package com.biz;

public class Adder implements IAdder {

	public double add(double a, double b) {
		return a+b;
	}

}
