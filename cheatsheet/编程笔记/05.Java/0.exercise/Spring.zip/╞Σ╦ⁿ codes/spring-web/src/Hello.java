
public class Hello implements HelloIf {

	public String sayHello(String name) {
		return "Hello,"+name;
	}

}
