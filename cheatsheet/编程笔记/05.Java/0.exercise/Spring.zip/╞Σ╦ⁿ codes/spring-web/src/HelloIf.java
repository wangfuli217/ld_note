
public interface HelloIf {
	String sayHello(String name);
}
