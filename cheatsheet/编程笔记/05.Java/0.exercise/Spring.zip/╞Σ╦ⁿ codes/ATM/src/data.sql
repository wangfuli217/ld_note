create table account(
	id bigint primary key,
	name varchar(20),
	balance double
);

drop table account;

delete from account;

select * from account;