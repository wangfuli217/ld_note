package BeforeAdvice;

//业务接口
public interface IHello {
	
	//业务方法声明
	void hello(String name);
	void goodbye(String str);

}
