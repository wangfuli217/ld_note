package PreBeforeAdvice;

//业务接口
public interface IHello {
	
	//业务方法声明
	void hello(String name);

}
