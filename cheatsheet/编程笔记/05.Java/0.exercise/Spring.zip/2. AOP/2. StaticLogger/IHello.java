package StaticLogger;

interface IHello {
	
	//业务方法声明
	public void hello(String username);

}
