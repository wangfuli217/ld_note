package ApplicationContextBean;

public class FirstBean {

}
