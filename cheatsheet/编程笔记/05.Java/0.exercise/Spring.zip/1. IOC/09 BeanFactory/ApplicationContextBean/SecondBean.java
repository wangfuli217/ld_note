package ApplicationContextBean;

public class SecondBean {

}
