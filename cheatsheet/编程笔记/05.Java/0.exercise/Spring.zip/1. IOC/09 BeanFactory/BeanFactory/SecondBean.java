package BeanFactory;

public class SecondBean {

}
