package BeanFactory;

public class FirstBean {

}
