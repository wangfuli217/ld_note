package propertiesPackage;

import java.util.Properties;

public class PropertiesBean {
	
	private Properties props;

	public PropertiesBean() {	super();}
	
	public Properties getProps() {return props;}
	public void setProps(Properties props) {this.props = props;}


}
