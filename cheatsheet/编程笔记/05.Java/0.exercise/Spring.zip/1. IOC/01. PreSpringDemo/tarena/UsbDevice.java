﻿package tarena;


//实现类
public class UsbDevice implements IDevice {

	public void saveToDevice() {
		System.out.println("存储至U盘...");
	}

}
