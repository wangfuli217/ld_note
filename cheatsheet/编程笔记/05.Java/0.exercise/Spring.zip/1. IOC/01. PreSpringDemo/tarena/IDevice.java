﻿package tarena;


//存储设备的接口
public interface IDevice {
	//方法
	public void saveToDevice();
}
