﻿package tarena;

//实现类
public class SoftDevice implements IDevice {

	public void saveToDevice() {
		System.out.println("存储至软盘...");
	}

}
