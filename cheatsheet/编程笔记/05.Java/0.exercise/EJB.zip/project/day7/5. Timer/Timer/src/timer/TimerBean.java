package timer;

import javax.annotation.Resource;
import javax.ejb.Stateless;
import javax.ejb.Timeout;
import javax.ejb.Timer;
import javax.ejb.TimerService;

@Stateless
public class TimerBean implements ITimerEJB {
	@Resource
	TimerService ts;

	@Override
	public void startTimer(String task) {
		//ts.createTimer(1000, task);//单动定时器，只运行一次
		ts.createTimer(1000,2000,task); //多动定时器，每隔2秒一次，只能调用cancel()来停止
	}

	@Override
	public void stopTimer(String task) {
		for(Object obj:ts.getTimers()){
			 Timer t = (Timer)obj;
			 if(t.getInfo().equals(task))t.cancel();//停止定时器
		}
	}
	
	@Timeout //定时任务
	public void executeTask(Timer timer){
		//ts.getTimers(); //得到所有定时器
		if(timer.getInfo().equals("丁丁丁")){
			System.out.println("下课了...");
		}else{
			System.out.println("没有定时任务");
		}
	}

}
