package timer;

import javax.ejb.Remote;

@Remote
public interface ITimerEJB {
	public void startTimer(String task);
	public void stopTimer(String task);

}
