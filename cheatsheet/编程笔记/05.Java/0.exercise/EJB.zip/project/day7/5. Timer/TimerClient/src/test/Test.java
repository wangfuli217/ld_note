package test;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;

import timer.ITimerEJB;

public class Test {

	public static void main(String[] args) throws NamingException{
		System.setProperty(Context.INITIAL_CONTEXT_FACTORY,"org.jnp.interfaces.NamingContextFactory");
   System.setProperty(Context.PROVIDER_URL, "localhost");
   Context ctx = new InitialContext();

   ITimerEJB timer = (ITimerEJB)ctx.lookup("TimerBean/remote");
   timer.startTimer("丁丁丁");
   timer.startTimer("丁丁丁"); //可以同时start多个
   
   try { Thread.sleep(10000);}//睡10秒，给它打印
   catch (InterruptedException e) {e.printStackTrace();}
   
   timer.stopTimer("丁丁丁");//让它停下来
	}
}

/* 
 这是个普通java工程
 添加 Timer 工程的支持，或者把 ITimerEJB 接口导进来
 导包：jbossall-client.jar
 
 把 Timer 工程发布到jboss后，启动jboss，再运行这个Test
 
 jboss控制台的打印结果(是jboss控制台，不是这程序的控制台)：
19:27:13,477 INFO  [STDOUT] 下课了...
19:27:13,511 INFO  [STDOUT] 下课了...
19:27:15,482 INFO  [STDOUT] 下课了...
19:27:15,518 INFO  [STDOUT] 下课了...
19:27:17,490 INFO  [STDOUT] 下课了...
19:27:17,528 INFO  [STDOUT] 下课了...
19:27:19,499 INFO  [STDOUT] 下课了...
19:27:19,530 INFO  [STDOUT] 下课了...
19:27:21,503 INFO  [STDOUT] 下课了...
19:27:21,538 INFO  [STDOUT] 下课了...

(可见，是每隔两秒打印一次，每次两个一起打印。10秒后停下)
 */
