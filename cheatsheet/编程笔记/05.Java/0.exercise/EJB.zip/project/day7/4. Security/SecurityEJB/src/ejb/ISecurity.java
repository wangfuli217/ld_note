package ejb;

import javax.ejb.Remote;

@Remote
public interface ISecurity {
	public void test1();
	public void test2();
	public void test3();
}
