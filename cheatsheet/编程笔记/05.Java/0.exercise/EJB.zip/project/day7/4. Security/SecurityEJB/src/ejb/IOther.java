package ejb;

public interface IOther {
	public void other();
}
