package ejb;

import javax.annotation.security.RolesAllowed;
import javax.ejb.Stateless;

@Stateless
@RolesAllowed("other")
public class OtherBean implements IOther {

	public void other() {
		System.out.println("other methed invoked....");
	}

}
