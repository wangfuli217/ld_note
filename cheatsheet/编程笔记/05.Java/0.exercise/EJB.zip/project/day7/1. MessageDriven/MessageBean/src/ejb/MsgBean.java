package ejb;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;
import javax.ejb.ActivationConfigProperty;
import javax.ejb.MessageDriven;
import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.MessageListener;
import javax.jms.TextMessage;

@MessageDriven(activationConfig={
	@ActivationConfigProperty(propertyName="destinationType", propertyValue="javax.jms.Topic")	
	,@ActivationConfigProperty(propertyName="destination", propertyValue="topic/tarenaTopic")	
	,@ActivationConfigProperty(propertyName="messageSelector", propertyValue="sender='YangGuo'") //不写这行则接收所有人的	
})
public class MsgBean implements MessageListener {
  //某人的私人助手，只是接收YangGuo发送的消息
	public void onMessage(Message msg) {
		if(msg instanceof TextMessage){
			TextMessage txtMsg = (TextMessage)msg;
			try {
				System.out.println(txtMsg.getText());
			} catch (JMSException e) {
				e.printStackTrace();
			}
		}
	}
	
	@PostConstruct 
	public void PostConstruct(){ //当然，这方法名可以任意改。
		System.out.println("PostConstruct...");
	}//当第一次需要接收信息时调用；如ZhouBoTong发信息时，不需它接收，不调用；YangGuo第一次发信息时就调用
	//@PostConstruct调用一次后，就一直等候，不会调用@PreDestroy来消除。除非关闭服务器或者销毁这个工程
	
	@PreDestroy
	public void PreDestroy(){
		System.out.println("PreDestroy...");
	} 

}

/*
 这是个EJB工程，需要发布到jboss
 导包 jbossall-client.jar
 
 启动jboss
 当YangGuo发送消息后
 jboss控制台打印：
19:46:46,506 INFO  [STDOUT] PostConstruct... //杨过第一次发信息时，以后再发，就没有这一行了
19:46:46,508 INFO  [STDOUT] 杨过说：大家好
 
 当ZhouBoTong发送消息后
 jboss控制台没有显示(可见，他的消息不接收) 

 */
