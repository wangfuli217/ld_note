package jms;

import javax.jms.Connection;
import javax.jms.ConnectionFactory;
import javax.jms.Destination;
import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.MessageConsumer;
import javax.jms.Session;
import javax.jms.TextMessage;
import javax.naming.Context;
import javax.naming.InitialContext;

//小龙女
public class XiaoLongNv {
	public static void main(String[] args){

	  Connection conn = null;
	  Session sess = null;
	  MessageConsumer mc = null;
	  
	  try {
		    //1.获得连接工厂 
		  System.setProperty(Context.INITIAL_CONTEXT_FACTORY, "org.jnp.interfaces.NamingContextFactory");
			System.setProperty(Context.PROVIDER_URL, "localhost");
			
			Context ctx = new InitialContext();
			ConnectionFactory cf = (ConnectionFactory)ctx.lookup("ConnectionFactory");
			
		      //2. 创建连接
		  conn = cf.createConnection();
		  
		     //3.创建会话   false表示不需要事务；Session.AUTO_ACKNOWLEDGE 自动确认收到消息
		  sess = conn.createSession(false, Session.AUTO_ACKNOWLEDGE);
		  
		     //4.获得目的地
		  Destination dest = (Destination)ctx.lookup("queue/tarenaQueue");
		  
		     //5. 创建消费者(消息接收者；跟杨过的相对) 
		  mc = sess.createConsumer(dest);
		  
		     //6.启动连接
		  conn.start();
		  
		     //7.接收消息 
		  Message msg = mc.receive();
		  
		      //8. 处理消息
		  if(msg instanceof TextMessage)
				System.out.println(((TextMessage)msg).getText());
		  
		     //9.最后关闭资源
	} catch (Exception e) { e.printStackTrace();
	} finally {
		 try {conn.close();} catch (JMSException e) {e.printStackTrace();}
		 try {sess.close();} catch (JMSException e) {e.printStackTrace();}
		 try { mc.close(); } catch (JMSException e) {e.printStackTrace();}
	}
     
	}
}
