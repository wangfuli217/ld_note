package ejb;

import javax.ejb.ActivationConfigProperty;
import javax.ejb.MessageDriven;
import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.MessageListener;
import javax.jms.TextMessage;

@MessageDriven(activationConfig={
	@ActivationConfigProperty(propertyName="destinationType", propertyValue="javax.jms.Queue")	
	,@ActivationConfigProperty(propertyName="destination", propertyValue="queue/tarenaQueue")	
	,@ActivationConfigProperty(propertyName="messageSelector", propertyValue="sender='YangGuo'")	
})
public class MsgBean implements MessageListener {
  // 某人的私人助手，只是接收YangGuo发送的消息
	public void onMessage(Message msg) {
		if(msg instanceof TextMessage){
			TextMessage txtMsg = (TextMessage)msg;
			try {
				System.out.println(txtMsg.getText());
			} catch (JMSException e) {
				e.printStackTrace();
			} 
		}
	}

}

/*
 这是老是有 javax.ejb.EJBTransactionRolledbackException 异常
 你能解决么？
 
 */
