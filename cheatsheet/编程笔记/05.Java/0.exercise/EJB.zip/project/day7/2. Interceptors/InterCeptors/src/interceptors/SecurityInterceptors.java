package interceptors;

import javax.interceptor.AroundInvoke;
import javax.interceptor.InvocationContext;

public class SecurityInterceptors {
	@AroundInvoke 
	public Object checkSecurtiy(InvocationContext ic) throws Exception{
		
		System.out.println("方法拦截器开始！！");
		Object obj = ic.proceed();		
		System.out.println("方法拦截器结束！！");
		
		return obj;
		
	}
}
