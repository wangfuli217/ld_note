package ejb;

import interceptors.SecurityInterceptors;
import interceptors.TransInterceptors;

import javax.ejb.Stateless;
import javax.interceptor.AroundInvoke;
import javax.interceptor.Interceptors;
import javax.interceptor.InvocationContext;

@Stateless
@Interceptors(TransInterceptors.class) //定义类拦截器
public class BankBean implements IBank {
	@AroundInvoke
	public Object selfInterceptors(InvocationContext ic) throws Exception{
		System.out.println("自我拦截器开始...");	
		Object obj = ic.proceed();		
		System.out.println("自我拦截器结束...");
		return obj;
	}

	public void deposit() {
		System.out.println("存入一百万大洋！");
	}

	public boolean transfer() {
		System.out.println("转账一百万！");
		return false;
	}

	@Interceptors(SecurityInterceptors.class)
	public void withdraw() {
		System.out.println("取出一百万零花钱！");
	}
	
}
