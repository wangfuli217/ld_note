package ejb;

import javax.ejb.Remote;

@Remote
public interface IBank {
	//存钱
	public void deposit();
	
	//取钱
	public void withdraw();
	
	//转账
	public boolean transfer(); 
}
