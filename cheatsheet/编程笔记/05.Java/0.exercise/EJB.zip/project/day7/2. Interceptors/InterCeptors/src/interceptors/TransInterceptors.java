package interceptors;

import javax.interceptor.AroundInvoke;
import javax.interceptor.InvocationContext;

public class TransInterceptors {
	
	@AroundInvoke
	public Object transDeal(InvocationContext ic) throws Exception{
		
		System.out.println("类拦截器开始！！");		
		Object obj = ic.proceed();		
		System.out.println("类拦截器结束！！");
		
		return obj;
	}
}
