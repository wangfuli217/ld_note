package interceptors;

import javax.interceptor.AroundInvoke;
import javax.interceptor.InvocationContext;

public class LogInterceptors {
	
	@AroundInvoke 
	public Object log(InvocationContext ic) throws Exception{
		System.out.println("缺省拦截器开始...   Method="+ic.getMethod().getName());
		Object obj = ic.proceed();
		//Object[] objs = ic.getParameters();//获得业务方法参数
		System.out.println("缺省拦截器结束...   Method="+ic.getMethod().getName());
		System.out.println();
		return obj;
	} //用作记录业务日志
}
