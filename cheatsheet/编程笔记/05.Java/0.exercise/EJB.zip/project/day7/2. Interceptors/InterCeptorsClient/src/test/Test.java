package test;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;

import ejb.IBank;

public class Test {

	public static void main(String[] args) throws NamingException{
		/*System.setProperty(Context.INITIAL_CONTEXT_FACTORY, org.jnp.interfaces.NamingContextFactory.class.getName());
		System.setProperty(Context.PROVIDER_URL, "jnp://localhost:1099");*/
		System.setProperty(Context.INITIAL_CONTEXT_FACTORY,"org.jnp.interfaces.NamingContextFactory");
		System.setProperty(Context.PROVIDER_URL, "localhost");
		
		Context ctx  = new InitialContext();
		IBank bank = (IBank)ctx.lookup("BankBean/remote");
		
		bank.withdraw();//多一个方法拦截器
		bank.deposit();
	 //bank.transfer(); //写太多难看
	}

}

/*
 这是个普通java工程
 添加 InterCeptors工程的支持，或者导入那工程的接口的jar包
 导包：jbossall-client.jar
 
 InterCeptors工程是个EJB工程，需发布到jboss中
 启动jboss后，jboss控制台打印结果：
 
21:28:01,499 INFO  [STDOUT] 缺省拦截器开始...   Method=withdraw
21:28:01,500 INFO  [STDOUT] 类拦截器开始！！
21:28:01,500 INFO  [STDOUT] 方法拦截器开始！！
21:28:01,500 INFO  [STDOUT] 自我拦截器开始...
21:28:01,501 INFO  [STDOUT] 取出一百万零花钱！
21:28:01,501 INFO  [STDOUT] 自我拦截器结束...
21:28:01,501 INFO  [STDOUT] 方法拦截器结束！！
21:28:01,501 INFO  [STDOUT] 类拦截器结束！！
21:28:01,501 INFO  [STDOUT] 缺省拦截器结束...   Method=withdraw

21:28:01,526 INFO  [STDOUT] 缺省拦截器开始...   Method=deposit
21:28:01,526 INFO  [STDOUT] 类拦截器开始！！
21:28:01,526 INFO  [STDOUT] 自我拦截器开始...
21:28:01,527 INFO  [STDOUT] 存入一百万大洋！
21:28:01,527 INFO  [STDOUT] 自我拦截器结束...
21:28:01,527 INFO  [STDOUT] 类拦截器结束！！
21:28:01,527 INFO  [STDOUT] 缺省拦截器结束...   Method=deposit 
 
 */
