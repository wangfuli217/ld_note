package entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity //这个标注表明他是pojo类
@Table(name="t_film") //对应的表名；可以不写
public class Film{
 
	@Id //表明他是id；要求一定要有ID
	@GeneratedValue //指定需要框架自动产生主键
	@Column(name="id") //表中的字段名，不写则跟属性名一样(大小写也一样)
	private int id;
	
	@Column(name="film_name")
 private	String filmName;	//电影名称
 
 @Column(name="film_type")
 private	String filmType;		//类型
 private	String actor;		//主要演员
 private	String country;		//发行国家
 
 
public int getId() {return id;}
public void setId(int id) {this.id = id;}

public String getFilmName() {return filmName;}
public void setFilmName(String filmName) {this.filmName = filmName;}

public String getFilmType() {return filmType;}
public void setFilmType(String filmType) {this.filmType = filmType;}

public String getActor() {return actor;}
public void setActor(String actor) {this.actor = actor;}

public String getCountry() {return country;}
public void setCountry(String country) {this.country = country;}

 
}

//可以把所有的标注放到 orm.xml(它需要放到META-INF目录下)