package test;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import entity.Film;

public class Test {
	public static void main(String [] args){
	//1.创建实体管理器工厂
	EntityManagerFactory emf = Persistence.createEntityManagerFactory("FilmPU");
	
	//创建实体管理器
	EntityManager em= emf.createEntityManager();
	
	//创建实体对象
	Film film = new Film();
	film.setFilmName("非诚勿扰");
	film.setFilmType("戏剧");
	film.setActor("葛优");
	film.setCountry("中国");
	
	//开启事务，提交数据
	em.getTransaction().begin();
	em.persist(film);
	em.getTransaction().commit();
	
	System.out.println("添加成功");
	}
}

/*
导包：mysql驱动
PP(持久化提供者)的包：HibernateJPA
 这是一个ejb工程，发布在jboss里
 打印：
 
log4j:WARN No appenders could be found for logger (org.hibernate.ejb.Version).
log4j:WARN Please initialize the log4j system properly.

Hibernate: insert into t_film (filmName, filmType, actor, country) values (?, ?, ?, ?)
添加成功
 */
