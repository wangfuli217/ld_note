package object;

//ά��һЩ����
public class Constants {
	public static final String JNDI_CART_BEAN="CartBean/remote";
}
