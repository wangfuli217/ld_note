package util;

import javax.naming.Context;
import javax.naming.InitialContext;

//ʹ��singletonģʽ��ƻ�ȡJNDI�����ĵĹ�����
public class ContextUtil {
	private static Context ctx;

	private ContextUtil() {

	}

	public static Context getContext() {
		try {
			if (ctx==null) {
				System.setProperty(Context.INITIAL_CONTEXT_FACTORY,
						"org.jnp.interfaces.NamingContextFactory");
				System.setProperty(Context.PROVIDER_URL, "localhost");

				ctx = new InitialContext();
			}
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("get InitialContext error!!");
		}
		return ctx;
	}
}
