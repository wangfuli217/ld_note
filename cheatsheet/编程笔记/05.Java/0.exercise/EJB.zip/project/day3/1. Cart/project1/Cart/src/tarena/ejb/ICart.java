package tarena.ejb;

import java.util.List;

import javax.ejb.Remote;

import tarena.vo.Order;
import tarena.vo.ProductItem;

@Remote
public interface ICart {
	public void addProduct(ProductItem p);
	public void saveToOrder(Order o);
	public List<ProductItem> getProduct();
}
