package ejb;

import java.sql.Connection;
import java.sql.PreparedStatement;

import javax.annotation.Resource;
import javax.ejb.Stateless;
import javax.sql.DataSource;

import vo.ProductItem;

@Stateless
public class ProductItemDaoBean implements IProductItemDao {
	@Resource(mappedName="java:/tarena")
	DataSource ds;
	
	public void addProductItem(ProductItem item) {
		Connection conn = null;
		PreparedStatement pst = null;
		
		try{
			conn = ds.getConnection();
			String sql = "insert into productitem(name,amount,price) values(?,?,?)";
			pst = conn.prepareStatement(sql);
			
			pst.setString(1, item.getName());
			pst.setInt(2, item.getAmount());
			pst.setFloat(3, item.getPrice());
			
			pst.execute();
		}catch(Exception e){
			e.printStackTrace();
		}finally{
			try{
				conn.close();
			}catch(Exception e1){}
			try{
				pst.close();
			}catch(Exception e1){}
		}
	}

}
