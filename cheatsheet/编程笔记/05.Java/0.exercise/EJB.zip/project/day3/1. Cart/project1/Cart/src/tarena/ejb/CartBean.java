package tarena.ejb;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;
import javax.ejb.Stateful;
import javax.sql.DataSource;

import tarena.dao.IOrderDao;
import tarena.dao.IProductItemDao;
import tarena.dao.OrderDaoImpl;
import tarena.dao.ProductItemDaoImpl;
import tarena.vo.Order;
import tarena.vo.ProductItem;

@Stateful
//@CacheConfig(maxSize = 2, idleTimeoutSeconds = 1)
public class CartBean implements ICart {

	// 购物篮中选购商品
	List<ProductItem> list = new ArrayList<ProductItem>();

	// 注入数据源
	@Resource(mappedName = "java:/tarena")
	DataSource ds;

	//订单dao
	IOrderDao orderDao = new OrderDaoImpl();

	//订单商品明细Dao
	IProductItemDao itemDao = new ProductItemDaoImpl();

	//为dao注入数据源
	@PostConstruct
	public void PostConstruct() {
		orderDao.setDs(ds);
		itemDao.setDs(ds);
	}

	//添加商品到购物车
	public void addProduct(ProductItem p) {
		list.add(p);

	}

	//生成订单记录
	public void saveToOrder(Order o) {
		//插入订单记录
		orderDao.addOrder(o);
		
		//插入商品明显订单记录
		for (ProductItem item : list) {
			itemDao.addProductItem(item);
		}
		
		//清空购物车
		list.clear();

	}

	//获得购物篮中所有选购商品
	public List<ProductItem> getProduct() {
		return list;
	}
}
