package tarena.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;

import javax.sql.DataSource;

import tarena.vo.Order;

public class OrderDaoImpl implements IOrderDao {

	private DataSource ds;

	public void setDs(DataSource ds) {
		this.ds = ds;
	}

	public void addOrder(Order order) {
		Connection conn = null;
		PreparedStatement ps = null;

		try {
			conn = ds.getConnection();

			String sql = "insert into torder(client,orderno,orderdate) values(?,?,?)";
			ps = conn.prepareStatement(sql);

			ps.setString(1, order.getClient());
			ps.setString(2, order.getOrderNo());
			ps.setString(3, order.getOrderDate());
			
			ps.execute();

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				ps.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
			try {
				conn.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}
}
