package ejb;

import vo.ProductItem;

public interface IProductItemDao {
	public void addProductItem(ProductItem item);
}
