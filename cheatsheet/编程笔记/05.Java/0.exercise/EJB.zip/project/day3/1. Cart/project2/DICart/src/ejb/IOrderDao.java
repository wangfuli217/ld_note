package ejb;
import vo.Order;

public interface IOrderDao {
	public void addOrder(Order order);
}
