package action;

import javax.ejb.NoSuchEJBException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import object.Constants;

import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import vo.Order;
import vo.ProductItem;
import ejb.ICart;
import form.CartForm;

public class CartAction extends BaseAction {
	
	//ģ������ݿ����id��ѯ��Ʒ
	private ProductItem getProduct(String id){
		ProductItem item = new ProductItem();
		if(id.equals("1")){
			item.setId(1);
			item.setName("MP3");
			item.setAmount(1);
			item.setPrice(100f);
		}else if(id.equals("2")){
			item.setId(2);
			item.setName("MP4");
			item.setAmount(1);
			item.setPrice(300f);
		}else if(id.equals("3")){
			item.setId(2);
			item.setName("�������");
			item.setAmount(1);
			item.setPrice(2000f);
		}
		
		return item;
	}
	
	public ActionForward addProduct(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response)throws Exception{
		//���Զ�̴���
		HttpSession session = request.getSession();
		ICart cart = (ICart)session.getAttribute("cartBean");
		if(cart==null){
			cart = (ICart)getContext().lookup(Constants.JNDI_CART_BEAN);
			session.setAttribute("cartBean", cart);
		}
		
		//���ݲ�Ʒid��ò�Ʒ
		String productId = request.getParameter("id");
		ProductItem product = getProduct(productId);
		
		try{
			cart.addProduct(product);
		}catch(NoSuchEJBException e){
			//Զ�̵�EJB�������²����Ժ󣬻�����µ�Skeleton
			//�þɵ�stub�޷����µ�Skeletonͨ��
			
			e.printStackTrace();
			session.removeAttribute("cartBean");
			
			return mapping.findForward("error");
		}
		
		//�Ѳ�Ʒ���õ�request������
		try{
			request.setAttribute("products", cart.getProducts());
		}catch(NoSuchEJBException e){
			//Զ�̵�EJB�������²����Ժ󣬻�����µ�Skeleton
			//�þɵ�stub�޷����µ�Skeletonͨ��
			
			e.printStackTrace();
			session.removeAttribute("cartBean");
			
			return mapping.findForward("error");
		}
		
		return mapping.findForward("success");
	}
	
	public ActionForward placeOrder(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response)throws Exception{
		//���Զ�̴���
		HttpSession session = request.getSession();
		ICart cart = (ICart)session.getAttribute("cartBean");
		if(cart==null){
			cart = (ICart)getContext().lookup(Constants.JNDI_CART_BEAN);
			session.setAttribute("cartBean", cart);
		}
		
		//�Ѳ�Ʒ���õ�request������
		try{
			request.setAttribute("products", cart.getProducts());
		}catch(NoSuchEJBException e){
			//Զ�̵�EJB�������²����Ժ󣬻�����µ�Skeleton
			//�þɵ�stub�޷����µ�Skeletonͨ��
			
			e.printStackTrace();
			session.removeAttribute("cartBean");
			
			return mapping.findForward("error");
		}
		return mapping.findForward("placeOrder");
	}
	
	public ActionForward saveToOrder(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response)throws Exception{
		//���Զ�̴���
		HttpSession session = request.getSession();
		ICart cart = (ICart)session.getAttribute("cartBean");
		if(cart==null){
			cart = (ICart)getContext().lookup(Constants.JNDI_CART_BEAN);
			session.setAttribute("cartBean", cart);
		}
		
		//��form���ݷ�װ��DTO
		CartForm cartForm = (CartForm)form;
		Order order = new Order();
		order.setClient(cartForm.getClient());
		order.setOrderNo(cartForm.getOrderNo());
		order.setOrderDate(cartForm.getOrderDate());
		
		try{
			cart.saveToOrder(order);
		}catch(NoSuchEJBException e){
			e.printStackTrace();
			session.removeAttribute("cartBean");
			
			return mapping.findForward("error");
		}
		
		return mapping.findForward("orderSuccess");
	}
}
