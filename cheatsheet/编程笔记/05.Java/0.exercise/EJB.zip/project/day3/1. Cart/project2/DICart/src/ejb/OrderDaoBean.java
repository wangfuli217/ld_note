package ejb;

import java.sql.Connection;
import java.sql.PreparedStatement;

import javax.annotation.Resource;
import javax.ejb.Stateless;
import javax.sql.DataSource;

import vo.Order;

@Stateless
public class OrderDaoBean implements IOrderDao {
	@Resource(mappedName="java:/tarena")
	DataSource ds;
	
	public void addOrder(Order order) {
		Connection conn = null;
		PreparedStatement pst = null;
		
		try{
			conn = ds.getConnection();
			String sql = "insert into torder(client,orderno,orderdate) values(?,?,?)";
			pst = conn.prepareStatement(sql);
			
			pst.setString(1, order.getClient());
			pst.setString(2, order.getOrderNo());
			pst.setString(3, order.getOrderDate());
			
			pst.execute();
		}catch(Exception e){
			e.printStackTrace();
		}finally{
			try{
				conn.close();
			}catch(Exception e1){}
			try{
				pst.close();
			}catch(Exception e1){}
		}
	}

}
