package tarena.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;

import javax.sql.DataSource;

import tarena.vo.ProductItem;

public class ProductItemDaoImpl implements IProductItemDao {

	private DataSource ds;

	public void setDs(DataSource ds) {
		this.ds = ds;
	}

	public void addProductItem(ProductItem item) {
		Connection conn = null;
		PreparedStatement ps = null;

		try {
			conn = ds.getConnection();

			String sql = "insert into productitem(name,amount,price) values(?,?,?)";
			ps = conn.prepareStatement(sql);
			
			ps.setString(1, item.getName());
			ps.setInt(2, item.getAmount());
			ps.setFloat(3, item.getPrice());
			

			ps.execute();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				ps.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
			try {
				conn.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}

	}

}
