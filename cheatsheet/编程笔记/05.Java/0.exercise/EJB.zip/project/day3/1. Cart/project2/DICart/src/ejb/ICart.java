package ejb;

import java.util.List;

import javax.ejb.Remote;

import vo.Order;
import vo.ProductItem;

@Remote
public interface ICart {
	public void addProduct(ProductItem item);
	public List<ProductItem> getProducts();
	public void saveToOrder(Order order);
}
