package tarena.objects;

public class Constants {
	public static final String EJBJNDI_CARTBEAN="CartBean/remote";
}
