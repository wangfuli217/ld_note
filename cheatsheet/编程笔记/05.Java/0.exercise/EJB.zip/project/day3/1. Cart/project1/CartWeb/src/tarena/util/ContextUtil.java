package tarena.util;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;

public class ContextUtil {
	private static Context ctx;

	public static Context getContext() {
		if (ctx == null) {
			try {
				System.setProperty("java.naming.factory.initial",
						"org.jnp.interfaces.NamingContextFactory");
				System.setProperty("java.naming.provider.url",
						"jnp://localhost");
				ctx = new InitialContext();
			} catch (NamingException e) {
				e.printStackTrace();
				System.out.println("%=== Error Initial Context======%");
			}
		}
		return ctx;
	}
}
