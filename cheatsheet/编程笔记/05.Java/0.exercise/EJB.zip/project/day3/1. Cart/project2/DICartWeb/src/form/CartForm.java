package form;

import org.apache.struts.action.ActionForm;

@SuppressWarnings("serial")
public class CartForm extends ActionForm {
	private String client;
	private String orderNo;
	private String orderDate;

	public String getClient() {
		return client;
	}
	public void setClient(String client) {
		this.client = client;
	}
	public String getOrderNo() {
		return orderNo;
	}
	public void setOrderNo(String orderNo) {
		this.orderNo = orderNo;
	}
	public String getOrderDate() {
		return orderDate;
	}
	public void setOrderDate(String orderDate) {
		this.orderDate = orderDate;
	}

}
