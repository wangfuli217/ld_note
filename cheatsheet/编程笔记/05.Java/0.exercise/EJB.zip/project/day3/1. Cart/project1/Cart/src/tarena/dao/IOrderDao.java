package tarena.dao;

import javax.sql.DataSource;

import tarena.vo.Order;
public interface IOrderDao {
	public void addOrder(Order order);
	
	public void setDs(DataSource ds);
}
