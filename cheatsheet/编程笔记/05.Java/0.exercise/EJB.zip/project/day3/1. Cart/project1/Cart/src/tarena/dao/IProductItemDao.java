package tarena.dao;

import javax.sql.DataSource;

import tarena.vo.ProductItem;

public interface IProductItemDao {
	public void addProductItem(ProductItem item);
	
	public void setDs(DataSource ds);
}
