package entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "t_film")
public class Film implements Serializable {
	@Id
	@GeneratedValue
	@Column(name = "id")
	private int id;

	private String filmName;
	private String filmType;
	private String actors;

	public int getId() {	return id;	}
	public void setId(int id) {this.id = id;}

	public String getFilmName() {return filmName;}
	public void setFilmName(String filmName) {this.filmName = filmName;	}

	public String getFilmType() {return filmType;}
	public void setFilmType(String filmType) {this.filmType = filmType;}

	public String getActors() {return actors;}
	public void setActors(String actors) {this.actors = actors;}

}
