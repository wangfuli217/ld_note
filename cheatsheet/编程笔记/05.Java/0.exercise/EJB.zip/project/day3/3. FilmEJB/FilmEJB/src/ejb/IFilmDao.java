package ejb;

import javax.ejb.Remote;

import entity.Film;

@Remote
public interface IFilmDao {
	public void addFilm(Film film);
}
