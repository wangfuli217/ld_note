package ejb;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import entity.Film;

@Stateless
public class FilmDaoBean implements IFilmDao {
	@PersistenceContext(unitName="FilmPU") //unitName 可写可不写
	private EntityManager em;

	public void addFilm(Film film) {
		em.persist(film);
	}

}
