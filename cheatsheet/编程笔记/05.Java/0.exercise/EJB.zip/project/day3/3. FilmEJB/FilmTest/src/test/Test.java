package test;

import javax.naming.Context;
import javax.naming.InitialContext;

import ejb.IFilmDao;
import entity.Film;

public class Test {

	public static void main(String[] args) throws Exception{

		System.setProperty(Context.INITIAL_CONTEXT_FACTORY, "org.jnp.interfaces.NamingContextFactory");
		System.setProperty(Context.PROVIDER_URL, "localhost");
		Context ctx = new InitialContext();
		
		IFilmDao dao = (IFilmDao)ctx.lookup("FilmDaoBean/remote");
		
		Film film = new Film();
		film.setFilmName("非诚勿扰");
		film.setFilmType("喜剧片");
		film.setActors("葛优，舒琪");
		
		dao.addFilm(film);
		
	}
}

/*
这是个普通java工程；
导包：jbossall-client.jar
添加 FilmEJB 工程的支持，或者导入 IFilmDao接口和entity.Film 的jar包

把 mysql-ds.xml配置正确(url,username,password)；放到 %jboss_home%/server/default/deploy/
把 mysql驱动程序放到： %jboss_home%/server/default/lib/
mysql数据库需 create database jpa;

被调用的 FilmEJB 是个ejb 工程。 发布它，并启动 jboss (它自身有HibernateJPA的支持)
发布 FilmEJB 时，它会自动去数据库建表 t_film (数据库操作都由服务器完成) 

运行结果：
15:58:02,180 INFO  [STDOUT] Hibernate: insert into t_film (filmName, filmType, actors) values (?, ?, ?)

mysql数据库里：
mysql> select * from t_film;
+----+--------------+-----------+-----------------+
| id | filmName     | filmType  | actors          |
+----+--------------+-----------+-----------------+
|  1 | 非诚勿扰     | 喜剧片    | 葛优，舒琪      | 
+----+--------------+-----------+-----------------+
1 row in set (0.00 sec)

jboss的控制台打印：
log4j:WARN No appenders could be found for logger (org.jboss.security.SecurityAssociation).
log4j:WARN Please initialize the log4j system properly.

*/