package test;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import entity.Account;;

public class Test {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("idPU");
		EntityManager em = emf.createEntityManager();
		
		em.getTransaction().begin();
		Account a = new Account();
		a.setBalanceNo("A100000");
		a.setBalance(10000000);
		
		em.persist(a);
		
		em.getTransaction().commit();
	}

}
