package Entity;

import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.PostPersist;
import javax.persistence.PrePersist;

@Entity
@EntityListeners(Callback.class) //指定一个独立的回调类。与会话Bean相似，只是它用 @Interceptors
public class Account {
	
	@PrePersist  //insert into SQL执行之前调用
	public void prePersist(){
		System.out.println("@PrePersest回调方法被调用");
	}
	
	@PostPersist  //insert into SQL执行之后调用
	public void postPersist(){
		System.out.println("@PostPersist回调方法被调用");
	}
	
	
	@Id
	@GeneratedValue
	private int id;
	private int balanceNo;  //帐户编号
	private String balanceName; //用户名称
	
	
	public int getId() {	return id;	}
	public void setId(int id) {	this.id = id;	}
	
	public int getBalanceNo() {return balanceNo;	}
	public void setBalanceNo(int balanceNo) {this.balanceNo = balanceNo;	}

	public String getBalanceName() {return balanceName;}
	public void setBalanceName(String balanceName) {this.balanceName = balanceName;	}
	
	

}
