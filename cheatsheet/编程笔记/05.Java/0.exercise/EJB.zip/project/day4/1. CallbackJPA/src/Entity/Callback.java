package Entity;

import javax.persistence.PostLoad;
import javax.persistence.PostRemove;
import javax.persistence.PostUpdate;
import javax.persistence.PreRemove;
import javax.persistence.PreUpdate;

public class Callback {
	
	@PreUpdate  //update sql执行之前调用
	public void preUpdate(Object obj){
		System.out.println("invoked before update:" + 
				obj.getClass().getName()+" @PreUpdate 被回调");
	}
	
	@PostUpdate //update sql执行之后调用
	public void postUpdate(Object obj){
		System.out.println("invoked after update:" + 
				obj.getClass().getName()+" @PostUpdate 被回调");
	}
	
	@PreRemove
	public void preRemove(Object obj){
		System.out.println("invoked before remove:" + 
				obj.getClass().getName()+" @PreRemove 被回调");
	}
	
	@PostRemove
	public void postRemove(Object obj){
		System.out.println("invoked after remove:" + 
				obj.getClass().getName()+" @PostRemove 被回调");
	}
	
	@PostLoad  //加载实体之后，select 之后调用。这个没有 pre 方法
	public void postLoad(Object obj){
		System.out.println("invoked after select!");
	}

}
