package test;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import Entity.Account;

public class Test {

	public static void main(String[] args) {
		//第一步创建实体管理器工厂
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("CallbackPU");
		
		//创建实体管理器
		EntityManager em = emf.createEntityManager();
		
		//持久化对象，测试insert sql的回调方法
		em.getTransaction().begin();
		Account a = new Account();
		a.setBalanceNo(100000);
		a.setBalanceName("yourl");
		em.persist(a);
		em.getTransaction().commit();
		
		//更新对象， 测试update sql的回调方法
		em.getTransaction().begin();
		a.setBalanceName("tarena");
		em.getTransaction().commit();
		
		//加载对象， 测试select sql的回调方法
		em.clear();
		a = em.find(Account.class, 5);
		
		//删除对象，测试remove sql的回调方法
		em.getTransaction().begin();
		em.remove(a);
		em.getTransaction().commit();
		
		em.close();

	}

}

/*
 导包：数据库驱动包;  PP(持久化提供者)的包
 
 打印结果：
log4j:WARN No appenders could be found for logger (org.hibernate.ejb.Version).
log4j:WARN Please initialize the log4j system properly.
@PrePersest回调方法被调用
Hibernate: insert into Account (balanceNo, balanceName) values (?, ?)
@PostPersist回调方法被调用
invoked before update:Entity.Account @PreUpdate 被回调
Hibernate: update Account set balanceNo=?, balanceName=? where id=?
invoked after update:Entity.Account @PostUpdate 被回调
Hibernate: select account0_.id as id0_0_, account0_.balanceNo as balanceNo0_0_, account0_.balanceName as balanceN3_0_0_ from Account account0_ where account0_.id=?
invoked after select!
invoked before remove:Entity.Account @PreRemove 被回调
Hibernate: delete from Account where id=?
invoked after remove:Entity.Account @PostRemove 被回调

 
 */
