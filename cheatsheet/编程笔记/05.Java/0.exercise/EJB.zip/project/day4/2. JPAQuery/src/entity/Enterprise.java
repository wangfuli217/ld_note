package entity;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.NamedNativeQuery;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Transient;

//根据该实体类编写回调程序，使用独立的回调类
@Entity
@NamedQuery(name="查询名", query="from Enterprise where id=:id") //也可用 id=?2 的形式
@NamedNativeQuery(name="本地名", query="select * from aa",resultClass=Enterprise.class)
@Table(name="aa")
public class Enterprise {
	
	@Id
	@GeneratedValue
	private int id;
	
	private String name;// 公司名称	
	private String shortName;// 公司简称	
	private String Address;// 公司地址	
	private String qulity;// 公司性质	
	private String vocation;// 所属行业	
	private String scale;// 规模	
	private Date regsiterDate;// 注册日期
	
	@Transient //短暂的；不持久化到数据库
	private String color;// 颜色, 列表交替显示不同颜色,

	public String getName() {	return name;	}
	public void setName(String name) {	this.name = name;}

	public String getShortName() {return shortName;}
	public void setShortName(String shortName) {this.shortName = shortName;}

	public String getAddress() {return Address;}
	public void setAddress(String Address) {	this.Address = Address;	}

	public String getQulity() {return qulity;}
	public void setQulity(String qulity) {this.qulity = qulity;}

	public String getVocation() {return vocation;}
	public void setVocation(String vocation) {this.vocation = vocation;}

	public String getScale() {return scale;}
	public void setScale(String scale) {this.scale = scale;}

	public Date getRegsiterDate() {	return regsiterDate;}
	public void setRegsiterDate(Date regsiterDate) {this.regsiterDate = regsiterDate;}

	public String getColor() {return color;}
	public void setColor(String color) {this.color = color;}

	public int getId() {return id;}
	public void setId(int id) {this.id = id;	}

}
