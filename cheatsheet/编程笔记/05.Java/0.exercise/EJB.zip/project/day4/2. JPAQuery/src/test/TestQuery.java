package test;

import java.util.List;

import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import entity.Enterprise;

public class TestQuery {

	public static void main(String[] args) {
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("QueryPU");
		javax.persistence.EntityManager em = emf.createEntityManager();
		
		//普通查詢
		javax.persistence.Query query = em.createQuery("select 别名 from Enterprise 别名");
		//query = em.createQuery("from Enterprise"); //这样也行
		List<Enterprise> list = query.getResultList();
		for(Enterprise ep : list){
			System.out.println("企業名稱:" + ep.getName());
			System.out.println("公司地址:" + ep.getAddress());
			System.out.println("行業:" + ep.getQulity());
		}
		
		System.out.println();
		System.out.println("本地查詢....");
		query = em.createNativeQuery("select * from aa", Enterprise.class);
		list = query.getResultList();
		for(Enterprise ep : list){
			System.out.println("企業名稱:" + ep.getName());
			System.out.println("公司地址:" + ep.getAddress());
			System.out.println("行業:" + ep.getQulity());
		}
		
		System.out.println();
		System.out.println("命名查詢....");
		query = em.createNamedQuery("查询名");
		query.setParameter("id", 2);
		//query.setParameter(2, 2);
		list = query.getResultList();
		for(Enterprise ep : list){
			System.out.println("企業名稱:" + ep.getName());
			System.out.println("公司地址:" + ep.getAddress());
			System.out.println("行業:" + ep.getQulity());
		}
		
		
		System.out.println();
		System.out.println("本地命名查詢....");
		query = em.createNamedQuery("本地名");
		list = query.getResultList();
		for(Enterprise ep : list){
			System.out.println("企業名稱:" + ep.getName());
			System.out.println("公司地址:" + ep.getAddress());
			System.out.println("行業:" + ep.getQulity());
		}
		
		em.close();
	}

}


/* 
打印结果：

log4j:WARN No appenders could be found for logger (org.hibernate.ejb.Version).
log4j:WARN Please initialize the log4j system properly.
Hibernate: select enterprise0_.id as id0_, enterprise0_.name as name0_, enterprise0_.shortName as shortName0_, enterprise0_.Address as Address0_, enterprise0_.qulity as qulity0_, enterprise0_.vocation as vocation0_, enterprise0_.scale as scale0_, enterprise0_.regsiterDate as regsiter8_0_ from aa enterprise0_
企業名稱:IBM
公司地址:天河北路大都會廣場
行業:null
企業名稱:Microsoft
公司地址:天河北路中心廣場
行業:IT行業

本地查詢....
Hibernate: select * from aa
企業名稱:IBM
公司地址:天河北路大都會廣場
行業:null
企業名稱:Microsoft
公司地址:天河北路中心廣場
行業:IT行業

命名查詢....
Hibernate: select enterprise0_.id as id0_, enterprise0_.name as name0_, enterprise0_.shortName as shortName0_, enterprise0_.Address as Address0_, enterprise0_.qulity as qulity0_, enterprise0_.vocation as vocation0_, enterprise0_.scale as scale0_, enterprise0_.regsiterDate as regsiter8_0_ from aa enterprise0_ where enterprise0_.id=?
企業名稱:Microsoft
公司地址:天河北路中心廣場
行業:IT行業

本地命名查詢....
Hibernate: select * from aa
企業名稱:IBM
公司地址:天河北路大都會廣場
行業:null
企業名稱:Microsoft
公司地址:天河北路中心廣場
行業:IT行業

*/