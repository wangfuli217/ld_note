package test;

import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import entity.Enterprise;

public class Test {

	public static void main(String[] args) {
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("QueryPU");
		
		javax.persistence.EntityManager em = emf.createEntityManager();
		
		em.getTransaction().begin();
		Enterprise ep1 = new Enterprise();
		ep1.setName("IBM");
		ep1.setAddress("天河北路大都會廣場");
		ep1.setColor("紅色");
		ep1.setScale("200");
		em.persist(ep1);
		
		Enterprise ep2 = new Enterprise();
		ep2.setName("Microsoft");
		ep2.setAddress("天河北路中心廣場");
		ep2.setQulity("IT行業");
		em.persist(ep2);
		
		em.getTransaction().commit();		
		em.close();
	}

}
