package test;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;

import entity.Enterprise;

public class TestParameterQuery {
	public static void main(String[] args){
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("QueryPU");
		EntityManager em = emf.createEntityManager();
		
		//问号的下标顺序
		String ql = "select u from Enterprise u where id=? and name=?";
		Query query = em.createQuery(ql);
		query.setParameter(1, 1);
		query.setParameter(2, "IBM");
		Enterprise ep = (Enterprise)query.getSingleResult();
		System.out.println(ep.getName());
		
		//问号的下标顺序
		ql = "select u from Enterprise u where id=?2 and name=?1";
		query = em.createQuery(ql);
		query.setParameter(2, 1);
		query.setParameter(1, "IBM");
		ep = (Enterprise)query.getSingleResult();
		System.out.println(ep.getName());
		
		
		//命名参数
		ql = "select u from Enterprise u where name=:name and id=:id";
		query = em.createQuery(ql);
		query.setParameter("name", "IBM");
		query.setParameter("id", 1);
		ep = (Enterprise)query.getSingleResult();
		System.out.println(ep.getName());
		
	}
	
}

/*
打印结果：

log4j:WARN No appenders could be found for logger (org.hibernate.ejb.Version).
log4j:WARN Please initialize the log4j system properly.
Hibernate: select enterprise0_.id as id0_, enterprise0_.name as name0_, enterprise0_.shortName as shortName0_, enterprise0_.Address as Address0_, enterprise0_.qulity as qulity0_, enterprise0_.vocation as vocation0_, enterprise0_.scale as scale0_, enterprise0_.regsiterDate as regsiter8_0_ from aa enterprise0_ where enterprise0_.id=? and enterprise0_.name=?
IBM
Hibernate: select enterprise0_.id as id0_, enterprise0_.name as name0_, enterprise0_.shortName as shortName0_, enterprise0_.Address as Address0_, enterprise0_.qulity as qulity0_, enterprise0_.vocation as vocation0_, enterprise0_.scale as scale0_, enterprise0_.regsiterDate as regsiter8_0_ from aa enterprise0_ where enterprise0_.id=? and enterprise0_.name=?
IBM
Hibernate: select enterprise0_.id as id0_, enterprise0_.name as name0_, enterprise0_.shortName as shortName0_, enterprise0_.Address as Address0_, enterprise0_.qulity as qulity0_, enterprise0_.vocation as vocation0_, enterprise0_.scale as scale0_, enterprise0_.regsiterDate as regsiter8_0_ from aa enterprise0_ where enterprise0_.name=? and enterprise0_.id=?
IBM

*/