package test;

import java.io.FileOutputStream;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import entity.Student;

public class TestReadPic {

	public static void main(String[] args) throws Exception{
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("metaPU");
		EntityManager em = emf.createEntityManager();
		
		Student st = em.find(Student.class, 1);
		System.out.println(st.getId());
		System.out.println(st.getName());
		
		byte[] pic = st.getPic();
		FileOutputStream fos = new FileOutputStream("/home/sd0807/ldh.jpg");
		fos.write(pic);
		fos.flush();
		fos.close();
		
	}

}

/*
先运行 Test 插入数据和图片

打印结果：
log4j:WARN No appenders could be found for logger (org.hibernate.ejb.Version).
log4j:WARN Please initialize the log4j system properly.
Hibernate: select student0_.id as id0_0_, student0_.name as name0_0_, student0_.age as age0_0_, student0_.pic as pic0_0_ from Student student0_ where student0_.id=?
1
猫猫

生成文件： /home/sd0807/ldh.jpg

*/