package test;

import java.io.FileInputStream;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import entity.Student;

public class Test {

	public static void main(String[] args) throws Exception{
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("metaPU");
		EntityManager em = emf.createEntityManager();
		
		em.getTransaction().begin();
		Student st = new Student();
		st.setName("猫猫");
		st.setAge(48);
		
		FileInputStream fis = new FileInputStream("/home/sd0807/photo.jpg");
		byte[] pic = new byte[fis.available()];
		fis.read(pic);
		
		st.setPic(pic);
		fis.close();
		
		em.persist(st);
				
		em.getTransaction().commit();
	}

}

/*
 导包： 数据库驱动包;  和   PP(持久化提供者)的包
 先放文件：/home/sd0807/photo.jpg
 运行后把这文件插进数据库 
 */

