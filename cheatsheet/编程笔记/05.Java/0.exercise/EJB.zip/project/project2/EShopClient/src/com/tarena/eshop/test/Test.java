package com.tarena.eshop.test;
/**
 * �����̳ǲ�������
 */
import java.util.List;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;

import com.tarena.eshop.bean.IProduct;
import com.tarena.eshop.entity.Product;

public class Test {
	public static void main(String[] args) throws NamingException {
		Context ctx = new InitialContext();
		IProduct product = (IProduct)ctx.lookup("ProductBean/remote");
		
//		add(product);//������Ʒ
//		delete(product,2L);//ɾ����Ʒ
//		update(product);//�޸�ĳ��Ʒ��Ϣ
		query(product);//��ѯ������Ʒ
	}
	
	private static void add(IProduct product){
		Product p = new Product();
		p.setProductname("С���ϴ�»�");
		p.setStorecount(12);
		p.setPrice(1200D);
		product.addDBProduct(p);
		System.out.println("������Ʒ�ɹ�");
	}
	
	private static void delete(IProduct product,Long id){
		Product p = new Product();
		p.setProductid(id);
		product.deleteDBProduct(p);
		System.out.println("ɾ����Ʒ�ɹ�");
	}
	
	private static void update(IProduct product){
		Product p = new Product();
		p.setProductid(3L);
		p.setProductname("���˼����");
		p.setStorecount(2);
		p.setPrice(200D);
		product.updateDBProduct(p);
		System.out.println("�޸���Ʒ�ɹ�");
	}
	
	private static void query(IProduct product){
		List<Product> result = product.queryDBProducts();
		for(Product p:result){
			System.out.println("name��"+p.getProductname()+" count:"+p.getStorecount()+" price:"+p.getPrice());
		}
	}
}
