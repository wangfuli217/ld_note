package com.tarena.client;

import java.util.HashMap;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;

import com.tarena.ShoppingCart;

public class Client {
	public static void main(String[] args) throws NamingException {
		Context ctx = new InitialContext();
		ShoppingCart cart = (ShoppingCart)ctx.lookup("ShoppingCartBean/remote");
		
		System.out.println("buy 1st Apple");
		cart.buy("Apple", 1);
		
		//getcarts
		HashMap<String,Integer> carts = cart.getCartContents();
		for(String p:carts.keySet()){
			System.out.println(carts.get(p)+" "+p);
		}
		
		System.out.println("buy 2st Apple");
		cart.buy("Apple", 1);
		
		System.out.println("buy 1st Bananer");
		cart.buy("bananer", 1);
		
		//getcarts
		carts = cart.getCartContents();
		for(String p:carts.keySet()){
			System.out.println(carts.get(p)+" "+p);
		}
		
		//checkout
		System.out.println("Checkout");
		cart.checkout();
		
		try{
			cart.getCartContents();
		}catch(Exception e){
			System.out.println("Successfully caught no such object exception");
		}
	}

}
