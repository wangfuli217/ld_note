package com.tarena.eshop.entity;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * ��Ʒʵ��
 * @author eric
 *
 */
@Entity
@Table(name="product")
public class Product implements Serializable{
	@Id
	@GeneratedValue
	private Long productid;
	private String productname;
	private Integer storecount;
	private Double price;
	public Long getProductid() {
		return productid;
	}
	public void setProductid(Long productid) {
		this.productid = productid;
	}
	public String getProductname() {
		return productname;
	}
	public void setProductname(String productname) {
		this.productname = productname;
	}
	public Integer getStorecount() {
		return storecount;
	}
	public void setStorecount(Integer storecount) {
		this.storecount = storecount;
	}
	public Double getPrice() {
		return price;
	}
	public void setPrice(Double price) {
		this.price = price;
	}
}
