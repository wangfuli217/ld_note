package com.tarena.eshop.bean;
/**
 * ��Ʒ������EJB���ͻ���ֱ�Ӳ�����bean�ķ���
 */
import java.util.List;

import javax.ejb.EJB;
import javax.ejb.Stateless;

import com.tarena.eshop.dao.IProductDao;
import com.tarena.eshop.entity.Product;
@Stateless
public class ProductBean implements IProduct {
	//ע��Dao��ʵ��
	@EJB
	private IProductDao productDao;
	
	public void addDBProduct(Product product) {
		productDao.addDBProduct(product);
	}

	public void deleteDBProduct(Product product) {
		productDao.deleteDBProduct(product);
	}

	public List<Product> queryDBProducts() {
		return productDao.queryDBProducts();
	}

	public void updateDBProduct(Product product) {
		productDao.updateDBProduct(product);
	}
}
