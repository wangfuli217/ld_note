package com.tarena.eshop.bean;

import java.util.List;

import javax.ejb.Remote;

import com.tarena.eshop.entity.Product;

@Remote
public interface IProduct {
	void addDBProduct(Product product);
	void updateDBProduct(Product product);
	void deleteDBProduct(Product product);
	List<Product> queryDBProducts();
}
