package com.tarena.eshop.dao;
/**
 * ��ƷDao�Ľӿ�
 * @author eric
 */
import java.util.List;

import javax.ejb.Local;

import com.tarena.eshop.entity.Product;

@Local
public interface IProductDao {
	void addDBProduct(Product product);
	void updateDBProduct(Product product);
	void deleteDBProduct(Product product);
	List<Product> queryDBProducts();
}
