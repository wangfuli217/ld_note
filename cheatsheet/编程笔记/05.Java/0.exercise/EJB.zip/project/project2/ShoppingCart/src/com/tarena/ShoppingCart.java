package com.tarena;

import java.util.HashMap;

import javax.ejb.Remote;
@Remote
public interface ShoppingCart {
	void buy(String product,int quantity);
	HashMap<String,Integer> getCartContents();
	void checkout();
}
