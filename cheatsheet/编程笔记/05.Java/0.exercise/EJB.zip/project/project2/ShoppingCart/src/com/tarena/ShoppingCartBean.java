package com.tarena;

import java.util.HashMap;

import javax.ejb.Remove;
import javax.ejb.Stateful;
@Stateful
public class ShoppingCartBean implements ShoppingCart {
	//��������ÿ���ͻ����ﳵ����Ϣ
	private HashMap<String,Integer> cart = new HashMap<String,Integer>();
	public void buy(String product, int quantity) {
		if(cart.containsKey(product)){
			int curQuantity = cart.get(product) + quantity;
			cart.put(product, curQuantity);
		}else{
			cart.put(product, quantity);
		}
	}

	@Remove
	public void checkout() {
		System.out.println("CheckOut:====Print cart in Server");
		for(String p:cart.keySet()){
			System.out.println(cart.get(p)+" "+p);
		}
	}

	public HashMap<String, Integer> getCartContents() {
		return cart;
	}

}
