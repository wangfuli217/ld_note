package com.tarena.eshop.forms;

import org.apache.struts.action.ActionForm;

public class ProductForm extends ActionForm {
	private String productname;
	private Integer storecount;
	private Double price;
	public String getProductname() {
		return productname;
	}
	public void setProductname(String productname) {
		this.productname = productname;
	}
	public Integer getStorecount() {
		return storecount;
	}
	public void setStorecount(Integer storecount) {
		this.storecount = storecount;
	}
	public Double getPrice() {
		return price;
	}
	public void setPrice(Double price) {
		this.price = price;
	}
}
