package com.tarena.eshop.action;

import java.util.List;

import javax.naming.Context;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.actions.DispatchAction;

import com.sun.org.apache.commons.beanutils.BeanUtils;
import com.tarena.eshop.bean.IProduct;
import com.tarena.eshop.entity.Product;
import com.tarena.eshop.forms.ProductForm;
import com.tarena.eshop.util.ContextUtil;
import com.tarena.eshop.util.Global;

public class ProductAction extends DispatchAction {
	
	private Context ctx;
	//��ȡJNDI��ʼ��������
	public ProductAction(){
		ctx = ContextUtil.getContext();
	}

	//��ѯ��Ʒ
	public ActionForward queryProducts(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {
		IProduct productBean = (IProduct)ctx.lookup(Global.EJBJNDI_PRODUCT);
		List<Product> products = productBean.queryDBProducts();
		request.getSession().setAttribute("products", products);
		return mapping.findForward("listProduct");
	}
	
	//������Ʒ
	public ActionForward addProduct(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {
		ProductForm proForm = (ProductForm)form;
		Product p = new Product();
		//��Form Bean������ֵ������pojo��
		//����BeanUtils���������
		BeanUtils.copyProperties(p, proForm);
		
		IProduct productBean = (IProduct)ctx.lookup(Global.EJBJNDI_PRODUCT);
		productBean.addDBProduct(p);
		return mapping.findForward("queryProduct");
	}
	
	//�޸���Ʒ
	public ActionForward updateProduct(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {
		ProductForm proForm = (ProductForm)form;
		Product p = new Product();
		//��Form Bean������ֵ������pojo��
		//����BeanUtils���������
		BeanUtils.copyProperties(p, proForm);
		
		IProduct productBean = (IProduct)ctx.lookup(Global.EJBJNDI_PRODUCT);
		productBean.updateDBProduct(p);
		return mapping.findForward("queryProduct");
	}
	
	//ɾ����Ʒ
	public ActionForward deleteProduct(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {
		IProduct productBean = (IProduct)ctx.lookup(Global.EJBJNDI_PRODUCT);
		String[] productids = request.getParameterValues("productid");
		for(String productid:productids){
			Product p = new Product();
			p.setProductid(Long.parseLong(productid));
			productBean.deleteDBProduct(p);
		}
		return mapping.findForward("queryProduct");
	}

}
