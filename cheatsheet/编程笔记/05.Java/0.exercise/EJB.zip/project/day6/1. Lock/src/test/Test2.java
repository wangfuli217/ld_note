package test;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.LockModeType;
import javax.persistence.Persistence;

import entity.Account;

public class Test2 {
	public static void main(String[] args) {
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("LockPU");
        EntityManager em = emf.createEntityManager();
        
        em.getTransaction().begin();
        Account a = em.find(Account.class, 1);
        em.lock(a, LockModeType.READ); //数据库锁，将产生for update语句。只有数据库锁才是悲观锁
        //em.lock(a, LockModeType.WRITE); //乐观锁，版本锁
        try {	Thread.sleep(5000);	
        } catch (InterruptedException e) {
        			e.printStackTrace();}
        
        System.out.println("现在的钱是："+a.getBalance());
        a.setBalance(a.getBalance()+100);
        em.getTransaction().commit();
        System.out.println("现在的钱是："+a.getBalance());
    }
}

/*
先运行 TestPersist 建表后再运行这个，然后马上运行Test3
目的是验证同时修改的后果。

不使用版本号时
打印结果：
log4j:WARN No appenders could be found for logger (org.hibernate.ejb.Version).
log4j:WARN Please initialize the log4j system properly.
Hibernate: select account0_.id as id0_0_, account0_.name as name0_0_, account0_.balance as balance0_0_, account0_.version as version0_0_ from Account account0_ where account0_.id=?
现在的钱是：100.0
Hibernate: update Account set name=?, balance=?, version=? where id=?
现在的钱是：200.0

Test2 和 Test3都运行后，数据库的表是：
mysql> select * from Account;
+----+--------+---------+---------+
| id | name   | balance | version |
+----+--------+---------+---------+
|  1 | 张三   |     200 |       0 | 
+----+--------+---------+---------+
1 row in set (0.00 sec)



使用版本号之后：
打印结果：update时有异常。

Test2 和 Test3都运行后，数据库的表是：
mysql> select * from Account;
+----+--------+---------+---------+
| id | name   | balance | version |
+----+--------+---------+---------+
|  1 | 张三   |     200 |       1 | 
+----+--------+---------+---------+
1 row in set (0.00 sec)

*/