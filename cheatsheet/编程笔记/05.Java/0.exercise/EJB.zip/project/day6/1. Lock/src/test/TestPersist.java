package test;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import entity.Account;

public class TestPersist {
	public static void main(String[] args) {
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("LockPU");
        EntityManager em = emf.createEntityManager();
        
        em.getTransaction().begin();
        Account a = new Account();
        a.setName("张三");
        a.setBalance(100);
        em.persist(a);
        em.getTransaction().commit();
    }

}

/*
 这是EJB工程
 导包：数据库驱动，HibernateJPA支持
 这个 TestPersist 先运行，建表，再往数据库增加一条记录，然后运行后两个 Test
 
 这时，数据库是：
 mysql> select * from Account;
+----+--------+---------+---------+
| id | name   | balance | version |
+----+--------+---------+---------+
|  1 | 张三   |     100 |       0 | 
+----+--------+---------+---------+
1 row in set (0.00 sec)

 */