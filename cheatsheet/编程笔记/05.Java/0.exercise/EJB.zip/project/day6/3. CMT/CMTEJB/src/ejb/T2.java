package ejb;

import javax.ejb.Stateless;

//@Stateless
public class T2 implements IT2 {

	public void withdraw(int id, double balance) {

		throw new RuntimeException();
		
	}

	public void deposit(int id, double balance) {
		// TODO Auto-generated method stub

	}

}
