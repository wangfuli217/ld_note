package Test;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.transaction.UserTransaction;

import ejb.IBank;

public class Test_required {
	public static void main(String[] args) throws Exception{
		System.setProperty(Context.INITIAL_CONTEXT_FACTORY, "org.jnp.interfaces.NamingContextFactory");
		System.setProperty(Context.PROVIDER_URL, "localhost");
		Context ctx = new InitialContext();
		
		UserTransaction utx = (UserTransaction)ctx.lookup("UserTransaction");
		
		utx.begin();
		IBank bank = (IBank)ctx.lookup("BankBean/remote");
		
		bank.deposit(1, 100);
		
		utx.rollback();
		
		
	}

}
