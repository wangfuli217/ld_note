package ejb;

public interface IT2 {
	public void withdraw(int id, double balance);
}
