package ejb;

import javax.annotation.Resource;
import javax.ejb.Stateless;
import javax.ejb.TransactionManagement;
import javax.ejb.TransactionManagementType;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.UserTransaction;

import entity.Account;

@Stateless
//�������������������bean�Լ��������� (BMT)
@TransactionManagement(TransactionManagementType.BEAN)
public class BankBean implements IBank {
	@PersistenceContext
	EntityManager em;
	
	@Resource
	UserTransaction utx ;
	
	public void deposit(int id, double balance) {
		try{
			//......
			//�Լ������{���մ��a
			utx.begin();
			
			Account a = em.find(Account.class, id);
			a.setBalance(a.getBalance()+ balance);
			
			utx.commit();
			//......
		}catch(Exception e){
			e.printStackTrace();
		}
	}

}
