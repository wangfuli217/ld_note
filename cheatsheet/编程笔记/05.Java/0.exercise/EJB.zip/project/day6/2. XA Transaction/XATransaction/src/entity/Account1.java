package entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

@Entity
public class Account1 {
	@Id
	@GeneratedValue
	private int id;
	private String name;
	private double balance; //帐号余额
	
	//@Version //版本号，防止同时修改
	private int version = 0;
	
	public int getId() {	return id;	}
	public void setId(int id) {this.id = id;}
	
	public String getName() {return name;}
	public void setName(String name) {this.name = name;}
	
	public double getBalance() {return balance;}
	public void setBalance(double balance) {this.balance = balance;}
	
	public int getVersion() {	return version;}
	public void setVersion(int version) {	this.version = version;}
	

}
