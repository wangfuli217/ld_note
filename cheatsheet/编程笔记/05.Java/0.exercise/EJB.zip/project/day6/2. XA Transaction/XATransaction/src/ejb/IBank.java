package ejb;

import javax.ejb.Remote;

@Remote
public interface IBank  {
	public void test();
}