package test;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;

import ejb.IBank;

public class Test {
	public static void main(String[] args) throws NamingException{
		System.setProperty(Context.INITIAL_CONTEXT_FACTORY, 
				  "org.jnp.interfaces.NamingContextFactory");
		System.setProperty(Context.PROVIDER_URL, "localhost");
		Context ctx = new InitialContext();
		
		IBank bank = (IBank)ctx.lookup("BankBean/remote");
		
		bank.test();
	}
}

/*
添加 XATransaction 工程的支持，或者导它的接口和entity的jar包
导包： jbossall-client.jar
发布 XATransaction 工程到jboss 后就可运行
(注： XATransaction 是个EJB工程，jboss 需导入 mysql 和 oracle 的驱动) 
另外，jboss的发布目录下需有数据源 mysql-xa-ds.xml 和 oracle-xa-ds.xml


*/