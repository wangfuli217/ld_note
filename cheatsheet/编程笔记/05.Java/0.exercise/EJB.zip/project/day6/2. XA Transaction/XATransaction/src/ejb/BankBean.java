package ejb;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import entity.Account1;

@Stateless
public class BankBean implements IBank {

	@PersistenceContext(unitName="mysqlPU")
	EntityManager mysqlEm;
	
	@PersistenceContext(unitName="oraclePU")
	EntityManager oracleEm;
	
	public void test() {
		System.out.println("test invoked!");
		
		//从工行转账到建行
		Account1 icbc = mysqlEm.find(Account1.class, 1);
		icbc.setBalance(icbc.getBalance()-100);
		System.out.println("转出100");
		
		 //故意出错，看是否会回滚
		if (true){ throw new RuntimeException(); }
		
		Account1 cbc = oracleEm.find(Account1.class, 1);
		cbc.setBalance(cbc.getBalance()+100);
		System.out.println("转账成功!!");
		
	}

}
