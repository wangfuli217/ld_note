package jms;

import javax.jms.Connection;
import javax.jms.ConnectionFactory;
import javax.jms.Destination;
import javax.jms.JMSException;
import javax.jms.MessageProducer;
import javax.jms.Session;
import javax.jms.TextMessage;
import javax.naming.Context;
import javax.naming.InitialContext;

//杨过
public class YangGuo {

	public static void main(String[] args) {
		
		  Connection conn = null;
		  Session sess = null;
		  MessageProducer mp = null;
		  
	try {
		     // 1. 获得连接工厂
		  System.setProperty(Context.INITIAL_CONTEXT_FACTORY, 
			     	 "org.jnp.interfaces.NamingContextFactory");
	    System.setProperty(Context.PROVIDER_URL, "localhost");
	    Context ctx = new InitialContext();
	    ConnectionFactory cf = (ConnectionFactory)ctx.lookup("ConnectionFactory");
	  
		      //2. 创建连接
		  conn = cf.createConnection();
		  
		     //3.创建会话   false表示不需要事务；Session.AUTO_ACKNOWLEDGE 自动确认收到消息
		   sess = conn.createSession(false, Session.AUTO_ACKNOWLEDGE);
		  
		     //4.获得目的地 (只有这里与queue不同) 
		  Destination dest = (Destination)ctx.lookup("topic/tarenaTopic");
		  
		     //5. 创建生产者(消息发送者) 
		   mp = sess.createProducer(dest);
		  
		     //6.创建文本消息
		  TextMessage msg = sess.createTextMessage("大家好");
		  
		      //7.发送消息
		  mp.send(msg);
		  System.out.println("消息发送成功");
		  
		     //8. 关闭资源
	} catch (Exception e) {
		e.printStackTrace();
	} finally {
		try { mp.close(); } catch (JMSException e) {e.printStackTrace();}
		try {sess.close();} catch (JMSException e) {e.printStackTrace();}
		try {conn.close();} catch (JMSException e) {e.printStackTrace();}
	}

	}

}

/*
 这是个EJB工程，不需发布到jboss，
 需导包： jbossall-client.jar
 先启动小龙女、郭芙蓉来等待接收；再发送信息
 发送信息时
 
 打印结果：
 这一端： 消息发送成功
 小龙女的一端：大家好
 郭芙蓉的一端：大家好
 */
