package ejb;

import java.util.Date;

import javax.ejb.Stateless;

import entity.Student;

@Stateless(name="studentDao") //指定ejb名字；远程lookup时用
public class StudentImpl implements IStudent{
	
	@Override
	public Student get(int id){
		Student student =null;
		if(id==1){
			student = new Student();
			student.setId(1);
			student.setName("kkkk");
			student.setBirthday(new Date());
		}
		return student;
	}

}
/*
 * 这是一个EJB工程，可发布到jboss中
 * 被远程调用者
 */
