package ejb;

import javax.ejb.Remote;

import entity.Student;

@Remote
public interface IStudent {
	public Student get(int id);

}
