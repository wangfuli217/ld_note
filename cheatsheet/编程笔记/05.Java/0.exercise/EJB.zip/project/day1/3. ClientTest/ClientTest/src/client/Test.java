package client;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;

import ejb.IStudent;
import entity.Student;

public class Test {
	public static void main(String[] args) throws NamingException {
		Context ctx = new InitialContext();
		IStudent impl = (IStudent)ctx.lookup("studentDao/remote");
		Student student = impl.get(1);
		System.out.println("Id="+ student.getId());
		System.out.println("name="+ student.getName());
		System.out.println("birthday="+student.getBirthday());
		
	}

}

/*
 *   导包 jbossall-client.jar
 *   添加StudentBean工程的支持；模拟远程调用
 *   启动jboss
 *   打印结果：
 *   
 *   Id=1
 *   name=kkkk
 *   birthday=Mon Jan 05 15:43:30 CST 2009 
 */
