package first;

import javax.ejb.Remote;

@Remote
public interface IHello {
	
	public String sayHello(String user);

}
