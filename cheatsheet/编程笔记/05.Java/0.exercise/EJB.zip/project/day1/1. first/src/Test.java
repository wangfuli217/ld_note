import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;

import first.IHello;

public class Test {

	public static void main(String[] args) throws NamingException{
		//1 .获得初始化上下文(Context) 
		// System.setProperty("java.naming.factory.initial",
		// "org.jnp.interfaces.NamingContextFactory");
		System.setProperty(Context.INITIAL_CONTEXT_FACTORY,
				org.jnp.interfaces.NamingContextFactory.class.getName());
		//上下文(Context) 的服务
		System.setProperty(Context.PROVIDER_URL, "localhost");

		Context ctx = new InitialContext(); //系统异常 NamingException

		//2 .通过初试化上下文查找EJB
		IHello hello =  (IHello)ctx.lookup("HelloBean/remote");//系统异常 NamingException
		
		//3 调用EJB
		System.out.println(hello.sayHello("tarena"));
	}

}

/*    
 导包 jbossall-client.jar
 添加 java EE 5 Libraries 支持
把first包打成jar包，放到 jboss安装包下 /server/default/deploy/里
启动 jboss
打印结果：

hello, tarena
*/