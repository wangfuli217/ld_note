package first;

import javax.ejb.Stateless;

@Stateless
public class HelloBean implements IHello {

	public String sayHello(String user) {
		
		System.out.println("调用本地的HelloBean");
		//System.out.println("调用服务器的HelloBean"); //在发布的jar里用这句，看效果
		return "hello, " + user;
	}

}
