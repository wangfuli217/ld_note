
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;

public class ShowLookup {

	public static void main(String[] args) throws NamingException {
		Context context= new InitialContext();
		String id=(String) context.lookup("id");
		
		Student stu=(Student) context.lookup("student");

		
		System.out.println("name="+stu.getName()+", birthday="+stu.getBirthday());
		System.out.println("id="+id);
		
	}

}

/*
ShowBinding 正常运行后
打印结果：

name=Alex, birthday=Mon Jan 05 14:34:25 CST 2009
id=AlexId
*/