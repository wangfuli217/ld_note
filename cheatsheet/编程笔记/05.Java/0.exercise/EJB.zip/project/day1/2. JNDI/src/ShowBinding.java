
import java.util.Date;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;

public class ShowBinding {

	public static void main(String[] args) throws NamingException {
		//1.获得context
		Context context= new InitialContext();
		
		String name="AlexId";
		Student stu=new Student();
		stu.setBirthday(new Date());
		stu.setName("Alex");
		
		//绑定
		context.rebind("id", name);
		context.rebind("student", stu);
		
		System.out.println("绑定完成");
				
	}

}

/*    
导包 jbossall-client.jar
启动 jboss 
浏览器 http://127.0.0.1:8080/jmx-console/HtmlAdaptor 的最下面
   可以看见：  +- id (class: java.lang.String)  
   以及  +- student (class: Student)
打印结果：

绑定完成
*/


