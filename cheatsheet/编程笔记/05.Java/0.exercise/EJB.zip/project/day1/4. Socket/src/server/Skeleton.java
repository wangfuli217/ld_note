package server;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;

public class Skeleton {

	IHello hello = new HelloBean();

	public static void main(String[] args) throws Exception {
		new Skeleton().service();
	}

	// 接收和处理客户请求
	public void service() throws Exception {
		ServerSocket ss = new ServerSocket(8888);//如果端口8888被占用，则用别的
		System.out.println("服务器启动成功,等待客户端调用...");

		while (true) {
			String returnValue = "";
			Socket s = ss.accept();

			//获取客户端发送的字符串
			BufferedReader reader = new BufferedReader(
					new InputStreamReader(s.getInputStream()));

			String msg = reader.readLine();

			//处理消息   // 服务器端要读懂 msg 需要一套协议
			String[] keys = msg.split(" ");
			if (keys == null) {	returnValue = "调用不正确！"; }
			else {
				if (keys[0].equals("sayHello")) {
					  if (keys.length > 1) {	returnValue = hello.sayHello(keys[1]);}
					  else {	returnValue = "请填写用户名！";	}
				} else {	returnValue = "调用方法不存在！";	}
			}

			// pw 与客户端的Socket连接关联
			PrintWriter pw = new PrintWriter(s.getOutputStream(), true);
			//返回调用结果；
			pw.println(returnValue);
			
			
			//关闭资源    // 通常需要 try...catch...finally
			reader.close();
			pw.close();
		}

	}
}

/*
 * 先启动这个服务器端，再去启动客户端
 * 正常启动后；要求保持不停
 * 一直供给客户端的调用
 */
