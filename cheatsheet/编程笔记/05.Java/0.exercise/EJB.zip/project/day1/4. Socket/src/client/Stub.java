package client;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;

import server.IHello;

public class Stub implements IHello {

	public String sayHello(String user) {
		try {
			Socket s = new Socket("127.0.0.1", 8888); //连接指定端口
			
			//向服务器端发送消息
			PrintWriter pw = new PrintWriter(s.getOutputStream(), true);
			pw.println("sayHello " + user);

			//读取服务器端发过来的信息
			BufferedReader reader = new BufferedReader(new InputStreamReader(s
					.getInputStream()));
			String msg = reader.readLine();

			pw.close();
			reader.close();

			return msg;
		} catch (Exception e) {
			e.printStackTrace();
		}

		return null;
	}

}
