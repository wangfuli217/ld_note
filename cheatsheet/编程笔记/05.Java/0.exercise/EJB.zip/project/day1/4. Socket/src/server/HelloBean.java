package server;

public class HelloBean implements IHello {

	public String sayHello(String user) {

		return "hello, " + user;
	}

}
