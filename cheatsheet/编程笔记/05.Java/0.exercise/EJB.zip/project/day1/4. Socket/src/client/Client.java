package client;

import server.IHello;

public class Client {
	public static void main(String[] args){
		
		IHello hello = new Stub();
		System.out.println(hello.sayHello("tarena")); //打印：hello, tarena
		System.out.println(hello.sayHello(" ")); //不写或只写空格都打印：请填写用户名！
		System.out.println(hello.sayHello(""));//同上
		System.out.println(hello.sayHello("tarena hehe"));//打印：hello, tarena
		
	}
}

/*
 * 启动jboss；导包 jbossall-client.jar
 * Skeleton 正常启动后；要求保持不停
 *  若Skeleton停了，则抛 java.net.ConnectException: Connection refused
 *  且打印 null
 * 运行结果：
 * 
 * hello, tarena
 * 请填写用户名！
 * 请填写用户名！
 * hello, tarena
 */
