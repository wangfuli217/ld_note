package server;

public interface IHello {
	
	public String sayHello(String user);

}
