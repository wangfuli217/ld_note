import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;

import first.IWelcome;

public class Test {

	public static void main(String[] args) throws NamingException{

		Context ctx =  new InitialContext(); 

		IWelcome wel =  (IWelcome)ctx.lookup("welcome/remote");

		System.out.println(wel.welcome("tarena"));
	}

}

/*    
 导包 jbossall-client.jar
启动 jboss
把 first包 打成jar包，发布到jboss
打印结果：

hello, tarena
(调用本地的HelloBean)
*/