package first;

import javax.ejb.Local;

@Local //默认就是Local接口
public interface IHello {
	
	public String sayHello(String user);

}
