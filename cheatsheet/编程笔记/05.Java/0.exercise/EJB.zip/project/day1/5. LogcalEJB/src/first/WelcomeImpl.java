package first;

import javax.ejb.EJB;
import javax.ejb.Stateless;

@Stateless(name="welcome")
public class WelcomeImpl implements IWelcome {
	@EJB //(mappedName="HelloImpl/local")
	IHello hello;
	
	public String welcome(String name) {
		return hello.sayHello(name);
	}

}
