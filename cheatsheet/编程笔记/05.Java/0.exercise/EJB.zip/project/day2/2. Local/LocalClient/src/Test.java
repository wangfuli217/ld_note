import javax.naming.Context;
import javax.naming.InitialContext;

import ejb.IWelcome;


public class Test {

	public static void main(String[] args) throws Exception {
		Context ctx = new InitialContext();
		// 没有调用local本地接口
		IWelcome remote = (IWelcome)ctx.lookup("welcome/remote");//用 lookup("welcome/remote")也行
		
		System.out.println(remote.welcome("tarena"));
	}
}

/*
添加 LocalEJB项目的支持
导包 jbossall-client.jar
LocalEJB工程发布，再启动jboss后调用

页面 http://127.0.0.1:8081/jmx-console/HtmlAdaptor：
+- Welcome (class: org.jnp.interfaces.NamingContext)
  |   +- remote (p...
+- welcome (class: org.jnp.interfaces.NamingContext)
  |   +- remote ...
  
如果 ejb-jar.xml 里面不写IWelcome的内容，则：
这个控制台RuntimeException:异常：
Unable to inject jndi dependency: env/ejb.WelcomeImpl/hello into field interface ejb.IHello

jboss控制台NamingException: 异常：
Could not dereference object ... HelloImpl not bound


现在，可以正常调用，打印结果：
Hello, tarena
*/