package ejb;

import javax.ejb.EJB;
import javax.ejb.Stateless;

@Stateless(name="welcome") //不写name则用 WelcomeImpl 远程调用
public class WelcomeImpl implements IWelcome {
	@EJB(mappedName="Hello11/local")  //不写mappedName则不能调用，因为它找的是HelloImpl
	IHello hello;
	
	public String welcome(String name) {
		return hello.sayHello(name);
	}

}
