package ejb;

import javax.ejb.Local;
import javax.ejb.Remote;

//可以两个标注都写
@Local  //默认就是Local接口   只写这一个时，只允许本地调用
@Remote //只写这一个时，远程、本地都可调用
public interface IHello {
	public String sayHello(String name);
}
