import javax.naming.Context;
import javax.naming.InitialContext;

import ejb.IHello;


public class TestLocal {

	//  本地接口只能在jboss(ejb服务器)中的代码才能访问
	public static void main(String[] args) throws Exception {
		Context ctx = new InitialContext();
		
		IHello local = (IHello)ctx.lookup("aaa"); //按jboss.xml对应的 <jndi-name>
		
		//有jboss.xml之后，IHello变成local文件，不能再用这句了。因为它的名字已经变成"aaa"，只能用上句
		//删除 jboss.xml 就可用这名字
		//IHello local = (IHello)ctx.lookup("Hello11/remote"); 
		
		System.out.println(local.sayHello("tarena"));
		
	}

}

/*
添加 LocalEJB项目的支持
导包 jbossall-client.jar
LocalEJB工程发布，再启动jboss后就可调用

页面 http://127.0.0.1:8081/jmx-console/HtmlAdaptor：
+- Hello11 (class: org.jnp.interfaces.NamingContext)
  |   +- local (proxy:   ...
+- aaa (proxy: $Proxy133 ...

打印结果：
Hello, tarena
*/