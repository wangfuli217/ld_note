package ejb;

import javax.ejb.Stateless;

@Stateless(name="Hello00")
public class HelloImpl implements IHello {

	public String sayHello(String name) {
		return "Hello, " + name;
	}

}
