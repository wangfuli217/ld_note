package ejb;

import javax.ejb.Remote;

@Remote
public interface IWelcome {
	public String welcome(String name);
}
