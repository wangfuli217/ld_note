package com;

import javax.ejb.Stateless;
import javax.interceptor.Interceptors;

@Stateless
@Interceptors(CountCallback.class) //也可以把CountCallback.class的内容直接写进来
public class CountBean implements ICount {
	//实例个数
	public static int count;
	
	public CountBean(){
		count ++;
	}
	
	public int getCount() {
		return count;
	}
	
	
}

//这是个ejb工程，发布到jboss后，就可调用
