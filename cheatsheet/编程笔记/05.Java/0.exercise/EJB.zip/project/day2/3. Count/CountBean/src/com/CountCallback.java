package com;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;
import javax.interceptor.InvocationContext;

public class CountCallback {
	@PostConstruct
	public void postConstruct(InvocationContext ic){
		System.out.println("独立的回调类：Count Bean的构造方法调用完！注入已完整");
	}

	@PreDestroy
	public void preDestroy(InvocationContext ic){
		System.out.println("独立的回调类：Count Bean将被销毁！");
		//删除这项目时调用这方法
	}
}

/*
无状态会话Bean的生命周期(状态图) 
   1)不存在 -> 就绪 (过程: 1创建Bean实例 2依赖注入 3@PostConstrcut回调方法) 
   2)就绪 -> 不存在(过程: @PreDestroy回调方法) 
   3)@PostConstrcut和@PreDestroy是回调方法，可以定义在Bean类中，也可以定义在单独的类中
     @PostConstrcut 进行初始化工作，比如获取一些不能用依赖注入获得的资源
     @PreDestroy 释放初始化时获得的资源
   4)这个是独立的回调类
     @Interceptors(Callback.class) 

jboss的控制台打印(会多个)：
15:25:24,299 INFO  [STDOUT] 独立的回调类：Count Bean的构造方法调用完！注入已完整
*/
