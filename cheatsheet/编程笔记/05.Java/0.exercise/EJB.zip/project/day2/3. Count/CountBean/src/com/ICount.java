package com;

import javax.ejb.Remote;

@Remote
public interface ICount {
	public int getCount();
}
