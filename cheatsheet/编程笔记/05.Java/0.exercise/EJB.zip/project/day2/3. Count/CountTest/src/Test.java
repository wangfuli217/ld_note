
import javax.naming.Context;
import javax.naming.InitialContext;

import com.ICount;

public class Test {

	public static void main(String[] args) throws Exception{
		Context ctx = new InitialContext();
		
		ICount count = (ICount)ctx.lookup("CountBean/remote");
		
		for(int i=0; i<1000; i++){
			System.out.println(count.getCount());
		}

	}

}

/*
需导包 jbossall-client.jar
添加CoutBean工程的支持或导入ICount接口
CountBean工程发布，再启动jboss后就可调用

无状态会话Bean的对象和并发服务
实例数量是容器根据客户端数量，来创建的。

连续多次启动此程序，就有可能返回一个大点的数
打印结果：连续的 1  或者有更大的数

*/