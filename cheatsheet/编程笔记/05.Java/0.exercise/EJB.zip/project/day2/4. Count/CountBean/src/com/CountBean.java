package com;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;
import javax.ejb.PostActivate;
import javax.ejb.PrePassivate;
import javax.ejb.Remove;
import javax.ejb.Stateful;

import org.jboss.annotation.ejb.cache.simple.CacheConfig;

//聪明的服务生
//有状态的会话Bean
@Stateful

//JBoss应用服务器特有的标注；idleTimeoutSeconds设置钝化时间
@CacheConfig(maxSize=100,idleTimeoutSeconds=3)
public class CountBean implements ICount {

	//钝化时不保存瞬间态的属性值
	private  int val;
	private static int Counter;

	public CountBean() {	
		Counter++;
		System.out.println(this.hashCode() + "出生了!");	}
	
	public void set(int val) {	this.val = val;}
	public int get(){return Counter;}
		
	public int count() {
		val++;
		System.out.println(this.hashCode() + "后台:" + val);
		return val;
	}

	//销毁Bean实例
	@Remove
	public void remove() {
		Counter--;
		System.out.println(this.hashCode() +"被投诉了,老板炒人了!");

	}
	
	//添加生命周期方法
	//生命周期方法都是由EJB容器调用
	
	//不存在->就绪
	//生命周期方法要求:1 方法可以任意合法Java的命名   2 必须添加@PostConstruct标注
	@PostConstruct
	public void postConstruct(){
		System.out.println(this.hashCode()+"老板,我准备好了,随时可以为你提供服务!");
	}

	//就绪->不存在
	@PreDestroy
	public void preDestroy(){
		System.out.println(this.hashCode() +"完成身后事,留遗嘱等等工作!");
		//调用remove() 或者 删除这项目时调用这方法
	}
	
	//就绪->钝化
	@PrePassivate
	public void prePassivate(){
		System.out.println(this.hashCode() +"我的客户很久都没来光临我了,主人要我去休息!");
			}
	
	//钝化->就绪
	@PostActivate
	public void postActivate(){
		System.out.println(this.hashCode() +"我的客户终于出现,我有工开了!");
	}
}

/*
导包：jboss-annotations-ejb3.jar (这个包在 %jboss_home%/client/ 下) 
*/