import javax.naming.Context;
import javax.naming.InitialContext;

import com.ICount;

public class Test2 {

	public static void main(String[] args) throws Exception {

		Context ctx = new InitialContext();
		ICount countStub = (ICount) ctx.lookup("CountBean/remote");
		countStub.set(100);
		//countStub.remove(); //删除之后就不能再调用了，需要再次 lookup
		System.out.println(countStub.count());//101
		
		//钝化
		Thread.sleep(10000);
		System.out.println("go");
		
		//再次激活，创建一个新的实例对象
		System.out.println(countStub.count());//102
		
	}
}

/*
jboss 控制台打印：
13:54:18,911 INFO  [STDOUT] 25395364出生了!
13:54:18,916 INFO  [STDOUT] 25395364老板,我准备好了,随时可以为你提供服务!
13:54:18,940 INFO  [STDOUT] 25395364后台:101
13:54:24,895 INFO  [STDOUT] 25395364我的客户很久都没来光临我了,主人要我去休息!
13:54:28,999 INFO  [STDOUT] 5182915出生了!
13:54:28,999 INFO  [STDOUT] 5182915我的客户终于出现,我有工开了!
13:54:29,000 INFO  [STDOUT] 5182915后台:102
13:54:34,014 INFO  [STDOUT] 5182915我的客户很久都没来光临我了,主人要我去休息!

本控制台打印：
101
go
102

*/