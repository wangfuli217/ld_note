package com;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;
import javax.ejb.Stateless;
import javax.interceptor.InvocationContext;

@Stateless
public class CountStateless implements ICount {
	//实例个数
	public static int count;
	
	public CountStateless(){
		count ++;
		System.out.println(this.hashCode() + "出生了!");
	}
	
	// 累加
	public int count(){	return count;	}

	// 重新设置值
	public void set(int val){	this.count = val;}

	// 删除Bean
	public void remove(){
		System.out.println(this.hashCode() +"被投诉了,老板炒人了!");	}
	
	public int getCount() {	return count;}
	
	@PostConstruct
	public void postConstruct(InvocationContext ic){
		System.out.println("独立的回调类：Count Bean的构造方法调用完！注入已完整");
	}

	@PreDestroy
	public void preDestroy(InvocationContext ic){
		System.out.println("独立的回调类：Count Bean将被销毁！");
	}

}
