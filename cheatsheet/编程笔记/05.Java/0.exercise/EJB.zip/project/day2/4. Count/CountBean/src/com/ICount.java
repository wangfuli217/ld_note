package com;

import javax.ejb.Remote;

@Remote
public interface ICount {

	// 累加
	public int count();

	// 重新设置值
	public void set(int val);

	// 删除Bean
	public void remove();

}
