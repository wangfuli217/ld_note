
import javax.naming.Context;
import javax.naming.InitialContext;

import com.ICount;

public class Test {

	public static void main(String[] args) throws Exception {

		Context ctx = new InitialContext();
		ICount[] counts = new ICount[5];

		for (int i = 0; i < 5; i++) {
			counts[i] = (ICount) ctx.lookup("CountBean/remote");
			// System.out.println(counts[i].hashCode());
			System.out.println("counts[" + i + "]:" + counts[i].count());
		}

		System.out.println("*************************");

		for (int i = 0; i < 5; i++) {
			// counts[i] = (Count) ctx.lookup("CountBean/remote");
			// System.out.println(counts[i].hashCode());
			System.out.println("counts[" + i + "]:" + counts[i].count());
		}

		System.out.println("*************************");
		for (int i = 0; i < 5; i++) {
			// counts[i] = (Count) ctx.lookup("CountBean/remote");
			// System.out.println(counts[i].hashCode());
			counts[i].set(100);
			System.out.println("counts[" + i + "]:" + counts[i].count());
		    
		}
		
		counts[3].remove();
		
		//原来服务生已经被炒,需要重新申请服务生
		counts[3]=(ICount)ctx.lookup("CountBean/remote");
		counts[3].count();//用的是另外生出的一个session

	}
}

/*
需导包 jbossall-client.jar
添加CoutBean工程的支持或导入ICount接口
CountBean工程发布，再启动jboss后就可调用

有状态会话Bean的对象和并发服务
实例数量是容器根据客户端数量，来创建的。
生命周期：不存在 -> 就绪 -> 钝化

本控制台打印：
counts[0]:1
counts[1]:1
counts[2]:1
counts[3]:1
counts[4]:1
*************************
counts[0]:2
counts[1]:2
counts[2]:2
counts[3]:2
counts[4]:2
*************************
counts[0]:101
counts[1]:101
counts[2]:101
counts[3]:101
counts[4]:101

jboss控制台打印：
14:04:14,792 INFO  [STDOUT] 26834999出生了!
14:04:14,795 INFO  [STDOUT] 26834999老板,我准备好了,随时可以为你提供服务!
14:04:14,796 INFO  [STDOUT] 26834999后台:1
14:04:14,870 INFO  [STDOUT] 982796出生了!
14:04:14,872 INFO  [STDOUT] 982796老板,我准备好了,随时可以为你提供服务!
14:04:14,874 INFO  [STDOUT] 982796后台:1
14:04:14,943 INFO  [STDOUT] 7871549出生了!
14:04:14,947 INFO  [STDOUT] 7871549老板,我准备好了,随时可以为你提供服务!
14:04:14,948 INFO  [STDOUT] 7871549后台:1
14:04:15,034 INFO  [STDOUT] 14660115出生了!
14:04:15,037 INFO  [STDOUT] 14660115老板,我准备好了,随时可以为你提供服务!
14:04:15,038 INFO  [STDOUT] 14660115后台:1
14:04:15,118 INFO  [STDOUT] 18669450出生了!
14:04:15,120 INFO  [STDOUT] 18669450老板,我准备好了,随时可以为你提供服务!
14:04:15,121 INFO  [STDOUT] 18669450后台:1
14:04:15,138 INFO  [STDOUT] 26834999后台:2
14:04:15,154 INFO  [STDOUT] 982796后台:2
14:04:15,192 INFO  [STDOUT] 7871549后台:2
14:04:15,206 INFO  [STDOUT] 14660115后台:2
14:04:15,223 INFO  [STDOUT] 18669450后台:2
14:04:15,374 INFO  [STDOUT] 26834999后台:101
14:04:15,425 INFO  [STDOUT] 982796后台:101
14:04:15,575 INFO  [STDOUT] 7871549后台:101
14:04:15,605 INFO  [STDOUT] 14660115后台:101
14:04:15,655 INFO  [STDOUT] 18669450后台:101
14:04:15,673 INFO  [STDOUT] 14660115被投诉了,老板炒人了!
14:04:15,673 INFO  [STDOUT] 14660115完成身后事,留遗嘱等等工作!
14:04:15,826 INFO  [STDOUT] 23252842出生了!
14:04:15,828 INFO  [STDOUT] 23252842老板,我准备好了,随时可以为你提供服务!
14:04:15,830 INFO  [STDOUT] 23252842后台:1
14:04:19,897 INFO  [STDOUT] 26834999我的客户很久都没来光临我了,主人要我去休息!
14:04:19,923 INFO  [STDOUT] 982796我的客户很久都没来光临我了,主人要我去休息!
14:04:19,927 INFO  [STDOUT] 7871549我的客户很久都没来光临我了,主人要我去休息!
14:04:19,930 INFO  [STDOUT] 18669450我的客户很久都没来光临我了,主人要我去休息!
14:04:19,935 INFO  [STDOUT] 23252842我的客户很久都没来光临我了,主人要我去休息!

*/