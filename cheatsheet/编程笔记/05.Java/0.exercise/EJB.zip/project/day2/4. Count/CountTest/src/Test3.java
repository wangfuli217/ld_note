
import javax.naming.Context;
import javax.naming.InitialContext;

import com.ICount;

public class Test3 {

	public static void main(String[] args) throws Exception {

		Context ctx = new InitialContext();

		ICount[] counts = new ICount[10];

		for (int i = 0; i < 10; i++) {
			counts[i] = (ICount) ctx.lookup("CountBean/remote");
			counts[i].set(2);
		}

		for (int i = 0; i < 10; i++) {
			counts[i].set(3);
		}

	}

}

/*
jboss控制台打印：
14:01:34,746 INFO  [STDOUT] 11530728出生了!
14:01:34,748 INFO  [STDOUT] 11530728老板,我准备好了,随时可以为你提供服务!
14:01:34,805 INFO  [STDOUT] 10766349出生了!
14:01:34,807 INFO  [STDOUT] 10766349老板,我准备好了,随时可以为你提供服务!
14:01:34,967 INFO  [STDOUT] 6831720出生了!
14:01:34,969 INFO  [STDOUT] 6831720老板,我准备好了,随时可以为你提供服务!
14:01:35,047 INFO  [STDOUT] 10251926出生了!
14:01:35,049 INFO  [STDOUT] 10251926老板,我准备好了,随时可以为你提供服务!
14:01:35,119 INFO  [STDOUT] 28830939出生了!
14:01:35,121 INFO  [STDOUT] 28830939老板,我准备好了,随时可以为你提供服务!
14:01:35,193 INFO  [STDOUT] 30703749出生了!
14:01:35,196 INFO  [STDOUT] 30703749老板,我准备好了,随时可以为你提供服务!
14:01:35,266 INFO  [STDOUT] 12424711出生了!
14:01:35,270 INFO  [STDOUT] 12424711老板,我准备好了,随时可以为你提供服务!
14:01:35,343 INFO  [STDOUT] 31642721出生了!
14:01:35,345 INFO  [STDOUT] 31642721老板,我准备好了,随时可以为你提供服务!
14:01:35,416 INFO  [STDOUT] 20192428出生了!
14:01:35,442 INFO  [STDOUT] 20192428老板,我准备好了,随时可以为你提供服务!
14:01:35,499 INFO  [STDOUT] 14688701出生了!
14:01:35,502 INFO  [STDOUT] 14688701老板,我准备好了,随时可以为你提供服务!
14:01:40,625 INFO  [STDOUT] 11530728我的客户很久都没来光临我了,主人要我去休息!
14:01:40,630 INFO  [STDOUT] 10766349我的客户很久都没来光临我了,主人要我去休息!
14:01:40,634 INFO  [STDOUT] 6831720我的客户很久都没来光临我了,主人要我去休息!
14:01:40,641 INFO  [STDOUT] 10251926我的客户很久都没来光临我了,主人要我去休息!
14:01:40,645 INFO  [STDOUT] 28830939我的客户很久都没来光临我了,主人要我去休息!
14:01:40,654 INFO  [STDOUT] 30703749我的客户很久都没来光临我了,主人要我去休息!
14:01:40,657 INFO  [STDOUT] 12424711我的客户很久都没来光临我了,主人要我去休息!
14:01:40,661 INFO  [STDOUT] 31642721我的客户很久都没来光临我了,主人要我去休息!
14:01:40,666 INFO  [STDOUT] 20192428我的客户很久都没来光临我了,主人要我去休息!
14:01:40,670 INFO  [STDOUT] 14688701我的客户很久都没来光临我了,主人要我去休息! 
 
 */
