package test;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import entity.Dept;
import entity.User;

public class TestQuery {
	public static void main(String[] args){
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("Many2OnePU");
		EntityManager em = emf.createEntityManager();
		
		Dept dept = em.find(Dept.class,1);
		List<User> list = dept.getUsers();
		for(User user:list){
			System.out.println(user.getName());
		}
		
		System.out.println("=============");
		String ql = "from User";
		List<User> user = em.createQuery(ql).getResultList();
		for(User u:user){
			System.out.print(u.getClass()+": " + u.getId()+" "+u.getName()+" ");
			System.out.println(u.getLoginid()+" " + u.getPassword()+" "+u.getDept().getName());
		}
	}

}

/*
 先运行Test，插入内容
 打印结果：
log4j:WARN No appenders could be found for logger (org.hibernate.ejb.Version).
log4j:WARN Please initialize the log4j system properly.
Hibernate: select dept0_.id as id1_0_, dept0_.name as name1_0_ from Dept dept0_ where dept0_.id=?
Hibernate: select users0_.dept_id as dept5_1_, users0_.id as id1_, users0_.id as id0_0_, users0_.dept_id as dept5_0_0_, users0_.name as name0_0_, users0_.loginid as loginid0_0_, users0_.password as password0_0_ from sys_user users0_ where users0_.dept_id=?
daillo
=============
Hibernate: select user0_.id as id0_, user0_.dept_id as dept5_0_, user0_.name as name0_, user0_.loginid as loginid0_, user0_.password as password0_ from sys_user user0_
class entity.User: 1 daillo null null 教学部
class entity.User: 2 holemar Exception in thread "main" java.lang.NullPointerException
	at test.TestQuery.main(TestQuery.java:28)


后面抛异常，因为第二个 u.getDept() 是null，再.getName()就异常了。如果删除这个，变：
log4j:WARN No appenders could be found for logger (org.hibernate.ejb.Version).
log4j:WARN Please initialize the log4j system properly.
Hibernate: select dept0_.id as id1_0_, dept0_.name as name1_0_ from Dept dept0_ where dept0_.id=?
Hibernate: select users0_.dept_id as dept5_1_, users0_.id as id1_, users0_.id as id0_0_, users0_.dept_id as dept5_0_0_, users0_.name as name0_0_, users0_.loginid as loginid0_0_, users0_.password as password0_0_ from sys_user users0_ where users0_.dept_id=?
daillo
=============
Hibernate: select user0_.id as id0_, user0_.dept_id as dept5_0_, user0_.name as name0_, user0_.loginid as loginid0_, user0_.password as password0_ from sys_user user0_
class entity.User: 1 daillo null null 
class entity.User: 2 holemar null null 

 */
