package test;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import entity.Dept;
import entity.User;

public class Test {

	public static void main(String[] args) {
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("ManyToOnePU");
		EntityManager em = emf.createEntityManager();
		
		em.getTransaction().begin();
		
		Dept dept = new Dept();
		dept.setName("教学部");
		em.persist(dept); //这不能用merge
		
		User user = new User(); 
		user.setName("daillo");
		user.setDept(dept);  //先有部门，再设用户
		em.merge(user);
		
		em.getTransaction().commit();
		System.out.println("===========");

		
		em.getTransaction().begin();
		
		User user2 = new User(); 
		user2.setName("holemar");
		
		Dept dept2 = new Dept();
		dept2.setName("资讯部");
		dept.getUsers().add(user2); //先有用户，再设部门；看关系是否稳定：结果没有联系上
		em.persist(dept2); //这也不能用merge
		
		user2.setDept(dept2);
		em.merge(user2); //必须得设置user2的部门，否则它的部门只能为空
			
		em.getTransaction().commit();
	}

}

/*
 这是EJB工程
 导包：数据库驱动，HibernateJPA支持
 
 打印结果：
log4j:WARN No appenders could be found for logger (org.hibernate.ejb.Version).
log4j:WARN Please initialize the log4j system properly.
Hibernate: insert into Dept (name) values (?)
Hibernate: insert into user (dept_id, name, loginid, password) values (?, ?, ?, ?)
===========
Hibernate: insert into Dept (name) values (?)
Hibernate: insert into user (dept_id, name, loginid, password) values (?, ?, ?, ?)
	
数据库的表：
mysql> show tables;
+---------------+
| Tables_in_jpa |
+---------------+
| Dept          | 
| user          | 
+---------------+
2 rows in set (0.00 sec)

mysql> select * from Dept;
+----+-----------+
| id | name      |
+----+-----------+
|  1 | 教学部    | 
|  2 | 资讯部    | 
+----+-----------+
2 rows in set (0.00 sec)

mysql> select * from user;
+----+---------+---------+----------+---------+
| id | name    | loginid | password | dept_id |
+----+---------+---------+----------+---------+
|  1 | daillo  | NULL    | NULL     |       1 | 
|  2 | holemar | NULL    | NULL     |       2 | 
+----+---------+---------+----------+---------+
2 rows in set (0.00 sec)

 */
