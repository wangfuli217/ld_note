package entity;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.OneToMany;

@Entity
public class Leader {
	@Id
	@GeneratedValue
	private int id;
	private String name;
	
	@OneToMany //(mappedBy = "leader") //加上mappedBy就不再建中间表来维护关系
	@JoinTable(name="leader_member" //反映Leader与Member关系的一个表。不写则不建
		,joinColumns={@JoinColumn(name="leader_id")} //这个关系表的主键字段，可以用复合主键
	  ,inverseJoinColumns={@JoinColumn(name="member_id")}) //这个关系表的成员的字段
	private List<Member> member = new ArrayList<Member>(); //多个下属
	//创建一个ArrayList()，避免空指针异常
	
	public int getId() {return id;}
	public void setId(int id) {this.id = id;}
	
	public String getName() {return name;	}
	public void setName(String name) {this.name = name;}
	
	public List<Member> getMember() {return member;}
	public void setMember(List<Member> member) {this.member = member;}
	
	
}
