package entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

@Entity
public class Member {
	@Id
	@GeneratedValue
	private int id;
	private String name;	
	
	@ManyToOne  //下属只有一个领导；这个要用 @ManyToOne，否则有异常
	@JoinColumn(name="LeaderId") //指定外键字段的名字；默认按维护关系表的名称 leader_id
	private Leader leader;
		
	public int getId() {return id;}
	public void setId(int id) {this.id = id;}
	
	public String getName() {return name;	}
	public void setName(String name) {this.name = name;}

	public Leader getLeader() {return leader;}
	public void setLeader(Leader leader) {this.leader = leader;}
}
