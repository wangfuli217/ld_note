package test;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import entity.Leader;
import entity.Member;

public class Test {

    public static void main(String[] args) {
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("One2ManyPU");
        EntityManager em = emf.createEntityManager();
        
        em.getTransaction().begin();
        
        Leader leader = new Leader();
        leader.setName("毛泽东");
        
        Member m1 = new Member();
        m1.setName("彭德怀");
        m1.setLeader(leader);
        
        Member m2 = new Member();
        m2.setName("林彪");
        m2.setLeader(leader);
        
        leader.getMember().add(m1);
        leader.getMember().add(m2);
        
        em.persist(m1);
        em.persist(m2);
        em.persist(leader);
        
        em.getTransaction().commit();
    }
}

/*
 这是EJB工程
 导包：数据库驱动，HibernateJPA支持
 
 打印结果：
log4j:WARN No appenders could be found for logger (org.hibernate.ejb.Version).
log4j:WARN Please initialize the log4j system properly.
Hibernate: insert into Member (name, LeaderId) values (?, ?)
Hibernate: insert into Member (name, LeaderId) values (?, ?)
Hibernate: insert into Leader (name) values (?)
Hibernate: update Member set name=?, LeaderId=? where id=?
Hibernate: update Member set name=?, LeaderId=? where id=?
Hibernate: insert into leader_member (leader_id, member_id) values (?, ?)
Hibernate: insert into leader_member (leader_id, member_id) values (?, ?)

    
数据库的表：
mysql> show tables;
+---------------+
| Tables_in_jpa |
+---------------+
| Leader        | 
| Member        | 
| leader_member | 
+---------------+

mysql> select * from Leader;
+----+-----------+
| id | name      |
+----+-----------+
|  1 | 毛泽东     | 
+----+-----------+

mysql> select * from Member;
+----+-----------+-----------+
| id | name      | leader_id |
+----+-----------+-----------+
|  1 | 彭德怀    |         1 | 
|  2 | 林彪      |         1 | 
+----+-----------+-----------+
2 rows in set (0.00 sec)

mysql> select * from leader_member;
+-----------+-----------+
| leader_id | member_id |
+-----------+-----------+
|         1 |         1 | 
|         1 |         2 | 
+-----------+-----------+
2 rows in set (0.00 sec)

 */
