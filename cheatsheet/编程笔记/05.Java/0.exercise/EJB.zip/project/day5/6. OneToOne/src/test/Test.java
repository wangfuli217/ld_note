package test;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import entity.Boy;
import entity.Girl;

public class Test {

    public static void main(String[] args) {
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("One2OnePU");
        EntityManager em = emf.createEntityManager();
        
        em.getTransaction().begin();
        
        Boy boy = new Boy();
        boy.setName("二狗");
        boy.setMoney(100000);
        em.persist(boy);
        
        Girl girl = new Girl();
        girl.setName("如花");
        girl.setAge(16);
        em.merge(girl);
        
        boy.setGirlfriend(girl);
        em.persist(boy); //如果这里用merge，会添加两个"二狗"到数据库，因为merge是合并到context上下文
        
        //girl.setBoyfriend(boy); //这句有异常；因为Girl的属性上有mappedBy，没有则没异常
        //em.persist(girl);
        
        em.getTransaction().commit();
    }

}

/*
 这是EJB工程
 导包：数据库驱动，HibernateJPA支持
 
 打印结果：
log4j:WARN No appenders could be found for logger (org.hibernate.ejb.Version).
log4j:WARN Please initialize the log4j system properly.
Hibernate: insert into Boy (name, money, girlfriend_id) values (?, ?, ?)
Hibernate: insert into Girl (name, age) values (?, ?)
Hibernate: insert into Boy (name, money, girlfriend_id) values (?, ?, ?)

    
数据库的表：
mysql> show tables;
+---------------+
| Tables_in_jpa |
+---------------+
| Boy           | 
| Girl          | 
+---------------+

mysql> select * from Boy;
+----+--------+--------+---------------+
| id | name   | money  | girlfriend_id |
+----+--------+--------+---------------+
|  1 | 二狗   | 100000 |             1 | 
+----+--------+--------+---------------+
1 row in set (0.00 sec)

mysql> select * from Girl;
+----+--------+--------+
| id | name   | age    |
+----+--------+--------+
|  1 | 如花   |    16      | 
+----+--------+--------+
1 row in set (0.00 sec)

 */
