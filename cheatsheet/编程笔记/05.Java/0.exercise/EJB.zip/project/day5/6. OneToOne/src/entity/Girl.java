package entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToOne;

@Entity
public class Girl {
	
	@Id
	@GeneratedValue
	private int id;
	private String name;	
	private int age; //身高(厘米) 
	
	@OneToOne(mappedBy="girlfriend")  //写上mappedBy之后，就不维护外键。默认有维护
	private Boy boyfriend;            //不写这个属性，就是BOY单向维护关系
	
	public int getId() {return id;}
	public void setId(int id) {this.id = id;}
	
	public String getName() {return name;	}
	public void setName(String name) {this.name = name;}
	
	public int getAge() {return age;}
	public void setAge(int age) {this.age = age;}
	
	public Boy getBoyfriend() {return boyfriend;}
	public void setBoyfriend(Boy boy) {this.boyfriend = boy;}

}
