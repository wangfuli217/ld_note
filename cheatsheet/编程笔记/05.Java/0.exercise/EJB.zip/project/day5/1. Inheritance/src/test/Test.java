package test;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import entity.Bird;
import entity.Fish;

public class Test {

	public static void main(String[] args) {
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("AnimalPU");
		EntityManager em = emf.createEntityManager();
		
		em.getTransaction().begin();
		
		Fish fish = new Fish();
		fish.setName("鲨鱼");
		fish.setGill("巨腮");

		Bird bird = new Bird();
		bird.setName("鸵鸟");
		bird.setSwing("不会飞的翅膀");
		
		em.persist(fish);
		em.persist(bird);
		
		em.getTransaction().commit();
	}

}

/*
导包：数据库驱动，HibernateJPA支持

打印结果：
log4j:WARN No appenders could be found for logger (org.hibernate.ejb.Version).
log4j:WARN Please initialize the log4j system properly.
Hibernate: insert into Animal (name, gill, DTYPE) values (?, ?, 'Fish')
Hibernate: insert into Animal (name, swing, DTYPE) values (?, ?, 'Bird')


mysql里的表：
mysql> select * from T_fish;
+----+--------+--------+
| id | name   | gill   |
+----+--------+--------+
|  1 | 鲨鱼   | 巨腮   | 
+----+--------+--------+

mysql> select * from T_bird;
+----+--------+--------------------+
| id | name   | swing              |
+----+--------+--------------------+
|  1 | 鸵鸟   | 不会飞的翅膀       | 
+----+--------+--------------------+

*/
