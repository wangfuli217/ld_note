package entity;

import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name="T_fish")
public class Fish extends Animal {
	private String gill; //腮

	public String getGill() {	return gill;}
	public void setGill(String gill) {this.gill = gill;}

}
