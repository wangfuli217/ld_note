package test;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import entity.Animal;
import entity.Bird;
import entity.Fish;

public class Test {

	public static void main(String[] args) {
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("AnimalPU");
		EntityManager em = emf.createEntityManager();
		
		em.getTransaction().begin();
		
		Animal a = new Animal(); //把Animal改成普通类了，不再是抽象的
		a.setName("动物");
		em.persist(a);
		
		Fish fish = new Fish();
		fish.setName("天池之鱼");
		fish.setGill("没有见过");

		Bird bird = new Bird();
		bird.setName("凤凰");
		bird.setSwing("神话翅膀");
		
		em.persist(fish);
		em.persist(bird);
		
		em.getTransaction().commit();
	}

}


/*
导包：数据库驱动，HibernateJPA支持

打印结果：
log4j:WARN No appenders could be found for logger (org.hibernate.ejb.Version).
log4j:WARN Please initialize the log4j system properly.
Hibernate: insert into Animal (name, type) values (?, 'animal')
Hibernate: insert into Animal (name, gill, type) values (?, ?, 'fish')
Hibernate: insert into Animal (name, swing, type) values (?, ?, 'bird')


mysql里的表：(先清空之前的表；只建立这一张表) 
mysql> select * from Animal;
+--------+----+--------------+--------------+--------------+
| type   | id | name         | swing        | gill         |
+--------+----+--------------+--------------+--------------+
| animal |  1 | 动物         | NULL         | NULL         | 
| fish   |  2 | 天池之鱼     | NULL         | 没有见过     | 
| bird   |  3 | 凤凰         | 神话翅膀     | NULL         | 
+--------+----+--------------+--------------+--------------+


*/