package test;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import entity.Animal;
import entity.Bird;
import entity.Fish;

public class TestQuery {
	public static void main(String[] args){
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("AnimalPU");
		EntityManager em = emf.createEntityManager();
		
		//查询所有的动物
		String ql = "from Animal";
		List<Animal> animals = em.createQuery(ql).getResultList();
		for(Animal a:animals){
			System.out.print(a.getClass()+": " + a.getName()+" ");
			
			if(a instanceof Fish){
				Fish fish = (Fish) a;
				System.out.println(fish.getGill());continue;
			}
			
			if(a instanceof Bird){
				Bird bird = (Bird) a;
				System.out.println(bird.getSwing());continue;
			}
			
			if(a instanceof Animal){System.out.println();}
		}
	}

}

/*
 先运行Test，插入内容
 打印结果：
log4j:WARN No appenders could be found for logger (org.hibernate.ejb.Version).
log4j:WARN Please initialize the log4j system properly.
Hibernate: select animal0_.id as id0_, animal0_.name as name0_, animal0_.swing as swing0_, animal0_.gill as gill0_, animal0_.type as type0_ from Animal animal0_
class entity.Animal: 动物 
class entity.Fish: 天池之鱼 没有见过
class entity.Bird: 凤凰 神话翅膀


 */
