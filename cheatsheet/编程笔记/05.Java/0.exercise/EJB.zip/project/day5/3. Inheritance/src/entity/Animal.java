package entity;

import javax.persistence.DiscriminatorColumn;
import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;

@Entity
@Inheritance(strategy=InheritanceType.SINGLE_TABLE) //一棵继承树一张表
@DiscriminatorColumn(name="type") //用来区分各子类的列，不写也会自动产生一个字段
@DiscriminatorValue("animal") //来用鉴别的各个类的值，如果这个不是抽象类，就可以用这个了
public class Animal {
	
	@Id
	@GeneratedValue
	private int id;
	private String name;
	
	public int getId() {return id;}
	public void setId(int id) {this.id = id;}
	
	public String getName() {	return name;}
	public void setName(String name) {	this.name = name;}
	
	

}
