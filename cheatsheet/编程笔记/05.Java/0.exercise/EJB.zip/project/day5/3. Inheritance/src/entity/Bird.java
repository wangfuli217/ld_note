package entity;

import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name="T_bird")
@DiscriminatorValue("bird") //来用鉴别的各个类的值
public class Bird extends Animal {
	private String swing;

	public String getSwing() {
		return swing;
	}

	public void setSwing(String swing) {
		this.swing = swing;
	}
	

}
