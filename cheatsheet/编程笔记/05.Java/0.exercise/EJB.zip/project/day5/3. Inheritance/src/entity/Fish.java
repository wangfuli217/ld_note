package entity;

import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name="T_fish")
@DiscriminatorValue("fish") //来用鉴别的各个类的值
public class Fish extends Animal {
	private String gill; //腮

	public String getGill() {	return gill;}
	public void setGill(String gill) {this.gill = gill;}

}
