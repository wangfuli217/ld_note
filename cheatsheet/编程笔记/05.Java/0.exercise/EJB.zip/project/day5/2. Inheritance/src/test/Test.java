package test;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import entity.Bird;
import entity.Fish;

public class Test {

	public static void main(String[] args) {
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("AnimalPU");
		EntityManager em = emf.createEntityManager();
		
		em.getTransaction().begin();
		
		Fish fish = new Fish();
		fish.setName("大马哈鱼");
		fish.setGill("大腮");

		Bird bird = new Bird();
		bird.setName("布谷鸟");
		bird.setSwing("大翅膀");
		
		em.persist(fish);
		em.persist(bird);
		
		em.getTransaction().commit();
	}

}


/*
导包：数据库驱动，HibernateJPA支持

打印结果：
log4j:WARN No appenders could be found for logger (org.hibernate.ejb.Version).
log4j:WARN Please initialize the log4j system properly.
Hibernate: insert into Animal (name) values (?)
Hibernate: insert into T_fish (gill, id) values (?, ?)
Hibernate: insert into Animal (name) values (?)
Hibernate: insert into T_bird (swing, id) values (?, ?)

mysql里的表：(先清空之前的表) 
mysql> select * from Animal;
+----+--------------+
| id | name         |
+----+--------------+
|  1 | 大马哈鱼     | 
|  2 | 布谷鸟       | 
+----+--------------+

mysql> select * from T_fish;
+----+--------+
| id | gill   |
+----+--------+
|  1 | 大腮   | 
+----+--------+

mysql> select * from T_bird;
+----+-----------+
| id | swing     |
+----+-----------+
|  2 | 大翅膀    | 
+----+-----------+

*/