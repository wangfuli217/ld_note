package test;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import entity.Animal;
import entity.Bird;
import entity.Fish;

public class TestQuery {
	public static void main(String[] args){
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("AnimalPU");
		EntityManager em = emf.createEntityManager();
		
		//查询所有的动物
		String ql = "from Animal";
		List<Animal> animals = em.createQuery(ql).getResultList();
		for(Animal a:animals){
			System.out.println(a.getName());
			if(a instanceof Fish){
				Fish fish = (Fish) a;
				System.out.println(fish.getGill());
			}
			
			if(a instanceof Bird){
				Bird bird = (Bird) a;
				System.out.println(bird.getSwing());
			}
		}
	}

}

/*
 先运行Test，插入内容
 打印结果：
 log4j:WARN No appenders could be found for logger (org.hibernate.ejb.Version).
log4j:WARN Please initialize the log4j system properly.
Hibernate: select animal0_.id as id0_, animal0_.name as name0_, animal0_1_.swing as swing1_, animal0_2_.gill as gill2_, case when animal0_1_.id is not null then 1 when animal0_2_.id is not null then 2 when animal0_.id is not null then 0 end as clazz_ from Animal animal0_ left outer join T_bird animal0_1_ on animal0_.id=animal0_1_.id left outer join T_fish animal0_2_ on animal0_.id=animal0_2_.id
大马哈鱼
大腮
布谷鸟
大翅膀
 
 */
