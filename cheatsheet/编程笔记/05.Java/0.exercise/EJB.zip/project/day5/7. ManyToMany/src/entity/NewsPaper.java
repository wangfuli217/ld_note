package entity;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.ManyToMany;

@Entity
public class NewsPaper {
	@Id
	@GeneratedValue
	private int id;
	private String name;	
	
	@ManyToMany(mappedBy="papers") //放弃维护中间表，变成ManyToOne关系了
	//默认维护的(即另外建表NewsPaper_Reader来维护) 
	private List<Reader> readers = new ArrayList<Reader>();
		
	public int getId() {return id;}
	public void setId(int id) {this.id = id;}
	
	public String getName() {return name;	}
	public void setName(String name) {this.name = name;}
	
	public List<Reader> getReaders() {	return readers;}
	public void setReaders(List<Reader> readers) {this.readers = readers;}	
	
}
