package test;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import entity.NewsPaper;
import entity.Reader;

public class Test {

    public static void main(String[] args) {
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("Many2ManyPU");
        EntityManager em = emf.createEntityManager();
        
        em.getTransaction().begin();
        
        //维护读者的记录
        Reader r1 = new Reader();
        r1.setName("张三");
        em.persist(r1);        
        Reader r2 = new Reader();
        r2.setName("李四");
        em.persist(r2);
        
        //维护报纸的记录
        NewsPaper p1 = new NewsPaper();
        p1.setName("广州日报");
        em.persist(p1);
        NewsPaper p2 = new NewsPaper();
        p2.setName("羊城晚报");
        em.persist(p2);
        
        em.getTransaction().commit();
    }

}

/*
 这是EJB工程
 导包：数据库驱动，HibernateJPA支持
 
 打印结果：
log4j:WARN No appenders could be found for logger (org.hibernate.ejb.Version).
log4j:WARN Please initialize the log4j system properly.
Hibernate: insert into Reader (name) values (?)
Hibernate: insert into Reader (name) values (?)
Hibernate: insert into NewsPaper (name) values (?)
Hibernate: insert into NewsPaper (name) values (?)


    
数据库的表：
mysql> show tables;
+---------------+
| Tables_in_jpa |
+---------------+
| NewsPaper     | 
| Reader        | 
| reader_paper  | 
+---------------+
3 rows in set (0.00 sec)

mysql> select * from NewsPaper;
+----+--------------+
| id | name         |
+----+--------------+
|  1 | 广州日报     | 
|  2 | 羊城晚报     | 
+----+--------------+
2 rows in set (0.00 sec)

mysql> select * from Reader;
+----+--------+
| id | name   |
+----+--------+
|  1 | 张三   | 
|  2 | 李四   | 
+----+--------+
2 rows in set (0.01 sec)

mysql> select * from reader_paper;
Empty set (0.00 sec)

 */
