package test;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import entity.NewsPaper;
import entity.Reader;


@SuppressWarnings("unchecked") //压制泛形警告
public class TestRelation {
	public static void main(String[] args){
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("Many2ManyPU");
        EntityManager em = emf.createEntityManager();
        
        em.getTransaction().begin();
        
        //维护报纸和读者之间的关系
        Reader r1 =em.find(Reader.class, 1);
        List<NewsPaper> papers = em.createQuery("from NewsPaper").getResultList();
        
        r1.setPapers(papers);//订阅报纸
        em.merge(r1);
        
        em.getTransaction().commit();
	}

}

/*
先运行Test，插入读者和报纸信息
打印结果：
log4j:WARN No appenders could be found for logger (org.hibernate.ejb.Version).
log4j:WARN Please initialize the log4j system properly.
Hibernate: select reader0_.id as id0_0_, reader0_.name as name0_0_ from Reader reader0_ where reader0_.id=?
Hibernate: select newspaper0_.id as id1_, newspaper0_.name as name1_ from NewsPaper newspaper0_
Hibernate: delete from reader_paper where reader_id=?
Hibernate: insert into reader_paper (reader_id, paper_id) values (?, ?)
Hibernate: insert into reader_paper (reader_id, paper_id) values (?, ?)

数据库表 (其他的数据库表不变)：
mysql> select * from reader_paper;
+-----------+----------+
| reader_id | paper_id |
+-----------+----------+
|         1 |        1 | 
|         1 |        2 | 
+-----------+----------+
2 rows in set (0.00 sec)

*/
