package entity;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;

@Entity      //读者
public class Reader {
    
    @Id
    @GeneratedValue
    private int id;
    private String name;    
    
    @ManyToMany //加上mappedBy就不维护关系；现在另外建表来维护
    @JoinTable(name="reader_paper"  //定义维护关系的表名；默认维护关系表名： 己方类名_对方类名
        ,joinColumns={@JoinColumn(name="reader_id")} 
        ,inverseJoinColumns={@JoinColumn(name="paper_id")}) 
    private List<NewsPaper> papers = new ArrayList<NewsPaper>(); 
    
    public int getId() {return id;}
    public void setId(int id) {this.id = id;}
    
    public String getName() {return name;    }
    public void setName(String name) {this.name = name;}
    
    public List<NewsPaper> getPapers() {return papers;}
    public void setPapers(List<NewsPaper> papers) {this.papers = papers;}
    
}
