package test;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import entity.Reader;

public class TestEdit {

	//维护读者的信息
	public static void main(String[] args) {
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("Many2ManyPU");
        EntityManager em = emf.createEntityManager();
        
        //查询读者的记录，以便在edit页面中显示
        Reader r = em.find(Reader.class, 1);
        em.close();
        
        //修改读者信息，并且提交
        EntityManager em1 = emf.createEntityManager();
        em1.getTransaction().begin();
        r.setName("张无忌"); //把第一个读者的名字改成 张无忌
        em1.merge(r);
        em1.getTransaction().commit();
	}

}

/* 
先运行TestRelation

打印结果：
log4j:WARN No appenders could be found for logger (org.hibernate.ejb.Version).
log4j:WARN Please initialize the log4j system properly.
Hibernate: select reader0_.id as id0_0_, reader0_.name as name0_0_ from Reader reader0_ where reader0_.id=?
Hibernate: select reader0_.id as id0_0_, reader0_.name as name0_0_ from Reader reader0_ where reader0_.id=?
Hibernate: update Reader set name=? where id=?

数据库表(其他表不变)：
mysql> select * from Reader;
+----+-----------+
| id | name      |
+----+-----------+
|  1 | 张无忌    | 
|  2 | 李四      | 
+----+-----------+
2 rows in set (0.00 sec)

*/