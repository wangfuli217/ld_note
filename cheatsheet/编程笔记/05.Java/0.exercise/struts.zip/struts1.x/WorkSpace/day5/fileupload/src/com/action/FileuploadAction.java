package com.action;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.upload.FormFile;

import com.form.FileUploadForm;

public class FileuploadAction extends Action {

	@Override
	public ActionForward execute(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {
		FileUploadForm frm = (FileUploadForm)form;
		FormFile formfile = frm.getFile();
		
		InputStream is = formfile.getInputStream();
		String filepath = "d:\\temp\\" + formfile.getFileName();
		
		byte[] databuffer = new byte[formfile.getFileSize()];
		try {
			FileOutputStream fos = new FileOutputStream(filepath);
			while(is.read(databuffer) != -1) {
				fos.write(databuffer);
			}
		} catch (IOException e) {
			//e.printStackTrace();
		}
		
		return mapping.findForward("success");
	}

}
