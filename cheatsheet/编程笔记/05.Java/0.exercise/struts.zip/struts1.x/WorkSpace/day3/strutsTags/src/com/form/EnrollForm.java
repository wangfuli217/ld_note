package com.form;

import org.apache.struts.action.ActionForm;

public class EnrollForm extends ActionForm {

	private String username;
	private String gender;
	private String city;
	private String[] favors;
	private String[] conn;

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String[] getFavors() {
		return favors;
	}

	public void setFavors(String[] favors) {
		this.favors = favors;
	}

	public String[] getConn() {
		return conn;
	}

	public void setConn(String[] conn) {
		this.conn = conn;
	}

}
