package com.user.action;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.DynaActionForm;
import org.apache.struts.actions.DispatchAction;

public class UserAction extends DispatchAction {
	
	public ActionForward enroll(ActionMapping mapping, ActionForm form,
	        HttpServletRequest request, HttpServletResponse response) {
		
		System.out.println("enroll user");
		
		DynaActionForm daf = (DynaActionForm)form;
		System.out.println(daf.get("username"));
		System.out.println(daf.get("password"));
		System.out.println(daf.get("age"));
		
		
		return mapping.findForward("success");
	}
	
	public ActionForward delete(ActionMapping mapping, ActionForm form,
	        HttpServletRequest request, HttpServletResponse response) {
		System.out.println("delete user");
		
		DynaActionForm daf = (DynaActionForm)form;
		System.out.println(daf.get("username"));
		System.out.println(daf.get("password"));
		System.out.println(daf.get("age"));
		
		
		return mapping.findForward("success");
	}
	
	public ActionForward update(ActionMapping mapping, ActionForm form,
	        HttpServletRequest request, HttpServletResponse response) {
		System.out.println("update user");
		
		DynaActionForm daf = (DynaActionForm)form;
		System.out.println(daf.get("username"));
		System.out.println(daf.get("password"));
		System.out.println(daf.get("age"));
		
		
		return mapping.findForward("success");
	}
	
	public ActionForward query(ActionMapping mapping, ActionForm form,
	        HttpServletRequest request, HttpServletResponse response) {
		System.out.println("query user");
		
		DynaActionForm daf = (DynaActionForm)form;
		System.out.println(daf.get("username"));
		System.out.println(daf.get("password"));
		System.out.println(daf.get("age"));
		
		
		return mapping.findForward("success");
	}

}
