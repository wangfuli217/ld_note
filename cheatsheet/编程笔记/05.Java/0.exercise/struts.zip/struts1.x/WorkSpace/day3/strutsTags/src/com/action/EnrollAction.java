package com.action;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import com.form.EnrollForm;

public class EnrollAction extends Action {

	@Override
	public ActionForward execute(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {
		EnrollForm enrollForm = (EnrollForm) form;
		System.out.println(enrollForm.getCity());
		if (enrollForm.getFavors() != null) {
			System.out.println("favors:");
			for (String favor : enrollForm.getFavors()) {
				System.out.println(favor);
			}
		}
		return mapping.findForward("success");
	}

}
