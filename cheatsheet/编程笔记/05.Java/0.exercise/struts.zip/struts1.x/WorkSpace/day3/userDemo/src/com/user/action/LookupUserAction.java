package com.user.action;

import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.actions.LookupDispatchAction;

public class LookupUserAction extends LookupDispatchAction {

	@Override
	protected Map getKeyMethodMap() {
		Map map = new HashMap();
		map.put("method.enroll", "enrollUser");
		map.put("method.update", "updateUser");
		map.put("method.query", "queryUser");
		map.put("method.delete", "deleteUser");
		return map;
	}

	public ActionForward enrollUser(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response) {
		System.out.println("enroll user.....");
		
		//TODO:business logic
		
		return mapping.findForward("success");
	}

	public ActionForward updateUser(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response) {
		System.out.println("update user.....");
		return mapping.findForward("success");
	}
	
	public ActionForward queryUser(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response) {
		System.out.println("query user.....");
		return mapping.findForward("success");
	}
	
	public ActionForward deleteUser(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response) {
		System.out.println("delete user.....");
		return mapping.findForward("success");
	}

}
