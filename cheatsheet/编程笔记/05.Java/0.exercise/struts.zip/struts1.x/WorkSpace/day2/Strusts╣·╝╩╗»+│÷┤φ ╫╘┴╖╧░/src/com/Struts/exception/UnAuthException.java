package com.Struts.exception;

public class UnAuthException extends Exception {

}
