package com.struts.exception;

public class UnAuthException extends Exception {

}
