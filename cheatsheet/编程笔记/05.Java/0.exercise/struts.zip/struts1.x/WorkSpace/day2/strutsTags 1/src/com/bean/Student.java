package com.bean;

import java.util.ArrayList;
import java.util.List;

public class Student {
	
	private String name;
	private Integer age;
	private String gender;
	
	private List songs;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Integer getAge() {
		return age;
	}

	public void setAge(Integer age) {
		this.age = age;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public List getSongs() {
		List list = new ArrayList();
		list.add("�Ұ������찲��");
		list.add("�Һ���");
		list.add("�Ҳ������ö���");
		return list;
	}

	public void setSongs(List songs) {
		this.songs = songs;
	}

}
