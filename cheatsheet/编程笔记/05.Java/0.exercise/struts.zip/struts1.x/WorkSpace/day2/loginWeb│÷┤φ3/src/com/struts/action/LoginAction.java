package com.struts.action;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.ActionMessage;

import com.struts.exception.UnAuthException;
import com.struts.form.LoginForm;

public class LoginAction extends Action {

	@Override
	public ActionForward execute(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {
		LoginForm loginForm = (LoginForm) form;
		String username = loginForm.getUsername();
		String password = loginForm.getPassword();
		
		
		ActionErrors errors = new ActionErrors();
		if("narci".equals(username)) {
			ActionMessage msg = new ActionMessage("error.username.blacklist");
			errors.add("blacklist", msg);
			this.saveErrors(request, errors);
			return mapping.findForward("current");
		}
		
		boolean isLogin = false;
		if("maxwell".equals(username)) {
			if("456".equals(password))
				throw new UnAuthException();
			if("123".equals(password))
				isLogin = true;
		}
		
		if(isLogin) {
			return mapping.findForward("success");
		}
		
		return mapping.findForward("fail");
	}

}
