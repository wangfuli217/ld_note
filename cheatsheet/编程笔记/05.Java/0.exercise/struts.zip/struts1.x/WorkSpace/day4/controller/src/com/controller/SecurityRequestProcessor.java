package com.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.RequestProcessor;

public class SecurityRequestProcessor extends RequestProcessor {

	@Override
	protected boolean processPreprocess(HttpServletRequest request,
			HttpServletResponse response) {
		System.out.println("start controller ...");
		String ip = request.getRemoteAddr();
		if (ip.equals("127.0.0.1")) {
			System.out.println("valid client: 127.0.0.1");
			return true;
		}
		int lastPoint = ip.lastIndexOf(".");
		String fourth = ip.substring(lastPoint + 1);
		int fourthInt = Integer.parseInt(fourth);
		if (ip.startsWith("192.168.1.") && fourthInt > 50 && fourthInt < 60) {
			System.out.println("invalid client: 192.168.1.[50~60]");
			return false;
		}
		return false;
	}

}
