﻿package com;

import com.opensymphony.xwork2.Action;
import com.opensymphony.xwork2.ActionContext;
/**  实现xwork 里提供 Action接口  */
public class LogonAction implements Action {
	
	private String username;
	private String password;

	public String getUsername() {return username;}
	public void setUsername(String username) {this.username = username;}

	public String getPassword() {return password;}
	public void setPassword(String password) {this.password = password;}

	
	public String execute() throws Exception {
		if("maxwell".equals(username) && "123".equals(password)) {
			/*
			 * Struts2.x框架使用拦截器来完成：
			 * HttpSession.setAttribute("user", username);
			 * 
			 * 原因：使得业务控制器彻底和Servlet API解耦
			 * 
			 */
			ActionContext.getContext().getSession().put("user", username);			
			return this.SUCCESS;
			//return "success";
		} else {
			return this.LOGIN;
			//return "error";
		}
	}

}
