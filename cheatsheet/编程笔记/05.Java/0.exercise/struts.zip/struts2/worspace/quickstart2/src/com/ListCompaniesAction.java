﻿package com;

import java.util.ArrayList;
import java.util.List;

import com.opensymphony.xwork2.Action;
import com.opensymphony.xwork2.ActionContext;
import com.CompanyPojo;

public class ListCompaniesAction implements Action {
	
	private List<CompanyPojo> companies = new ArrayList<CompanyPojo>();

	public List<CompanyPojo> getCompanies() {
		return companies;
	}

	public void setCompanies(List<CompanyPojo> companies) {
		this.companies = companies;
	}

	public String execute() throws Exception {
		
		String user = (String)ActionContext.getContext().getSession().get("user");
		if("maxwell".equals(user)) {
			//TODO:query data from database
			CompanyPojo comp = new CompanyPojo();
			comp.setCompName("Tarena");
			comp.setAddress("天河区岗顶");
			comp.setCity("广州市");
			comp.setEmail("hr@tarena.com.cn");

			CompanyPojo comp1 = new CompanyPojo();
			comp1.setCompName("Tecent");
			comp1.setAddress("深南路55号");
			comp1.setCity("深圳市");
			comp1.setEmail("hr@qq.com.cn");

			CompanyPojo comp2 = new CompanyPojo();
			comp2.setCompName("IBM Research Center(Chinese)");
			comp2.setAddress("王府井3楼");
			comp2.setCity("北京市");
			comp2.setEmail("hr@ibm.com");
			
			this.companies.add(comp);
			this.companies.add(comp1);
			this.companies.add(comp2);
			
			return this.SUCCESS;
		} else {
			return this.ERROR;
		}
		
	}

}
