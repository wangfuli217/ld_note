package com;

public class CompanyPojo {

	private String compName;
	private String address;
	private String city;
	private String email;


	public String getCompName() {return compName;}
	public void setCompName(String compName) {this.compName = compName;}

	public String getAddress() {	return address;}
	public void setAddress(String address) { this.address = address;}

	public String getCity() {	return city;}
	public void setCity(String city) {	this.city = city;}

	public String getEmail() {	return email;}
	public void setEmail(String email) {this.email = email;}

}
