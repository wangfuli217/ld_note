package com;

import java.util.ArrayList;
import java.util.List;

import com.opensymphony.xwork2.Action;
import com.opensymphony.xwork2.ActionContext;
import com.pojo.Company;

public class ListCompaniesAction implements Action {
	
	private List<Company> companies = new ArrayList<Company>();

	public List<Company> getCompanies() {
		return companies;
	}

	public void setCompanies(List<Company> companies) {
		this.companies = companies;
	}

	public String execute() throws Exception {
		
		String user = (String)ActionContext.getContext().getSession().get("user");
		if("maxwell".equals(user)) {
			//TODO:query data from database
			Company comp = new Company();
			comp.setCompName("Tarena");
			comp.setAddress("������ڶ�");
			comp.setCity("������");
			comp.setEmail("hr@tarena.com.cn");

			Company comp1 = new Company();
			comp1.setCompName("Tecent");
			comp1.setAddress("����·55��");
			comp1.setCity("������");
			comp1.setEmail("hr@qq.com.cn");

			Company comp2 = new Company();
			comp2.setCompName("IBM Research Center(Chinese)");
			comp2.setAddress("������3¥");
			comp2.setCity("������");
			comp2.setEmail("hr@ibm.com");
			
			this.companies.add(comp);
			this.companies.add(comp1);
			this.companies.add(comp2);
			
			ActionContext.getContext().getSession().put("companies", this.companies);
			
			return this.SUCCESS;
		} else {
			return this.ERROR;
		}
		
	}

}
