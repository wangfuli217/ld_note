#include "stdafx.h"
#include "LuaVM.h"

LuaVM* LuaVM::pInstance = NULL;

LuaVM::LuaVM()
{
	for (int idx = 0; idx < sizeof(insExecute) / sizeof(InsExecuteFun); ++idx)
	{
		insExecute[idx] = NULL;
	}

	insExecute[(int)OP_LOADK] = &LuaVM::LoadK;
	insExecute[(int)OP_SETGLOBAL] = &LuaVM::SetGlobal;
	insExecute[(int)OP_GETGLOBAL] = &LuaVM::GetGlobal;
	insExecute[(int)OP_ADD] = &LuaVM::_Add;
	insExecute[(int)OP_SUB] = &LuaVM::_Sub;
	insExecute[(int)OP_MUL] = &LuaVM::_Mul;
	insExecute[(int)OP_DIV] = &LuaVM::_Div;
	insExecute[(int)OP_CALL] = &LuaVM::_Call;
	insExecute[(int)OP_MOD] = &LuaVM::_Mod;
	insExecute[(int)OP_LT] = &LuaVM::_LT;
	insExecute[(int)OP_JMP] = &LuaVM::_JMP;
	insExecute[(int)OP_RETURN] = &LuaVM::_Return;

	jumpPcCount = 0;
}



LuaVM::~LuaVM()
{
}

void LuaVM::Execute()
{
	printf("\n-----------Begin of Run LuaCode--------------");
	//printf("Execute:InsCount:%d", instrunctionList.size());
	std::list<LuaInstrunction>::iterator insIter = instrunctionList.begin();
	int execSuc = 0;
	for (; insIter != instrunctionList.end(); ++insIter)
	{
		bool excSuc = false;
		InsExecuteFun insExecFunc = this->insExecute[(int)(*insIter).opCode];

		if (insExecFunc != NULL)
		{
			excSuc = (this->*insExecFunc)((*insIter));
		}

		if (!excSuc)
		{
			printf("\nError:execute error,insIndex:%d,opCode:%d\n", (execSuc + 1), (int)(*insIter).opCode);
			return;
		}
		else
		{
			++execSuc;
			for (int idx = 0; idx < jumpPcCount; ++idx)
			{
				++insIter;
			}
			jumpPcCount = 0;
		}
	}

	printf("\n-----------End of Run LuaCode--------------");
}

bool LuaVM::_Return(LuaInstrunction ins)
{
	//do nothing
	return true;
}

bool LuaVM::_LT(LuaInstrunction ins)
{
	//LT: if(RK(B) < RK(C) ~= A) then PC++
	//Get RA
	//0��false�� ����ֵΪtrue
	bool isTrue = !(luaRegisters[ins.aValue].GetVaule() < 0.01 && luaRegisters[ins.aValue].GetVaule() > -0.01);

	if (GetBK(ins.bValue) < GetBK(ins.cValue) != isTrue)
	{
		//++pc;
		jumpPcCount = 1;
	}

	return true;
}

bool LuaVM::_JMP(LuaInstrunction ins)
{
	//jmp sbx:
	jumpPcCount = ins.sbxValue;

	return true;
}


bool LuaVM::_Call(LuaInstrunction ins)
{
	//ֻ����һ�������ĵ��ã�
	//ʵ��print��
	//R(A)����Ҫ�����õĺ������������  
	//������  R(A+1)��
	if (ins.aValue > REG_MAXSIZE)
	{
		printf("Error:_Add,aValue > REG_MAXSIZE:%d", ins.aValue);
		return false;
	}

	if (luaRegisters[ins.aValue].IsSameValue("print"))
	{
		//ֱ��Print��
		if (luaRegisters[ins.aValue + 1].isNumber())
		{
			printf("\nLuaPrint:%f", luaRegisters[ins.aValue + 1].GetVaule());
		}
		else
		{
			printf("\nLuaPrint:%s", luaRegisters[ins.aValue + 1].GetStrV());
		}
	}
	else
	{
		printf("\nCallFunction,but not support:%s", luaRegisters[ins.aValue].GetVauleName());
	}

	return true;
}


bool LuaVM::_Add(LuaInstrunction ins)
{
	//R(A):=RK(B)+RK(C) :::  
	if (ins.aValue > REG_MAXSIZE)
	{
		printf("Error:_Add,aValue > REG_MAXSIZE:%d", ins.aValue);
		return false;
	}

	luaRegisters[ins.aValue].SetValue(0, GetBK(ins.bValue) + GetBK(ins.cValue));

	return true;
}

bool LuaVM::_Sub(LuaInstrunction ins)
{
	//R(A):=RK(B)+RK(C) :::  
	if (ins.aValue > REG_MAXSIZE)
	{
		printf("Error:_Add,aValue > REG_MAXSIZE:%d", ins.aValue);
		return false;
	}

	luaRegisters[ins.aValue].SetValue(0, GetBK(ins.bValue) - GetBK(ins.cValue));

	return true;
}

bool LuaVM::_Mul(LuaInstrunction ins)
{
	//R(A):=RK(B)+RK(C) :::  
	if (ins.aValue > REG_MAXSIZE)
	{
		printf("Error:_Add,aValue > REG_MAXSIZE:%d", ins.aValue);
		return false;
	}

	luaRegisters[ins.aValue].SetValue(0, GetBK(ins.bValue) * GetBK(ins.cValue));

	return true;
}

bool LuaVM::_Div(LuaInstrunction ins)
{
	//R(A):=RK(B)+RK(C) :::  
	if (ins.aValue > REG_MAXSIZE)
	{
		printf("Error:_Add,aValue > REG_MAXSIZE:%d", ins.aValue);
		return false;
	}

	luaRegisters[ins.aValue].SetValue(0, GetBK(ins.bValue) / GetBK(ins.cValue));

	return true;
}

bool LuaVM::_Mod(LuaInstrunction ins)
{
	//R(A):=RK(B)+RK(C) :::  
	if (ins.aValue > REG_MAXSIZE)
	{
		printf("Error:_Add,aValue > REG_MAXSIZE:%d", ins.aValue);
		return false;
	}

	luaRegisters[ins.aValue].SetValue(0, (int)GetBK(ins.bValue) % (int)GetBK(ins.cValue));

	return true;
}

double LuaVM::GetBK(int idx)
{
	//���Ǻ�����˼��һ��������
	//�����Ĵ�������ֵ��������һ���㷨�������üĴ���������
	//Lua �Ĵ���Ӧ����255������?�µ�
	//demo��������Ͼ��õ�������
	int regMaxSize = 256;
	if (idx < regMaxSize)
	{
		return luaRegisters[idx].GetVaule();
	}
	else
	{
		return luaContest[idx - 256].GetVaule();
	}
}


bool LuaVM::LoadK(LuaInstrunction ins)
{
	//R(A) := Kst(Bx) ��Bx�ų�������Ĵ���R(A)
	//��鳣��ֵ��
	if (ins.bxValue > CONESTV_MAXSIZE)
	{
		printf("Error:LoadK,bxV > CONESTV_MAXSIZE:%d", ins.bxValue);
		return false;
	}

	if (ins.aValue > REG_MAXSIZE)
	{
		printf("Error:LoadK,aValue > REG_MAXSIZE:%d", ins.aValue);
		return false;
	}

	luaRegisters[ins.aValue].LoadVaule(luaContest[ins.bxValue]);

	return true;
}




bool LuaVM::GetGlobal(LuaInstrunction ins)
{
	//R(A) := GBL[Kst[Bx]]  �ѼĴ���R��A����ֵ������ ����ΪBx�ó�����ȫ�ֱ����У�
	if (ins.bxValue > CONESTV_MAXSIZE)
	{
		printf("Error:LoadK,bxV > CONESTV_MAXSIZE:%d", ins.bxValue);
		return false;
	}
	if (ins.aValue > REG_MAXSIZE)
	{
		printf("Error:LoadK,aValue > REG_MAXSIZE:%d", ins.aValue);
		return false;
	}

	LuaValues* value = GetGlobal(luaContest[ins.bxValue].GetStrV());
	luaRegisters[ins.aValue].LoadVaule(*value);

	return true;
}

bool LuaVM::SetGlobal(LuaInstrunction ins)
{
	//GBL[Kst[Bx]] := R(A)  �ѼĴ���R��A����ֵ������ ����ΪBx�ó�����ȫ�ֱ����У�
	if (ins.bxValue > CONESTV_MAXSIZE)
	{
		printf("Error:LoadK,bxV > CONESTV_MAXSIZE:%d", ins.bxValue);
		return false;
	}
	if (ins.aValue > REG_MAXSIZE)
	{
		printf("Error:LoadK,aValue > REG_MAXSIZE:%d", ins.aValue);
		return false;
	}
	SetGlobal(luaRegisters[ins.aValue], luaContest[ins.bxValue].GetStrV());
	return true;
}



void LuaVM::SetGlobal(LuaValues luaV, const char* valueName)
{
	for (std::list<LuaValues*>::iterator iter = golbalValueList.begin(); iter != golbalValueList.end(); ++iter)
	{
		if ((*iter)->IsSameValue(valueName))
		{
			(*iter)->LoadVaule(luaV);
			return;
		}
	}

	LuaValues* newV = new LuaValues();
	newV->LoadVaule(luaV);
	newV->SetValueName(valueName);
	golbalValueList.push_back(newV);
}

LuaValues* LuaVM::GetGlobal(const char* valueName)
{
	for (std::list<LuaValues*>::iterator iter = golbalValueList.begin(); iter != golbalValueList.end(); ++iter)
	{
		if ((*iter)->IsSameValue(valueName))
		{
			return (*iter);
		}
	}

	//��ʼ��������Ǹ�nilֵ
	LuaValues* newV = new LuaValues();
	//newV->LoadVaule(luaV);
	newV->SetValueName(valueName);
	golbalValueList.push_back(newV);

	return newV;
}