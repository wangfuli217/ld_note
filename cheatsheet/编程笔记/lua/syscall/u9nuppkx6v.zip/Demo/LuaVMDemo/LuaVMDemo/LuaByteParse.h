#pragma once
#include "StdAfx.h"
#include <string>
#include <list>
#include"LuaInstructionPrase.h"

#define FileHeaderLen 12

enum ParseLuaByteError
{
	E_ParseOK = 0,
	E_FileNotExist,
	E_FilePointNULL,
	E_FileHeaderError,
	E_BufferOutOfRange,
};

struct LuaContestValue
{
	LuaContestValue() : contestType(0), contestIValue(0), contestSVaule(""){}
	long contestType;              
	double contestIValue;            //03 ��int
	std::string contestSVaule;    //04 ��string
};

struct LuaLocalValue
{
	std::string valueName;
	long startPc;
	long endPc;
	long valueIndex;
};




class LuaByteParse
{
public:
	LuaByteParse(void);
	~LuaByteParse(void);

	void SetLastError(ParseLuaByteError err);
	ParseLuaByteError _GetLastError();

	void InitReader(const char* filePath);
	
	void Prase();

protected:
	//����ģ��Ľ���
	void PraseHeader();              //�����ļ�ͷ
	void PraseFunction();     //�������㺯��



	//ԭ�����ȵĽ���
	void PraseString(std::string& outString);
	void ParseByte(unsigned char& outChar);
	void ParseLong(long& outV);
	void ParseLuaNumber(double& outV);
	void ParseContestValue(LuaContestValue& contestV);
	void ParseLocalVaule(LuaLocalValue& outV);

	//��ͷϷ��ָ��Ľ�����


protected:
	ParseLuaByteError lastError;
	unsigned char* fileBuffer;
	int currentOffset;
	int bufferSize;

	//�Ĵ�����
	//100���Ĵ�����100��������
	//LuaValues luaRegisters[100];
	//LuaValues luaContest[100];
	//LuaValues golbalValue[100];
	//std::list<LuaInstrunction> instrunctionList;
};

