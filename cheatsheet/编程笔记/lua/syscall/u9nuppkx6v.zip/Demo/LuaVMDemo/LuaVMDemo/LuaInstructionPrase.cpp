#include "StdAfx.h"
#include "LuaInstructionPrase.h"
#include<sstream>  


LuaInstructionPrase::LuaInstructionPrase(void)
{
}


LuaInstructionPrase::~LuaInstructionPrase(void)
{
}

void LuaInstructionPrase::ParseInstruction(long instruction, std::string& outStr, LuaInstrunction& luaInstrunction)
{
	const char opCodeName[38][20] = {"MOVE     ", "LOADK    ", "LOADBOOL ", "LOADNIL  ", "GETUPVAL ",
									 "GETGLOBAL", "GETTABLE ", "SETGLOBAL", "SETUPVAL ", "SETTABLE ",
									 "NEWTABLE ", "SELF     ", "ADD      ", "SUB      ", "MUL      "
									,"DIV      ", "MOD      ", "POW      ", "UNM      ", "NOT      "
									,"LEN      ", "CONCAT   ", "JMP      ", "EQ       ", "LT       "
									,"LE       ", "TEST     ", "TESTTEST ", "CALL     ", "TAILCALL "
									,"RETURN   ", "FORLOOP  ", "FORPREP  ", "TFORLOOP ", "SETLIST  "
									,"CLOSE    ", "CLOSURE  ", "VARARG   "};

	long opCodeLong = instruction & 0x3f;
	//�Ȼ�ȡָ���룺����λ��
	long aValue = 0;
	long bValue = 0;
	long cValue = 0;
	long bxValue = 0;
	long sbxValue = 0;

	//6~15λ
	aValue = instruction & 0x3fc0;
	aValue = aValue >> 6;
	//16~23λ
	bValue = instruction & 0x7fc000;
	bValue = bValue >> 14;
	//24~31λ
	cValue = instruction & 0xff800000;
	cValue = cValue >> 23;
	bxValue = instruction & 0xffffc000;
	bxValue = bxValue >> 14;
	sbxValue = bxValue + 131073/*0001 1111 1111 1111 1111*/;

	if (aValue < 0)
	{
		aValue += 512;
	}
	if (bValue < 0)
	{
		bValue += 512;
	}
	if (cValue < 0)
	{
		cValue += 512;
	}


	luaInstrunction.opCode = (LuaOpCode)opCodeLong;
	luaInstrunction.aValue = aValue;
	luaInstrunction.bValue = bValue;
	luaInstrunction.cValue = cValue;
	luaInstrunction.bxValue = bxValue;
	luaInstrunction.sbxValue = sbxValue;

	if(opCodeLong >= 38)
	{
		outStr = "\nOpCodeError:";
		outStr += opCodeLong;
		return;
	}
	
	//Tableϵ��ָ����ԣ�
	//UNM,NOT,LEN,CONCAT

	LuaOpCode eOpcode = (LuaOpCode)opCodeLong;
	std::stringstream ss; 
	ss << "\n" << std::hex << instruction << ":" << opCodeName[opCodeLong];
	switch(eOpcode)
	{
	case OP_MOVE:
		{
			//MOVE A,B  === R(A) := R(B)	
			ss << " " << aValue << "," << bValue;
		}break;
	case OP_LOADNIL:
		{
			//LOADNIL A,B ==== R(A) :=...:= R(B) := nil
			ss << " " << aValue << "," << bValue;
		}break;
	case OP_LOADK:
		{
			//LOADK A, Bx === R(A):=Kst(Bx)
			ss << " " << aValue << "," << bxValue;
		}break;
	case OP_LOADBOOL:
		{
			//LoadBool A B C==> R(A):=(BOOL)B:if(C)PC++
			ss << " " << aValue << "," << bValue << "," << cValue;
		}break;
	case OP_GETGLOBAL:
		{
			//GetGlobal A Bx ==> R(A):=Gbl[Kst(Bx)]
			ss << " " << aValue << "," << bxValue;
		}break;
	case OP_SETGLOBAL:
		{
			//SetGlobal A Bx ==>Gbl[Kst(Bx)]:=R(A)
			ss << " " << aValue << "," << bxValue;
		}break;
	case OP_GETUPVAL:
		{
			//GetUPV A B ==>R(A):=UPVALUE[B]
			ss << " " << aValue << "," << bValue;
		}break;
	case OP_SETUPVAL:
		{
			//SetUPV A B ==>UPVALUE[B]=R(A)
			ss << " " << aValue << "," << bValue;
		}break;
	
	case OP_ADD:
		{
			//ADD A,B,C  ==> R(A):=RK(B)+RK(C)
			ss << " " << aValue << "," << bValue << "," << cValue;
		}break;
	case OP_SUB:
		{
			//SUB A,B,C  ==> R(A):=RK(B)-RK(C)
			ss << " " << aValue << "," << bValue << "," << cValue;
		}break;
	case OP_MUL:
		{
			//MUL A,B,C  ==> R(A):=RK(B)*RK(C)
			ss << " " << aValue << "," << bValue << "," << cValue;
		}break;
	case OP_DIV:
		{
			//DIV A,B,C  ==> R(A):=RK(B)/RK(C)
			ss << " " << aValue << "," << bValue << "," << cValue;
		}break;
	case OP_MOD:
		{
			//MOD A,B,C  ==> R(A):=RK(B)%RK(C)
			ss << " " << aValue << "," << bValue << "," << cValue;
		}break;
	case OP_POW:
		{
			//POW A,B,C  ==> R(A):=RK(B)^RK(C)
			ss << " " << aValue << "," << bValue << "," << cValue;
		}break;
	case OP_JMP:
		{
			//JMP sBx  PC += sBX
			ss << " " << sbxValue;
		}break;
	case OP_LT:
		{
			//LT: if(RK(B) < RK(C) ~= A) then PC++
			ss << " " << aValue << "," << bValue << "," << cValue;
		}break;
	case OP_CALL:
		{
			//Call a b c ==> R(A),...,R(A+c-2):=R(A)(R(A+1), ..., R(A+B-1))
			ss << " " << aValue << "," << bValue << "," << cValue;
		}break;
	case OP_RETURN:
		{
			//Return A B   ===> return R(A), ..., R(A+B-2)
			ss << " " << aValue << "," << bValue;
		}break;
	case OP_TAILCALL:
		{
			//TAILCALL ABC
			ss << " " << aValue << "," << bValue << "," << cValue;
		}break;
	case OP_CLOSURE:
		{
			//OP_CLOSURE A BX
			ss << " " << aValue << "," << bxValue;
		}break;
	default:
		break;
	}

	outStr = ss.str().c_str();
}