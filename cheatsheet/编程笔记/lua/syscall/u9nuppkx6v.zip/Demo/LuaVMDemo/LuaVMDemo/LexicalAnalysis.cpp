#include "StdAfx.h"
#include "LexicalAnalysis.h"
#include<sstream>  

LexicalAnalysis* LexicalAnalysis::pInstance = NULL;

LexicalAnalysis::LexicalAnalysis(void)
{
	strContext = "if a < b then a = c end ";
	//strContext = "if a < b a = c end ";
	currentReadCount = 0;
	currentReadTokenPos = 0;
}


LexicalAnalysis::~LexicalAnalysis(void)
{
}

void LexicalAnalysis::DoLexical()
{
	std::string strWord = "";

	while(GetWord(strWord))
	{
		LexToken lexToken = LexToken();
		lexToken.tokenValue = strWord;
		lexToken.tokenType = GetTokenType(strWord);
		lexTokenList.push_back(lexToken);
	}
}

void LexicalAnalysis::Analysis()
{
	currentReadTokenPos = 0;

	//list<string>::iterator iter=lstStr.begin();  
	//advance(iter,3-1);//ȡ���е�����Ԫ��  
	LexToken token = GetTokenByIndex(currentReadTokenPos);

	if(token.tokenType == TokenType_If)
	{
		++currentReadTokenPos;
		if(!ReadExp(ifStateMent.conditionExp))
		{
			return;
		}

		if(!ReadThen())
		{
			return;
		}

		if(!ReadContext(ifStateMent.contextValue))
		{
			return;
		}
		
		if(!ReadEnd())
		{
			return;
		}
	}

	//�﷨��ת��ָ���
	//�����б���
	ifStateMent.GetIns();
}

std::string IfStateMent::GetIns()
{
	//�ȶ� ifStateMent.conditionExp ��ֵ���������0�żĴ������棺
	//�ٶ� ifStateMent.contextValue ������д��������jump�������
	//

	//�� ifStateMent.conditionExp ��ֵ
	int aIdx = PutIntoContest(conditionExp.valueA.c_str());
	int bIdx = PutIntoContest(conditionExp.valueB.c_str());

	int regIdx = 10;
	std::stringstream str;

	str << "\nGetGlobal " << regIdx << "," << aIdx;
	++regIdx;
	str << "\nGetGlobal " << regIdx << "," << bIdx;
	str << "\n LT " << regIdx + 1 << ", " << regIdx - 1 << "," << regIdx;

	std::string strCC = "";
	int coCount = GetContextValueIns(strCC, regIdx + 3);

	str << "\nJmp " << coCount << strCC;
	str << "\n Return";
	str << "\n\nContest:::";
	int ida = 0;
	for(std::list<std::string>::iterator it = listContestString.begin(); it != listContestString.end(); ++it)
	{
		str << "\nContest:" << ida << ",Value:" << (*it).c_str();
		++ida;
	}
	str << "\n\nContest End\n";
	printf("----------------------INS Begin---------------------------");
	printf("\n%s\n", str.str().c_str());
	printf("----------------------INS End  ---------------------------");

	return str.str();
}

int IfStateMent::GetContextValueIns(std::string& strOut, int regIdx)
{
	std::stringstream str;
	int retCount = 0;

	int aIdx = PutIntoContest(contextValue.leftV.c_str());
	int bIdx = PutIntoContest(contextValue.rightContestV.c_str());

	str << "\nGetGlobal " << regIdx + 1 << "," << bIdx;
	++retCount;
	str << "\nMove " << regIdx + 2 << "," << regIdx + 1;
	++retCount;
	str << "\nSetGlobal " << aIdx << "," << regIdx + 2;
	++retCount;
	strOut = str.str().c_str();
	return retCount;
}

int IfStateMent::PutIntoContest(const char* vName)
{
	int idx = 0;
	for(std::list<std::string>::iterator it = listContestString.begin(); it != listContestString.end(); ++it)
	{
		if((*it) == vName)
		{
			return idx;
		}
		++idx;
	}

	listContestString.push_back(std::string(vName));
	return listContestString.size() - 1;
}

bool LexicalAnalysis::ReadExp(OpExpStateMent& opExp)
{
	LexToken token = GetTokenByIndex(currentReadTokenPos);
	if(token.tokenType == TokenType_Var)
	{
		opExp.valueA = token.tokenValue;
	}
	++currentReadTokenPos;
	token = GetTokenByIndex(currentReadTokenPos);
	if(token.tokenType != TokenType_OpLess)
	{
		printf("Compile Error: No Option!");
		return false;
	}
	++currentReadTokenPos;
	token = GetTokenByIndex(currentReadTokenPos);
	if(token.tokenType == TokenType_Var)
	{
		opExp.valueB = token.tokenValue;
		++currentReadTokenPos;
		return true;
	}

	return false;
}

bool LexicalAnalysis::ReadThen()
{
	LexToken token = GetTokenByIndex(currentReadTokenPos);
	if(token.tokenType != TokenType_Then)
	{
		printf("Compile Error: if should pairs then");
		return false;
	}
	else
	{
		++currentReadTokenPos;
	}

	return true;
}

bool LexicalAnalysis::ReadContext(EqualExpStateMent& eqExp)
{
	LexToken token = GetTokenByIndex(currentReadTokenPos);
	if(token.tokenType == TokenType_Var)
	{
		eqExp.leftV = token.tokenValue;
	}
	++currentReadTokenPos;
	token = GetTokenByIndex(currentReadTokenPos);
	if(token.tokenType != TokenType_OpEqual)
	{
		printf("Compile Error: No Option!");
		return false;
	}
	++currentReadTokenPos;
	token = GetTokenByIndex(currentReadTokenPos);
	if(token.tokenType == TokenType_Var)
	{
		eqExp.rightContestV = token.tokenValue.c_str();
		++currentReadTokenPos;
		return true;
	}

	return false;
}

bool LexicalAnalysis::ReadEnd()
{
	LexToken token = GetTokenByIndex(currentReadTokenPos);
	if(token.tokenType != TokenType_End)
	{
		printf("Compile Error: if then  should pairs End");
		return false;
	}
	else
	{
		++currentReadTokenPos;
	}

	return true;
}

LexToken LexicalAnalysis::GetTokenByIndex(int idx)
{
	std::list<LexToken>::iterator iter = lexTokenList.begin();  
	advance(iter, idx);
	return *iter;
}

LexTokenType LexicalAnalysis::GetTokenType(std::string& strInput)
{
	if(strInput == "if")
	{
		return TokenType_If;
	}
	else if(strInput == "then")
	{
		return TokenType_Then;
	}
	else if(strInput == "end")
	{
		return TokenType_End;
	}
	else if(strInput == "=")
	{
		return TokenType_OpEqual;
	}
	else if(strInput == "<")
	{
		return TokenType_OpLess;
	}
	else
	{
		if(strInput[0] >= '0' && strInput[0] <= '9')
		{
			return TokenType_Contest;
		}
		
		
		return TokenType_Var;
	}
}

bool LexicalAnalysis::GetWord(std::string& strOut)
{
	//�ո�ͷֺ��Լ����з��������Ŷ��� �ָ�����
	if(strContext.size() <= currentReadCount)
	{
		return false;
	}
	
	//��ȥ�ո�
	while(strContext[currentReadCount] == ' ')
	{
		++currentReadCount;
		if(strContext.size() <= currentReadCount)
		{
			return false;
		}
		continue;
	}
	
	int readStart = currentReadCount;
	int readEnd = 0;

	++currentReadCount;
	while(strContext[currentReadCount] != ' ')
	{
		++currentReadCount;
		if(strContext.size() <= currentReadCount)
		{
			strOut = strContext.substr(readStart, currentReadCount - readStart);
			return true;
		}
		continue;
	}

	strOut = strContext.substr(readStart, currentReadCount - readStart);
	return true;
}
