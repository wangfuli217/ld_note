#pragma once
#include <string>

enum LuaOpCode
{
	OP_NONE = -1,
	OP_MOVE = 0,
	OP_LOADK = 1,
	OP_LOADBOOL = 2,
	OP_LOADNIL = 3,
	OP_GETUPVAL = 4,
	OP_GETGLOBAL = 5,
	OP_GETTABLE = 6,
	OP_SETGLOBAL = 7,
	OP_SETUPVAL = 8,
	OP_SETTABLE = 9,
	OP_NEWTABLE = 10,
	OP_SELF = 11,
	OP_ADD = 12,
	OP_SUB = 13,
	OP_MUL = 14,
	OP_DIV = 15,
	OP_MOD = 16,
	OP_POW = 17,
	OP_UNM = 18,
	OP_NOT = 19,
	OP_LEN = 20,
	OP_CONCAT = 21,
	OP_JMP = 22,
	OP_EQ = 23,
	OP_LT = 24,
	OP_LE = 25,
	OP_TEST = 26,
	OP_TESTTEST = 27,
	OP_CALL = 28,
	OP_TAILCALL = 29, 
	OP_RETURN = 30,
	OP_FORLOOP = 31,
	OP_FORPREP = 32,
	OP_TFORLOOP = 33,
	OP_SETLIST = 34,
	OP_CLOSE = 35,
	OP_CLOSURE = 36,
	OP_VARARG = 37
};

struct LuaInstrunction
{
	LuaInstrunction() :opCode(OP_NONE), aValue(0), bValue(0), cValue(0), bxValue(0), sbxValue(0){}

	LuaOpCode opCode;
	long aValue;
	long bValue;
	long cValue;
	long bxValue;
	long sbxValue;
};

class LuaInstructionPrase
{
public:
	LuaInstructionPrase(void);
	~LuaInstructionPrase(void);

	static void ParseInstruction(long instruction, std::string& outStr, LuaInstrunction& luaInstrunction);

protected:

};

