#include "StdAfx.h"
#include "LuaByteParse.h"
#include "LuaInstructionPrase.h"
#include "LuaVM.h"

LuaByteParse::LuaByteParse(void) : lastError(E_ParseOK), fileBuffer(NULL), currentOffset(0), bufferSize(0)
{
}


LuaByteParse::~LuaByteParse(void)
{
}


void LuaByteParse::InitReader(const char* filePath)
{
	//Read Buffer From File
	FILE *infile = fopen(filePath, "rb");

	if(infile == NULL)
	{
		SetLastError(E_FileNotExist);
		return;
	}

	long fileSize = 0;           //FileSize
	fseek (infile , 0 , SEEK_END);         
	fileSize = ftell (infile);   
	rewind (infile);  

	fileBuffer = (unsigned char*) malloc (fileSize); 
	fread(fileBuffer, sizeof(unsigned char), fileSize, infile);
	bufferSize = fileSize;
}

void LuaByteParse::Prase()
{
	if(fileBuffer == NULL)
	{
		SetLastError(E_FilePointNULL);
		return;
	}

	PraseHeader();

	if(_GetLastError() != E_ParseOK) return;

	//�������㺯��
	PraseFunction();
}

//��������
void LuaByteParse::PraseFunction()
{
	printf("\n\n------Begin of Function------");
	//�������㺯�������ԣ�
	//�ֱ��ǣ�Դ�����ļ�����lineDef��lastLineDef��nups������������is_vararg��ջ������
	std::string strSource = "";
	long lineDefined = 0;
	long lastLineDefined = 0;
	unsigned char nups = 0;
	unsigned char numparams = 0;
	unsigned char is_vararg = 0;
	unsigned char maxStacksSize = 0;

	PraseString(strSource);
	ParseLong(lineDefined);
	ParseLong(lastLineDefined);
	ParseByte(nups);
	ParseByte(numparams);
	ParseByte(is_vararg);
	ParseByte(maxStacksSize);

	printf("\nSourceName:%s", strSource.c_str() );

	//����ָ���
	long instructionsLen = 0;
	long*instructions = NULL;

	ParseLong(instructionsLen);
	instructions = new long[instructionsLen];
	for(int idx = 0; idx < instructionsLen; ++idx)
	{
		ParseLong(instructions[idx]);
	}

	printf("\n\n----Instruction Count:%d----", instructionsLen );
	for(int idx = 0; idx < instructionsLen; ++idx)
	{
		std::string strInstruction = "";
		LuaInstrunction ins;
		LuaInstructionPrase::ParseInstruction(instructions[idx], strInstruction, ins);
		//printf("\n  %x", instructions[idx] );
		LuaVMInstance.InsertInstrunction(ins);
		//instrunctionList.push_back(ins);
		printf("   %s", strInstruction.c_str());
	}
	printf("\n---- End of Instruction ----");


	//������������
	long constValueCount = 0;
	LuaContestValue* luaConstValues = NULL;

	ParseLong(constValueCount);
	luaConstValues = new LuaContestValue[constValueCount];
	for(int idx = 0; idx < constValueCount; ++idx)
	{
		ParseContestValue(luaConstValues[idx]);
	}

	printf("\n\n----ContestValue Count:%d----", constValueCount );
	for(int idx = 0; idx < constValueCount; ++idx)
	{
		if(luaConstValues[idx].contestType == 3)
		{
			printf("\nNumberContest:%.2f", luaConstValues[idx].contestIValue );
			//��¼������
			LuaVMInstance.InsertContestNumberValue(idx, luaConstValues[idx].contestIValue);
			//luaContest[idx].SetValue(0, luaConstValues[idx].contestIValue);
		}
		else if(luaConstValues[idx].contestType == 4)
		{
			printf("\nStringContest:%s", luaConstValues[idx].contestSVaule.c_str() );
			LuaVMInstance.InsertContestStringValue(idx, luaConstValues[idx].contestSVaule.c_str());
			//luaContest[idx].SetValue(1, 0, luaConstValues[idx].contestSVaule.c_str());
		}
	}
	printf("\n---- End of ContestValue ----" );


	//���������б���
	long functionCount = 0;
	ParseLong(functionCount);
	printf("\n\n------Sub Function:%d------", functionCount);
	for(int idx = 0; idx < functionCount; ++idx)
	{
		PraseFunction();
	}
	printf("\n\n------End of Sub Function------");

	//����  ָ�  ��Ӧ�� �к���Ϣ��
	long lineInfo = 0;
	//ֻ�������йأ������Ҿ�ֱ�������ˣ�
	ParseLong(lineInfo);
	currentOffset += 4*lineInfo;

	//����local������Ϣ:
	long localVCount = 0;
	LuaLocalValue* localValues = NULL;
	ParseLong(localVCount);
	localValues = new LuaLocalValue[localVCount];
	for(int idx = 0; idx < localVCount; ++idx)
	{
		ParseLocalVaule(localValues[idx]);
		localValues[idx].valueIndex = idx;
	}

	printf("\n\n------LocalValue:%d------", localVCount);
	for(int idx = 0; idx < localVCount; ++idx)
	{
		printf("\nValueName:%s,startPc:%d,endPc:%d", localValues[idx].valueName.c_str(), localValues[idx].startPc, localValues[idx].endPc);
	}
	printf("\n------End of LocalValue------");


	//����Upvalue��
	long upVCount = 0;
	ParseLong(upVCount);
	//TodoList��ĿǰupVCountһ��Ҫ����0

	printf("------ End of Function ------\n\n");
}



//�����ļ�ͷ
void LuaByteParse::PraseHeader()
{
	//�̶��ļ�ͷ����00 1b 4c 75 61 51 00 01 04 04 04 08 00��
	int headerValues[12] = {0x1b, 0x4c,0x75,0x61,0x51,0x0,0x01,0x04,0x04,0x04,0x08,0x00 };
	//��ӡ������
	for(int idx = 0; idx < sizeof(headerValues) / sizeof(int); ++idx)
	{
		if((int)fileBuffer[idx + currentOffset] != headerValues[idx])
		{
			SetLastError(E_FileHeaderError);
			return;
		}
	}

	currentOffset += FileHeaderLen;
}

void LuaByteParse::ParseLocalVaule(LuaLocalValue& outV)
{
	PraseString(outV.valueName);
	ParseLong(outV.startPc);
	ParseLong(outV.endPc);
}

void LuaByteParse::ParseContestValue(LuaContestValue& contestV)
{
	unsigned char vType = 0;
	ParseByte(vType);

	contestV.contestType = (long)vType;

	if((int)vType == 4)
	{
		//string:
		PraseString(contestV.contestSVaule);
	}
	else if((int)vType == 3)
	{
		ParseLuaNumber(contestV.contestIValue);
	}
	//Table?nil?function?
}

void LuaByteParse::ParseLuaNumber(double& outV)
{
	if(bufferSize < currentOffset + 8)
	{
		SetLastError(E_BufferOutOfRange);
		return;
	}

	memcpy(&outV, &(fileBuffer[currentOffset]), 8);
	currentOffset += 8;
}

void LuaByteParse::ParseLong(long& outV)
{
	if(bufferSize < currentOffset + 4)
	{
		SetLastError(E_BufferOutOfRange);
		return;
	}

	outV = 0;
	outV += (int)fileBuffer[0 + currentOffset];
	outV += (int)fileBuffer[1+ currentOffset] << 8;
	outV += (int)fileBuffer[2+ currentOffset] << 16;
	outV += (int)fileBuffer[3+ currentOffset] << 24;

	currentOffset += 4;
}

void LuaByteParse::ParseByte(unsigned char& outChar)
{
	if(bufferSize < currentOffset + 1)
	{
		SetLastError(E_BufferOutOfRange);
		return;
	}

	outChar = fileBuffer[currentOffset];
	currentOffset += 1;
}

void LuaByteParse::PraseString(std::string& outString)
{
	if(bufferSize < currentOffset + 4)
	{
		SetLastError(E_BufferOutOfRange);
		return;
	}

	int strLen = 0;
	strLen += (int)fileBuffer[0 + currentOffset];
	strLen += (int)fileBuffer[1+ currentOffset] << 8;
	strLen += (int)fileBuffer[2+ currentOffset] << 16;
	strLen += (int)fileBuffer[3+ currentOffset] << 24;
	//printf("\nReadString:stringlen:%d,currentOffset:%d", strLen, currentOffset);

	if(strLen == 0)
	{
		currentOffset += 4;
		return;
	}

	if(bufferSize < currentOffset + 4 + strLen)
	{
		SetLastError(E_BufferOutOfRange);
		return;
	}

	char* outStr = new char[strLen];
	for(int idx = 0; idx < strLen; ++idx)
	{
		outStr[idx] = fileBuffer[idx + 4 + currentOffset];
	}

	outString = outStr;
	delete outStr;
	//printf("\nReadString:stringContext:%s", outString.c_str());

	currentOffset += strLen + 4;
}


void LuaByteParse::SetLastError(ParseLuaByteError err)
{
	lastError = err;
}

ParseLuaByteError LuaByteParse::_GetLastError()
{
	return lastError;
}
