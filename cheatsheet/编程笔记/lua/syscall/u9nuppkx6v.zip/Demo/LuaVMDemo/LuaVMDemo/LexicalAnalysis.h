#pragma once
#include <string>
#include <list>

enum LexTokenType
{
	TokenType_NULL,
	TokenType_Contest,
	TokenType_OpEqual,
	TokenType_OpLess,
	TokenType_Var,
	TokenType_If,
	TokenType_Then,
	TokenType_End
};

struct LexToken
{
	LexTokenType tokenType;
	std::string tokenValue;
};

// if a < b then a = c end
class OpExpStateMent
{
public:
	//��ʾ�ĺ����� valueA < valueB ����ʽ
	std::string valueA;  // "a"
	std::string valueB;  // "b"
	//OP
};

class EqualExpStateMent
{
public:
	//��ʾ�ĺ����� leftV = rightContestV ����ʽ
	std::string leftV;             //"a"
	std::string rightContestV;     //"c"
};

class IfStateMent
{
public:
	//��ʾ�ĺ����� if conditionExp then contextValue end  = if a < b then a = c end
	OpExpStateMent conditionExp;
	EqualExpStateMent contextValue;
	std::string GetIns();           //��ȡָ�
	int GetContextValueIns(std::string& strOut, int regIdx);

	int PutIntoContest(const char* vName);
	std::list<std::string> listContestString;
};

class LexicalAnalysis
{
public:
	LexicalAnalysis(void);
	~LexicalAnalysis(void);

	static LexicalAnalysis* pInstance;

	static LexicalAnalysis& instance()
	{
		if (pInstance == NULL)
		{
			pInstance = new LexicalAnalysis();
		}

		return *pInstance;
	}

	void DoLexical();
	void Analysis();

	bool GetWord(std::string& strOut);

	LexTokenType GetTokenType(std::string& strInput);
	LexToken GetTokenByIndex(int idx);

	bool ReadExp(OpExpStateMent& opExp);
	bool ReadThen();
	bool ReadContext(EqualExpStateMent& eqExp);
	bool ReadEnd();

private:
	std::string strContext;
	int currentReadCount;
	std::list<LexToken> lexTokenList;
	IfStateMent ifStateMent;
	int currentReadTokenPos;
};

#define LexicalInstance LexicalAnalysis::instance()




