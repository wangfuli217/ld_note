#pragma once

#include"LuaInstructionPrase.h"
#include<list>

#define OP_CODECOUNT 38
#define CONESTV_MAXSIZE 100
#define REG_MAXSIZE 100
#define GLOBALV_MAXSIZE 100

class LuaValues
{
public:
	LuaValues() : luaV(0.0f), strV(""), typeZeroIsNum(0), valueName("") {}

	double GetVaule()
	{
		return luaV;
	}

	const char* GetStrV()
	{
		return strV.c_str();
	}

	bool isNumber()
	{
		return typeZeroIsNum == 0;
	}

	//�Ĵ�����������
	void LoadVaule(LuaValues va)
	{
		luaV = va.luaV;
		strV = va.strV;
		typeZeroIsNum = va.typeZeroIsNum;
		valueName = va.valueName;
	}

	void SetValue(int typeZeroisNum, double v, const char* strV = NULL, const char* valueName = NULL)
	{
		this->typeZeroIsNum = typeZeroisNum;
		this->luaV = v;
		if (strV != NULL)
		{
			this->strV = strV;
		}

		if (valueName != NULL)
		{
			this->valueName = valueName;
		}
	}

	bool IsSameValue(const char*valueName)
	{
		if (this->valueName == valueName)
		{
			return true;
		}

		return false;
	}

	void SetValueName(const char* name)
	{
		valueName = name;
	}

	const char* GetVauleName()
	{
		return valueName.c_str();
	}

protected:
	double luaV;
	std::string strV;
	int typeZeroIsNum;
	std::string valueName; //Global��ʱ������ã������úͼĴ����õ�������ֵ��
};

//�õ����ӵ�ģʽ���Ͼ�ֻ�Ǹ�demo

class LuaVM
{
public:
	static LuaVM* pInstance;

	LuaVM();
	~LuaVM();


	static LuaVM& instance()
	{
		if (pInstance == NULL)
		{
			pInstance = new LuaVM();
		}

		return *pInstance;
	}

	void InsertContestNumberValue(int idx, double numV)
	{
		luaContest[idx].SetValue(0, numV);
	}

	void InsertContestStringValue(int idx, const char* strV)
	{
		luaContest[idx].SetValue(1, 0, strV);
	}

	void InsertInstrunction(LuaInstrunction luaIns)
	{
		instrunctionList.push_back(luaIns);
	}

	void Execute();

	typedef bool (LuaVM::*InsExecuteFun)(LuaInstrunction);


protected:
	//����ÿ��ָ���ִ�����̣�
	bool LoadK(LuaInstrunction ins);
	bool SetGlobal(LuaInstrunction ins);
	bool GetGlobal(LuaInstrunction ins);
	bool _Add(LuaInstrunction ins);
	bool _Sub(LuaInstrunction ins);
	bool _Mul(LuaInstrunction ins);
	bool _Div(LuaInstrunction ins);
	bool _Mod(LuaInstrunction ins);
	bool _Call(LuaInstrunction ins);
	bool _LT(LuaInstrunction ins);
	bool _JMP(LuaInstrunction ins);
	bool _Return(LuaInstrunction ins);


	//ȫ�ֱ����ĺ�����أ�
	void SetGlobal(LuaValues luaV, const char* valueName);
	LuaValues* GetGlobal(const char* valueName);
	double GetBK(int idx);

private:
	LuaValues luaRegisters[REG_MAXSIZE];
	LuaValues luaContest[CONESTV_MAXSIZE];
	std::list<LuaValues*> golbalValueList;
	std::list<LuaInstrunction> instrunctionList;
	InsExecuteFun insExecute[OP_CODECOUNT];
	int jumpPcCount;
};

#define LuaVMInstance LuaVM::instance()

