function AddAB(a, b)
	return a + b
end

local test = "TestLua"
local test2 = "HellowWorld"
local a = 1
local b = a + 5
local d = AddAB(a, b)