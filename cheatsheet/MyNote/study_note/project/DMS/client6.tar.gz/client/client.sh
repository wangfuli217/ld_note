#!/bin/bash
cd /home/tarena/CSD1503/DMS/client
./client
./reset.sh # 仅用于测试
exit 0
