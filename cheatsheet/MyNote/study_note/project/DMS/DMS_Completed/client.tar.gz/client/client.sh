#!/bin/bash
cd /home/tarena/dms/client
./reset.sh
./client
exit 0
