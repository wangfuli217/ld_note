https://github.com/msysgit/msysgit/releases/

https://code.google.com/p/tortoisegit/
