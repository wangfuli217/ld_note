1  libffi

2  glib

3  gtk

4  wireshark