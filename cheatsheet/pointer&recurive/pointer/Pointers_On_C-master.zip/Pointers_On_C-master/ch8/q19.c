for( kwp = keyword_table; **kwp != '\0'; kwp++ )
