#include<stdio.h>
static char b = 2;
void y( void )
{
}
int a = 1;
void x( void )
{
	int  c = 3;
	static float d = 4;
}
int main(int argc, char *argv[])
{

	return 0;
}
