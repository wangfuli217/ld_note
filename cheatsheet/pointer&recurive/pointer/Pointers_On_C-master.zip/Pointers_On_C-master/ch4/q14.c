while ( hungry() ) {
  eat_humberger();
}
