do {
  eat_humberger();
} while( hungry() );
