#include<stdio.h>

/*
 *negat函数接受一个整型参数，返回它的相反数
 * */

int negate( int num)
{
	return -num;
}
