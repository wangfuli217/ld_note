
 
/*
 *increment函数接受一个整型参数，返回该参数值加1
 * */

int increment( int  num)
{
	return num+1;
}
