
#include <stdio.h>
int main()
{
	printf("\"Blunder\?\?!??\"");//使用gcc  q3.c编译
	printf("\"Blunder??!??\"");//使用gcc -trigraphs q3.c编译

}
