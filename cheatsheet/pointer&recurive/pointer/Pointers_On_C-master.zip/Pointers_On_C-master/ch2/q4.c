#include<stdio.h>
int main()
{
	printf("\40");
	return 0;
}
