#ifndef REVERSEISOTREE_H
#define REVERSEISOTREE_H

btlink reverse_btree_iso(btlink);

#endif