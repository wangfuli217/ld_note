#define DISQUE_VERSION "1.0-rc1"
