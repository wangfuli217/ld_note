关于
===========

这是《Redis 设计与实现》第一版的原稿，
在线阅读请访问 http://origin.redisbook.com/ 。


声明
===========

本书由 `huangz <http://huangz.me>`_ 撰写，保留所有权利。


贡献者
===========

以下朋友通过回报 bug 、提供意见等方式为本书做出了贡献，特此感谢：

- `Zhao Jun <https://github.com/milkliker>`_

    - https://github.com/huangz1990/redisbook/commit/994e03b8a9ab998ad0c9453d7a02bcd1bdb0f220

    - https://github.com/huangz1990/redisbook/commit/deb9b1ffc9928a8fdc55f5928b1e9da711302604

- coderbee：

    - https://github.com/huangz1990/redisbook/commit/20ee93fdc483a0ffe76154495b6e56f57ffde74e

    - http://www.redisbook.com/en/latest/internal/rdb.html#comment-829903931

- shenchenhs：
    
    - https://redisbook.readthedocs.org/en/latest/internal/redis.html#comment-829050701

    - https://redisbook.readthedocs.org/en/latest/internal/redis.html#comment-829079413

- 王超： http://www.redisbook.com/en/latest/feature/transaction.html#comment-830849132

- disqus_YBOaGxxUSD： http://www.redisbook.com/en/latest/feature/pubsub.html#comment-833341938

- `hongliuliao <https://github.com/hongliuliao>`_ ：https://github.com/huangz1990/annotated_redis_source/issues/3

- Hardy Simpson：

    - http://www.redisbook.com/en/latest/feature/transaction.html#comment-831264796

    - http://www.redisbook.com/en/latest/internal-datastruct/sds.html#comment-830179461

- lifecoder： http://www.redisbook.com/en/latest/internal-datastruct/dict.html#comment-829921706

- 许成东： 

    - http://www.redisbook.com/en/latest/internal/aof.html#comment-842272424

    - http://www.redisbook.com/en/latest/internal/db.html#comment-845838947

- Liber：http://www.redisbook.com/en/latest/compress-datastruct/intset.html#comment-847564840

- `袁茁 <https://github.com/yzprofile>`_ ： https://github.com/huangz1990/redisbook/pull/10

- Vincent：

    - http://www.redisbook.com/en/latest/datatype/set.html#comment-858178830

    - http://www.redisbook.com/en/latest/datatype/set.html#comment-858176965

    - http://www.redisbook.com/en/latest/internal/db.html#comment-890402119

- rockxsj：http://www.redisbook.com/en/latest/datatype/hash.html#comment-860448434

- jabari：

    - http://www.redisbook.com/en/latest/compress-datastruct/ziplist.html#comment-860554408

    - http://www.redisbook.com/en/latest/internal/aof.html#comment-877666176

- yifang：http://www.redisbook.com/en/latest/internal-datastruct/skiplist.html#comment-864867431

- shpng ： http://www.redisbook.com/en/latest/internal/ae.html#comment-1026187665
