#!/bin/bash

cp -f ~/hack/redis/adlist.[ch] .
cp -f ~/hack/redis/ae.[ch] .
cp -f ~/hack/redis/ae_*.c .
cp -f ~/hack/redis/anet.[ch] .
cp -f ~/hack/redis/config.h .
cp -f ~/hack/redis/fmacros.h .
cp -f ~/hack/redis/sds.[ch] .
cp -f ~/hack/redis/zmalloc.[ch] .
