#ifndef __REDISTOOLS_UTILS_H
#define __REDISTOOLS_UTILS_H

long long microseconds();
void bytesToHuman(char *s, unsigned long long n);

#endif

