cool-digital-image-processing
=============================

cool digital image processing library