/* STL study */

#include <iostream>
#include "cppstl.h"
#include <cstdlib>

using namespace std;

int main(int argc, char *argv[])
{


	std::cout << "Hello STL" << std::endl;
	exit(0);
}
