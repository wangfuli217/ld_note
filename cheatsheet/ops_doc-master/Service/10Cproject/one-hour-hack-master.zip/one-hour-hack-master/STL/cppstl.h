namespace cppstl
{
	/* be in an object of a class */
	template <class T>
	inline const T& max(const T& a, const T& b)
	{
		return a<b ? b : a;
	}

	template <class T>
	class machine{
		

	};



}

