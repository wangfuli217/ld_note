#! /bin/bash

echo "this is a shell script"
echo "used to test file command"
