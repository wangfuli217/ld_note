#include <stdio.h>

void file1(void);
void file2(void);
void file3(void);
void file4(void);
void file5(void);

int main(void)
{
	file1();
	file2();
	file3();
	file4();
	file5();
	printf("All Functions Executed\n");
	return 0;
}
