#ifndef __MQNS_H
#define __MQNS_H

#define DEV_MQUEUE "/dev/mqueue"
#define DEV_MQUEUE2 "/dev/mqueue2"
#define SLASH_MQ1 "/MQ1"
#define NOSLASH_MQ1 "MQ1"
#define SLASH_MQ2 "/MQ2"
#define NOSLASH_MQ2 "MQ2"

#endif /* __MQNS_H */
