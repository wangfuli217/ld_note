#!/bin/sh

echo ""
echo "------------- HOSTNAME -------------------"
echo ""
hostname
echo ""
echo "------------- /PROC/VERSION --------------"
echo ""
cat /proc/version
echo ""
echo "------------- /PROC/CPUINFO --------------"
echo ""
cat /proc/cpuinfo
echo ""
echo "------------- /PROC/MEMINFO --------------"
echo ""
cat /proc/meminfo
echo ""
echo "------------- /PROC/DEVICES --------------"
echo ""
cat /proc/devices
echo ""
echo "------------- /PROC/INTERRUPTS -----------"
echo ""
cat /proc/interrupts
echo ""
echo "------------- /PROC/IOMEM ----------------"
echo ""
cat /proc/iomem
echo ""
echo "------------- /PROC/PARTITIONS -----------"
echo ""
cat /proc/partitions
echo ""
echo "------------- DF -H ----------------------"
echo ""
df -h
echo ""
echo "------------- LSPCI ----------------------"
echo ""
lspci
echo ""
echo "------------- LSMOD ----------------------"
echo ""
lsmod
echo ""
echo "------------- IFCONFIG -------------------"
echo ""
ifconfig
echo ""
echo "------------- PS -E ----------------------"
echo ""
ps -e
