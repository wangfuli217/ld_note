###Collection of Maze Generation Algorithms

From    

	http://weblog.jamisbuck.org/2011/2/7/maze-generation-algorithm-recap


Thany you, Jamis Buck !!!

