#ifndef __ENDIAN_CONV__
#define __ENDIAN_CONV__

void EndianConvert(void *_value, int nbytes);

#endif
