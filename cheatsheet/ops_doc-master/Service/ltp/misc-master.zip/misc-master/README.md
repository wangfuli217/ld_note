misc
====

misc source codes

