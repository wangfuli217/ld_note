/*
   The LemonCurry Lib implementation.
*/

public class Lemon
{
   // not tested, not even compiled yet.
   public void lemonize(String s) {
      System.out.println(new OpenCurry().curryize(s));
   }
};
