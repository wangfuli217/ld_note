=====================================================

The LemonCurry Lib is part of the SFK Test File Suite
and does not serve a particular purposte, except that
it demonstrates a nested zip/jar/jar structure with
some dummy source codes.

=====================================================
