
Swiss File Knife third party library source folder
==================================================

sfklib contains only the files from zlib-1.2.11.tar.gz
required to run joinsfkpack.bat, to build sfkpack.cpp.

if a newer version of zlib is released, 
you may copy the .tar.gz herein, then:

   rmdir /S /Q zlib
   gzip -d zlibnew.tar.gz
   tar xvf zlibnew.tar
   ren zlibnew zlib

to update sfklib, then

   cd ..
   joinsfkpack.bat

to update sfkpack.cpp.

