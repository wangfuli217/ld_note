/*
** $Id$
** watchcatd - Watchcat Daemon
** See copyright notice in distro's COPYRIGHT file
*/

#ifndef SLAVE_H
#define SLAVE_H

/* EMPTY */

#endif /* SLAVE_H */
