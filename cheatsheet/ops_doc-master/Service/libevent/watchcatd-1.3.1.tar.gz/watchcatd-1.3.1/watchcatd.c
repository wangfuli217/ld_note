/*
** $Id$
** watchcatd - Watchcat Daemon
** See copyright notice in distro's COPYRIGHT file
*/

#include "watchcatd.h"

WATCHCAT_GLOBAL_CONF GLOBAL_CONF;
