/*
 *  Read a line (discarding \n and replacing it with \0).
 *  Returned line is in a "static" buffer, which is actually
 *  dynamically allocated so as to be guaranteed big enough.
 */

#include <stdio.h>
#include <stdlib.h>

char *
agetline(fd)
FILE *fd;
{
static char *retbuf = NULL;
static int retsize = 0;
register int c;
register char *p = retbuf;
register int i = 0;

while(1)
	{
	c = getc(fd);

	if(c == EOF && i == 0)
		return NULL;

	if(i >= retsize)
		{
		int nretsize = retsize;
		char *nretbuf;

		if(retsize == 0)
			nretsize = BUFSIZ;

		if(i >= nretsize)
			nretsize = 3 * retsize / 2;

		if(i >= nretsize)
			nretsize = i + 10;

#ifndef SAFEREALLOC
		if(retbuf == NULL)
			nretbuf = malloc(nretsize);
		else
#endif
			nretbuf = realloc(retbuf, nretsize);

		if(nretbuf == NULL && retbuf != NULL)
			{
			nretsize = i + 100;
			nretbuf = realloc(retbuf, nretsize);
			if(nretbuf == NULL)
				{
				nretsize = i + 10;
				nretbuf = realloc(retbuf, nretsize);
				if(nretbuf == NULL)
					{
					nretsize = i + 1;
					nretbuf = realloc(retbuf, nretsize);
					}
				}
			}

		if(nretbuf == NULL)
			return NULL;	/* XXX */

		retbuf = nretbuf;
		retsize = nretsize;

		p = &retbuf[i];
		}

	if(c == '\n' || c == EOF)
		{
		*p = '\0';
		return retbuf;
		}

	*p++ = c;
	i++;
	}
}
