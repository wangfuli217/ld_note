/*
 *  Takes a string (line) and builds an array of pointers to each word in it.
 *  Words are separated by spaces or any control characters.  At most maxargs
 *  pointers are calculated.  \0's are inserted in line, so that each word
 *  becomes a string in its own right.  The number of pointers (argc) is
 *  returned.
 *
 *  Steve Summit, scs@eskimo.com
 *
 *  (This source file is Public Domain.)
 */

#include <stdio.h>

#define iswhite(c) ((c) == ' ' || (c) == '\t' || (c) == '\n')

getargs(argv, line, maxargs)
register char *argv[];
register char *line;
int maxargs;
{
register int nargs;

nargs = 0;

while(1)
	{
	while(iswhite(*line))
		line++;

	if(*line == '\0')
		{
		if(nargs < maxargs) *argv = NULL;
		return(nargs);
		}

	*argv++ = line;
	nargs++;

	while(!iswhite(*line) && *line != '\0')
		line++;

	if(*line == '\0')
		{
		if(nargs < maxargs) *argv = NULL;
		return(nargs);
		}
	*line++ = '\0';
	if(nargs == maxargs) return(nargs);
	}
}
