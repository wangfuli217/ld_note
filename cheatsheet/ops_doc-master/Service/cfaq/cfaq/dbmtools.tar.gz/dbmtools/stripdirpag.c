/*
 *  this code is released to the Public Domain
 *  and may be used and redistributed without restriction
 */

#include <string.h>

stripdirpag(filename)
char *filename;
{
char *p = strrchr(filename, '.');
if(p == NULL)
	return;
if(strcmp(p, ".dir") == 0 || strcmp(p, ".pag") == 0)
	*p = '\0';
}
