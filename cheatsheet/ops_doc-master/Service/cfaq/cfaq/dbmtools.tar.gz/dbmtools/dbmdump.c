/*
 *  dbm utilities -- dump entire dbm files
 *  Steve Summit, scs@eskimo.com
 *  this code is released to the Public Domain
 *  and may be used and redistributed without restriction
 */

#include <stdio.h>
#include <string.h>
#include <errno.h>
#include "dbmglue.h"
#include "dbmutils.h"

#ifndef NOMAIN

#include "defs.h"
#include "version.h"

#ifdef GDBM
char *progname = "gdbmdump";
#else
char *progname = "dbmdump";
#endif

char usage[] = "usage: %s file\n";

main(argc, argv)
int argc;
char *argv[];
{
int argi;
char *p;
char *filename;
DBD_TYPE dbd;
int flags = 0;
int printwhat = DMP_KEYS | DMP_VALUES;
int printedhelp = FALSE;

for(argi = 1; argi < argc && argv[argi][0] == '-'; argi++)
	{
	for(p = &argv[argi][1]; *p != '\0'; p++)
		{
		switch(*p)
			{
			case '?':
printhelp:			printf(usage, progname);
				printf("options:\n");
				printf("\t-b\ttreat data as binary (don't append \\n)\n");
				printf("\t-d\tdump data only\n");
				printf("\t-l\tlist keys only\n");
				printf("\t-ml\tprint multiline values appropriately\n");
				printf("\t-nl\tdon't print extraneous newlines\n");
#ifdef PADDING
				printf("\t-pad\tpad odd-size binary output\n");
#endif
				printf("\t-version print program's version number\n");
				printf("\t-x\tprint value bytes in hex\n");
				printf("\t-?, -h\tprint this help\n");
				printedhelp = TRUE;
				break;

			case 'b':
				flags |= DB_BINARY;
				break;

			case 'd':
				printwhat &= ~DMP_KEYS;
				break;

			case 'h':
				if(strcmp(p, "hex") == 0)
					{
					flags |= DB_HEX;
					p = "x";	/* short circuit */
					break;
					}
				else if(strcmp(p, "help") == 0)
					p = "x";	/* short circuit */
				goto printhelp;

			case 'l':
				printwhat &= ~DMP_VALUES;
				break;

			case 'm':
				if(*(p+1) == 'l')
					{
					flags |= DB_MLGAMES;
					p++;
					break;
					}
				goto badopt;
				break;

			case 'n':
				if(*(p+1) == 'l')
					{
					flags |= DB_NLGAMES;
					p++;
					break;
					}
				goto badopt;
				break;

			case 'p':
#ifdef PADDING
				if(strncmp(p, "pad", 3) == 0)
					{
					flags |= DB_PAD;
					/* XXX should also accept pad4 */
					p = "x";	/* short circuit */
					break;
					}
#endif
				goto badopt;

			case 'v':
				if(strcmp(p, "version") == 0)
					{
printversion:				fprintf(stderr, "%s version %s\n",
							progname, VERSION);
					printedhelp = TRUE;
					p = "x";	/* short circuit */
					break;
					}

				goto badopt;

			case 'x':
				flags |= DB_HEX;
				break;

			case '-':
				/* --help, --version */
				if(strcmp(p, "-help") == 0)
					{
					p = "x";    /* short circuit */
					goto printhelp;
					}
				if(strcmp(p, "-version") == 0)
					{
					p = "x";    /* short circuit */
					goto printversion;
					}

				/* FALLTHROUGH */

			default:
badopt:				fprintf(stderr, "%s: unknown option -%c\n",
								progname, *p);
			}
		}
	}

if(argi != argc - 1)
	{
	if(printedhelp)
		exit(0);
	fprintf(stderr, usage, progname);
	exit(1);
	}

filename = argv[argi];

#ifndef GDBM
stripdirpag(filename);
#endif

dbd = DBMOPENFUNC(filename, DBM_READ, 0);

if(DBM_OPEN_FAIL(dbd))
	{
#ifdef GDBM
	fprintf(stderr, "%s: can't open %s (%s, %s)\n", progname, filename,
		strerror(errno), gdbm_strerror(gdbm_errno));
#else
	fprintf(stderr, "%s: can't open %s: %s\n", progname, filename,
			strerror(errno));
#endif
	exit(1);
	}

dbmdodump(dbd, printwhat, flags);

DBMCLOSEFUNC(dbd);

exit(0);
}

#endif

extern char *progname;

dbmdodump(dbd, printwhat, flags)
DBD_TYPE dbd;
int printwhat, flags;
{
datum keyd, key2, vald;

if(printwhat & DMP_KEYS)
	flags |= DB_VERBOSE;

for(keyd = DBMFIRSTFUNC(dbd), key2.dptr = NULL;
		keyd.dptr != NULL;
			key2 = keyd, keyd = DBMNEXTFUNC(dbd, key2))
	{
	if(printwhat & DMP_VALUES)
	{
	vald = DBMFETCHFUNC(dbd, keyd);

	if(vald.dptr == NULL)
		{
#ifdef GDBM
		fprintf(stderr, "%s: can't fetch \"%.*s\": %s\n", progname,
			keyd.dsize, keyd.dptr, gdbm_strerror(gdbm_errno));
#else
		fprintf(stderr, "%s: can't fetch \"%.*s\"\n", progname,
						keyd.dsize, keyd.dptr);
#endif
		exit(1);
		}
	}

	if(printwhat == DMP_KEYS)
		printf("%.*s\n", keyd.dsize, keyd.dptr);
	else	dbmdoprint(keyd, vald, flags);

	if(key2.dptr != NULL)
		DBMFREEFUNC(key2.dptr);
	if(printwhat & DMP_VALUES)
		DBMFREEFUNC(vald.dptr);
	}

if(key2.dptr != NULL)
	DBMFREEFUNC(key2.dptr);
}
