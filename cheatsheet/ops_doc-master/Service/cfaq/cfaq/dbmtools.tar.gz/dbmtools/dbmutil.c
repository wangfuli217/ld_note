/*
 *  dbm utilities -- generic driver
 *  Steve Summit, scs@eskimo.com
 *  this code is released to the Public Domain
 *  and may be used and redistributed without restriction
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include "dbmglue.h"
#include "dbmutils.h"
#include "defs.h"
#include "version.h"

#define MAXLINE 512
#define MAXARGS 10

#define Streq(s1, s2) (strcmp(s1, s2) == 0)

int readonly = FALSE;
int creflag = FALSE;

int dbmflags = 0;	/* flags of ours (e.g. DB_KEEPNULL) */
int dbmlibflags = 0;	/* aux flags to underlying dbm lib (e.g. GDBM_SYNC) */

int interactive = TRUE;

char filename[FILENAME_MAX];	/* XXX */
DBD_TYPE dbd = 0;

#ifdef GDBM
char *progname = "gdbmutil";
#else
char *progname = "dbmutil";
#endif

#ifdef AGETLINE
extern char *agetline();
#endif

main(argc, argv)
int argc;
char *argv[];
{
int argi;
char *p;
char line[MAXLINE];
char *linep;
int ac;
char *av[MAXARGS];
int printedhelp = FALSE;

interactive = isatty(0);

for(argi = 1; argi < argc && argv[argi][0] == '-'; argi++)
	{
	for(p = &argv[argi][1]; *p != '\0'; p++)
		{
		switch(*p)
			{
			case '?':
printhelp:			printf("usage: %s [options] [dbmfile [command]]\n", progname);
				printf("options:\n");
				printf("\t-c\tcreate dbm file if necessary\n");
#ifdef GDBM
#ifdef GDBM_FAST
#ifdef GDBM_SYNC
				printf("\t-fast\tuse gdbm \"fast\" mode (default)\n");
#else
				printf("\t-fast\tuse gdbm \"fast\" mode\n");
#endif
#endif
#endif
				printf("\t-i\tforce interactive mode\n");
				printf("\t-n\tuse nul (\\0) character to terminate keys and values\n");
				printf("\t-nl\thandle newlines appropriately\n");
#ifdef GDBM
#ifdef GDBM_NOLOCK
				printf("\t-nolock\tuse gdbm \"nolock\" mode\n");
#endif
#endif
#ifdef GDBM
				printf("\t-ok\tno complaint on deletion if key not present\n");
#endif
#ifdef GDBM
#ifdef GDBM_SYNC
				printf("\t-sync\tuse gdbm \"sync\" mode\n");
#endif
#endif
				printf("\t-r\topen dbm file readonly\n");
				printf("\t-v\tverbose: print messages about (most) actions completed\n");
				printf("\t-version print program's version number\n");
				printf("\t-?, -h\tprint this help\n");
				printedhelp = TRUE;
				break;

			case 'c':
				creflag = TRUE;
				break;

			case 'f':
#ifdef GDBM
#ifdef GDBM_FAST
				if(Streq(p, "fast"))
					{
					dbmlibflags |= GDBM_FAST;
					p = "x";
					break;
					}
#endif
#endif
				goto badopt;

			case 'h':
				if(Streq(p, "help"))
					p = "x";	/* short circuit */
				goto printhelp;

			case 'i':
				interactive = TRUE;
				break;

			case 'o':
#ifdef GDBM
				if(*(p+1) == 'k')
					{
					dbmflags |= DB_DELMISSOK;
					p++;
					break;
					}
#endif
				goto badopt;

			case 'n':
				if(*(p+1) == 'l')
					{
					p++;
					dbmflags |= DB_NLGAMES;
					break;
					}

#ifdef GDBM
#ifdef GDBM_NOLOCK
				else if(Streq(p, "nolock"))
					{
					dbmlibflags |= GDBM_NOLOCK;
					p = "x";
					break;
					}
#endif
#endif
				dbmflags |= DB_KEEPNULL;
				break;

			case 'r':
				readonly = TRUE;
				break;

			case 's':
#ifdef GDBM
#ifdef GDBM_SYNC
				if(Streq(p, "sync"))
					{
					dbmlibflags |= GDBM_SYNC;
					p = "x";
					break;
					}
#endif
#endif
				goto badopt;

			case 'v':
				if(Streq(p, "version"))
					{
printversion:				fprintf(stderr, "%s version %s\n",
							progname, VERSION);
#ifdef GDBM
					fprintf(stderr, "%s\n", gdbm_version);
#endif

					printedhelp = TRUE;
					p = "x";	/* short circuit */
					break;
					}

				dbmflags |= DB_VERBOSE;
				break;

			case '-':
				/* --help, --version */
				if(Streq(p, "-help"))
					{
					p = "x";    /* short circuit */
					goto printhelp;
					}
				if(Streq(p, "-version"))
					{
					p = "x";    /* short circuit */
					goto printversion;
					}

				/* FALLTHROUGH */

			default:
badopt:				fprintf(stderr, "%s: unknown option -%c\n", progname, *p);
			}
		}
	}

if(argi >= argc && printedhelp)
	exit(0);

if(argi < argc)
	{
	strcpy(filename, argv[argi++]);

#ifndef GDBM
	stripdirpag(filename);
#endif

	if(readonly)
		dbd = DBMOPENFUNC(filename, DBM_READ | dbmlibflags, 0);
	else if(creflag)
		{
#ifdef DBM_WRCREAT
		dbd = DBMOPENFUNC(filename, DBM_WRCREAT | dbmlibflags, 0666);
#else
		checkdirpag(filename);
		dbd = DBMOPENFUNC(filename, DBM_WRITE | dbmlibflags, 0);
#endif
		}
	else	{
		/* duplicated below */
		dbd = DBMOPENFUNC(filename, DBM_WRITE | dbmlibflags, 0);
		if(DBM_OPEN_FAIL(dbd) && errno == ENOENT && interactive)
			{
			printf("%s does not exist.  Create? ", filename); fflush(stdout);
			getline(stdin, line, MAXLINE);
			if(line[0] == 'y' || line[0] == 'Y')
				{
#ifdef DBM_WRCREAT
				dbd = DBMOPENFUNC(filename, DBM_WRCREAT | dbmlibflags, 0666);
#else
				checkdirpag(filename);
				dbd = DBMOPENFUNC(filename, DBM_WRITE | dbmlibflags, 0);
#endif
				}
			}
		}

	if(DBM_OPEN_FAIL(dbd))
		{
#ifdef GDBM
		fprintf(stderr, "%s: can't open %s (%s, %s)\n", progname, filename,
			strerror(errno), gdbm_strerror(gdbm_errno));
#else
		fprintf(stderr, "%s: can't open %s: %s\n", progname, filename,
						strerror(errno));
#endif
		}

#ifdef OLD_DBM
	dbd = 1;	/* just something other than 0 */
#endif
	}

if(argi < argc)
	docommand(argc - argi, &argv[argi]);
else	{
	while(TRUE)
		{
		if(interactive)
			{
			printf("? ");
			fflush(stdout);
			}
#ifdef AGETLINE
		if((linep = agetline(stdin)) == NULL)
			break;
#else
		if(getline(stdin, line, MAXLINE) == EOF)
			break;
		linep = line;
#endif
		ac = getargs(av, linep, MAXARGS);
		if(Streq(av[0], "quit") || Streq(av[0], "exit"))
			break;
		docommand(ac, av);
		}
	}

if(dbd != 0)
	DBMCLOSEFUNC(dbd);

return 0;
}

docommand(ac, av)
int ac;
char *av[];
{
int i;
char *key;
char *value;
datum keyd, vald;
#ifdef GDBM
static datum fnkey = { 0 };
#endif
char line[MAXLINE];
char line2[MAXLINE];

if(ac == 0)
	return;

if(Streq(av[0], "open") || Streq(av[0], "create"))
	{
	int creflag2 = creflag;
	int readonly2 = readonly;

	if(dbd != 0)
		{
		fprintf(stderr, "db already open\n");
		return;
		}

	if(Streq(av[0], "create"))
		creflag2 = TRUE;

	for(i = 1; i < ac && av[i][0] == '-'; i++)
		{
		char *p;
		for(p = &av[i][1]; *p != '\0'; p++)
			{
			switch(*p)
				{
				case 'c':
					creflag2 = TRUE;
					break;

				case 'r':
					readonly2 = TRUE;
					break;
#ifdef GDBM
				/* XXX -fast, -sync, -nolock? */
#endif
				default:
					fprintf(stderr,
					   "%s: %s: unrecognized option -%c\n",
							progname, av[0], *p);
				}
			}
		}

	if(i < ac)
		strcpy(filename, av[i++]);
	else	{
		if(interactive)
			{
			printf("db filename? ");
			fflush(stdout);
			}
		getline(stdin, line, MAXLINE);
		strcpy(filename, line);
		}

#ifndef GDBM
	stripdirpag(filename);
#endif

	/* duplicated above */

	if(readonly2)
		dbd = DBMOPENFUNC(filename, DBM_READ | dbmlibflags, 0);
	else if(creflag2)
		{
#ifdef DBM_WRCREAT
		dbd = DBMOPENFUNC(filename, DBM_WRCREAT | dbmlibflags, 0666);
#else
		checkdirpag(filename);
		dbd = DBMOPENFUNC(filename, DBM_WRITE | dbmlibflags, 0);
#endif
		}
	else	{
		dbd = DBMOPENFUNC(filename, DBM_WRITE | dbmlibflags, 0);
		if(DBM_OPEN_FAIL(dbd) && errno == ENOENT && interactive)
			{
			printf("%s does not exist.  Create? ", filename); fflush(stdout);
			getline(stdin, line, MAXLINE);
			if(line[0] == 'y' || line[0] == 'Y')
				{
#ifdef DBM_WRCREAT
				dbd = DBMOPENFUNC(filename, DBM_WRCREAT | dbmlibflags, 0666);
#else
				checkdirpag(filename);
				dbd = DBMOPENFUNC(filename, DBM_WRITE | dbmlibflags, 0);
#endif
				}
			}
		}

	if(DBM_OPEN_FAIL(dbd))
		{
#ifdef GDBM
		fprintf(stderr, "can't open %s (%s, %s)\n", filename,
			strerror(errno), gdbm_strerror(gdbm_errno));
#else
		fprintf(stderr, "can't open %s: %s\n", filename, strerror(errno));
#endif
		}
#ifdef OLD_DBM
	else
		dbd = 1;	/* just something other than 0 */
#endif
	}
else if(Streq(av[0], "close"))
	{
	if(dbd == 0)
		{ fprintf(stderr, "db not open\n"); return; }
	DBMCLOSEFUNC(dbd);
	dbd = 0;
	}
else if(Streq(av[0], "fetch"))
	{
	int flags2 = dbmflags;

	if(dbd == 0)
		{ fprintf(stderr, "db not open\n"); return; }

	for(i = 1; i < ac && av[i][0] == '-'; i++)
		{
		char *p;
		for(p = &av[i][1]; *p != '\0'; p++)
			{
			switch(*p)
				{
				case 'x':
					flags2 |= DB_HEX;
					break;

				default:
					fprintf(stderr,
					   "%s: %s: unrecognized option -%c\n",
							progname, av[0], *p);
				}
			}
		}

	if(ac > 1)
		key = av[1];
	else	{
		if(interactive)
			{ printf("key? "); fflush(stdout); }
		getline(stdin, line, MAXLINE);
		key = line;
		}

	dofetch(dbd, key, flags2);
	}
else if(Streq(av[0], "store") || Streq(av[0], "insert") || Streq(av[0], "replace") ||
				Streq(av[0], "enter"))
	{
	int flags2 = dbmflags;

	if(dbd == 0)
		{ fprintf(stderr, "db not open\n"); return; }

	if(Streq(av[0], "insert"))
		flags2 |= DB_INSERTONLY;

	for(i = 1; i < ac && av[i][0] == '-'; i++)
		{
		char *p;
		for(p = &av[i][1]; *p != '\0'; p++)
			{
			switch(*p)
				{
				case 'i':
					flags2 |= DB_INSERTONLY;
					break;

				case 'x':
					flags2 |= DB_HEX;
					break;

				default:
					fprintf(stderr,
					   "%s: %s: unrecognized option -%c\n",
							progname, av[0], *p);
				}
			}
		}

	if(i < ac)
		key = av[i++];
	else	{
		if(interactive)
			{ printf("key? "); fflush(stdout); }
		getline(stdin, line, MAXLINE);
		key = line;
		}

	keyd.dptr = key;
	keyd.dsize = strlen(key);
	/* XXX repeats processing in dostore() */
	if(flags2 & DB_KEEPNULL)
		keyd.dsize++;

	if(Streq(av[0], "replace"))
		flags2 |= DB_REPLACEONLY;

	if(Streq(av[0], "enter"))
		{
		int totlen = 0;
		int r;
		if(interactive)
			printf("type data, terminated by \".\":\n");
		while((r = getline(stdin, &line2[totlen], MAXLINE - totlen - 2)) != EOF)
			{
			if(line2[totlen] == '.' && r == 1)
				break;
			totlen += r;
			line2[totlen++] = '\n';
			}
		clearerr(stdin);
		vald.dptr = line2;
		vald.dsize = totlen;

		/*
		 *  Arguably, if not (dbmflags & DB_NLGAMES),
		 *  oughta delete trailing newline if present,
		 *  but presumption is that "enter" *always* wants
		 *  file-like record, with newlines.
		 */
		}
	else if(i == ac - 1)
		{
		vald.dptr = av[i];
		vald.dsize = strlen(vald.dptr);
		}
	else if(i < ac)
		{
		/* sigh. gotta un-do getargs */
		char *sep = "";
		*line2 = '\0';
		for(; i < ac; i++)
			{
			strcat(line2, sep);
			strcat(line2, av[i]);
			sep = " ";
			}
		vald.dptr = line2;
		vald.dsize = strlen(line2);
		}
	else	{
		if(interactive)
			{ printf("value? "); fflush(stdout); }
		getline(stdin, line2, MAXLINE);
		vald.dptr = line2;
		vald.dsize = strlen(vald.dptr);
		}

	if((flags2 & DB_NLGAMES) && !Streq(av[0], "enter"))
		{
		if(vald.dptr != line2)
			{
			strcpy(line2, vald.dptr);
			vald.dptr = line2;
			}
		vald.dptr[vald.dsize++] = '\n';
		}

	/* XXX repeats processing in dostore() */
	if(flags2 & DB_KEEPNULL)
		vald.dptr[vald.dsize++] = '\0';

	/* disable processing we already did: */
	flags2 &= ~(DB_KEEPNULL | DB_MLGAMES | DB_NLGAMES);

	dostor2(dbd, filename, keyd, vald, flags2);
	}
#ifdef GDBM						/* ??? */
else if(Streq(av[0], "first"))
	{
	if(dbd == 0)
		{ printf("db not open\n"); return; }

	if(fnkey.dptr != NULL)
		free(fnkey.dptr);

	fnkey = gdbm_firstkey(dbd);

	if(fnkey.dptr == NULL)
		printf("no first key\n");
	else	printf("%.*s\n", fnkey.dsize, fnkey.dptr);
	}
else if(Streq(av[0], "next"))
	{
	if(dbd == 0)
		{ printf("db not open\n"); return; }

	if(ac > 1)
		{
		if(fnkey.dptr != NULL)
			free(fnkey.dptr);
		fnkey.dsize = strlen(av[1]);
		if((fnkey.dptr = malloc(fnkey.dsize+1)) == NULL)
			{
			printf("out of memory\n");
			return;
			}
		strcpy(fnkey.dptr, av[1]);
		if(dbmflags & DB_KEEPNULL)
			fnkey.dsize++;
		}
	else if(fnkey.dptr == NULL)
		{
		printf("no current key\n");
		return;
		}

	keyd = gdbm_nextkey(dbd, fnkey);

	free(fnkey.dptr);
	fnkey = keyd;

	if(fnkey.dptr == NULL)
		printf("no next key\n");
	else	printf("%.*s\n", fnkey.dsize, fnkey.dptr);
	}
#endif
else if(Streq(av[0], "list") || Streq(av[0], "dump"))
	{
	int printwhat = DMP_KEYS | DMP_VALUES;

	if(Streq(av[0], "list"))
		printwhat &= ~DMP_VALUES;

	if(dbd == 0)
		{ fprintf(stderr, "db not open\n"); return; }

	dbmdodump(dbd, printwhat, dbmflags);
	}
#ifdef DBMDELETEFUNC
else if(Streq(av[0], "delete"))
	{
	int flags2 = dbmflags;

	if(dbd == 0)
		{ fprintf(stderr, "db not open\n"); return; }

	i = 1;

#ifdef GDBM

	if(i < ac && Streq(av[i], "-ok"))
		{
		flags2 |= DB_DELMISSOK;
		i++;
		}

#endif

	if(i < ac)
		key = av[i];
	else	{
		if(interactive)
			{ printf("key? "); fflush(stdout); }
		getline(stdin, line, MAXLINE);
		key = line;
		}

	dbmdodelete(dbd, filename, key, flags2);
	}
#endif
else if(Streq(av[0], "exists"))
	{
	if(dbd == 0)
		{ fprintf(stderr, "db not open\n"); return; }

	if(ac > 1)
		key = av[1];
	else	{
		if(interactive)
			{ printf("key? "); fflush(stdout); }
		getline(stdin, line, MAXLINE);
		key = line;
		}

	keyd.dptr = key;
	keyd.dsize = strlen(key);
	if(dbmflags & DB_KEEPNULL)
		keyd.dsize++;

	printf("%s\n", DBMEXISTFUNC(dbd, keyd) ? "yes" : "no");
	}
else if(Streq(av[0], "read") || Streq(av[0], "write") || Streq(av[0], "edit"))
	{
	char *filename2;
	FILE *fp;

	if(dbd == 0)
		{ fprintf(stderr, "db not open\n"); return; }

	if(ac > 1)
		key = av[1];
	else	{
		if(interactive)
			{ printf("key? "); fflush(stdout); }
		getline(stdin, line, MAXLINE);
		key = line;
		}

	if(Streq(av[0], "edit"))
		{
#ifdef MKTEMP
		static char tmptemplate[20];
		strcpy(tmptemplate, "/tmp/dbmutXXXXXX");
		filename2 = mktemp(tmptemplate);
#else
		filename2 = tmpnam((char *)NULL);
#endif
		}
	else if(ac > 2)
		filename2 = av[2];
	else	{
		if(interactive)
			{ printf("file? "); fflush(stdout); }
		getline(stdin, line2, MAXLINE);
		filename2 = line2;
		}

	if(Streq(av[0], "write") || Streq(av[0], "edit"))
		{
		keyd.dptr = key;
		keyd.dsize = strlen(key);
		/* XXX repeats processing in dostore() */
		if(dbmflags & DB_KEEPNULL)
			keyd.dsize++;

		vald = DBMFETCHFUNC(dbd, keyd);

		if(vald.dptr == NULL)
			{
#ifdef GDBM
			fprintf(stderr, "can't fetch %s: %s\n", key, gdbm_strerror(gdbm_errno));
#else
			fprintf(stderr, "can't fetch %s\n", key);
#endif
			return;
			}

		fp = fopen(filename2, "w");
		if(fp == NULL)
			{
			fprintf(stderr, "can't open %s: %s\n",
						filename2, strerror(errno));
			return;
			}

		if(vald.dptr[vald.dsize-1] == '\0')
			vald.dsize--;

		fwrite(vald.dptr, 1, vald.dsize, fp);

		if(vald.dptr[vald.dsize-1] != '\n' && !(dbmflags & DB_NLGAMES))
			putc('\n', fp);

		fclose(fp);
		DBMFREEFUNC(vald.dptr);
		}

	if(Streq(av[0], "edit"))
		{
		char cmdbuf[100];				/* XXX */
		char *editor = getenv("EDITOR");
		if(editor == NULL)
			editor = "ed";				/* XXX */
		sprintf(cmdbuf, "%s %s", editor, filename2);
		system(cmdbuf);
		}

	if(Streq(av[0], "read") || Streq(av[0], "edit"))
		{
#ifdef notdef
		int insertonly = FALSE;
#endif
#ifdef OLD_DBM
		int storeflags;
#else
		int storeflags = DBM_REPLACE;
#endif
		char tmpbuf[1024];
		int nch;

		fp = fopen(filename2, "r");
		if(fp == NULL)
			{
			fprintf(stderr, "can't open %s: %s\n",
						filename2, strerror(errno));
			return;
			}

		nch = fread(tmpbuf, 1, sizeof(tmpbuf), fp);

		fclose(fp);

		if(nch < 0)
			{
			fprintf(stderr, "read error on %s: %s\n",
						filename2, strerror(errno));
			return;
			}

		keyd.dptr = key;
		keyd.dsize = strlen(key);
		/* XXX repeats processing in dostore() */
		if(dbmflags & DB_KEEPNULL)
			keyd.dsize++;

		if(!(dbmflags & DB_NLGAMES))
			{
			if(tmpbuf[nch-1] == '\n')
				nch--;
			}

		/* XXX repeats processing in dostore() */
		if(dbmflags & DB_KEEPNULL)
			tmpbuf[nch++] = '\0';

		vald.dptr = tmpbuf;
		vald.dsize = nch;

#ifdef notdef
#ifndef OLD_DBM
		storeflags = insertonly ? DBM_INSERT : DBM_REPLACE;
#else
		if(insertonly && DBMEXISTFUNC(dbd, keyd))
			fprintf(stderr, "%s already exists\n", key);
		else
#endif
#endif
		if(DBMSTOREFUNC(dbd, keyd, vald, storeflags) < 0)
#ifdef GDBM
			fprintf(stderr, "can't store %s: %s\n", key, gdbm_strerror(gdbm_errno));
#else
			fprintf(stderr, "can't store %s\n", key);
#endif
		}
	}
#ifdef GDBM
else if(Streq(av[0], "reorganize"))
	{
	if(dbd == 0)
		{ printf("db not open\n"); return; }
	if(gdbm_reorganize(dbd) < 0)
		printf("can't reorganize: %s\n", gdbm_strerror(gdbm_errno));
	}
else if(Streq(av[0], "sync"))
	{
	if(dbd == 0)
		{ printf("db not open\n"); return; }
	gdbm_sync(dbd);
	}
#endif
else if(Streq(av[0], "version"))
	{
	printf("dbm utils version %s\n", VERSION);
#ifdef GDBM
	printf("%s\n", gdbm_version);
#endif
	}
else if(Streq(av[0], "quit") || Streq(av[0], "exit"))
	{
	/* oops -- don't really work here */
	return;
	}
else if(Streq(av[0], "help"))
	{
	printf("commands:\n");
	printf("\tclose\t\t\tclose the dbm file\n");
	printf("\tdelete key\t\tdelete key and value\n");
	printf("\tdump\t\t\tlist keys and values\n");
	printf("\tedit key\t\tinvoke $EDITOR on key's value\n");
	printf("\tenter key\t\ttype (multi-line) value for key\n");
	printf("\texists key\t\tdetect whether key exists\n");
	printf("\texit\t\t\tquit\n");
	printf("\tfetch key\t\tfetch key's value\n");
	printf("\thelp\t\t\tprint this help\n");
	printf("\tinsert key value\tinsert new key and value (if not already)\n");
	printf("\tlist\t\t\tlist keys\n");
	printf("\topen file\t\topen new dbm file\n");
	printf("\tquit\t\t\tquit\n");
	printf("\tread key file\t\tread key's value from file\n");
#ifdef GDBM
	printf("\treorganize\t\trearrange database to reclaim internal space\n");
#endif
	printf("\treplace key value\treplace existing key's value\n");
	printf("\tstore key value\t\tstore new value in key (creating if necessary)\n");
#ifdef GDBM
	printf("\tsync\t\t\tensure database synchronized with gdbm file\n");
#endif
	printf("\tversion\t\t\tprint dbmutil version\n");
	printf("\twrite key file\t\twrite key's value to file\n");
	}
else	{
	printf("unrecognized command \"%s\"\n", av[0]);
	}
}
