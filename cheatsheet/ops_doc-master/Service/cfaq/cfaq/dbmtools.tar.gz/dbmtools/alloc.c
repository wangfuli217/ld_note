#include <stdio.h>
#ifdef __STDC__
#include <stdlib.h>
#endif
#include "alloc.h"

#ifdef __STDC__
#define SIZE_T size_t
#else
#define SIZE_T unsigned
#endif

static char nomem[] = "out of memory";

#ifdef PANIC

#ifdef __STDC__
extern void panic(char *, ...);
#endif

#else

extern char *progname;

#endif

#ifndef __STDC__
extern char *malloc();
extern char *realloc();
#endif

char *
alloc(size)
int size;
{
char *ret;

if((ret = malloc((SIZE_T)size)) == NULL)
	{
#ifdef PANIC
	panic(nomem);
#else
	if(progname != NULL)
		fprintf(stderr, "%s: ", progname);
	fprintf(stderr, "%s\n", nomem);
	exit(1);
#endif
	}

return ret;
}

char *
crealloc(ptr, size)
char *ptr;
int size;
{
char *ret;

#ifndef SAFEREALLOC
if(ptr == NULL)
	ret = malloc((SIZE_T)size);
else
#endif
	ret = realloc(ptr, (SIZE_T)size);

if(ret == NULL)
	{
#ifdef PANIC
	panic(nomem);
#else
	if(progname != NULL)
		fprintf(stderr, "%s: ", progname);
	fprintf(stderr, "%s\n", nomem);
	exit(1);
#endif
	}

return ret;
}
