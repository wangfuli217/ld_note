#ifdef GDBM

#include <gdbm.h>

typedef GDBM_FILE DBD_TYPE;
#define DBMOPENFUNC(filename, mode, filemode) \
		gdbm_open(filename, 0, mode, filemode, NULL)
#define DBM_READ GDBM_READER
#define DBM_WRITE GDBM_WRITER
#define DBM_WRCREAT GDBM_WRCREAT
#define DBM_OPEN_FAIL(dbd) ((dbd) == NULL)
#define DBMFETCHFUNC(dbd, key) gdbm_fetch(dbd, key)
#define DBMFREEFUNC(dptr) free(dptr)
#define DBMSTOREFUNC(dbd, key, val, flags) gdbm_store(dbd, key, val, flags)
#define DBMEXISTFUNC(dbd, key) gdbm_exists(dbd, key)
#define DBMFIRSTFUNC(dbd) gdbm_firstkey(dbd)
#define DBMNEXTFUNC(dbd, key) gdbm_nextkey(dbd, key)
#define DBMDELETEFUNC(dbd, key) gdbm_delete(dbd, key)
#define DBMCLOSEFUNC(dbd) gdbm_close(dbd)

#define DBM_INSERT GDBM_INSERT
#define DBM_REPLACE GDBM_REPLACE

#else

#ifdef OLD_DBM

#include <dbm.h>

typedef int DBD_TYPE;	/* XXX */
#define DBMOPENFUNC(filename, mode, filemode) dbminit(filename)
#define DBM_OPEN_FAIL(dbd) ((dbd) < 0)
#define DBMFETCHFUNC(dbd, key) fetch(key)
#define DBMFREEFUNC(dptr)
#define DBMSTOREFUNC(dbd, key, val, flags) store(key, val)
#define DBMEXISTFUNC(dbd, key) (fetch(key).dptr != NULL)
#define DBMFIRSTFUNC(dbd) firstkey()
#define DBMNEXTFUNC(dbd, key) nextkey(key)
#define DBMDELETEFUNC(dbd, key) delete(key)	/* XXX libc clash? */
#define DBMCLOSEFUNC(dbd) dbmclose()

#else

#include <ndbm.h>

typedef DBM *DBD_TYPE;
#define DBMOPENFUNC(filename, mode, filemode) dbm_open(filename, mode, filemode)
#define DBM_READ 0
#define DBM_WRITE 2
#ifdef O_CREAT
#define DBM_WRCREAT (2 | O_CREAT)
#endif
#define DBM_OPEN_FAIL(dbd) ((dbd) == NULL)
#define DBMFETCHFUNC(dbd, key) dbm_fetch(dbd, key)
#define DBMFREEFUNC(dptr)
#define DBMSTOREFUNC(dbd, key, val, flags) dbm_store(dbd, key, val, flags)
#define DBMEXISTFUNC(dbd, key) (dbm_fetch(dbd, key).dptr != NULL)
#define DBMFIRSTFUNC(dbd) dbm_firstkey(dbd)
#define DBMNEXTFUNC(dbd, key) dbm_nextkey(dbd)
#define DBMDELETEFUNC(dbd, key) dbm_delete(dbd, key)
#define DBMCLOSEFUNC(dbd) dbm_close(dbd)

#endif
#endif
