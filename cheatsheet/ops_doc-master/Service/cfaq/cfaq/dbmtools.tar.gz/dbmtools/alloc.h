extern char *alloc();
extern char *crealloc();
