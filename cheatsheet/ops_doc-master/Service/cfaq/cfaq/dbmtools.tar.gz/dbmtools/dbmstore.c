/*
 *  dbm utilities -- store new nodes
 *  Steve Summit, scs@eskimo.com
 *  this code is released to the Public Domain
 *  and may be used and redistributed without restriction
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include <assert.h>
#include "dbmglue.h"
#include "dbmutils.h"
#include "defs.h"

char *saferealloc();

#ifndef NOMAIN

#include "version.h"

#define MAXLINE 1000

#ifdef GDBM
char *progname = "gdbmstore";
#else
char *progname = "dbmstore";
#endif

char usage[] = "usage: %s file key value\n";

extern char *strerror();

main(argc, argv)
int argc;
char *argv[];
{
int argi;
char *p;
char *filename;
DBD_TYPE dbd;
int flags = 0;
char *key = NULL;
char *value;
char *inputfile = NULL;
int multi = FALSE;
FILE *ifp = NULL;
#ifdef LOCKING
int lockflag = 0;
char *lockfile = NULL;
int lfd = -1;
#ifndef GDBM
int lfd2 = -1;
#endif
#endif
int printedhelp = FALSE;

for(argi = 1; argi < argc && argv[argi][0] == '-'; argi++)
	{
	for(p = &argv[argi][1]; *p != '\0'; p++)
		{
		switch(*p)
			{
			case '?':
printhelp:			printf(usage, progname);
				printf("options:\n");
				printf("\t-b\ttreat data as binary\n");
				printf("\t-f file\tread value from file\n");
				printf("\t-i\tinsert only; do not replace\n");
#ifdef LOCKING
				printf("\t-l\tuse lock file\n");
				printf("\t-lf f\tlock file is f\n");
#endif
				printf("\t-m\tread multiple keys and values from file (with -f)\n");
				printf("\t-ml\thandle multiline values appropriately\n");
				printf("\t-n\tuse nul (\\0) character to terminate keys and values\n");
				printf("\t-nl\tappend newline to value if necessary\n");
				printf("\t-r\treplace only; do not insert\n");
				printf("\t-version print program's version number\n");
				printf("\t-x\taccept value bytes in hex\n");
				printf("\t-?, -h\tprint this help\n");
				printedhelp = TRUE;
				break;

			case 'b':
				flags |= DB_BINARY;
				break;

			case 'f':
				inputfile = argv[++argi];
				break;

			case 'h':
				if(strcmp(p, "hex") == 0)
					{
					flags |= DB_HEX;
					p = "x";	/* short circuit */
					break;
					}
				else if(strcmp(p, "help") == 0)
					p = "x";	/* short circuit */
				goto printhelp;

			case 'i':
				flags |= DB_INSERTONLY;
				break;

#ifdef LOCKING
			case 'l':
				lockflag = 1;
				if(*(p+1) == 'f')
					{
					lockfile = argv[++argi];
					p++;
					}
				break;
#endif
			case 'm':
				if(*(p+1) == 'l')
					{
					flags |= DB_MLGAMES;
					p++;
					break;
					}
				multi = TRUE;
				break;

			case 'n':
				if(*(p+1) == 'l')
					{
					flags |= DB_NLGAMES;
					p++;
					}
				else	flags |= DB_KEEPNULL;
				break;

			case 'r':
				flags |= DB_REPLACEONLY;
				break;

			case 'v':
				if(strcmp(p, "version") == 0)
					{
printversion:				fprintf(stderr, "%s version %s\n",
							progname, VERSION);
					printedhelp = TRUE;
					p = "x";	/* short circuit */
					break;
					}

				goto badopt;

			case 'x':
				flags |= DB_HEX;
				break;

			case '-':
				/* --help, --version */
				if(strcmp(p, "-help") == 0)
					{
					p = "x";    /* short circuit */
					goto printhelp;
					}
				if(strcmp(p, "-version") == 0)
					{
					p = "x";    /* short circuit */
					goto printversion;
					}

				/* FALLTHROUGH */

			default:
badopt:				fprintf(stderr, "%s: unknown option -%c\n",
							progname, *p);
			}
		}
	}

if(inputfile == NULL ?
			argi > argc - 3 :
	multi ?		argi != argc - 1 :
			argi != argc - 2)
	{
	if(printedhelp)
		exit(0);
	fprintf(stderr, usage, progname);
	exit(1);
	}

if(multi && inputfile == NULL)
	{
	fprintf(stderr, "%s: -m requires -f\n", progname);
	exit(1);
	}

if(multi && (flags & DB_BINARY))
	{
	fprintf(stderr, "%s: can't use -b and -m\n", progname);
	exit(1);
	}

if((flags & DB_MLGAMES) && !multi)
	{
	fprintf(stderr, "%s: -ml only makes sense with -m\n", progname);
	exit(1);
	}

filename = argv[argi++];

if(inputfile != NULL)
	{
	if(strcmp(inputfile, "-") == 0)
		ifp = stdin;
	else	ifp = fopen(inputfile, "r");
	if(ifp == NULL)
		{
		fprintf(stderr, "%s: can't open %s: %s\n", progname,
					inputfile, strerror(errno));
		exit(1);
		}
	}

if(argi < argc)
	key = argv[argi++];

if(inputfile != NULL)
	;
else if(argi == argc - 1)
	{
	value = argv[argi++];
	}
else	{
	static char tmpbuf[512];	/* XXX */
	char *sep = "";

	/* sigh. gotta un-do getargs */

	*tmpbuf = '\0';
	for(; argi < argc; argi++)
		{
		strcat(tmpbuf, sep);
		strcat(tmpbuf, argv[argi]);
		sep = " ";
		}

	value = tmpbuf;
	}

#ifndef GDBM
stripdirpag(filename);
#endif

#ifdef LOCKING

if(lockflag)
	{
	if(lockfile != NULL)
		lfd = mylock(lockfile, 1);
	else	{
#ifndef GDBM	/* gdbm does its own locking */
		static char lockfbuf[256];
		lockfile = lockfbuf;
		sprintf(lockfile, "%s.dir", filename);
		lfd = mylock(lockfile, 1);
		if(lfd >= 0)
			{
			lfd2 = lfd;
			sprintf(lockfile, "%s.pag", filename);
			lfd = mylock(lockfile, 1);
			}
#endif
		}

	if(lfd < 0)
		{
		fprintf(stderr, "%s: can't lock %s\n", progname, lockfile);
		exit(1);
		}
#ifdef DEBUG
	printf("%s %d: lfd = %d, lfd2 = %d\n", progname, getpid(), lfd, lfd2);
#endif
	}

#ifdef DEBUG
sleep(10);
#endif

#endif

#ifdef DBM_WRCREAT
dbd = DBMOPENFUNC(filename, DBM_WRCREAT, 0666);
#else
checkdirpag(filename);
dbd = DBMOPENFUNC(filename, DBM_WRITE, 0666);
#endif

if(DBM_OPEN_FAIL(dbd))
	{
#ifdef GDBM
	fprintf(stderr, "%s: can't open %s (%s, %s)\n", progname, filename,
		strerror(errno), gdbm_strerror(gdbm_errno));
#else
	fprintf(stderr, "%s: can't open %s: %s\n", progname, filename,
						strerror(errno));
#endif
	exit(1);
	}

if(inputfile == NULL)
	{
	assert(key != NULL);
	dostore(dbd, filename, key, value, flags);
	}
else if(!multi || (flags & DB_BINARY))
	{
	datum keyd, vald;
	char buf[BUFSIZ];	/* XXX arbitrary */
	int size;

	size = fread(buf, 1, sizeof(buf), ifp);
	if(size < 0)	/* <= 0? */
		{
		fprintf(stderr, "%s: read error on %s: %s\n",
					progname, inputfile, strerror(errno));
		exit(1);
		}

	assert(key != NULL);

	keyd.dptr = key;
	keyd.dsize = strlen(key);
	if(flags & DB_KEEPNULL)
		keyd.dsize++;

	vald.dptr = buf;
	vald.dsize = size;

	dostor2(dbd, filename, keyd, vald, flags);
	}
else	{
	char line[MAXLINE+1];	/* +1 so multiline can stick \n back in */
	int l;
	char *keybuf = NULL; int keysize = 0;
	char *valbuf = NULL; int valsize = 0; int vallen = 0;

	key = NULL;
	while((l = getline(ifp, line, MAXLINE)) != EOF)
		{
		if(flags & DB_MLGAMES)
			{
			line[l++] = '\n';
			line[l] = '\0';

			if(*line == '\t' ||
				      ((flags & DB_NLGAMES) && *line == '\n'))
				{
				/* continuation */

				value = line;

				if(*line == '\t')
					{
					value++;
					l--;
					}

				if(vallen + l >= valsize)
					{
					valsize = vallen + l + 1;
					valbuf = saferealloc(valbuf, valsize);
					}

				strcpy(&valbuf[vallen], value);
				value = valbuf;
				vallen += l;

				continue;
				}
			else if(key != NULL)
				{
				dostore(dbd, filename, key, value, flags);
				key = NULL;
				}
			}

		key = line;
		value = strpbrk(line, " \t");
		if(value == NULL)
			value = "";		/* ? */
		else	{
			*value++ = '\0';
			while(*value == ' ' || *value == '\t')
				value++;
			}

		if(!(flags & DB_MLGAMES))
			dostore(dbd, filename, key, value, flags);
		else	{
			if((l = strlen(key)) >= keysize)
				{
				keysize = l + 1;
				keybuf = saferealloc(keybuf, keysize);
				}
			strcpy(keybuf, key);
			key = keybuf;

			if((l = strlen(value)) >= valsize)
				{
				valsize = l + 1;
				valbuf = saferealloc(valbuf, valsize);
				}
			strcpy(valbuf, value);
			value = valbuf;
			vallen = l;
			}
		}

	if((flags & DB_MLGAMES) && key != NULL)
		dostore(dbd, filename, key, value, flags);
	}

if(ifp != NULL && ifp != stdin)
	fclose(ifp);

DBMCLOSEFUNC(dbd);

#ifdef LOCKING

#ifdef DEBUG
sleep(10);
#endif

if(lockflag)
	{
	if(lfd >= 0)
		{
#ifdef DEBUG
		printf("%s %d: unlocking %d\n", progname, getpid(), lfd);
#endif
		myunlock(lfd);
		}
#ifndef GDBM
	if(lfd2 >= 0)
		{
#ifdef DEBUG
		printf("%s %d: unlocking %d\n", progname, getpid(), lfd2);
#endif
		myunlock(lfd2);
		}
#endif
	}

#endif

exit(0);
}

#endif

extern char *progname;

dostore(dbd, filename, key, value, flags)
DBD_TYPE dbd;
char *filename;
char *key;
char *value;
int flags;
{
datum keyd, vald;

keyd.dptr = key;
keyd.dsize = strlen(key);
if(flags & DB_KEEPNULL)
	keyd.dsize++;

vald.dptr = value;
vald.dsize = strlen(value);

return dostor2(dbd, filename, keyd, vald, flags);
}

dostor2(dbd, filename, keyd, vald, flags)
DBD_TYPE dbd;
char *filename;
datum keyd, vald;
int flags;
{
int vallen = vald.dsize;
static char *tmpbuf = NULL;
static int tmpsize = 0;
#ifndef profiling
int storeflags;
#endif

if(flags & DB_HEX)
	{
	int i;
	char *sp, *dp;
	int msgprinted = FALSE;

	vald.dsize = vald.dsize / 2 + 2;	/* + 2 for \n and \0 if nec. */
	if(vald.dsize > tmpsize)
		{
		tmpsize = vald.dsize;
		tmpbuf = saferealloc(tmpbuf, tmpsize);
		}

	/* unhex */

	vald.dsize = 0;
	for(i = 0, sp = vald.dptr, dp = tmpbuf; i < vallen;i++, sp++)
		{
		if(isspace(*sp))
			continue;

		if(!isascii(*sp) || !isxdigit(*sp))
			{
			if(!msgprinted)
				{
				fprintf(stderr, "%s: garbage in hex\n", progname);
				msgprinted = TRUE;
				}
			continue;
			}

		if(i >= vallen - 1 || !isxdigit(*(sp+1)))
			{
			if(!msgprinted)
				{
				fprintf(stderr, "%s: long hex digit\n", progname);
				msgprinted = TRUE;
				}
			continue;
			}

#define XCtod(c) (isdigit(c) ? (c) - '0' : isupper(c) ? (c) - 'A' + 10 : (c) - 'a' + 10)

		*dp++ = (XCtod(*sp) << 4) | XCtod(*(sp+1));
		i++;
		sp++;
		}

	vald.dptr = tmpbuf;
	vald.dsize = dp - tmpbuf;
	}

if(flags & DB_NLGAMES)
	{
	/* obscure special case: with DB_MLGAMES, */
	/* DB_NLGAMES deletes an extra newline */
	/* (not 100% sure this is the right place to handle it, though) */

	if((flags & DB_MLGAMES) && vald.dsize > 0 && vald.dptr[vald.dsize-1] == '\n')
		vald.dptr[--vald.dsize] = '\0';	/* XXX hope buffer was writable */
	else if(!(flags & DB_MLGAMES) && vald.dsize > 0 && vald.dptr[vald.dsize-1] != '\n')
		{
		if(vald.dptr != tmpbuf)
			{
			if(vald.dsize + 2 > tmpsize)
				{
				tmpsize = vald.dsize + 2;
				tmpbuf = saferealloc(tmpbuf, tmpsize);
				}
			strcpy(tmpbuf, vald.dptr);
			vald.dptr = tmpbuf;
			}
		vald.dptr[vald.dsize++] = '\n';
		vald.dptr[vald.dsize] = '\0';
		}
	}

if(flags & DB_KEEPNULL)
	vald.dsize++;

#ifdef profiling

return dostor3(dbd, filename, keyd, vald, flags);
}

dostor3(dbd, filename, keyd, vald, flags)
DBD_TYPE dbd;
char *filename;
datum keyd, vald;
int flags;
{
int storeflags;

#endif

if((flags & DB_REPLACEONLY) && !DBMEXISTFUNC(dbd, keyd))
	{
	fprintf(stderr, "%s: %s: key %s does not exist\n", progname,
							filename, keyd.dptr);
	return FALSE;
	}

#ifndef OLD_DBM
storeflags = (flags & DB_INSERTONLY) ? DBM_INSERT : DBM_REPLACE;
#else
if((flags & DB_INSERTONLY) && DBMEXISTFUNC(dbd, keyd))
	{
	fprintf(stderr, "%s: %s: key %s already exists\n", progname,
							filename, keyd.dptr);
	return FALSE;
	}
else
#endif
if(DBMSTOREFUNC(dbd, keyd, vald, storeflags) < 0)
	{
#ifdef GDBM
	fprintf(stderr, "%s: %s: can't store \"%s\": %s\n", progname,
				filename, keyd.dptr, gdbm_strerror(gdbm_errno));
#else
	fprintf(stderr, "%s: %s: can't store \"%s\"\n", progname,
				filename, keyd.dptr);
#endif
	return FALSE;
	}

if(flags & DB_VERBOSE)
	fprintf(stderr, "%s stored\n", keyd.dptr);

return TRUE;
}

char *
saferealloc(buf, size)
char *buf;
int size;
{
char *ret;

#ifndef SAFEREALLOC
if(buf == NULL)
	ret = malloc(size);
else
#endif
	ret = realloc(buf, size);
if(ret == NULL)
	{
	fprintf(stderr, "%s: out of memory\n", progname);
	exit(1);
	}

return ret;
}
