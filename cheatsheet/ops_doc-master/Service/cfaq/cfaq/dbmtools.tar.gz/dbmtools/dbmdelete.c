/*
 *  dbm utilities -- delete nodes
 *  Steve Summit, scs@eskimo.com
 *  this code is released to the Public Domain
 *  and may be used and redistributed without restriction
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include "dbmglue.h"
#include "dbmutils.h"
#include "defs.h"

#ifndef pdp11
#define HARDWAY
#endif

#ifndef NOMAIN

#include "version.h"

#ifdef GDBM
char *progname = "gdbmdelete";
#else
char *progname = "dbmdelete";
#endif

char usage[] = "usage: %s file key(s)\n";

main(argc, argv)
int argc;
char *argv[];
{
int argi;
char *p;
char *filename;
char *key;
DBD_TYPE dbd;
int flags = 0;
int errs = 0;
int printedhelp = FALSE;

for(argi = 1; argi < argc && argv[argi][0] == '-'; argi++)
	{
	for(p = &argv[argi][1]; *p != '\0'; p++)
		{
		switch(*p)
			{
			case '?':
printhelp:			printf(usage, progname);
				printf("options:\n");
#ifdef HARDWAY
				printf("\t-h\thardway search for quasi-matching keys (modulo \\0, etc.)\n");
#endif
#ifdef GDBM
				printf("\t-ok\tno complaint if key not present\n");
#endif
				printf("\t-n\tassume nul (\\0) character terminates keys\n");
				printf("\t-v\tverbose: print message for each node deleted\n");
				printf("\t-version print program's version number\n");
				printf("\t-?\tprint this help\n");
				printedhelp = TRUE;
				break;

			case 'h':
				if(strcmp(p, "help") == 0)
					{
					p = "x";	/* short circuit */
					goto printhelp;
					}
#ifdef HARDWAY
				flags |= DB_HARDWAY;
#else
				goto badopt;
#endif
				break;

			case 'o':
#ifdef GDBM
				if(*(p+1) == 'k')
					{
					flags |= DB_DELMISSOK;
					p++;
					break;
					}
#endif
				goto badopt;

			case 'n':
				flags |= DB_KEEPNULL;
				break;

			case 'v':
				if(strcmp(p, "version") == 0)
					{
printversion:				fprintf(stderr, "%s version %s\n",
							progname, VERSION);
					printedhelp = TRUE;
					p = "x";	/* short circuit */
					break;
					}

				flags |= DB_VERBOSE;
				break;

			case '-':
				/* --help, --version */
				if(strcmp(p, "-help") == 0)
					{
					p = "x";    /* short circuit */
					goto printhelp;
					}
				if(strcmp(p, "-version") == 0)
					{
					p = "x";    /* short circuit */
					goto printversion;
					}

				/* FALLTHROUGH */

			default:
badopt:				fprintf(stderr, "%s: unknown option -%c\n",
								progname, *p);
			}
		}
	}

if(argi > argc - 2)
	{
	if(printedhelp)
		exit(0);
	fprintf(stderr, usage, progname);
	exit(1);
	}

filename = argv[argi++];

#ifndef GDBM
stripdirpag(filename);
#endif

dbd = DBMOPENFUNC(filename, DBM_WRITE, 0);

if(DBM_OPEN_FAIL(dbd))
	{
#ifdef GDBM
	fprintf(stderr, "%s: can't open %s (%s, %s)\n", progname, filename,
		strerror(errno), gdbm_strerror(gdbm_errno));
#else
	fprintf(stderr, "%s: can't open %s: %s\n", progname, filename,
			strerror(errno));
#endif
	exit(1);
	}

while(argi < argc)
	{
	key = argv[argi++];

	if(!dbmdodelete(dbd, filename, key, flags))
		errs++;
	}

DBMCLOSEFUNC(dbd);

return errs == 0 ? EXIT_SUCCESS : EXIT_FAILURE;
}

#endif

extern char *progname;

dbmdodelete(dbd, filename, key, flags)
DBD_TYPE dbd;
char *filename;
char *key;
int flags;
{
	datum keyd;

	keyd.dptr = key;
	keyd.dsize = strlen(key);
	if(flags & DB_KEEPNULL)
		keyd.dsize++;
#ifdef HARDWAY
	if(flags & DB_HARDWAY)
		return hardwaydelete(dbd, filename, keyd, flags);
	else
#endif
	     if(DBMDELETEFUNC(dbd, keyd) < 0)
		{
		if(flags & DB_DELMISSOK)
			{
#ifdef GDBM
			if(gdbm_errno == GDBM_ITEM_NOT_FOUND)
				return TRUE;
#endif
			}
#ifdef GDBM
		fprintf(stderr, "%s: %s: can't delete \"%s\": %s\n", progname,
				filename, key, gdbm_strerror(gdbm_errno));
#else
		fprintf(stderr, "%s: %s: can't delete \"%s\"\n", progname,
				filename, key);
#endif
		return FALSE;
		}
	else if(flags & DB_VERBOSE)
		printf("deleted %s\n", key);

	return TRUE;
}

#ifdef HARDWAY

#define MAXFOUND 5

hardwaydelete(dbd, filename, keyd, flags)
DBD_TYPE dbd;
char *filename;
datum keyd;
int flags;
{
datum keyd2, keyd3;
datum found[MAXFOUND];
int nfound = 0;
int i;
int errs = 0;

for(keyd2 = DBMFIRSTFUNC(dbd), keyd3.dptr = NULL;
		keyd2.dptr != NULL;
			keyd3 = keyd2, keyd2 = DBMNEXTFUNC(dbd, keyd3))
	{
	if(strcmp(keyd2.dptr, keyd.dptr) == 0)
		{
		if(nfound >= MAXFOUND)
			{
			fprintf(stderr,
	    "%s: %s: more than %d matching keys found; re-run to delete all\n",
						progname, filename, MAXFOUND);
			break;
			}
		found[nfound].dsize = keyd2.dsize;
		found[nfound].dptr = malloc(keyd2.dsize);
		if(found[nfound].dptr == NULL)
			{
			fprintf(stderr, "%s: out of memory\n", progname);
			exit(1);
			}
		memcpy(found[nfound].dptr, keyd2.dptr, keyd2.dsize);
		nfound++;
		}

	if(keyd3.dptr != NULL)
		DBMFREEFUNC(keyd3.dptr);
	}

if(nfound == 0)
	{
	fprintf(stderr, "%s: %s: no data matching \"%s\" found\n",
						progname, filename, keyd.dptr);
	return FALSE;
	}

for(i = 0; i < nfound; i++)
	{
	if(DBMDELETEFUNC(dbd, found[i]) < 0)
		{
		fprintf(stderr, "%s: %s: can't delete %dth key \"%s\"",
					progname, filename, i, found[i].dptr);
#ifdef GDBM
		fprintf(stderr, ": %s", gdbm_strerror(gdbm_errno));
#endif
		fprintf(stderr, "\n");
		errs++;
		}
	else if(flags & DB_VERBOSE)
		printf("deleted %s\n", found[i].dptr);
	}

return errs == 0;
}

#endif
