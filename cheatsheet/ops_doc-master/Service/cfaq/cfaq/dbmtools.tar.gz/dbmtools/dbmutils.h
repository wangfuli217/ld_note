/* flags for various "do" functions */

#define DB_KEEPNULL	0x01
#define DB_INSERTONLY	0x02
#define DB_REPLACEONLY	0x04
#define DB_VERBOSE	0x08
#define DB_NLGAMES	0x10	/* dbmdoprint */
#define DB_HARDWAY	0x20	/* dbmdodelete */
#define DB_MLGAMES	0x40
#define DB_HEX		0x80
#define DB_BINARY	0x100
#ifdef PADDING
#define DB_PAD		0x200
#define DB_PAD4		0x400
#endif
#define DB_DELMISSOK	0x800	/* no error if deleting already deleted */

/* "printwhat" flags for dbmdodump */

#define DMP_KEYS	01
#define DMP_VALUES	02
