/*
 *  dbm utilities -- fetch existing nodes
 *  Steve Summit, scs@eskimo.com
 *  this code is released to the Public Domain
 *  and may be used and redistributed without restriction
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include "dbmglue.h"
#include "dbmutils.h"
#include "defs.h"

#ifndef NOMAIN

#include "version.h"

#ifdef GDBM
char *progname = "gdbmfetch";
#else
char *progname = "dbmfetch";
#endif

char usage[] = "usage: %s file key(s)\n";

main(argc, argv)
int argc;
char *argv[];
{
int argi;
char *p;
char *filename;
char *key;
DBD_TYPE dbd;
int flags = 0;
int exitstat = EXIT_SUCCESS;
int printedhelp = FALSE;

for(argi = 1; argi < argc && argv[argi][0] == '-'; argi++)
	{
	for(p = &argv[argi][1]; *p != '\0'; p++)
		{
		switch(*p)
			{
			case '?':
printhelp:			printf(usage, progname);
				printf("options:\n");
				printf("\t-b\ttreat data as binary (don't append \\n)\n");
				printf("\t-ml\tprint multiline values appropriately\n");
				printf("\t-n\tassume nul (\\0) character terminates keys\n");
				printf("\t-nl\tdon't print extraneous newlines\n");
				printf("\t-v\tverbose: print key and value\n");
				printf("\t-version print program's version number\n");
				printf("\t-x\tprint value bytes in hex\n");
				printf("\t-?, -h\tprint this help\n");
				printedhelp = TRUE;
				break;

			case 'b':
				flags |= DB_BINARY;
				break;

			case 'h':
				if(strcmp(p, "hex") == 0)
					{
					flags |= DB_HEX;
					p = "x";	/* short circuit */
					break;
					}
				else if(strcmp(p, "help") == 0)
					p = "x";	/* short circuit */
				goto printhelp;

			case 'm':
				if(*(p+1) == 'l')
					{
					flags |= DB_MLGAMES;
					p++;
					break;
					}
				goto badopt;
				break;

			case 'n':
				if(*(p+1) == 'l')
					{
					flags |= DB_NLGAMES;
					p++;
					}
				else	flags |= DB_KEEPNULL;
				break;

			case 'p':
#ifdef PADDING
				if(strncmp(p, "pad", 3) == 0)
					{
					flags |= DB_PAD;
					/* XXX should also accept pad4 */
					p = "x";	/* short circuit */
					break;
					}
#endif
				goto badopt;

			case 'v':
				if(strcmp(p, "version") == 0)
					{
printversion:				fprintf(stderr, "%s version %s\n",
							progname, VERSION);
					printedhelp = TRUE;
					p = "x";	/* short circuit */
					break;
					}

				flags |= DB_VERBOSE;
				break;

			case 'x':
				flags |= DB_HEX;
				break;

			case '-':
				/* --help, --version */
				if(strcmp(p, "-help") == 0)
					{
					p = "x";    /* short circuit */
					goto printhelp;
					}
				if(strcmp(p, "-version") == 0)
					{
					p = "x";    /* short circuit */
					goto printversion;
					}

				/* FALLTHROUGH */

			default:
badopt:				fprintf(stderr, "%s: unknown option -%c\n",
							progname, *p);
			}
		}
	}

if(argi > argc - 2)
	{
	if(printedhelp)
		exit(0);
	fprintf(stderr, usage, progname);
	exit(1);
	}

filename = argv[argi++];

#ifndef GDBM
stripdirpag(filename);
#endif

dbd = DBMOPENFUNC(filename, DBM_READ, 0);

if(DBM_OPEN_FAIL(dbd))
	{
#ifdef GDBM
	fprintf(stderr, "%s: can't open %s (%s, %s)\n", progname, filename,
		strerror(errno), gdbm_strerror(gdbm_errno));
#else
	fprintf(stderr, "%s: can't open %s: %s\n", progname, filename,
			strerror(errno));
#endif
	exit(1);
	}

while(argi < argc)
	{
	key = argv[argi++];

	if(!dofetch(dbd, key, flags))
		exitstat = EXIT_FAILURE;
	}

DBMCLOSEFUNC(dbd);

return exitstat;
}

#endif

extern char *progname;

dofetch(dbd, key, flags)
DBD_TYPE dbd;
char *key;
int flags;
{
	datum keyd, vald;

	keyd.dptr = key;
	keyd.dsize = strlen(key);
	if(flags & DB_KEEPNULL)
		keyd.dsize++;

	vald = DBMFETCHFUNC(dbd, keyd);

#ifdef AUTONULL

	if(vald.dptr == NULL)
		{
		if(!keepnull)
			keyd.dsize++;
		else	keyd.dsize--;
		vald = DBMFETCHFUNC(dbd, keyd);
		}

#endif

	if(vald.dptr == NULL)
		{
#ifdef GDBM
		fprintf(stderr, "%s: can't fetch \"%s\": %s\n", progname, key,
					gdbm_strerror(gdbm_errno));
#else
		fprintf(stderr, "%s: can't fetch \"%s\"\n", progname, key);
#endif
		return FALSE;
		}

	dbmdoprint(keyd, vald, flags);

	DBMFREEFUNC(vald.dptr);

	return TRUE;
}

dbmdoprint(keyd, vald, flags)
datum keyd, vald;
int flags;
{
	if(flags & DB_VERBOSE)
		printf("%.*s\t", (int)keyd.dsize, keyd.dptr);

	if(flags & DB_HEX)
		{
		int i;
		int wid = -1;

		if(flags & DB_MLGAMES)
			{
			wid = 72;
			if(flags & DB_VERBOSE)
				wid -= 8;	/* approximate */

			wid /= 2;		/* 2 hex digits per byte */
			}

		for(i = 0; i < vald.dsize; i++)
			{
			printf("%02x", vald.dptr[i] & 0xff);
			if(wid > 0 && i % wid == wid - 1)
				{
				putchar('\n');
				if((flags & DB_VERBOSE) && i < vald.dsize-1)
					putchar('\t');
				}
			}
		if(wid <= 0 || i % wid != 0)
			putchar('\n');
		return;
		}

	if(vald.dptr[vald.dsize-1] == '\0' && !(flags & DB_BINARY))
		vald.dsize--;		/* just to make \n test easier */
	if((flags & DB_NLGAMES) && !(flags & DB_MLGAMES) && vald.dptr[vald.dsize-1] == '\n')
		vald.dsize--;

	if(!(flags & DB_MLGAMES))
		{
		fwrite(vald.dptr, 1, vald.dsize, stdout);

		if(!(flags & DB_BINARY))
			printf("\n");
#ifdef PADDING
		else if(flags & DB_PAD)
			{
			int pad = 2;
			if(vald.dsize % pad != 0)
			   fwrite("\0\0\0\0", 1, pad - vald.dsize%pad, stdout);
			}
#endif
		}
	else	{
		char *p;
		int sawnl = FALSE;

		for(p = vald.dptr; p < vald.dptr + vald.dsize; p++)
			{
			if(*p == '\0' && p == &vald.dptr[vald.dsize-1])
				break;
			if(sawnl)
				putchar('\t');
#ifdef notdef
			if(*p == '\0')
				fputs("\\0", stdout);
			else
#endif
				putchar(*p);
			sawnl = (*p == '\n');
			}

		/* obscure special case: with DB_MLGAMES, */
		/* DB_NLGAMES turns extra newline back on */

		if(!sawnl || (flags & DB_NLGAMES))
			printf("\n");
		}
}
