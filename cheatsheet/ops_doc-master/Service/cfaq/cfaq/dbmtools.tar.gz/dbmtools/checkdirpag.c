/*
 *  this code is released to the Public Domain
 *  and may be used and redistributed without restriction
 */

#include <string.h>
#include <errno.h>

#define MAXLEN 513

checkdirpag(filename)
char *filename;
{
int len = strlen(filename);
char tmpname[MAXLEN];
int fd;

if(len + 1 + 3 + 1 > MAXLEN)
	return;				/* XXX */

strcpy(tmpname, filename);
strcpy(&tmpname[len], ".dir");

if(access(tmpname, 0) >= 0 || errno != ENOENT)
	return;

close(creat(tmpname, 0666));

strcpy(&tmpname[len], ".pag");

if(access(tmpname, 0) >= 0 || errno != ENOENT)
	return;

close(creat(tmpname, 0666));
}
