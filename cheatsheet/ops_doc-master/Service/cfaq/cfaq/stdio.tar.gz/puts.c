#include <stdio.h>
#ifdef FASTNBF
#include "stdio2.h"
#endif

puts(s)
register char *s;
{
#ifdef FASTNBF

/* #if defined(_IOB2) && defined(_CHARFLAGS)	XXX obscure godiva cpp bug */
#if _IOB2 && _CHARFLAGS
struct _iobuf2 *stdo2 = IOB2(stdout);
#define stdofl stdo2
#else
#define stdofl stdout
#endif

if(stdofl->_flag & _IONBF)
	{
	char *base = s;
	while(*s != '\0')
		s++;
	_fwrite(stdout, base, s - base);
	}
else
#endif
while(*s != '\0')
	putchar(*s++);

return putchar('\n');
}
