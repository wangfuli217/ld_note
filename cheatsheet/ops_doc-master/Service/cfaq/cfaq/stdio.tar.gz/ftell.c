#include <stdio.h>
#include "stdio2.h"

long int
ftell(fp)
FILE *fp;
{
long int baseoffset;
#ifdef _IOB2
struct _iobuf2 *fp2 = IOB2(fp);
#else
#define fp2 fp
#endif
#ifdef _CHARFILE
#define fpfi fp2
#else
#define fpfi fp
#endif
#ifdef _CHARFLAGS
#define fpfl fp2
#else
#define fpfl fp
#endif
struct _iofuncs *fpfu = fp2->_funcs;

if(fpfu->_seekfunc == NULL)
	baseoffset = 0;
else	{
#ifdef _IOFPTR
	if(fpfl->_flag & _IOFPTR)
		baseoffset = (*fpfu->_seekfunc)(fp2->_fptr, 0L, 1);
	else
#endif
		baseoffset = (*fpfu->_seekfunc)(fpfi->_file, 0L, 1);
	}

if(fp->_base == NULL)
	return baseoffset;

if(fpfl->_flag & _IOREAD)
	return baseoffset - fp->_cnt;
else	return baseoffset + (fp->_ptr - fp->_base);
}
