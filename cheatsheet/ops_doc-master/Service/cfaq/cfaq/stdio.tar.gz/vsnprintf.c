#include <stdio.h>
#include "stdio2.h"
#ifdef VARARGS
#include <varargs.h>
#else
#include <stdarg.h>
#endif

vsnprintf(s, n, fmt, argp)
char *s;
int n;
char *fmt;
va_list argp;
{
#ifdef _IOB2
struct _iobuf3 f3;
#define fp (&f3._iob1)
#define fp2 (&f3._iob2)
#else
FILE f;
#define fp (&f)
#define fp2 fp
#endif
int r;

_initsfile(fp, s, n - 1, _IOWRT | _IOSTRG);
		/* n - 1 to leave room for \0 */

r = _doprnt(fmt, argp, fp);

putc('\0', fp);

return r;
}
