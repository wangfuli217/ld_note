#include <stdio.h>
#include "stdio2.h"

extern FILE *_lastiob;
extern FILE *_ioblist;

_scanfiles(func)
int (*func)();
{
register FILE *fp;
#ifdef _IOB2
struct _iobuf2 *fp2;
#else
#define fp2 fp
#endif
#ifdef _CHARFLAGS
#define fpfl fp2
#else
#define fpfl fp
#endif

for(fp = _iob; fp < _lastiob; fp++)
	{
#ifdef _IOB2
#ifdef _CHARFLAGS
	fp2 = IOB2(fp);
#endif
#endif
	if(fpfl->_flag != 0)
		(*func)(fp);
	}

for(fp = _ioblist; fp != NULL; )
	{
#ifdef _IOB2
	fp2 = IOB2(fp);
#endif

	(*func)(fp);

	fp = fp2->_next;
	}
}
