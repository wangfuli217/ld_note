#include <stdio.h>
#include "stdio2.h"

fseek(fp, offset, whence)
FILE *fp;
long int offset;
int whence;
{
#ifdef _IOB2
struct _iobuf2 *fp2 = IOB2(fp);
#else
#define fp2 fp
#endif
#ifdef _CHARFILE
#define fpfi fp2
#else
#define fpfi fp
#endif
#ifdef _CHARFLAGS
#define fpfl fp2
#else
#define fpfl fp
#endif
struct _iofuncs *fpfu = fp2->_funcs;
#ifdef _BUFSZ2
#define fpb fp2
#else
#define fpb fp
#endif

fpfl->_flag &= ~_IOEOF;

/*
 *  A questionable optimization: simply relocate _ptr in buffer, if possible.
 *  Problems are with ungetc:
 *	1. if _ptr ends up smack dab at _base, there's no place to ungetc
 *	2. an ungetc'd character could possibly (?) be written back out
 *	   to the file (horrifying thought)
 *	3. fseek is supposed to undo the effects of an ungetc
 */

if(whence == SEEK_CUR && fp->_base != NULL && (fpfl->_flag & _IOREAD))
	{
	if((offset > 0 && fp->_cnt - offset >= 0) ||
			fp->_ptr - fp->_base >= -offset)
		{
		fp->_ptr += offset;
		fp->_cnt -= offset;
#ifdef READWRITE
		fpfl->_flag &= ~_IOWRT;
#endif
		return 0;
		}
	}

if(fpfl->_flag & _IOWRT)
	fflush(fp);

if(fpfu->_seekfunc == NULL)
	return EOF;

if(whence == SEEK_CUR && fp->_base != NULL)
	{
	if(fpfl->_flag & _IOREAD)
		offset -= fp->_cnt;
	else if(fpfl->_flag & _IOWRT)
		offset += fp->_ptr - fp->_base;
	}

#ifdef READWRITE

if(fpfl->_flag & _IORW)
	fpfl->_flag &= ~(_IOREAD | _IOWRT);

#endif

#ifdef _IOFPTR
if(fpfl->_flag & _IOFPTR)
	(*fpfu->_seekfunc)(fp2->_fptr, offset, whence);
else
#endif
	(*fpfu->_seekfunc)(fpfi->_file, offset, whence);

#ifdef notyet

if(r == -1)
	{
	fpfl->_flag |= _IOERR;
	if(fpfu->_errfunc != NULL)
		(*fpfu->_errfunc)(fp2->_filename, 's', fp);
	}

#endif

if(fp->_base == NULL)
	return 0;

fp->_ptr = fp->_base;	/* worry that there's now no room for ungetc */

/*
 *  Is this the right way to do this?  Or should it always be set
 *  to 0?  A putc in _IORW mode will cause a flush, even though
 *  there oughta be room.  (_flsbuf will notice _ptr == _base,
 *  though, and not write anything.)  Of course, in _IORW mode,
 *  we don't know whether a putc or getc will happen next.
 */

if(fpfl->_flag & _IOWRT)
	fp->_cnt = fpb->_bufsiz;
else	fp->_cnt = 0;

return 0;
}
