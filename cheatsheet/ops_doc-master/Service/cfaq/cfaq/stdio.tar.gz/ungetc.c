#include <stdio.h>
#include "stdio2.h"

ungetc(c, fp)
int c;
FILE *fp;
{
/* #if defined(_IOB2) && defined(_CHARFLAGS)	XXX obscure godiva cpp bug */
#if _IOB2 && _CHARFLAGS
struct _iobuf2 *fp2 = IOB2(fp);
#define fpfl fp2
#else
#define fpfl fp
#endif

if(c == EOF || !(fpfl->_flag & _IOREAD))
	return EOF;

if(fp->_base == NULL)
	{
	/*
	 *  Could call _getbuf, but the doc sez you've gotta have read
	 *  at least one character, which will have taken care of it.
	 */

	return EOF;
	}

if(fp->_cnt < 0)	/* should never happen, given paranoid _filbuf */
	return EOF;

if(fp->_ptr > fp->_base)
	{
	fp->_ptr--;
	if(*fp->_ptr != c)
		*fp->_ptr = c;
	fp->_cnt++;
	fpfl->_flag &= ~_IOEOF;
	return c;
	}

/*
 *  This case (_ptr == _base) should only be reached if an ungetc
 *  is attempted immediately after an f*open or fseek, which is
 *  not required to work.
 */

return EOF;
}
