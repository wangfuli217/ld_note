#include <stdio.h>
#include "stdio2.h"

_filbuf(fp)
register FILE *fp;
{
register int r;
char c;
#ifdef _IOB2
struct _iobuf2 *fp2;
#else
#define fp2 fp
#endif
#ifdef _CHARFILE
#define fpfi fp2
#else
#define fpfi fp
#endif
#ifdef _CHARFLAGS
#define fpfl fp2
#else
#define fpfl fp
#endif
struct _iofuncs *fpfu;
#ifdef _BUFSZ2
#define fpb fp2
#else
#define fpb fp
#endif

if(fp == NULL)		/* would also be nice to check validity somehow */
	{
	/* set errno? */
	/* call error handler? */
	/* abort? */

	return EOF;
	}

#ifdef _IOB2
fp2 = IOB2(fp);
#endif

fpfu = fp2->_funcs;

if(fpfu->_filbuf != NULL)
	return (*fpfu->_filbuf)(fp);

fp->_cnt = 0;	/* avoid runaway count if repeated getc's at EOF */
		/* also ensures ungetc at EOF works */

#ifdef READWRITE

if((fpfl->_flag & _IORW) && (fpfl->_flag & (_IOREAD | _IOWRT)) == 0)
	fpfl->_flag |= _IOREAD;

#endif

if(!(fpfl->_flag & _IOREAD) || (fpfl->_flag & _IOSTRG))
	{
	/* set errno? */
	/* set _IOERR? */
	/* call error handler? */
	/* abort? */

	return EOF;
	}

#ifdef STICKYEOF

if(fpfl->_flag & _IOEOF)
	return EOF;

#endif

#ifdef STDINFLUSH

	{
/* #if defined(_IOB2) && defined(_CHARFLAGS)	XXX obscure godiva cpp bug */
#if _IOB2 && _CHARFLAGS
	struct _iobuf2 *stdo2 = IOB2(stdout);
#define stdofl stdo2
#else
#define stdo2 stdout
#define stdofl stdout
#endif
	if(fp == stdin && (stdofl->_flag & _IOLBF))	/* ? */
		fflush(stdout);
	}

#endif

if(fp->_base == NULL)
	_getbuf(fp);

if(fpfu->_readfunc == NULL)
	r = 0;
else	{
	r = _fread(fp, fp->_base, fpb->_bufsiz);

	if(r > 0)
		{
		fp->_cnt = r - 1;
		fp->_ptr = fp->_base;
		c = *fp->_ptr++;
		}
	}

if(r <= 0)
	return EOF;

return c & 0377;
}

_fread(fp, p, n)
register FILE *fp;
char *p;
int n;
{
int r;
#ifdef _IOB2
struct _iobuf2 *fp2 = IOB2(fp);
#else
#define fp2 fp
#endif
#ifdef _CHARFILE
#define fpfi fp2
#else
#define fpfi fp
#endif
#ifdef _CHARFLAGS
#define fpfl fp2
#else
#define fpfl fp
#endif
struct _iofuncs *fpfu = fp2->_funcs;

#ifdef _IOFPTR
if(fpfl->_flag & _IOFPTR)
	r = (*fpfu->_readfunc)(fp2->_fptr, p, n);
else
#endif
	r = (*fpfu->_readfunc)(fpfi->_file, p, n);

if(r <= 0)
	{
	if(r == 0)
		{
		fpfl->_flag |= _IOEOF;

#ifdef READWRITE

		if(fpfl->_flag & _IORW)
			fpfl->_flag &= ~(_IOREAD | _IOWRT);
#endif
		}
	else	{
		fpfl->_flag |= _IOERR;
		if(fpfu->_errfunc != NULL)
			(*fpfu->_errfunc)(fp2->_filename, 'r', fp);
		}

#ifdef _IOB2
#ifdef _CLARFLAGS
	fp->_dummyflag = fpfl->_flag;
#endif
#endif
	}

return r;
}
