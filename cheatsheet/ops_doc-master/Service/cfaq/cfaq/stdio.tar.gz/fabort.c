/*
 *  Discard any buffering for stream, without doing I/O.
 *  For input streams, equivalent to some implementation's fflush.
 */

#include <stdio.h>
#include "stdio2.h"

fabort(fp)
register FILE *fp;
{
#if defined(_IOB2) && defined(_CHARFLAGS)
struct _iobuf2 *fp2 = IOB2(fp);
#define fpfl fp2
#else
#define fpfl fp
#endif

fp->_ptr = fp->_base;

if(fpfl->_flag & (_IOREAD | _IONBF
#ifdef READWRITE
				   | _IORW
#endif
#ifndef PUTCLBUF
					   | _IOLBF
#endif
						  ))
	fp->_cnt = 0;
else	{
#if defined(_IOB2) && defined(_BUFSZ2)
	struct _iobuf2 *fp2 = IOB2(fp);
#else
#define fp2 fp
#endif
#ifdef _BUFSZ2
#define fpb fp2
#else
#define fpb fp
#endif

	fp->_cnt = fpb->_bufsiz;
	}
}
