#include <stdio.h>

char *
fgets(s, n, fp)
char *s;
int n;
FILE *fp;
{
register char *p = s;
register int c = EOF;		/* This produces an EOF condition if n < 2 */

while(--n > 0)
	{
	c = getc(fp);

	if(c == EOF)
		break;

	*p++ = c;
	n--;

	if(c == '\n')
		break;
	}

if(c == EOF && (p == s || ferror(fp)))
	return NULL;

*p = '\0';

return s;
}
