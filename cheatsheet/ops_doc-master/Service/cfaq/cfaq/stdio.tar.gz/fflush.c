#include <stdio.h>
#include "stdio2.h"

fflush(fp)
register FILE *fp;
{
register int n;
int r = 0;
#ifdef _IOB2
struct _iobuf2 *fp2 = IOB2(fp);
#else
#define fp2 fp
#endif
#ifdef _CHARFLAGS
#define fpfl fp2
#else
#define fpfl fp
#endif
struct _iofuncs *fpfu = fp2->_funcs;
#ifdef _BUFSZ2
#define fpb fp2
#else
#define fpb fp
#endif
int iflag = fpfl->_flag;

#ifdef READWRITE

if(fpfl->_flag & _IORW)
	fpfl->_flag &= ~(_IOREAD | _IOWRT);

#endif

if((iflag & _IOWRT) && fp->_base != NULL)
	{
	if(fpfu->_flsbuf != NULL)	/* NULL means standard _flsbuf */
		{
		if(fp->_ptr > fp->_base)
			return 0;

		fp->_cnt++;
		return (*fpfu->_flsbuf)(*--fp->_ptr, fp);
		}
	
	if((n = fp->_ptr - fp->_base) > 0)
		{
		r = _fwrite(fp, fp->_base, n);

		if(r < 0)
			r = EOF;

		fp->_ptr = fp->_base;		/* moving these outside of */
		fp->_cnt = fpb->_bufsiz;	/* writeability test would */
						/* allow "flushing" input */
						/* fp's, whatever that means */
		}
	}

return r;
}
