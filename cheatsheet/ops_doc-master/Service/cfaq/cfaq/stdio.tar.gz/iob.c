#include <stdio.h>
#include "stdio2.h"
#include "funcs.h"

extern int READFUNC();
extern int WRITEFUNC();
extern long SEEKFUNC();
extern int CLOSEFUNC();
extern int _errfunc();

extern struct _iofuncs _dfltfuncs;

#ifdef _IOB2

struct _iobuf2 _iob2[_NFILE] =
		{
/* 0: */		{
#ifdef _CHARFLAGS
/* _flag */		_IOREAD | _IOFBF | _IOSTFN,
#endif
#ifdef _CHARFILE
/* _file, */		0,
#endif
/* _fptr */		NULL,
#ifdef _BUFSZ2
/* _bufsiz */		0,
#endif
/* _tinybuf */		0,
/* _filename */		"standard input",
/* _funcs */		&_dfltfuncs,
/* _next */		NULL,
			},

/* 1: */		{
#ifdef _CHARFLAGS
/* _flag */		_IOWRT | _IOFBF | _IOSTFN,
#endif
#ifdef _CHARFILE
/* _file, */		1,
#endif
/* _fptr */		NULL,
#ifdef _BUFSZ2
/* _bufsiz */		0,
#endif
/* _tinybuf */		0,
/* _filename */		"standard output",
/* _funcs */		&_dfltfuncs,
/* _next */		NULL,
			},

/* 2: */		{
#ifdef _CHARFLAGS
/* _flag */		_IOWRT | _IONBF | _IOSTFN,
#endif
#ifdef _CHARFILE
/* _file, */		2,
#endif
/* _fptr */		NULL,
#ifdef _BUFSZ2
/* _bufsiz */		0,
#endif
/* _tinybuf */		0,
/* _filename */		"standard error",
/* _funcs */		&_dfltfuncs,
/* _next */		NULL,
			},
		};

#endif

FILE _iob[_NFILE] =	/* _NFILE just for compatibility */
		{
/* 0: */		{
/* _cnt, _ptr, _base */	0, 0, NULL,
#ifdef _IOB2PTR
/* _iobp2 */		&_iob2[0],
#endif
#ifdef _BUFSZ1
/* _bufsiz */		0,
#endif
/* _flag */		_IOREAD | _IOFBF | _IOSTFN,
/* _file */		0,
#ifndef _IOB2
/* _fptr */		NULL,
#ifdef _BUFSZ2
/* _bufsiz */		0,
#endif
/* _tinybuf */		0,
/* _filename */		"standard input",
/* _funcs */		&_dfltfuncs,
/* _next */		NULL,
#endif
			},

/* 1: */		{
/* _cnt, _ptr, _base */	0, 0, NULL,
#ifdef _IOB2PTR
/* _iobp2 */		&_iob2[1],
#endif
#ifdef _BUFSZ1
/* _bufsiz */		0,
#endif
/* _flag */		_IOWRT | _IOFBF | _IOSTFN,
/* _file */		1,
#ifndef _IOB2
/* _fptr */		NULL,
#ifdef _BUFSZ2
/* _bufsiz */		0,
#endif
/* _tinybuf */		0,
/* _filename */		"standard output",
/* _funcs */		&_dfltfuncs,
/* _next */		NULL,
#endif
			},

/* 2: */		{
/* _cnt, _ptr, _base */	0, 0, NULL,
#ifdef _IOB2PTR
/* _iobp2 */		&_iob2[2],
#endif
#ifdef _BUFSZ1
/* _bufsiz */		0,
#endif
/* _flag */		_IOWRT | _IONBF | _IOSTFN,
/* _file */		2,
#ifndef _IOB2
/* _fptr */		NULL,
#ifdef _BUFSZ2
/* _bufsiz */		0,
#endif
/* _tinybuf */		0,
/* _filename */		"standard error",
/* _funcs */		&_dfltfuncs,
/* _next */		NULL,
#endif
			},
		};

FILE *_lastiob = &_iob[sizeof(_iob) / sizeof(*_iob)];
