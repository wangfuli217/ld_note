#include <stdio.h>
#include "stdio2.h"
#include "funcs.h"

extern FILE *_ioblist;
extern FILE *_lastiob;

fclose(fp)
register FILE *fp;
{
int r1, r2;
#ifdef _IOB2
struct _iobuf2 *fp2 = IOB2(fp);
#else
#define fp2 fp
#endif
#ifdef _CHARFILE
#define fpfi fp2
#else
#define fpfi fp
#endif
#ifdef _CHARFLAGS
#define fpfl fp2
#else
#define fpfl fp
#endif
struct _iofuncs *fpfu = fp2->_funcs;

r1 = fflush(fp);

if(fpfu->_closefunc != NULL)
	{
#ifdef _IOFPTR
	if(fpfl->_flag & _IOFPTR)
		r2 = (*fpfu->_closefunc)(fp2->_fptr);
	else
#endif
		r2 = (*fpfu->_closefunc)(fpfi->_file);

	if(r2 < 0 && fpfu->_errfunc != NULL)
		(*fpfu->_errfunc)(fp2->_filename, 'c', fp);
	}
else	r2 = 0;

_freefile(fp);

return (r1 == EOF || r2 < 0) ? EOF : 0;		/* ? */
}

_freefile(fp)
register FILE *fp;
{
register FILE **fpp;
#ifdef _IOB2
struct _iobuf2 *fp2 = IOB2(fp);
#else
#define fp2 fp
#endif
#ifdef _CHARFLAGS
#define fpfl fp2
#else
#define fpfl fp
#endif

if(fp->_base != NULL && (fpfl->_flag & _IOMYBUF))
	{
	(*_freefunc)(fp->_base);
	fp->_base = NULL;
	}

if(fp2->_filename != NULL && !(fpfl->_flag & _IOSTFN))
	{
	(*_freefunc)(fp2->_filename);
	fp2->_filename = NULL;
	}

if(fp >= _iob && fp < _lastiob)		/* potentially unportable */
	{				/* pointer comparison */
	fpfl->_flag = 0;
	return;
	}

for(fpp = &_ioblist; *fpp != NULL; )
	{
#ifdef _IOB2
	fp2 = IOB2(*fpp);
#else
#undef fp2
#define fp2 (*fpp)
#endif

	if(*fpp == fp)
		{
		*fpp = fp2->_next;
		break;
		}

	fpp = &fp2->_next;
	}

/* what if it wasn't found? */

#ifndef _IOB2
(*_freefunc)((char *)fp);
#else
(*_freefunc)((char *)(struct _iobuf3 *)fp);		/* XXX */
#endif
}
