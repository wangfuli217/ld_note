#include <stdio.h>
#ifdef VARARGS
#include <varargs.h>
#else
#include <stdarg.h>
#endif

/* VARARGS1 */

#ifdef __STDC__
printf(char *fmt, ...)
#else
#ifdef VARARGS
printf(va_alist)
va_dcl
#else
printf(fmt)
char *fmt;
#endif
#endif
{
register va_list argp;
int r;

#ifdef VARARGS

char *fmt;

va_start(argp);
fmt = va_arg(argp, char *);

#else

va_start(argp, fmt);

#endif

r = _doprnt(fmt, argp, stdout);

va_end(argp);

return r;
}
