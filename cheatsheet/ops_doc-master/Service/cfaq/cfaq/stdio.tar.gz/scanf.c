#include <stdio.h>
#ifdef VARARGS
#include <varargs.h>
#else
#include <stdarg.h>
#endif

/* VARARGS1 */

#ifdef __STDC__
scanf(char *fmt, ...)
#else
#ifdef VARARGS
scanf(va_alist)
va_dcl
#else
scanf(fmt)
char *fmt;
#endif
#endif
{
register va_list argp;
int r;

#ifdef VARARGS

char *fmt;

va_start(argp);
fmt = va_arg(argp, char *);

#else

va_start(argp, fmt);

#endif

r = _doscan(stdin, fmt, argp);

va_end(argp);

return r;
}
