#include <stdio.h>
#include "stdio2.h"
#include "funcs.h"

setvbuf(fp, buf, type, size)
register FILE *fp;
char *buf;
int type;
int size;
{
#ifdef _IOB2
struct _iobuf2 *fp2 = IOB2(fp);
#else
#define fp2 fp
#endif
#ifdef _CHARFLAGS
#define fpfl fp2
#else
#define fpfl fp
#endif
struct _iofuncs *fpfu = fp2->_funcs;
#ifdef _BUFSZ2
#define fpb fp2
#else
#define fpb fp
#endif

if((type == _IOFBF || type == _IOLBF) && buf == NULL)
	{
	if(size == 0)
		size = BUFSIZ;		/* fstat? */
#ifdef SETBUFANYTIME
	if(fpfl->_flag & _IOMYBUF)
		buf = (*_reallocfunc)(fp->_base, size);
	else
#endif
		buf = (*_mallocfunc)(size);

	if(buf == NULL)
		{
		if(fpfu->_errfunc != NULL)
			(*fpfu->_errfunc)(fp2->_filename, 'm', fp);	/* ? */
		return EOF;
		}

	type |= _IOMYBUF;
	}

/*
 *  #ifdef SETBUFANYTIME (nowhere near finished) still needs to:
 *	copy if going from user buf to _IOMYBUF
 *	flush if buf gets smaller (or _IONBF)
 *	skip following free if reallocating _IOMYBUF
 *	preserve _ptr and _cnt if partially-full buffer
 */

if(fp->_base != NULL && (fpfl->_flag & _IOMYBUF))
	(*_freefunc)(fp->_base);

fpfl->_flag &= ~(_IOFBF | _IONBF | _IOLBF | _IOMYBUF);


if(type & _IONBF)
	{
	buf = &fp2->_tinybuf;
	size = 1;
	}

fp->_base = fp->_ptr = buf;
fpb->_bufsiz = size;

if((fpfl->_flag & (_IOREAD
#ifdef READWRITE
			   | _IORW
#endif
				  )) || (type & (_IONBF
#ifndef PUTCLBUF
						      | _IOLBF
#endif
							      )))
	fp->_cnt = 0;
else	fp->_cnt = size;

fpfl->_flag |= type;

return 0;
}
