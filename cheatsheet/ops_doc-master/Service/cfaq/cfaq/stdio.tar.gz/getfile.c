#include <stdio.h>
#include "stdio2.h"
#include "funcs.h"

extern FILE *_ioblist;
extern FILE *_lastiob;

FILE *
_getfile()
{
register FILE *fp;
#ifdef _IOB2
struct _iobuf2 *fp2;
struct _iobuf3 *fp3;
#endif
#ifdef _CHARFLAGS
#define fpfl fp2
#else
#define fpfl fp
#endif

for(fp = _iob
#ifdef _IOB2
#ifdef _CHARFLAGS
             , fp2 = IOB2(fp)
#endif
#endif
			     ; fp < _lastiob; fp++)
	{
	if(fpfl->_flag == 0)
		{
		_initfile(fp);
		return fp;
		}
	}

#ifndef _IOB2

fp = (FILE *)(*_mallocfunc)(sizeof(FILE));

#else

fp3 = (struct _iobuf3 *)(*_mallocfunc)(sizeof(struct _iobuf3));
if(fp3 == NULL)
	fp == NULL;
else	{
	fp = &fp3->_iob1;
	fp2 = &fp3->_iob2;
	}

#endif

if(fp != NULL)
	{
#ifdef _IOB2PTR
	fp->_iob2p = fp2;
#endif

	_initfile(fp);

	fp2->_next = _ioblist;	/* would be nicer to keep FIFO */
	_ioblist = fp;
	}
	/*
	 *  ...else set errno?  (Generally, library functions
	 *  shouldn't, but the caller is likely to call perror
	 *  after f*open returns NULL, and EMFILE is germane.)
	 */

return fp;
}
