/*
 *  char *vsaprintf(fmt, va_list)
 *
 *  Like vsprintf, but malloc's its own buffer.
 *  Returns pointer to malloc'ed memory just big enough to hold
 *  formatted string.
 *  Caller must free this memory if/when no longer needed.
 */

#include <stdio.h>
#include "stdio2.h"
#ifdef VARARGS
#include <varargs.h>
#else
#include <stdarg.h>
#endif

extern char *(*_reallocfunc)();

extern int _saflsbuf();

char *
vsaprintf(fmt, argp)
char *fmt;
va_list argp;
{
#ifdef _IOB2
struct _iobuf3 f3;
#define fp (&f3._iob1)
#define fp2 (&f3._iob2)
#else
FILE f;
#define fp (&f)
#define fp2 fp
#endif
#ifdef _BUFSZ2
#define fpb fp2
#else
#define fpb fp
#endif

_initsafile(fp);

_doprnt(fmt, argp, fp);

putc('\0', fp);

return (*_reallocfunc)(fp->_base, fpb->_bufsiz - fp->_cnt);
}
