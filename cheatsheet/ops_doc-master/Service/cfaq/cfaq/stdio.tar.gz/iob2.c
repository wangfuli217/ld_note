#ifdef _IOB2
#ifndef _IOB2PTR

#include <stdio.h>
#include "stdio2.h"

extern FILE *_lastiob;

struct _iobuf2 *
_getiob2(fp)
FILE *fp;
{
if(fp >= _iob && fp < _lastiob)		/* potentially unportable */
	{				/* pointer comparison */
	return &_iob2[fp - _iob];
	}
else	{
	return &((struct _iobuf3 *)fp)->_iob2;
	}
}

#endif
#endif
