#include <stdio.h>

extern FILE *_getfile();

FILE *
strnopen(str, n, mode)
char *str;
int n;
char *mode;
{
register FILE *fp;
int flags = 0;

if(*mode == 'r')
	flags |= _IOREAD;
else if(*mode == 'w' || *mode == 'a')
	flags |= _IOWRT;
else	return NULL;

if((fp = _getfile()) == NULL)
	return NULL;

_initsfile(fp, str, n - 1, flags);

if(*mode == 'a')
		{
		int len;

		/*
		 *  Ambiguity: n is size of buffer, not length
		 *  of existing string.
		 */

		len = strlen(str);
		if(len > n)
			len = n;

		fp->_ptr += len;
		fp->_cnt -= len;
		}
return fp;
}
