#include <stdio.h>
#include <string.h>
#include <errno.h>

#define OTHERBUFSIZE 50

char *string1 = "String 1";
char *string2 = "String 2";

char *progname = "esuite4";

extern char *strerror();

main()
{
char *fn = "/dev/null";
FILE *fd;
int r;
static char buf[BUFSIZ];
char junk[BUFSIZ];	/* probably oughta initialize... */

printf("test 1\n");

fd = fopen(fn, "w");
if(fd == NULL)
	{
	fprintf(stderr, "%s: can't create/write to %s: %s\n",
					progname, fn, strerror(errno));
	exit(1);
	}

setbuf(fd, buf);

memset(buf, 'x', 10);

fwrite(string1, 1, strlen(string1), fd);

if(strncmp(buf, string1, strlen(string1)) != 0)
	fprintf(stderr, "%s 1: buf doesn't contain string 1 (1)\n", progname);

fwrite(junk, 1, BUFSIZ - strlen(string1), fd);

if(strncmp(buf, string1, strlen(string1)) != 0)
	fprintf(stderr, "%s 1: buf doesn't contain string 1 (2)\n", progname);

fwrite(string2, 1, strlen(string2), fd);

if(strncmp(buf, string2, strlen(string2)) != 0)
	fprintf(stderr, "%s 1: buf doesn't contain string 2\n", progname);

r = fclose(fd);

if(r != 0)
	{
	fprintf(stderr, "%s: fclose returned %d on %s: %s\n",
					progname, r, fn, strerror(errno));
	}

printf("test 2\n");

fd = fopen(fn, "w");
if(fd == NULL)
	{
	fprintf(stderr, "%s: can't create/write to %s: %s\n",
					progname, fn, strerror(errno));
	exit(1);
	}

r = setvbuf(fd, buf, _IOFBF, BUFSIZ);

if(r != 0)
	fprintf(stderr, "%s: setvbuf returned %d\n", r);

memset(buf, 'x', 10);

fwrite(string1, 1, strlen(string1), fd);

if(strncmp(buf, string1, strlen(string1)) != 0)
	fprintf(stderr, "%s 2: buf doesn't contain string 1 (1)\n", progname);

fwrite(junk, 1, BUFSIZ - strlen(string1), fd);

if(strncmp(buf, string1, strlen(string1)) != 0)
	fprintf(stderr, "%s 2: buf doesn't contain string 1 (2)\n", progname);

fwrite(string2, 1, strlen(string2), fd);

if(strncmp(buf, string2, strlen(string2)) != 0)
	fprintf(stderr, "%s 2: buf doesn't contain string 2\n", progname);

r = fclose(fd);

if(r != 0)
	{
	fprintf(stderr, "%s: fclose returned %d on %s: %s\n",
					progname, r, fn, strerror(errno));
	}

printf("test 3\n");

fd = fopen(fn, "w");
if(fd == NULL)
	{
	fprintf(stderr, "%s: can't create/write to %s: %s\n",
					progname, fn, strerror(errno));
	exit(1);
	}

r = setvbuf(fd, buf, _IOFBF, OTHERBUFSIZE);

if(r != 0)
	fprintf(stderr, "%s: setvbuf returned %d\n", r);

memset(buf, 'x', 10);

fwrite(string1, 1, strlen(string1), fd);

if(strncmp(buf, string1, strlen(string1)) != 0)
	fprintf(stderr, "%s 3: buf doesn't contain string 1 (1)\n", progname);

fwrite(junk, 1, OTHERBUFSIZE - strlen(string1), fd);

if(strncmp(buf, string1, strlen(string1)) != 0)
	fprintf(stderr, "%s 3: buf doesn't contain string 1 (2)\n", progname);

fwrite(string2, 1, strlen(string2), fd);

if(strncmp(buf, string2, strlen(string2)) != 0)
	fprintf(stderr, "%s 3: buf doesn't contain string 2\n", progname);

r = fclose(fd);

if(r != 0)
	{
	fprintf(stderr, "%s: fclose returned %d on %s: %s\n",
					progname, r, fn, strerror(errno));
	}

printf("test 4\n");

fd = fopen(fn, "w");
if(fd == NULL)
	{
	fprintf(stderr, "%s: can't create/write to %s: %s\n",
					progname, fn, strerror(errno));
	exit(1);
	}

r = setvbuf(fd, buf, _IOLBF, BUFSIZ);

if(r != 0)
	fprintf(stderr, "%s: setvbuf returned %d\n", r);

memset(buf, 'x', 10);

fwrite(string1, 1, strlen(string1), fd);

if(strncmp(buf, string1, strlen(string1)) != 0)
	fprintf(stderr, "%s 4: buf doesn't contain string 1 (1)\n", progname);

fwrite(junk, 1, 10, fd);

if(strncmp(buf, string1, strlen(string1)) != 0)
	fprintf(stderr, "%s 4: buf doesn't contain string 1 (2)\n", progname);

putc('\n', fd);

if(strncmp(buf, string1, strlen(string1)) != 0)
	fprintf(stderr, "%s 4: buf doesn't contain string 1 (3)\n", progname);

fwrite(string2, 1, strlen(string2), fd);

if(strncmp(buf, string2, strlen(string2)) != 0)
	fprintf(stderr, "%s 4: buf doesn't contain string 2\n", progname);

r = fclose(fd);

if(r != 0)
	{
	fprintf(stderr, "%s: fclose returned %d on %s: %s\n",
					progname, r, fn, strerror(errno));
	}

printf("test 5\n");

fd = fopen(fn, "w");
if(fd == NULL)
	{
	fprintf(stderr, "%s: can't create/write to %s: %s\n",
					progname, fn, strerror(errno));
	exit(1);
	}

setbuf(fd, buf);
setlinebuf(fd);

memset(buf, 'x', 10);

fwrite(string1, 1, strlen(string1), fd);

if(strncmp(buf, string1, strlen(string1)) != 0)
	fprintf(stderr, "%s 5: buf doesn't contain string 1 (1)\n", progname);

fwrite(junk, 1, 10, fd);

if(strncmp(buf, string1, strlen(string1)) != 0)
	fprintf(stderr, "%s 5: buf doesn't contain string 1 (2)\n", progname);

putc('\n', fd);

if(strncmp(buf, string1, strlen(string1)) != 0)
	fprintf(stderr, "%s 5: buf doesn't contain string 1 (3)\n", progname);

fwrite(string2, 1, strlen(string2), fd);

if(strncmp(buf, string2, strlen(string2)) != 0)
	fprintf(stderr, "%s 5: buf doesn't contain string 2\n", progname);

r = fclose(fd);

if(r != 0)
	{
	fprintf(stderr, "%s: fclose returned %d on %s: %s\n",
					progname, r, fn, strerror(errno));
	}

return 0;
}
