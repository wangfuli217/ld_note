#include <stdio.h>
#include "stdio2.h"

static struct _iofuncs strnullfuncs =
				{NULL, NULL, NULL, NULL, NULL, NULL, NULL};

_initsfile(fp, str, n, flags)
register FILE *fp;
char *str;
int n;
int flags;
{
#ifdef _IOB2
struct _iobuf2 *fp2 = IOB2(fp);
#else
#define fp2 fp
#endif
#ifdef _CHARFILE
#define fpfi fp2
#else
#define fpfi fp
#endif
#ifdef _CHARFLAGS
#define fpfl fp2
#else
#define fpfl fp
#endif
#ifdef _BUFSZ2
#define fpb fp2
#else
#define fpb fp
#endif

_initfile(fp);

fp->_base = fp->_ptr = str;
fp->_cnt = n;
fpb->_bufsiz = n;	/* XXX didn't used to do this for sprintf */
fpfl->_flag = _IOSTRG | flags;

/* _IOSTRG should keep I/O functions from getting called, but just in case: */
fp2->_funcs = &strnullfuncs;

fpfi->_file = -1;
#ifdef _IOB2
#ifdef _CHARFILE
fp->_dummyfile = -1;
#endif
#endif
}
