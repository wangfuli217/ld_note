#include <stdio.h>
#include "stdio2.h"

extern struct _iofuncs _dfltfuncs;

_initfile(fp)
register FILE *fp;
{
#ifdef _IOB2
struct _iobuf2 *fp2 = IOB2(fp);
#else
#undef fp2
#define fp2 fp
#endif
#ifdef _CHARFLAGS
#define fpfl fp2
#else
#define fpfl fp
#endif
#ifdef _BUFSZ2
#define fpb fp2
#else
#define fpb fp
#endif

fp->_base = fp->_ptr = fp2->_filename = NULL;
fp->_cnt = fpfl->_flag = 0;
fpb->_bufsiz = BUFSIZ;	/* could be 0; caller will usually fix;
						but 0 is too dangerous */

fp2->_fptr = NULL;
fp2->_filename = NULL;

fp2->_funcs = &_dfltfuncs;
/* though caller may override */

/* _next not set: would break freopen */
}
