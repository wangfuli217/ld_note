#include <stdio.h>
#include "stdio2.h"

clearerr(fp)
FILE *fp;
{
/* #if defined(_IOB2) && defined(_CHARFLAGS)	XXX obscure godiva cpp bug */
#if _IOB2 && _CHARFLAGS
#define fpfl IOB2(fp)
#else
#define fpfl fp
#endif

fpfl->_flag &= ~(_IOEOF | _IOERR);
}
