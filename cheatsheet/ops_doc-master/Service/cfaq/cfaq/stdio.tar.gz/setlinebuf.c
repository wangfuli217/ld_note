#include <stdio.h>
#include "stdio2.h"

setlinebuf(fp)
register FILE *fp;
{
#ifdef _IOB2
struct _iobuf2 *fp2 = IOB2(fp);
#else
#define fp2 fp
#endif
#ifdef _CHARFLAGS
#define fpfl fp2
#else
#define fpfl fp
#endif

if(fp->_base == NULL)
	setvbuf(fp, (char *)NULL, _IOLBF, BUFSIZ);
else if(!(fpfl->_flag & _IONBF))
	{
	fpfl->_flag |= _IOLBF;
#ifndef PUTCLBUF
	fp->_cnt = 0;
#endif
	}
}
