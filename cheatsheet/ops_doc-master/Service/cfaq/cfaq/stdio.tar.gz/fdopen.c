#include <stdio.h>
#include "stdio2.h"

extern FILE *_getfile();
extern long int lseek();

FILE *
fdopen(fd, mode)
int fd;
char *mode;
{
register FILE *fp;

if((fp = _getfile()) != NULL)
	{
#ifdef _IOB2
	struct _iobuf2 *fp2 = IOB2(fp);
#else
#define fp2 fp
#endif
#ifdef _CHARFILE
#define fpfi fp2
#else
#define fpfi fp
#endif
#ifdef _CHARFLAGS
#define fpfl fp2
#else
#define fpfl fp
#endif

	fpfi->_file = fd;
#ifdef _IOB2
#ifdef _CHARFILE
	fp->_dummyfile = fd;		/* XXX */
#endif
#endif

	if(*mode == 'r')
		fpfl->_flag |= _IOREAD;
	else	{
		fpfl->_flag |= _IOWRT;
		if(*mode == 'a')
			lseek(fd, 0L, 2);	/* should it do this? */
		}
	}

return fp;
}
