#include <stdio.h>
#include "stdio2.h"

char *
_fileptr(fp)
FILE *fp;
{
#ifdef _IOB2
#define fp2 IOB2(fp)
#else
#define fp2 fp
#endif

return fp2->_fptr;
}
