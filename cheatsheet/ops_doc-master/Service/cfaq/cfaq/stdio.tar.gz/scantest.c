main()
{
int r;
int i1, i2;
char s1[100], s2[100];
double d;

checki("%d", "");
checki("%d", "0");
checki("%d", "1");
checki("%d", "23");
checki("%d", "100");
checki("%d", "65535");
checki("%d", "-23");
checki("%d", "+45");
checki("%o", "0");
checki("%o", "1");
checki("%o", "0123");
checki("%o", "0177777");
checki("%x", "0");
checki("%x", "0x0");
checki("%x", "1a");
checki("%x", "a1");
checki("%x", "a1x");
checki("%i", "0");
checki("%i", "123");
checki("%i", "0123");
checki("%i", "0x123");

printf("multiple conversion, whitespace tests:\n");

r = sscanf("a 1 b 2", "a %d b %d", &i1, &i2);
printf("sscanf returned %d (%d %d)\n", r, i1, i2);
r = sscanf("a 3 b 4", "a%db%d", &i1, &i2);
printf("sscanf returned %d (%d %d)\n", r, i1, i2);
r = sscanf("a5b6", "a %d b %d", &i1, &i2);
printf("sscanf returned %d (%d %d)\n", r, i1, i2);
r = sscanf("a7b8", "a%db%d", &i1, &i2);
printf("sscanf returned %d (%d %d)\n", r, i1, i2);

printf("string tests:\n");

r = sscanf("Hello, world!\n", "%s %s", s1, s2);
printf("sscanf returned %d (\"%s\", \"%s\")\n", r, s1, s2);

r = sscanf("abcdefghi", "%3c%4c", s1, s2);
printf("sscanf returned %d (\"%.3s\", \"%.4s\")\n", r, s1, s2);

r = sscanf("abcabcxyzxyzabcabc", "%[abc]%[^abc]", s1, s2);
printf("sscanf returned %d (\"%s\", \"%s\")\n", r, s1, s2);

printf("floating-point tests:\n");

checkf("0");
checkf("1");
checkf("12.");
checkf("12.34");
checkf(".56");
checkf("1e3");
checkf("-2e-4");
checkf(".1e+7");
checkf("+1.2e34");

printf("numeric conversion field width tests:\n");

r = sscanf("12345", "%3d%s", &i1, s1);
printf("sscanf returned %d (%d, \"%s\")\n", r, i1, s1);
r = sscanf("-12345", "%3d%s", &i1, s1);
printf("sscanf returned %d (%d, \"%s\")\n", r, i1, s1);

r = sscanf("12345", "%3f%s", &d, s1);
printf("sscanf returned %d (%g, \"%s\")\n", r, d, s1);
r = sscanf("123.45", "%3f%s", &d, s1);
printf("sscanf returned %d (%g, \"%s\")\n", r, d, s1);
r = sscanf("12.345", "%3f%s", &d, s1);
printf("sscanf returned %d (%g, \"%s\")\n", r, d, s1);
r = sscanf("1.2345", "%3f%s", &d, s1);
printf("sscanf returned %d (%g, \"%s\")\n", r, d, s1);
r = sscanf(".12345", "%3f%s", &d, s1);
printf("sscanf returned %d (%g, \"%s\")\n", r, d, s1);
r = sscanf("1e23", "%3f%s", &d, s1);
printf("sscanf returned %d (%g, \"%s\")\n", r, d, s1);
r = sscanf("1e-23", "%4f%s", &d, s1);
printf("sscanf returned %d (%g, \"%s\")\n", r, d, s1);
r = sscanf("123e45", "%3f%s", &d, s1);
printf("sscanf returned %d (%g, \"%s\")\n", r, d, s1);
r = sscanf("1.2e345", "%3f%s", &d, s1);
printf("sscanf returned %d (%g, \"%s\")\n", r, d, s1);
r = sscanf("-12345", "%3f%s", &d, s1);
printf("sscanf returned %d (%g, \"%s\")\n", r, d, s1);
}

checki(fmt, str)
char *fmt;
char *str;
{
int n;
int r;

r = sscanf(str, fmt, &n);

printf("sscanf(\"%s\", \"%s\") returned %d; converted ", str, fmt, r);

if(strcmp(fmt, "%i") == 0)
	fmt = "%d";

printf(fmt, n);

printf("\n");
}

checkf(str)
char *str;
{
double d;
int r;

r = sscanf(str, "%lf", &d);

printf("sscanf(\"%s\", \"%%lf\") returned %d; converted %g\n", str, r, d);
}
