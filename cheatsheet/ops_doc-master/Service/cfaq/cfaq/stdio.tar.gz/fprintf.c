#include <stdio.h>
#ifdef VARARGS
#include <varargs.h>
#else
#include <stdarg.h>
#endif

/* VARARGS2 */

#ifdef __STDC__
fprintf(FILE *fp, char *fmt, ...)
#else
#ifdef VARARGS
fprintf(va_alist)
va_dcl
#else
fprintf(fp, fmt)
FILE *fp;
char *fmt;
#endif
#endif
{
register va_list argp;
int r;

#ifdef VARARGS

FILE *fp;
char *fmt;

va_start(argp);
fp = va_arg(argp, FILE *);
fmt = va_arg(argp, char *);

#else

va_start(argp, fmt);

#endif

r = _doprnt(fmt, argp, fp);

va_end(argp);

return r;
}
