#include <stdio.h>
#include <string.h>
#include <errno.h>

#define BUFSIZE 100

char *string1 = "Test.\n";
char *string2 = "This is a test.\n";
char *string3 = "pi";
char char1 = '=';
double numf1 = 3.14;
char *string4 = "This is the last test.\n";

char *progname = "esuite2";

extern char *strerror();

main()
{
char *fn = "testfile";
FILE *fd;
int r;
int c;
char *p;
char buf[BUFSIZE];
char cb;
double db;

/*
 *  first, check basic ability to open, write (in various ways), and close file
 *  (file so created will also be used in first read test)
 */

fd = fopen(fn, "w");
if(fd == NULL)
	{
	fprintf(stderr, "%s: can't create/write to %s: %s\n",
					progname, fn, strerror(errno));
	exit(1);
	}

for(p = string1; *p != '\0'; p++)
	putc(*p, fd);

if(ferror(fd))
	{
	fprintf(stderr, "%s: putc error on %s: %s\n",
					progname, fn, strerror(errno));
	clearerr(fd);
	}

r = fputs(string2, fd);

printf("fputs returned %d\n", r);

if(r < 0)
	{
	fprintf(stderr, "%s: fputs returned %d on %s: %s\n",
					progname, r, fn, strerror(errno));
	clearerr(fd);
	}

/* this is not an exhaustive printf test; that's another test */

r = fprintf(fd, "%s %c %.2f\n", string3, char1, numf1);

printf("fprintf returned %d\n", r);

if(r < 0)
	{
	fprintf(stderr, "%s: fprintf returned %d on %s: %s\n",
					progname, r, fn, strerror(errno));
	clearerr(fd);
	}

r = fwrite(string4, 1, strlen(string4), fd);

printf("fwrite returned %d\n", r);

if(r < 0)
	{
	fprintf(stderr, "%s: fwrite returned %d on %s: %s\n",
					progname, r, fn, strerror(errno));
	clearerr(fd);
	}

r = fclose(fd);

if(r != 0)
	{
	fprintf(stderr, "%s: fclose returned %d on %s: %s\n",
					progname, r, fn, strerror(errno));
	}

/* now, see if that file can be read */

fd = fopen(fn, "r");
if(fd == NULL)
	{
	fprintf(stderr, "%s: can't reread %s: %s\n",
					progname, fn, strerror(errno));
	exit(1);
	}

p = buf;

while((c = getc(fd)) != EOF)
	{
	*p++ = c;
	if(c == '\n')
		break;
	}

*p = '\0';

if(c == EOF)
	{
	fprintf(stderr, "%s: premature EOF on %s", progname, fn);
	if(ferror(fd))
		{
		fprintf(stderr, ": %s", strerror(errno));
		clearerr(fd);
		}
	fprintf(stderr, "\n");
	}

if(strcmp(buf, string1) != 0)
	fprintf(stderr, "%s: read incorrect string 1 from %s\n", progname, fn);

p = fgets(buf, sizeof(buf), fd);

if(p == NULL)
	{
	fprintf(stderr, "%s: unexpected EOF (fgets) on %s", progname, fn);
	if(ferror(fd))
		{
		fprintf(stderr, ": %s", strerror(errno));
		clearerr(fd);
		}
	fprintf(stderr, "\n");
	}

if(strcmp(buf, string2) != 0)
	fprintf(stderr, "%s: read incorrect string 2 from %s\n", progname, fn);

/* this is not an exhaustive scanf test; that's another test */

r = fscanf(fd, "%s %c %lf\n", buf, &cb, &db);

if(r != 3)
	{
	fprintf(stderr, "%s: fscanf returned %d on %s", progname, r, fn);
	if(ferror(fd))
		{
		fprintf(stderr, ": %s", strerror(errno));
		clearerr(fd);
		}
	fprintf(stderr, "\n");
	}

if(strcmp(buf, string3) != 0)
	fprintf(stderr, "%s: read incorrect string 3 from %s\n", progname, fn);

if(cb != char1)
	fprintf(stderr, "%s: read incorrect char from %s\n", progname, fn);

if(db != numf1)
	fprintf(stderr, "%s: read incorrect double from %s (%g != %g)\n",
						progname, fn, db, numf1);

r = fread(buf, 1, sizeof(buf), fd);

if(r <= 0)
	{
	fprintf(stderr, "%s: fread returned %d on %s", progname, r, fn);
	if(ferror(fd))
		{
		fprintf(stderr, ": %s", strerror(errno));
		clearerr(fd);
		}
	fprintf(stderr, "\n");
	}

r = fclose(fd);

if(r != 0)
	{
	fprintf(stderr, "%s: second fclose returned %d on %s: %s\n",
					progname, r, fn, strerror(errno));
	}
}
