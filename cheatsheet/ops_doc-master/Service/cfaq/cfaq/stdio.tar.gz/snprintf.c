#include <stdio.h>
#include "stdio2.h"
#ifdef VARARGS
#include <varargs.h>
#else
#include <stdarg.h>
#endif

/* VARARGS3 */

#ifdef __STDC__
snprintf(char *s, int n, char *fmt, ...)
#else
#ifdef VARARGS
snprintf(va_alist)
va_dcl
#else
snprintf(s, n, fmt)
char *s;
int n;
char *fmt;
#endif
#endif
{
va_list argp;
#ifdef _IOB2
struct _iobuf3 f3;
#define fp (&f3._iob1)
#define fp2 (&f3._iob2)
#else
FILE f;
#define fp (&f)
#define fp2 fp
#endif
int r;

#ifdef VARARGS

char *s;
int n;
char *fmt;

va_start(argp);
s = va_arg(argp, char *);
n = va_arg(argp, int);
fmt = va_arg(argp, char *);

#else

va_start(argp, fmt);

#endif

_initsfile(fp, s, n - 1, _IOWRT);
		/* n - 1 to leave room for \0 */

r = _doprnt(fmt, argp, fp);

va_end(argp);

*fp->_ptr++ = '\0';

return r;
}
