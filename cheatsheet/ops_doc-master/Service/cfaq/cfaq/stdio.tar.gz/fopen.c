#include <stdio.h>
#include "stdio2.h"
#include "funcs.h"
#include "defs.h"

FILE *_ioblist = NULL;

extern FILE *_lastiob;

extern struct _iofuncs _dfltfuncs;

FILE *_getfile();

extern (*_deflterrfunc)();

FILE *
fopen(filename, mode)
char *filename;
char *mode;
{
register FILE *fp;
register int fd;
int flag;
char rwamode;
char *p;
#ifdef READWRITE
int rwflag = FALSE;
#endif

rwamode = *mode;

/*
 *  Should the flags really be accepted in any order?  H & S say
 *  only that "...any of the types ["r", "w+", etc.] [can] be
 *  followed by the character b..."
 */

for(p = &mode[1]; *p != '\0'; p++)
	{
	switch(*p)
		{
#ifdef READWRITE
		case '+':
			rwflag = TRUE;
			break;
#endif
#ifdef notyet
		case 'b':
			binary = TRUE;
			break;
#endif
		/* 
		 *  Note that unrecognized mode modifiers are _i_g_n_o_r_e_d.
		 *  This is desirable; semi-standard extensions to stdio
		 *  are common, but not usually relevant on Unix systems.
		 */
		}
	}

if(rwamode == 'r')
	{
#ifdef READWRITE
	if(rwflag)
		{
		if((fd = (*_openfunc)(filename, 2)) < 0)
			return NULL;
		flag = _IORW;
		}
	else
#endif
		{
		if((fd = (*_openfunc)(filename, 0)) < 0)
			return NULL;
		flag = _IOREAD;
		}
	}
else	{
#ifdef READWRITE
	if(rwflag)
		{
		if(rwamode == 'w' || (fd = (*_openfunc)(filename, 2) < 0))
			fd = (*_creatfunc)(filename, 0666);

		if(fd < 0)
			return NULL;

		if((*_closefunc)(fd) < 0 ||
				(fd = (*_openfunc)(filename, 2)) < 0)
			return NULL;

		if(rwamode == 'a')
			(*_seekfunc)(fd, 0L, 2);

		flag = _IORW;
		}
	else
#endif
		{
		if(rwamode == 'w' || (fd = (*_openfunc)(filename, 1) < 0))
			fd = (*_creatfunc)(filename, 0666);

		if(fd < 0)
			return NULL;

		if(rwamode == 'a')
			(*_seekfunc)(fd, 0L, 2);

		flag = _IOWRT;
		}
	}

if((fp = _getfile()) != NULL)
	{
#ifdef _IOB2
	struct _iobuf2 *fp2 = IOB2(fp);
#else
#define fp2 fp
#endif
#ifdef _CHARFILE
#define fpfi fp2
#else
#define fpfi fp
#endif
#ifdef _CHARFLAGS
#define fpfl fp2
#else
#define fpfl fp
#endif

	fpfi->_file = fd;
#ifdef _IOB2
#ifdef _CHARFILE
	fp->_dummyfile = fd;		/* XXX */
#endif
#endif

	fpfl->_flag |= flag;
	if((fp2->_filename = (*_mallocfunc)(strlen(filename) + 1)) != NULL)
		strcpy(fp2->_filename, filename);
	}
else	{
	/*
	 *  Could theoretically have called _getfile first, before
	 *  opening file, and then wouldn't have to close it now,
	 *  but running out of fp's is by far the less common error.
	 */

	(void)(*_closefunc)(fd);

	/* _getfile set errno, either to EMFILE or ENOMEM */
	}

return fp;
}
