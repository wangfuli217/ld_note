/*
 *  char *saprintf(fmt, args)
 *
 *  Like sprintf, but malloc's its own buffer.
 *  Returns pointer to malloc'ed memory just big enough to hold
 *  formatted string.
 *  Caller must free this memory if/when no longer needed.
 */

#include <stdio.h>
#include "stdio2.h"
#ifdef VARARGS
#include <varargs.h>
#else
#include <stdarg.h>
#endif

extern char *_safinish();

/* VARARGS1 */

char *
#ifdef __STDC__
saprintf(char *fmt, ...)
#else
#ifdef VARARGS
saprintf(va_alist)
va_dcl
#else
saprintf(fmt)
char *fmt;
#endif
#endif
{
va_list argp;
#ifdef _IOB2
struct _iobuf3 f3;
#define fp (&f3._iob1)
#define fp2 (&f3._iob2)
#else
FILE f;
#define fp (&f)
#define fp2 fp
#endif

#ifdef VARARGS

char *fmt;

va_start(argp);
fmt = va_arg(argp, char *);

#else

va_start(argp, fmt);

#endif

_initsafile(fp);

_doprnt(fmt, argp, fp);

va_end(argp);

putc('\0', fp);

return _safinish(fp);
}
