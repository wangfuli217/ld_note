#include <stdio.h>
#include "stdio2.h"
#include "funcs.h"

FILE *
freopen(filename, mode, fp)
char *filename;
char *mode;
register FILE *fp;
{
int fd;
int flag;
#ifdef _IOB2
struct _iobuf2 *fp2;
#else
#define fp2 fp
#endif
#ifdef _CHARFILE
#define fpfi fp2
#else
#define fpfi fp
#endif
#ifdef _CHARFLAGS
#define fpfl fp2
#else
#define fpfl fp
#endif

if(*mode == 'r')
	{
	if((fd = (*_openfunc)(filename, 0)) < 0)
		return NULL;
	flag = _IOREAD;
	}
else	{
	if(*mode == 'w' || (fd = (*_openfunc)(filename, 1) < 0))
		fd = (*_creatfunc)(filename, 0666);

	if(fd < 0)
		return NULL;

	if(*mode == 'a')
		(*_seekfunc)(fd, 0L, 2);

	flag = _IOWRT;
	}

/* gotta effectively fclose, no? */

_initfile(fp);

#ifdef _IOB2
fp2 = IOB2(fp);
#endif

fpfi->_file = fd;
#ifdef _IOB2
#ifdef _CHARFILE
fp->_dummyfile = fd;			/* XXX */
#endif
#endif

fpfl->_flag |= flag;
if((fp2->_filename = (*_mallocfunc)(strlen(filename) + 1)) != NULL)
	strcpy(fp2->_filename, filename);

return fp;
}
