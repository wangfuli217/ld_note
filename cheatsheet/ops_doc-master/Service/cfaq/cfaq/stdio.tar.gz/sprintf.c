#include <stdio.h>
#include "stdio2.h"
#ifdef VARARGS
#include <varargs.h>
#else
#include <stdarg.h>
#endif

/* VARARGS2 */

#ifdef __STDC__
sprintf(char *s, char *fmt, ...)
#else
#ifdef VARARGS
sprintf(va_alist)
va_dcl
#else
sprintf(s, fmt)
char *s;
char *fmt;
#endif
#endif
{
va_list argp;
#ifdef _IOB2
struct _iobuf3 f3;
#define fp (&f3._iob1)
#define fp2 (&f3._iob2)
#else
FILE f;
#define fp (&f)
#define fp2 fp
#endif
int r;

#ifdef VARARGS

char *s;
char *fmt;

va_start(argp);
s = va_arg(argp, char *);
fmt = va_arg(argp, char *);

#else

va_start(argp, fmt);

#endif

_initsfile(fp, s, 32767, _IOWRT);
		/* 32767 oughta be INT_MAX or something */

r = _doprnt(fmt, argp, fp);

va_end(argp);

putc('\0', fp);

return r;
}
