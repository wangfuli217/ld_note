#include <stdio.h>
#include <string.h>
#include <errno.h>

#define BUFSIZE 100

char *string1 = "test";
int num1 = 42;
char char1 = 'x';

char *progname = "esuite3";

main()
{
char buf[BUFSIZE];
char buf2[BUFSIZE];
int r;
char cb;
int ib;

/* this is not an exhaustive printf test; that's another test */

r = sprintf(buf, "%s %d %c", string1, num1, char1);

printf("sprintf returned %d\n", r);

printf("buf = \"%s\"\n", buf);

/* this is not an exhaustive scanf test; that's another test */

r = sscanf(buf, "%s %d %c", buf2, &ib, &cb);

if(r != 3)
	fprintf(stderr, "%s: sscanf returned %d\n", progname, r);

if(strcmp(buf2, string1) != 0)
	fprintf(stderr, "%s: read incorrect string\n", progname);

if(ib != num1)
	fprintf(stderr, "%s: read incorrect int\n", progname);

if(cb != char1)
	fprintf(stderr, "%s: read incorrect char\n", progname);

return 0;
}
