#include <stdio.h>
#include <string.h>
#include <errno.h>

#define BUFSIZE 100

char *string1 = "Test.\n";
char *string2 = "This is a test.";
char *string3 = "pi";
char char1 = '=';
double numf1 = 3.14;

char *progname = "esuite1";

extern char *strerror();

main()
{
int r;
int c;
char *p;
char buf[BUFSIZE];
char cb;
double db;

#ifdef PASS1

/*
 *  first, check basic ability to write stdout in various ways
 *  (file so created will also be used in first read test)
 */

for(p = string1; *p != '\0'; p++)
	putchar(*p);

if(ferror(stdout))
	{
	fprintf(stderr, "%s: putc error: %s\n", progname, strerror(errno));
	clearerr(stdout);
	}

r = puts(string2);

if(r < 0)
	{
	fprintf(stderr, "%s: puts returned %d: %s\n",
					progname, r, strerror(errno));
	clearerr(stdout);
	}

/* this is not an exhaustive printf test; that's another test */

r = printf("%s %c %.2f\n", string3, char1, numf1);

if(r < 0)
	{
	fprintf(stderr, "%s: printf returned %d: %s\n",
					progname, r, strerror(errno));
	clearerr(stdout);
	}

#endif /* PASS1 */

#ifdef PASS2

/* try reading the file */

p = buf;

while((c = getchar()) != EOF)
	{
	*p++ = c;
	if(c == '\n')
		break;
	}

*p = '\0';

if(c == EOF)
	{
	fprintf(stderr, "%s: premature EOF", progname);
	if(ferror(stdin))
		{
		fprintf(stderr, ": %s", strerror(errno));
		clearerr(stdin);
		}
	fprintf(stderr, "\n");
	}

if(strcmp(buf, string1) != 0)
	fprintf(stderr, "%s: read incorrect string 1\n", progname);

p = gets(buf);

if(p == NULL)
	{
	fprintf(stderr, "%s: unexpected EOF (gets)", progname);
	if(ferror(stdin))
		{
		fprintf(stderr, ": %s", strerror(errno));
		clearerr(stdin);
		}
	fprintf(stderr, "\n");
	}

if(strcmp(buf, string2) != 0)
	fprintf(stderr, "%s: read incorrect string 2\n", progname);

/* this is not an exhaustive scanf test; that's another test */

r = scanf("%s %c %lf\n", buf, &cb, &db);

if(r != 3)
	{
	fprintf(stderr, "%s: scanf returned %d", progname, r);
	if(ferror(stdin))
		{
		fprintf(stderr, ": %s", strerror(errno));
		clearerr(stdin);
		}
	fprintf(stderr, "\n");
	}

if(strcmp(buf, string3) != 0)
	fprintf(stderr, "%s: read incorrect string 3\n", progname);

if(cb != char1)
	fprintf(stderr, "%s: read incorrect char\n", progname);

if(db != numf1)
	fprintf(stderr, "%s: read incorrect double (%g != %g)\n",
						progname, db, numf1);

#endif /* PASS2 */

return 0;
}
