#include <stdio.h>
#include "stdio2.h"

fileno(fp)
FILE *fp;
{
/* #if defined(_IOB2) && defined(_CHARFILE)	XXX obscure godiva cpp bug */
#if _IOB2 && _CHARFILE
#define fpfi IOB2(fp)
#else
#define fpfi fp
#endif

return fpfi->_file;
}
