#include <stdio.h>
#include "stdio2.h"

extern int (*_freefunc)();

setbuf(fp, buf)
FILE *fp;
char *buf;
{
#ifdef _IOB2
struct _iobuf2 *fp2 = IOB2(fp);
#else
#define fp2 fp
#endif
#ifdef _CHARFLAGS
#define fpfl fp2
#else
#define fpfl fp
#endif
#ifdef _BUFSZ2
#define fpb fp2
#else
#define fpb fp
#endif

if(fpfl->_flag & _IOMYBUF)
	(*_freefunc)(fp->_base);

fpfl->_flag &= ~(_IOMYBUF | _IONBF);

if(buf == NULL)
	{
	fp->_base = fp->_ptr = &fp2->_tinybuf;
	fp->_cnt = fpb->_bufsiz = 1;
	fpfl->_flag |= _IONBF;
	}
else	{
	fp->_base = fp->_ptr = buf;
	fpb->_bufsiz = BUFSIZ;

	/*
	 *  The same issue arises here as in fseek.
	 *  Don't worry about it much, since nobody ever said
	 *  setbuf was supposed to work after a read or write
	 *  (i.e. when _base non-NULL).
	 */

	if(fpfl->_flag & _IOWRT)
		fp->_cnt = fpb->_bufsiz;
	else	fp->_cnt = 0;
	}
}
