#include <stdio.h>
#include <errno.h>

char *progname = "esuite5";

extern char *strerror();

noisyread(fd, buf, n)
int fd;
char *buf;
int n;
{
printf("reading %d\n", n);
return n;
}

noisywrite(fd, buf, n)
int fd;
char *buf;
int n;
{
printf("writing %d\n", n);
return n;
}

noisyclose(fd)
int fd;
{
printf("closing\n");
return 0;
}

main()
{
char *fn = "/dev/null";
FILE *fd;
int r;
char junk[2 * BUFSIZ];	/* probably oughta initialize... */

fd = fopen(fn, "w");
if(fd == NULL)
	{
	fprintf(stderr, "%s: can't create/write to %s: %s\n",
					progname, fn, strerror(errno));
	exit(1);
	}

r = fsetfuncs(fd, noisyread, noisywrite, (long (*)())NULL, noisyclose);

if(!r)	fprintf(stderr, "fsetfuncs returned %d\n", r);

putc('T', fd);
putc('h', fd);
putc('i', fd);
putc('s', fd);
putc('\n', fd);

if(ferror(fd))
	{
	fprintf(stderr, "%s: putc error(s): %s\n", progname, strerror(errno));
	clearerr(fd);
	}

printf("%s: calling fflush\n", progname);

r = fflush(fd);

if(r == EOF)
	fprintf(stderr, "%s: fflush returned %d: %s\n",
					progname, r, strerror(errno));

printf("%s: about to fwrite a lot\n", progname);

r = fwrite(junk, BUFSIZ, 2, fd);

if(r != 2)
	fprintf(stderr, "%s: fwrite returned %d: %s\n",
					progname, r, strerror(errno));

printf("%s: about to close\n", progname);

r = fclose(fd);

if(r != 0)
	{
	fprintf(stderr, "%s: fclose returned %d: %s\n",
					progname, r, strerror(errno));
	}

return 0;
}
