#include <stdio.h>
#include "stdio2.h"

ferror(fp)
FILE *fp;
{
/* #if defined(_IOB2) && defined(_CHARFLAGS)	XXX obscure godiva cpp bug */
#if _IOB2 && _CHARFLAGS
#define fpfl IOB2(fp)
#else
#define fpfl fp
#endif

return fpfl->_flag & _IOERR;
}
