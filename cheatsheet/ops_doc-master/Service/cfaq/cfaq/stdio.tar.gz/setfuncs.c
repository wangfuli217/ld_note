#include <stdio.h>
#include "stdio2.h"
#include "funcs.h"
#include "defs.h"

extern struct _iofuncs _dfltfuncs;

fsetfuncs(fp, readfunc, writefunc, seekfunc, closefunc)
FILE *fp;
int (*readfunc)(), (*writefunc)();
long int (*seekfunc)();
int (*closefunc)();
{
if(fp == NULL)
	{
	_readfunc = readfunc;
	_writefunc = writefunc;
	_seekfunc = seekfunc;
	_closefunc = closefunc;
	}
else	{
#ifdef _IOB2
	struct _iobuf2 *fp2 = IOB2(fp);
#else
#define fp2 fp
#endif
	struct _iofuncs *fpfu = fp2->_funcs;

	if(fpfu == &_dfltfuncs)
		{
		if(!_ownfuncs(fp))
			return FALSE;

		fpfu = fp2->_funcs;
		}

	fpfu->_readfunc = readfunc;
	fpfu->_writefunc = writefunc;
	fpfu->_seekfunc = seekfunc;
	fpfu->_closefunc = closefunc;
	}

return TRUE;
}

_ownfuncs(fp)
FILE *fp;
{
#ifdef _IOB2
struct _iobuf2 *fp2 = IOB2(fp);
#else
#define fp2 fp
#endif
struct _iofuncs *newfu;

newfu = (struct _iofuncs *)(*_mallocfunc)(sizeof(struct _iofuncs));

if(newfu == NULL)
	return FALSE;

*newfu = *fp2->_funcs;
fp2->_funcs = newfu;

return TRUE;
}
