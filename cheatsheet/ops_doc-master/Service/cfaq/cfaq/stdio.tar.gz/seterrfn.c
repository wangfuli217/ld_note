#include <stdio.h>
#include "stdio2.h"
#include "defs.h"

extern int (*_deflterrfunc)();

extern struct _iofuncs _dfltfuncs;

fseterrfunc(fp, errfunc)
FILE *fp;
int (*errfunc)();
{
if(fp == NULL)
	_deflterrfunc = errfunc;
else	{
#ifdef _IOB2
	struct _iobuf2 *fp2 = IOB2(fp);
#else
#define fp2 fp
#endif

	if(fp2->_funcs == &_dfltfuncs)
		{
		if(!_ownfuncs(fp))
			return FALSE;
		}

	fp2->_funcs->_errfunc = errfunc;
	}

return TRUE;
}
