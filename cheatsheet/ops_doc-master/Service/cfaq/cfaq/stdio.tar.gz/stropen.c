#include <stdio.h>

extern FILE *_getfile();

FILE *
stropen(str, mode)
char *str;
char *mode;
{
register FILE *fp;
int flags = 0;
int n;

if(*mode == 'r')
	{
	n = strlen(str);
	flags |= _IOREAD;
	}
else if(*mode == 'w' || *mode == 'a')
	{
	n = 32767;			/* oughta be INT_MAX or something */
	flags |= _IOWRT;
	}
else	{
	return NULL;
	}

if((fp = _getfile()) == NULL)
	return NULL;

_initsfile(fp, str, n, flags);

if(*mode == 'a')
	fp->_ptr += strlen(str);

return fp;
}
