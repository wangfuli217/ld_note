#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "defs.h"

#define MAXLINE 100

#define NONE	0
#define INT	1
#define STRING	2
#define DOUBLE	3
#define CHAR	4
#define LONG	5
#define UNSIGNED 6
/* #define UNSLONG 7 */

extern unsigned strtou();

main(argc, argv)
int argc;
char *argv[];
{
char line[MAXLINE];
char line2[MAXLINE];
int ac;
char *av[6];
char *fmt;
int wid, prec;
char *arg;
int argtype;
char buf[MAXLINE];
char *expected;
int nargs;
int intarg;
char *stringarg;
char chararg;
double fparg;
long longarg;
unsigned unsarg;
int learn = FALSE;
int lineno;

if(argc > 1 && strcmp(argv[1], "-l") == 0)
	learn = TRUE;

lineno = 0;

while(getline(stdin, line, MAXLINE) != EOF)
	{
	lineno++;

	if(*line == '#')
		continue;

	strcpy(line2, line);

	if((ac = getargs(av, line2, 5)) == 0)
		continue;

	fmt = av[0];

	if(!learn)
		expected = av[ac-1];
	else	{
		expected = NULL;
		ac++;		/* pretend we had it */
		}

	switch(ac)
		{
		case 2:
			arg = NULL;
			nargs = 0;
			break;

		case 3:
			arg = av[1];
			nargs = 1;
			break;

		case 4:
			wid = atoi(av[1]);
			arg = av[2];
			nargs = 2;
			break;

		case 5:
			wid = atoi(av[1]);
			prec = atoi(av[2]);
			arg = av[3];
			nargs = 3;
			break;

		default:
			fprintf(stderr, "unparseable input, line %d\n", lineno);
		}

	if(arg == NULL)
		argtype = NONE;
	else	argtype = intuitargtype(fmt);

	switch(argtype)
		{
		case NONE:
			break;

		case INT:
			intarg = strtoi(arg, (char **)NULL, 0);
			break;

		case STRING:
			if(strcmp(arg, "0") == 0 || strcmp(arg, "NULL") == 0)
				stringarg = NULL;
			else	stringarg = arg;
			break;

		case DOUBLE:
			fparg = atof(arg);
			break;

		case CHAR:
			chararg = *arg;
			break;

		case LONG:
			longarg = strtol(arg, (char **)NULL, 0);
			break;

		case UNSIGNED:
			unsarg = strtou(arg, (char **)NULL, 0);
			break;
#ifdef UNSLONG
		case UNSLONG:
			ularg = strtoul(arg, (char **)NULL, 0);
			break;
#endif
		}

#define Pair(a, b) (((a) << 8) | (b))

	switch(Pair(nargs, argtype))
		{
		case Pair(0, NONE):
			sprintf(buf, fmt);
			break;

		case Pair(1, INT):
			sprintf(buf, fmt, intarg);
			break;

		case Pair(2, INT):
			sprintf(buf, fmt, wid, intarg);
			break;

		case Pair(3, INT):
			sprintf(buf, fmt, wid, prec, intarg);
			break;

		case Pair(1, STRING):
			sprintf(buf, fmt, stringarg);
			break;

		case Pair(2, STRING):
			sprintf(buf, fmt, wid, stringarg);
			break;

		case Pair(3, STRING):
			sprintf(buf, fmt, wid, prec, stringarg);
			break;

		case Pair(1, DOUBLE):
			sprintf(buf, fmt, fparg);
			break;

		case Pair(2, DOUBLE):
			sprintf(buf, fmt, wid, fparg);
			break;

		case Pair(3, DOUBLE):
			sprintf(buf, fmt, wid, prec, fparg);
			break;

		case Pair(1, CHAR):
			sprintf(buf, fmt, chararg);
			break;

		case Pair(2, CHAR):
			sprintf(buf, fmt, wid, chararg);
			break;

		case Pair(3, CHAR):
			sprintf(buf, fmt, wid, prec, chararg);
			break;

		case Pair(1, LONG):
			sprintf(buf, fmt, longarg);
			break;

		case Pair(2, LONG):
			sprintf(buf, fmt, wid, longarg);
			break;

		case Pair(3, LONG):
			sprintf(buf, fmt, wid, prec, longarg);
			break;

		case Pair(1, UNSIGNED):
			sprintf(buf, fmt, unsarg);
			break;

		case Pair(2, UNSIGNED):
			sprintf(buf, fmt, wid, unsarg);
			break;

		case Pair(3, UNSIGNED):
			sprintf(buf, fmt, wid, prec, unsarg);
			break;
#ifdef UNSLONG
		case Pair(1, UNSLONG):
			sprintf(buf, fmt, ularg);
			break;

		case Pair(2, UNSLONG):
			sprintf(buf, fmt, wid, ularg);
			break;

		case Pair(3, UNSLONG):
			sprintf(buf, fmt, wid, prec, ularg);
			break;
#endif
		}

	if(!learn)
		{
		if(strcmp(buf, expected) != 0)
			{
			printf("line %d: for %s: got \"%s\" instead of \"%s\"\n",
						lineno, fmt, buf, expected);

			}
		}
	else	{
		if(strpbrk(buf, " \t") == NULL)
			printf("%s\t%s\n", line, buf);
		else	printf("%s\t\"%s\"\n", line, buf);
		}
	}

return 0;
}

intuitargtype(fmt)
char *fmt;
{
char *p;
int lflag;
int argtype;

if(fmt == NULL)
	return NONE;

for(p = fmt; *p != '\0'; p++)
	{
	if(*p != '%')
		continue;

	argtype = NONE;
	lflag = FALSE;

	for(p++; *p != '\0'; p++)
		{
		switch(*p)
			{
			case 'l':
				lflag = TRUE;
				continue;

			case 'c':
				argtype = CHAR;
				break;

			case 'd':
			case 'i':
/* extensions: */	case 'b':
			case 'r':
			case 'R':
				argtype = lflag ? LONG : INT;
				break;

			case 'u':
			case 'o':
			case 'x':
			case 'X':
				if(!lflag)
					argtype = UNSIGNED;
				else	{
#ifdef UNSLONG
					argtype = UNSLONG;
#else
					fprintf(stderr,
					      "can't do unsigned long yet\n");
					argtype = NONE;
#endif
					}
				break;

			case 'f':
			case 'e':
			case 'E':
			case 'g':
			case 'G':
				argtype = DOUBLE;
				break;

			case 's':
				argtype = STRING;
				break;

			case '%':
				argtype = NONE;
				break;

			default:
				continue;
			}

		if(argtype != NONE)
			return argtype;
		}
	}

return NONE;
}
