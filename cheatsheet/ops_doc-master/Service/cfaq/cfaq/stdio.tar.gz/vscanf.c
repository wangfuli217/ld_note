#include <stdio.h>
#ifdef VARARGS
#include <varargs.h>
#else
#include <stdarg.h>
#endif

vscanf(fmt, argp)
char *fmt;
va_list argp;
{
return _doscan(stdin, fmt, argp);
}
