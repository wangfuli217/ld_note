#include <stdio.h>
#ifdef VARARGS
#include <varargs.h>
#else
#include <stdarg.h>
#endif

vfscanf(fp, fmt, argp)
FILE *fp;
char *fmt;
va_list argp;
{
return _doscan(fp, fmt, argp);
}
