#include <stdio.h>
#include "stdio2.h"
#ifdef VARARGS
#include <varargs.h>
#else
#include <stdarg.h>
#endif

/* VARARGS2 */

#ifdef __STDC__
sscanf(char *s, char *fmt, ...)
#else
#ifdef VARARGS
sscanf(va_alist)
va_dcl
#else
sscanf(s, fmt)
char *s;
char *fmt;
#endif
#endif
{
#ifdef _IOB2
struct _iobuf3 f3;
#define fp (&f3._iob1)
#define fp2 (&f3._iob2)
#else
FILE f;
#define fp (&f)
#define fp2 fp
#endif
register va_list argp;
int r;

#ifdef VARARGS

char *s;
char *fmt;

va_start(argp);
s = va_arg(argp, char *);
fmt = va_arg(argp, char *);

#else

va_start(argp, fmt);

#endif

_initsfile(fp, s, strlen(s), _IOREAD);

r = _doscan(fp, fmt, argp);

va_end(argp);

return r;
}
