#include <stdio.h>
#ifdef FASTNBF
#include "stdio2.h"
#endif

fputs(s, fp)
register char *s;
register FILE *fp;
{
register int r = 0;

#ifdef FASTNBF

/* #if defined(_IOB2) && defined(_CHARFLAGS)	XXX obscure godiva cpp bug */
#if _IOB2 && _CHARFLAGS
#define fpfl IOB2(fp)
#else
#define fpfl fp
#endif

if(fpfl->_flag & _IONBF)
	{
	char *base = s;

	while(*s != '\0')
		s++;

	return _fwrite(fp, base, s - base);
	}

#endif

while(*s != '\0')
	r = putc(*s++, fp);

return r;
}
