#include <stdio.h>
#include "stdio2.h"
#include "defs.h"

_flsbuf(c, fp)
char c;
register FILE *fp;
{
register int r;
int nwrt;
int bufstyle;
int printedc = FALSE;
#ifdef _IOB2
struct _iobuf2 *fp2;
#else
#define fp2 fp
#endif
#ifdef _CHARFILE
#define fpfi fp2
#else
#define fpfi fp
#endif
#ifdef _CHARFLAGS
#define fpfl fp2
#else
#define fpfl fp
#endif
struct _iofuncs *fpfu;
#ifdef _BUFSZ2
#define fpb fp2
#else
#define fpb fp
#endif

if(fp == NULL)		/* would also be nice to check validity somehow */
	{
	/* set errno? */
	/* abort? */

	return EOF;
	}

#ifdef _IOB2
fp2 = IOB2(fp);
#endif

fpfu = fp2->_funcs;

if(fpfu->_flsbuf != NULL)
	return (*fpfu->_flsbuf)(c, fp);

#ifdef READWRITE

if((fpfl->_flag & _IORW) && (fpfl->_flag & (_IOREAD | _IOWRT)) == 0)
	fpfl->_flag |= _IOWRT;

#endif

if(!(fpfl->_flag & _IOWRT) || (fpfl->_flag & _IOSTRG) ||
						fpfu->_writefunc == NULL)
	{
	/* set errno? */
	/* set _IOERR? */
	/* abort? */

	return EOF;
	}

if(fp->_base == NULL)
	_getbuf(fp);

nwrt = fp->_ptr - fp->_base;

bufstyle = fpfl->_flag & (_IOFBF | _IONBF | _IOLBF);

if(bufstyle == _IOLBF)
	{
#ifdef PUTCLBUF
	if(fp->_cnt > 0)
#else
	if(fp->_ptr < fp->_base + fpb->_bufsiz)
#endif
		{
		*fp->_ptr++ = c;
#ifdef PUTCLBUF				/* shouldn't happen */
		fp->_cnt--;
#endif
		nwrt++;
		printedc = TRUE;
		}

#ifndef PUTCLBUF
	if(c != '\n')
		return c;
#endif	
	}

if(nwrt > 0)
	r = _fwrite(fp, fp->_base, nwrt);
else	r = 0;

if(!printedc && (bufstyle == _IONBF || bufstyle == _IOLBF && c == '\n'))
	{
	char realc = c;		/* so can take address portably */
				/* (strictly speaking, declaring formal */
				/*	char c; */
				/* should suffice) */

	if(_fwrite(fp, &realc, 1) < 0)
		r = -1;

	printedc = TRUE;
	}

fp->_ptr = fp->_base;

fp->_cnt = (fpfl->_flag & (_IONBF
#ifndef PUTCLBUF
				  | _IOLBF
#endif
					  )) ? 0 : fpb->_bufsiz;

if(!printedc)
	{
	*fp->_ptr++ = c;
	fp->_cnt--;
	}

if(r < 0)
	return EOF;

return c & 0377;
}

_fwrite(fp, p, n)
FILE *fp;
char *p;
int n;
{
int r;
#ifdef _IOB2
struct _iobuf2 *fp2 = IOB2(fp);
#else
#define fp2 fp
#endif
#ifdef _CHARFILE
#define fpfi fp2
#else
#define fpfi fp
#endif
#ifdef _CHARFLAGS
#define fpfl fp2
#else
#define fpfl fp
#endif
struct _iofuncs *fpfu = fp2->_funcs;

if(fpfu->_writefunc == NULL)
	return -1;

#ifdef _IOFPTR
if(fpfl->_flag & _IOFPTR)
	r = (*fpfu->_writefunc)(fp2->_fptr, p, n);
else
#endif
	r = (*fpfu->_writefunc)(fpfi->_file, p, n);

if(r < 0)		/* if r != n ?? */
	{
	fpfl->_flag |= _IOERR;
	if(fpfu->_errfunc != NULL)
		(*fpfu->_errfunc)(fp2->_filename, 'w', fp);

#ifdef _IOB2
#ifdef _CLARFLAGS
	fp->_dummyflag = fpfl->_flag;
#endif
#endif
	}

return r;
}

#ifdef FORCECLEANUP

extern int _cleanup();

static int (*dummy)() = _cleanup;

#endif
