#include <stdio.h>
#include "stdio2.h"
#ifdef VARARGS
#include <varargs.h>
#else
#include <stdarg.h>
#endif

vsprintf(s, fmt, argp)
char *s;
char *fmt;
va_list argp;
{
#ifdef _IOB2
struct _iobuf3 f3;
#define fp (&f3._iob1)
#define fp2 (&f3._iob2)
#else
FILE f;
#define fp (&f)
#define fp2 fp
#endif
int r;

_initsfile(fp, s, 32767, _IOWRT | _IOSTRG);
		/* 32767 oughta be INT_MAX or something */

r = _doprnt(fmt, argp, fp);

putc('\0', fp);

return r;
}
