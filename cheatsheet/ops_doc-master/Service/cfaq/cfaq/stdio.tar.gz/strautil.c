#include <stdio.h>
#include "stdio2.h"
#include "funcs.h"

static
_saflsbuf(c, fp)
char c;
register FILE *fp;
{
int chunk = 10;				/* make it global so tunable? */
int newsize;
char *newbase;
#ifdef _IOB2
struct _iobuf2 *fp2 = IOB2(fp);
#else
#define fp2 fp
#endif
struct _iofuncs *fpfu = fp2->_funcs;
#ifdef _BUFSZ2
#define fpb fp2
#else
#define fpb fp
#endif

newsize = fpb->_bufsiz + chunk;

#ifndef SAFEREALLOC
if(fp->_base == NULL)
	newbase = (*_mallocfunc)(newsize);
else
#endif
	newbase = (*_reallocfunc)(fp->_base, newsize);

if(newbase == NULL)
	{
	if(fpfu->_errfunc != NULL)
		(*fpfu->_errfunc)(fp2->_filename, 'm', fp);	/* ? */
	return EOF;
	}

/* relocate _ptr in case _base moved */

fp->_ptr = newbase + (fp->_ptr - fp->_base);

fp->_base = newbase;
fpb->_bufsiz = newsize;

fp->_cnt += chunk - 1;	/* -1 because we're about to put a char */

/* could/should use putc(), but paranoid about looping */

return *fp->_ptr++ = c;		/* mask & 0377? */
}

static struct _iofuncs stranullfuncs =
			{NULL, _saflsbuf, NULL, NULL, NULL, NULL, NULL};

_initsafile(fp)
register FILE *fp;
{
#ifdef _IOB2
struct _iobuf2 *fp2 = IOB2(fp);
#else
#define fp2 fp
#endif

_initsfile(fp, NULL, 0, _IOWRT);

fp2->_funcs = &stranullfuncs;
}

char *
_safinish(fp)
register FILE *fp;
{
#if defined(_IOB2) && defined(_BUFSZ2)
struct _iobuf2 *fp2 = IOB2(fp);
#else
#define fp2 fp
#endif
#ifdef _BUFSZ2
#define fpb fp2
#else
#define fpb fp
#endif

return (*_reallocfunc)(fp->_base, fpb->_bufsiz - fp->_cnt);
}
