#include <string.h>	/* for size_t */
#include <ctype.h>
#ifdef __STDC__
#include "string2.h"
#endif

strnicmp(s1, s2, n)
register const char *s1, *s2;
size_t n;
{
char c1, c2;

while(n-- > 0)
	{
	c1 = *s1++;
	if(isupper(c1))
		c1 = tolower(c1);

	c2 = *s2++;
	if(isupper(c2))
		c2 = tolower(c2);

	if(c1 != c2)

		return c1 - c2;
	if(c1 == '\0')
		break;
	}

return 0;
}
