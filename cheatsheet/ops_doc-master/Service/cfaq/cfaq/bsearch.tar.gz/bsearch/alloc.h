#ifndef ALLOC_H
#define ALLOC_H

#define Salloc(type) (type *)alloc(sizeof(type))
#define SNalloc(type, n) (type *)alloc((n) * sizeof(type))
#define Srealloc(type, ptr, n) \
		(type *)crealloc((char *)(ptr), (n) * sizeof(type))

#ifdef __STDC__

extern char *alloc(int);
extern char *crealloc(char *, int);
extern char *strsave(const char *);

#endif

extern char *alloc();
extern char *crealloc();
extern char *strsave();

#endif
