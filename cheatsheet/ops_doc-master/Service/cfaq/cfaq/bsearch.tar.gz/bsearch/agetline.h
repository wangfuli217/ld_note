/*
 *  Functions for reading arbitrary-length lines
 *  into dynamically-allocated memory.
 *
 *  Steve Summit, scs@eskimo.com
 *
 *  Feel free to reuse these functions however you like.
 *  I'm placing this header file in the Public Domain.
 *
 *  See http://www.eskimo.com/~scs/src (packages bsearch,
 *  shuffle, or sort) for possible updates.
 */

#ifndef AGETLINE_H
#define AGETLINE_H

#define AGL_OK		1
#define AGL_EOF		2
#define AGL_NOMEM	3
#define AGL_ERR		4

#ifdef __STDC__
#ifndef PROTOTYPES
#define PROTOTYPES
#endif
#endif

#if defined(__STDC__) || defined(PROTOTYPES)

#ifndef EOF
#include <stdio.h>
#endif

extern char *agetline(FILE *fp);
extern char *agetline2(FILE *fp, int *statusp, int *lenp);
extern char *agetline2x(FILE *fp, int *statusp, int *lenp);
extern int agetline3(FILE *fp, char **bufp, int *bufszp);
extern int agetline4(FILE *fp, char **bufp, int *bufszp, int offset);
extern int agetline5(FILE *fp, char **bufp, int *bufszp, int offset, int *statusp);

#endif

extern char *agetline();
extern char *agetline2();
extern char *agetline2x();

#endif
