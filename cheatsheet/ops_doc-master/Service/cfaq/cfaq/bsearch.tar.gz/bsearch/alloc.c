#include <stdio.h>
#include <stdlib.h>
#include "alloc.h"

static char nomem[] = "out of memory";

extern char *progname;

char *
alloc(size)
int size;
{
char *ret;

ret = malloc((unsigned)size);

if(ret == NULL)
	{
#ifdef PANIC
	panic(nomem);
#else
	if(progname != NULL)
		fprintf(stderr, "%s: ", progname);
	fprintf(stderr, "%s\n", nomem);
	exit(1);
#endif
	}

return ret;
}

char *
crealloc(ptr, size)
char *ptr;
int size;
{
char *ret;

#ifndef SAFEREALLOC
if(ptr == NULL)
	ret = malloc((unsigned)size);
else
#endif
	ret = realloc(ptr, (unsigned)size);

if(ret == NULL)
	{
#ifdef PANIC
	panic(nomem);
#else
	if(progname != NULL)
		fprintf(stderr, "%s: ", progname);
	fprintf(stderr, "%s\n", nomem);
	exit(1);
#endif
	}

return ret;
}
