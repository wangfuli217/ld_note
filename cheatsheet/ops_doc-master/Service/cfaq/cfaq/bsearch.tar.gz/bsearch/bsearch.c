/*
 *  Perform binary search in a sorted file.
 *
 *  A generalization of the BSD "look" program.
 *  (And if invoked via a link named "look",
 *  backwards compatible with it.)
 *
 *  Intended to be complimentary to the standard sort(1) program
 *  (analogously to the way the library functions qsort(3) and
 *  bsearch(3) are complimentary).  This program accepts many
 *  (though not yet all) of the same options as does sort(1),
 *  with the intention that a file sorted by sort(1) can be
 *  searched by this program if given the same set of sort options
 *  (+column, -n, -f, -r, etc.).
 *
 *  Significantly nonportable: assumes that ftell/fseek offset numbers
 *  are, in fact, byte offsets (as they of course are on Unix systems,
 *  but not all others).  Might work on MS-DOS filesystems (where the
 *  on-disk newline representation is CRLF); definitely won't work on
 *  a system where ftell returns "cookies" that have no relationship
 *  to byte offsets.
 *
 *  Copyright 1998-2003
 *  Steve Summit, scs@eskimo.com
 *  This code may be freely redistributed and used
 *  so long as the author's name and this notice remain intact,
 *  and any modifications are marked as such.
 *
 *  See http://www.eskimo.com/~scs/src/#bsearch for full documentation
 *  and possible updates.
 */

#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>
#include <assert.h>

#include <sys/types.h>
#include <sys/stat.h>

#ifdef mac
#include <console.h>
#endif

#include "defs.h"
#include "alloc.h"
#include "sortmain.h"
#include "agetline.h"
#include "string2.h"

char *progname = "bsearch";
#define VERSION "1.8"	/* arbitrary; 2003-02-02 */

char *usage = "usage: %s [-fmnprsx] [-t c] [-k col] [-range key] key inputfile\n";
char *lusage = "usage: %s [-afrswx] key [inputfile]\n";

int searchcol = 0;
int sortflags = 0;
int multiple = FALSE;
int prefix = FALSE;
int exact = FALSE;
int printflag = TRUE;
int printoffset = FALSE;
int bracketflag = FALSE;
int rangeflag = FALSE;

int tabchar = -1;	/* means whitespace */

char *searchkey2 = NULL;	/* XXX global 'cos I don't feel like passing */
				/* it in to search() as an extra argument, */
				/* even though that's how the regular */
				/* searchkey is passed in */

#ifdef __STDC__
int search(char *filename, char *searchkey);
#endif

extern int compare();

#ifndef unix
#ifdef GETPROGNAME
extern char *getprogname();
#endif
#endif

main(argc, argv)
int argc;
char *argv[];
{
int argi;
int didone = FALSE;
FILE *fd;
char *p;
char *searchkey = NULL;
char *filename = NULL;
char *dfltfilename = "/usr/dict/words";
int printedhelp = FALSE;
int lookcompat;

#ifdef mac
argc = ccommand(&argv);
#endif

#ifdef unix

if(argc > 0)
	{
	progname = argv[0];
	if((p = strrchr(progname, '/')) != NULL)
		progname = p + 1;
	}

#else
#ifdef GETPROGNAME

progname = getprogname(argc, argv, progname);

#endif
#endif

if((lookcompat = (strstr(progname, "look") != NULL)))
	{
	prefix = TRUE;
	multiple = TRUE;
	}

for(argi = 1; argi < argc && (argv[argi][0] == '-' || argv[argi][0] == '+'); argi++)
	{
	if(strcmp(argv[argi], "--") == 0)	/* means end of options */
		{
		argi++;
		break;
		}

	if(!lookcompat && argv[argi][0] == '+' && isdigit(argv[argi][1]))
		{
		int s = strtol(&argv[argi][1], &p, 10);
		if(searchcol == 0)
			searchcol = s + 1;	/* note: +1 for internal use */
		else	{
			fprintf(stderr,
				"%s: can only specify one search column\n",
								progname);
			}
		if(*p == '.')
			{
			fprintf(stderr,
			  "%s: warning: %s part of column specifier ignored\n",
								progname, p);
			p++;
			while(isdigit(*p))
				p++;
			}
		}
	else	p = &argv[argi][1];

	for(; *p != '\0'; p++)
		{
		switch(*p)
			{
			case '?':
printhelp:			printf(lookcompat ? lusage : usage, progname);
				printf("+#\tsearch column # (0-based)\n");
				if(lookcompat)
				      printf("-a\tuse alternate dictionary\n");
				printf("-br\tif not found, print bracketing lines\n");
#ifdef notyet
				printf("-d\tdictionary sort order\n");
#endif
#ifdef SORTDATETIME
				printf("-D\tdate/time sort\n");
#endif
				printf("-f\tfold upper/lower case (i.e. caseless)\n");
				printf("-h, -?\tprint this help message\n");
#ifdef notyet
				printf("-i\tignore non-ASCII characters\n");
#endif
				if(!lookcompat)
				  printf("-m\tfind & print multiple values\n");
				printf("-n\tinput is numeric\n");
				if(!lookcompat)
					printf("-p\tprefix match\n");
				printf("-r\tinput is in reverse order\n");
				printf("-range\tsearch for matches in range between two keys\n");
				printf("-s\tno print; status only\n");
				printf("-tc\tset tab character to c\n");
				printf("-version print version number\n");
				printf("-w\tfirst word match%s\n",
					lookcompat ? "" : " (default)");
				printf("-x\texact (whole-line) match\n");
				printedhelp = TRUE;
				break;

			case 'a':
				if(lookcompat)
					{
					dfltfilename = "/usr/dict/web2";
					break;
					}

				goto badopt;

			case 'b':
				if(*(p+1) == 'r')
					{
					bracketflag = TRUE;
					p++;
					break;
					}
				else if(strcmp(p, "bracket") == 0)
					{
					bracketflag = TRUE;
					p = "x";
					break;
					}
				else if(strcmp(p, "byte-offset") == 0)
					{
					printoffset = TRUE;
					p = "x";
					break;
					}

				/* ignore -b, since we essentially assume it */
				break;
#ifdef notyet
			case 'd':
				sortflags |= DICTIONARY;
				break;
#endif
#ifdef SORTDATETIME
			case 'D':
				sortflags = (sortflags & ~TYPEMASK) | DATETIME;
				break;
#endif
			case 'f':
				sortflags |= FOLD;
				break;

			case 'h':
			case 'H':
				if(stricmp(p, "help") == 0)
					p = "x";    /* short circuit */
				goto printhelp;
#ifdef notyet
			case 'i':
				sortflags |= IGNORE;
				break;
#endif
			case 'k':
				if(argi >= argc-1)
					fprintf(stderr,
					"%s: missing column number after -k\n",
								progname);
				else	{
					char *p2;
					int s = strtol(argv[++argi], &p2, 10);
					if(searchcol == 0)
						searchcol = s;
					else	{
						fprintf(stderr,
				    "%s: can only specify one search column\n",
								progname);
						}
					if(*p2 == '.')
						{
						fprintf(stderr,
			  "%s: warning: %s part of column specifier ignored\n",
								progname, p2);
						p2++;
						while(isdigit(*p2))
							p2++;
						}
					if(*p2 == ',')
						{
						p2++;
						while(isdigit(*p2))
							p2++;
						if(*p2 == '.')
							{
							p2++;
							while(isdigit(*p2))
								p2++;
							}
						}
					if(*p2 != '\0')
						{
						fprintf(stderr,
	       "%s: warning: \"%s\" characters after -k column spec ignored\n",
								progname, p2);
						}
					}
				break;

			case 'm':
				multiple = TRUE;
				break;

			case 'n':
				sortflags = (sortflags & ~TYPEMASK) | NUMERIC;
				break;

			case 'o':
				if(strcmp(p, "off") == 0)
					{
					printoffset = TRUE;
					p = "x";
					break;
					}

				goto badopt;

			case 'p':
				prefix = TRUE;
				break;

			case 'r':
				if(strcmp(p, "range") == 0)
					{
					rangeflag = TRUE;
					p = "x";    /* short circuit */
					break;
					}

				sortflags |= REVERSE;
				break;

			case 's':
				printflag = FALSE;
				multiple = FALSE;
				break;

			case 't':
				if(*(p+1) != '\0')
					tabchar = *++p;
				else	tabchar = argv[++argi][0];	/* XXX what if it's a string? */
				break;

			case 'v':
				if(strcmp(p, "version") == 0)
					{
printversion:				fprintf(stderr, "%s version %s\n",
							progname, VERSION);
					p = "x";    /* short circuit */
					printedhelp = TRUE;
					break;
					}
				goto badopt;

			case 'w':
				prefix = exact = FALSE;
				break;

			case 'x':
				exact = TRUE;
				break;

			case '-':
				/* just skip, to cheesily accept --longopt */
				break;

			default:
				if(isdigit(*p))
					{
					/* ignore -M.N part of column spec */
					while(isdigit(*p))
						p++;
					if(*p == '.')
						{
						p++;
						while(isdigit(*p))
							p++;
						}

					p--;	/* XXX */
					break;
					}
badopt:
				fprintf(stderr,
					"%s: unknown option -%c\n",
							progname, *p);
			}
		}
	}

if(searchcol >= MAXCOLS)
	{
	fprintf(stderr, "%s: sort column %d/%d too high (max %d/%d)\n",
			progname, searchcol-1, searchcol, MAXCOLS-1, MAXCOLS);
	exit(2);
	}

if(exact && searchcol > 0)
	{
	fprintf(stderr, "%s: can't use -x and select column\n", progname);
	exit(2);
	}

/* these three are mutually exclusive */

if(multiple && bracketflag || bracketflag && rangeflag || multiple && rangeflag)
	{
	fprintf(stderr, "%s: can use only one of -m, -b, and -range\n",
								progname);
	exit(2);
	}

if(argi < argc)
	{
	searchkey = argv[argi++];

	if(rangeflag && argi < argc)			/* XXX awkward */
		searchkey2 = argv[argi++];

	if(argi < argc)
		filename = argv[argi++];
	else if(lookcompat)
		filename = dfltfilename;
	}

if(searchkey == NULL || filename == NULL)
	{
	if(printedhelp)
		exit(0);
	fprintf(stderr, lookcompat ? lusage : usage, progname);
	exit(2);
	}

if(rangeflag && searchkey2 == NULL)
	{
	fprintf(stderr, "%s: missing second search key with -range\n",
								progname);
	exit(2);
	}

if(argi < argc)
	{
	fprintf(stderr, "%s: warning: %d extra argument%s ignored\n",
			progname, argc-argi, argc-argi == 1 ? "" : "s");

	}

if(search(filename, searchkey) > 0)
	exit(0);
else	exit(1);
}


/* ultimately derived from mbindex.c */

#define FUDGEFAC 1024	/* go SEQ when low & high get nearer than this */

#define DUNNO	0
#define TOOLOW	(-1)
#define TOOHIGH	1
#define SEQ	2
#define SUCCESS	3
#define BRACKET	4
#define RANGE	5

#ifdef DEBUG
static char *sw[] = {"TOOLOW", "DUNNO", "TOOHIGH", "SEQ", "SUCCESS", "BRACKET", "RANGE"};
static char **statuswords = &sw[1];
#endif

#ifdef __STDC__
int ncmp(const char *, const char *);
#endif

int ncmp();

#ifdef DEBUGNEW
#define COVERAGE(tag) fprintf(stderr, "%s: coverage " #tag "\n", progname)
#else
#define COVERAGE(tag)
#endif

search(filename, searchkey)
char *filename;
char *searchkey;
{
FILE *fp;
int i;
int keylen = strlen(searchkey);
int iniread = keylen + 1;
long int searchn, inpn;
struct stat stbuf;
long int low, high;
long int mid;
long int off = 0;
long int prev = -1;
long int prev2 = 0;
int resynch = FALSE;	/* if TRUE, we don't know we're at beginning-of-line */
int partialline;	/* if TRUE, inpbuf contains partial line */
int r;
int len;
int cond;
int c;
int status = DUNNO;
static char *inpbuf = NULL;
static int inpbsize = 0;
char *p;
int nfound = 0;
#ifdef __STDC__
int (*cmpfunc)(const char *, const char *);
int (*cmpnfunc)(const char *, const char *, size_t);
#else
int (*cmpfunc)();
int (*cmpnfunc)();
#endif
#ifdef DEBUGNEW
int nloops = 0, nseqloops = 0;
#endif

/* this correction may not be needed for alphabetic searches, */
/* but it's definitely needed for numeric. */
/* (And it could be written to call strlen fewer than 3 times... */
if(rangeflag && strlen(searchkey2) > strlen(searchkey))
	iniread = strlen(searchkey2) + 1;

if(sortflags & FOLD)
	{
	cmpfunc = stricmp;
	cmpnfunc = strnicmp;
	}
else if(sortflags & NUMERIC)
	{
	searchn = atol(searchkey);
	/* cmpfuncs not used */
	}
else	{
	cmpfunc = strcmp;
	cmpnfunc = strncmp;
	}

fp = fopen(filename, "r");
if(fp == NULL)
	{
	fprintf(stderr, "%s: can't open %s: ", progname, filename);
	perror("");
	exit(2);
	}

#ifdef mac
if(stat(filename, &stbuf) < 0)
#else
if(fstat(fileno(fp), &stbuf) < 0)
#endif
	{
	fprintf(stderr, "%s: can't stat %s: ", progname, filename);
	perror("");
	exit(2);
	}

low = 0;
high = stbuf.st_size;

if(inpbsize <= iniread)
	{
	inpbsize = iniread + 1;
	inpbuf = crealloc(inpbuf, inpbsize);
	}

/*
 *  Basic algorithm:
 *
 *	if not sequential,
 *		recompute mid based on low and high
 *		seek
 *		resynchronize to next line start
 *	ftell
 *	read line fragment
 *	compare
 *	if match, print, we're probably done
 *	if not, recompute high/low, and continue
 *
 *  When low and high get very close to each other,
 *  a decision can be made to "go sequential".
 *  (That decision is currently made rather conservatively, but should
 *  really be whenever low and high get within, say, BUFSIZ of each
 *  other, and certainly within a nominal line length of each other.)
 *  There are additional wrinkles to reflect the `bracketflag'
 *  and `multiple' flags.
 */

/* beware: resynch/partialline logic is way too intricate, */
/* full of subtle behavior and kludges and accidents */

while(TRUE)
	{
#ifdef DEBUGNEW
	nloops++;
	if(status == SEQ || status == BRACKET || status == RANGE)
		nseqloops++;
#endif

	if(status == SEQ)
		COVERAGE(1);
	else if(status == BRACKET || status == RANGE)
		COVERAGE(2);
	else	{
		COVERAGE(3);
#ifdef FUDGEFAC
		/*
		 *  XXX I was worried that this was/is broken: can skip a
		 *  line, since code flow from here passes two getc() != '\n'
		 *  loops
		 *  (and this is, in fact, still the case)
		 */

		if(high - low <= FUDGEFAC)
			{
			COVERAGE(4);

			mid = low;
			status = SEQ;

			/*
			 *  Gotta not resynch, so don't inadvertently
			 *  skip a line (see old concern about "code flow
			 *  from here passes two getc() != '\n' loops").
			 *  It's obvious we're at the beginning of the line
			 *  if low == 0, but not necessarily otherwise --
			 *  but hey, presto, the low-setting code has had 
			 *  a certain "light asymmetry" ever since ever,
			 *  and it's just what we need.
			 */

			resynch = FALSE;

#ifdef DEBUG2
			fprintf(stderr, "going sequential (FUDGEFAC)\n");
#endif
			}
		else
#endif
			{
			/* XXX oughta try proportional search based on alphabet */
			COVERAGE(5);
			mid = (low + high) / 2;
			}

#ifdef DEBUG
		fprintf(stderr, "seeking to %ld\n", mid);
#endif

		fseek(fp, mid, 0);

		if(mid > 0)
			{
			COVERAGE(6);
			resynch = TRUE;
			}
		}

	if(resynch)
		{
		COVERAGE(8);
		while((c = getc(fp)) != EOF && c != '\n')
			;
		}

	off = ftell(fp);

#ifdef DEBUG
	fprintf(stderr, "%ld %ld\t%ld %ld (%ld)\n", low, high, mid, off, prev);
#endif

	/* XXX check low == high here? */
	if(off == prev && status != SEQ && status != BRACKET && status != RANGE)
		{
		COVERAGE(9);

		if(status == TOOHIGH)
			{
			COVERAGE(10);
#ifdef DEBUG
			fprintf(stderr, "going sequential (squeeze)\n");
			fprintf(stderr, "seeking to %ld\n", low);
#endif
			fseek(fp, low, 0);

			off = low;	/* ? */

			if(off == 0)
				resynch = FALSE;

			status = SEQ;
			continue;
			}

#if 1 /* but about to be ifdef notused */

		if(bracketflag || rangeflag)
			{
			COVERAGE(11);
			fprintf(stderr,
"Hey! (%s:) A suspected \"notused\" case fired (%d) -- save this test case!\n",
								progname, 11);
#ifdef DEBUG
			fprintf(stderr, "going bracket/range (squeeze)\n");
			fprintf(stderr, "seeking to %ld\n", prev2);
#endif
			if(bracketflag)
				{
				COVERAGE(12);
				status = BRACKET;
				}
			else	{
				COVERAGE(13);
				assert(rangeflag);
				status = RANGE;
				searchkey = searchkey2;
				/* XXX v. awkward to repeat next 3 assgns */
				/* (and in 3 places, to boot :-( ) */
				/* (though 2 of them aren't used?!) */
				keylen = strlen(searchkey);
				if(sortflags & NUMERIC)
					searchn = atol(searchkey);
				}
			resynch = FALSE;
			fseek(fp, prev2, 0);
			continue;
			}

#ifdef DEBUG
		fprintf(stderr, "punting: status = %s, low = %ld, mid = %ld ",
						statuswords[status], low, mid);
		fprintf(stderr, "high = %ld, off = %ld, prev = %ld\n",
							high, off, prev);
#endif
		break;
		}

#endif

	prev = off;

	partialline = FALSE;

	/* could theoretically get away with a partial read if, */
	/* say, searchcol == 3, but it's not worth it... */

	if(searchcol > 1)
		{
		COVERAGE(14);
		r = agetline3(fp, &inpbuf, &inpbsize);
		resynch = FALSE;
		}
	else	{
		COVERAGE(15);
		r = fread(inpbuf, 1, iniread, fp);
		if(r == 0)
			{
			COVERAGE(16);
			r = EOF;
			}
		else	{
			COVERAGE(17);
			inpbuf[r] = '\0';
			partialline = TRUE; /* maybe -- double-checked below */
			if(inpbuf[r-1] != '\n')
				resynch = TRUE;
			}
		}

#ifdef DEBUG
	if(r != EOF)
		fprintf(stderr, "trying \"%s...\", off = %ld\n", inpbuf, off);
#endif

compare:

	if(r == EOF)
		{
		COVERAGE(18);
		cond = 1;	/* too high */
		}
	else if(searchcol <= 1)
		{
		COVERAGE(19);
#ifdef DEBUG3
		fprintf(stderr, "(beginning-of-line case)\n");
#endif
		if(partialline && (p = strchr(inpbuf, '\n')) != NULL)
			{
			COVERAGE(20);
			*p = '\0';

			fseek(fp, (long)(-(r - (p-inpbuf))), 1);      /* XXX */

			r = p - inpbuf;
			partialline = FALSE;
			resynch = TRUE;		/* ? */
			}

#if 1 /* but about to be ifdef notused */
		if(prefix && r < keylen)
			{
			fprintf(stderr,
"Hey! (%s:) A suspected \"notused\" case fired (%d) -- save this test case!\n",
								progname, 21);
			COVERAGE(21);
			cond = -1;
			}
		else
#endif
		if(!(sortflags & NUMERIC))
			{
			COVERAGE(22);
			cond = exact ? (*cmpfunc)(inpbuf, searchkey) :
				(*cmpnfunc)(inpbuf, searchkey, keylen);
			}
		else	{
			COVERAGE(23);
			inpn = atol(inpbuf);
			if(inpn < searchn)
				cond = -1;
			else if(inpn > searchn)
				cond = 1;
			else	cond = 0;
			}

		if(cond == 0 && !prefix && !exact)
			{
			COVERAGE(24);

			if(!(inpbuf[keylen] == '\0' ||
				(tabchar == -1 ? Iswhite(inpbuf[keylen]) :
						   inpbuf[keylen] == tabchar)))
				{
				COVERAGE(25);
				cond = 1;
				}
			}

		if(cond == 0 && exact) assert(!partialline);
#ifdef notdef	/* shouldn't need, since iniread = strlen(searchkey) + 1 */
		if(cond == 0 && exact && partialline)
			{
			COVERAGE(26);
			r = agetline4(fp, &inpbuf, &inpbsize, r);
			resynch = FALSE;
			partialline = FALSE;
			if(r > keylen)
				{
				COVERAGE(27);
				cond = 1;
				/* does this reverse the same way? */
				}
			}
#endif
		}
	else	{
		char *starts[MAXCOLS];
		int lens[MAXCOLS];
		int nc;
		int n;

		COVERAGE(28);
#ifdef DEBUG2
		fprintf(stderr, "(somewhere-in-the-middle case)\n");
		fprintf(stderr, "splitting \"%s\"\n", inpbuf);
#endif
		nc = split(inpbuf, starts, lens, MAXCOLS);
		if(searchcol > nc)
			{
			fprintf(stderr, "%s: too few input columns (%d < %d)\n",
					progname, nc, searchcol);
			return 0;			/* ? */
			}

#ifdef DEBUG
		fprintf(stderr, "trying \"%.*s\"\n",
				lens[searchcol-1], starts[searchcol-1]);
#endif

		if(sortflags & NUMERIC)
			{
			COVERAGE(29);
			inpn = atol(starts[searchcol-1]);
			if(inpn < searchn)
				cond = -1;
			else if(inpn > searchn)
				cond = 1;
			else	cond = 0;
			}
		else	{
			COVERAGE(30);

			n = keylen;
			if(lens[searchcol-1] < n)
				n = lens[searchcol-1];

			cond = (*cmpnfunc)(starts[searchcol-1], searchkey, n);

			if(cond == 0)
				{
				COVERAGE(31);

				if(lens[searchcol-1] < keylen)
					{
					COVERAGE(32);
					cond = -1;
					}
				else if(!prefix && lens[searchcol-1] > keylen)
					{
					COVERAGE(33);
					cond = 1;
					}
				}
			}
		}

	if((sortflags & REVERSE) && r != EOF)
		cond = -cond;

	if(cond < 0)
		prev2 = off;

	if((multiple || rangeflag) && cond == 0 && status != SEQ && status != BRACKET && status != RANGE)
		{
		COVERAGE(34);
		cond = 1;	/* keep backing up to find first */
		}

	if(status == SEQ && cond >= 0 && rangeflag && r != EOF)
		{
		COVERAGE(35);

		/*
		 *  We've definitely found the beginning of the range
		 *  (though we didn't find it exactly).
		 *  We could *almost* go sequential now, and compare
		 *  against searchkey2 from now on, except:
		 *  the line we're at might be too big.
		 *  It'd be nice to just "go sequential",
		 *  having set searchkey to searchkey2,
		 *  but I can't prove that wouldn't read another line.
		 *  So for now, it's a goto back to just the
		 *  cond-setting comparison step
		 *  (itself excessively complicated, which is why
		 *  I can't possibly repeat it here).
		 */

#ifdef DEBUG
		fprintf(stderr, "going range (after seq)\n");
#endif

		status = RANGE;
		searchkey = searchkey2;
		/* XXX v. awkward to repeat next 3 assgns */
		/* (and in 3 places, to boot :-( ) */
		keylen = strlen(searchkey);
		if(sortflags & NUMERIC)
			searchn = atol(searchkey);
		goto compare;
		}

	if(cond == 0 || (status == BRACKET || status == RANGE && cond <= 0) && r != EOF)
		{
		COVERAGE(36);

#ifdef DEBUG2
		fprintf(stderr, "got it\n");
#endif

#if 1 /* but about to be ifdef notused */
		if(rangeflag && status != RANGE)
			{
			fprintf(stderr,
"Hey! (%s:) A suspected \"notused\" case fired (%d) -- save this test case!\n",
								progname, 37);
			COVERAGE(37);
			status = RANGE;
			searchkey = searchkey2;
			/* XXX v. awkward to repeat next 3 assgns */
			/* (and in 3 places, to boot :-( ) */
			/* (though 2 of them aren't used?!) */
			keylen = strlen(searchkey);
			if(sortflags & NUMERIC)
				searchn = atol(searchkey);
			}
#endif

		if(cond == 0)
			nfound++;
		else if(cond < 0 && status == RANGE)
			nfound++;

		len = r;

		/* XXX this next case never fires?  ("notused"?) */
		if(partialline && (p = strchr(inpbuf, '\n')) != NULL)
			{
			COVERAGE(38);
			fprintf(stderr,
"Hey! (%s:) A suspected \"notused\" case fired (%d) -- save this test case!\n",
								progname, 38);
			len = p - inpbuf;
			partialline = FALSE;
			}

		if(printflag)
			{
			COVERAGE(39);
			if(printoffset)
				printf("%lu:", off);	/* XXX is off always accurate? */
							/* (seems it'll sometimes need correction due to various partialline cases) */

			if(status == BRACKET)
				putchar(cond < 0 ? '<' : '>');

			printf("%.*s", len, inpbuf);

			if(partialline)
				{
				COVERAGE(40);
				while((c = getc(fp)) != EOF && c != '\n')
					putchar(c);
				partialline = FALSE;
				resynch = FALSE;
				}

			putchar('\n');
			}

		if(status == BRACKET)
			{
			COVERAGE(41);
			if(cond > 0)
				{
				COVERAGE(42);
#ifdef DEBUG
				fprintf(stderr, "finished (BRACKET)\n");
#endif
				break;
				}
			}
		else if(status == RANGE)
			COVERAGE(43);
		else if(!multiple)
			{
			COVERAGE(44);
#ifdef DEBUG
			fprintf(stderr, "status = SUCCESS\n");
#endif
			status = SUCCESS;
			break;
			}
		}

	if(status == BRACKET)
		{
		COVERAGE(45);
		if(r == EOF)
			break;
		continue;
		}

	if(status == RANGE)
		{
		COVERAGE(46);
		if(cond > 0 || r == EOF)
			{
			COVERAGE(47);
			if(nfound > 0)
				status = SUCCESS;
			break;
			}
		continue;
		}

	if(status == SEQ)
		{
		COVERAGE(48);

		if(cond > 0 || r == EOF)
			{
			COVERAGE(49);
#ifdef DEBUG
			fprintf(stderr, "punting: overshot sequential\n");
#endif
			if(nfound > 0)
				{
				COVERAGE(50);
#ifdef DEBUG
				fprintf(stderr, "status = SUCCESS\n");
#endif
				status = SUCCESS;
				}
			else if(bracketflag)
				{
				COVERAGE(51);
#ifdef DEBUG
				fprintf(stderr, "going bracket (overshot)\n");
				fprintf(stderr, "seeking to %ld\n", prev2);
#endif
				status = BRACKET;
				resynch = FALSE;
				fseek(fp, prev2, 0);
				continue;
				}

			break;
			}

		continue;
		}

	if(cond < 0)
		{
		COVERAGE(52);
		low = off;		/* yes, light asymmetry (was mid) */
				/* but handy to have low always @ line beg */
				/* (see esp. comment in FUDGEFAC code above) */
		status = TOOLOW;
		}
	else	{
		COVERAGE(53);
		high = mid;
		status = TOOHIGH;
		}
	}

#ifdef DEBUGNEW
fprintf(stderr, "%s: %d loops (%d sequential)\n", progname, nloops, nseqloops);
fprintf(stderr, "%s: final status %d\n", progname, status);
#endif

#ifdef DEBUG
if(status != SUCCESS)
	printf("(not found)\n");
#endif

fclose(fp);

return nfound;
}

ncmp(s1, s2)
const char *s1, *s2;
{
long n1 = atol(s1), n2 = atol(s2);
if(n1 < n2)
	return -1;
else if(n1 > n2)
	return 1;
else	return 0;
}
