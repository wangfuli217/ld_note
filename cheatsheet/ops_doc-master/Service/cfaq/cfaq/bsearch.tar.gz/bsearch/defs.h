#ifndef DEFS_H
#define DEFS_H

#define TRUE 1
#define FALSE 0

#ifndef NULL
#define NULL 0
#endif

#endif
