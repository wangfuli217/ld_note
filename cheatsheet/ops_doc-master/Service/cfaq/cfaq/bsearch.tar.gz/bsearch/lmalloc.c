/*
 *  "Limited" malloc.
 *
 *  For a program like sort, when memory is fixed (that is, in the
 *  absence of virtual memory), a "boogie 'til you puke" strategy is
 *  appropriate: rather than trying to know how much memory is available,
 *  and work within it (which involves an eternally frustrating
 *  system-dependent step, namely trying to know how much memory is
 *  available), it's better to just keep calling malloc 'til it fails
 *  (which means you've empirically found the limit, using portable
 *  code!), then try to pick up the pieces.  (Doing so can, it must
 *  be admitted, be a little tricky, but anyway.)
 *
 *  On a VM machine, however, malloc never ("well, hardly ever") fails,
 *  and the caller gets the impression it can have as much memory as it
 *  wants, except that trying to, say, sort the whole schmear in-memory
 *  leads to a downward spiral of bad thrashing.  (In other words, for
 *  a problem like sorting, smaller memory footprints plus explicit
 *  temporary files seem to perform much better.)
 *
 *  So we're going to invoke a self-imposed limit on the total amount
 *  of memory that can be malloc'ed.  Since the caller already knows how
 *  to pick up the pieces when malloc returns NULL, we can impose the
 *  limit down here, in a simple malloc wrapper, and just return NULL
 *  when the limit is reached.
 *
 *  Copyright 1993-2003
 *  Steve Summit, scs@eskimo.com
 *  This code may be freely redistributed and used
 *  so long as the author's name and this notice remain intact,
 *  and any modifications are marked as such.
 *
 *  See http://www.eskimo.com/~scs/src for possible updates.
 */

#ifdef DEBUG
#include <stdio.h>
#endif
#include <stdlib.h>

#ifdef VMLIMIT
static long int totmalloc = 0;
#endif

char *
lmalloc(size)
int size;
{
char *ret;

#ifdef VMLIMIT
if(totmalloc >= VMLIMIT)
	{
#ifdef DEBUG
	fprintf(stderr, "lmalloc: premature return (%ld)\n", totmalloc);
#endif
	return NULL;
	}
#endif

ret = malloc(size);

#ifdef VMLIMIT
if(ret != NULL)
	totmalloc += size;
#endif

return ret;
}

char *
lrealloc(oldptr, size)
char *oldptr;
int size;
{
char *ret;

#ifdef VMLIMIT
if(totmalloc >= VMLIMIT)
	{
#ifdef DEBUG
	fprintf(stderr, "lrealloc: premature return (%ld)\n", totmalloc);
#endif
	return NULL;
	}
#endif

ret = realloc(oldptr, size);

#ifdef VMLIMIT
if(ret != NULL)
	totmalloc += size / 2;	/* XXX wrong; should be += size - oldsize */
#endif

return ret;
}

lmalreset()
{
#ifdef VMLIMIT
#ifdef DEBUG2
fprintf(stderr, "lmalreset: resetting\n");
#endif
totmalloc = 0;
#endif
}
