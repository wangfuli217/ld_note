#ifndef SORTMAIN_H
#define SORTMAIN_H

#ifndef EOF
#include <stdio.h>
#endif

#define MAXCOLS 100

#define Iswhite(c) ((c) == ' ' || (c) == '\t' || (c) == '\r')

struct column
	{
	int c_number;
	int c_n2;
	int c_flags;
	struct column *c_next;
	};

#define NUMERIC	 1
#define FILENAME 2
#ifdef SORTDATETIME
#define DATETIME 3
#endif

#define TYPEMASK 0x0f

#define FOLD	 0x10
#define UNIQUE	 0x20
#define REVERSE	 0x40
#define FLOATING 0x80

extern char *progname;

extern struct column *columns;

extern int uflag;
extern int defltflags;

extern int keepgoing;
extern int onlyselected;

#ifdef __STDC__
extern stashalloc(void);
extern stashfree(void);
extern input(
#ifndef DBSORT
	     FILE *,
#else
	     struct dbfd *,
#endif
			    char *);
extern split(char *str, char *[], int [], int);
extern anothertemp(void);
extern compare(char *, char *);
#ifdef DBSORT
extern dbcompare(char *, char *);
extern dbsetup(void);
extern dbset2up(struct dbfd *);
#endif
extern dosort(void);
extern merge(FILE *, char *);
extern output(FILE *, char *);
#endif

#endif
