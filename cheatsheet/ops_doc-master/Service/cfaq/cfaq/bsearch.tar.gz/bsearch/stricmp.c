#include <ctype.h>

stricmp(s1, s2)
register char *s1, *s2;
{
char c1, c2;

do	{
	c1 = *s1++;
	if(isupper(c1))
		c1 = tolower(c1);

	c2 = *s2++;
	if(isupper(c2))
		c2 = tolower(c2);

	if(c1 != c2)
		return c1 - c2;

	} while(c1 != '\0');

return 0;
}
