/*
 *  Split a line into columns.
 *  Used by sort and bsearch programs.
 */

#include "sortmain.h"

extern int tabchar;

split(str, start, len, maxcols)
char *str;
char *start[];
int len[];
int maxcols;
{
register char *p = str;
register int i = 0;

do	{
	if(tabchar == -1)
		{
		while(Iswhite(*p))
			p++;
		}

	if(*p == '\0')
		break;

	if(i < maxcols)
		start[i] = p;

	while(*p != '\0' && !(tabchar == -1 ? Iswhite(*p) : *p == tabchar))
		p++;

	if(i < maxcols)
		{
		len[i] = p - start[i];

		i++;
		}

	if(tabchar != -1 && *p != '\0')
		p++;
	} while(*p != '\0');

return i;
}
