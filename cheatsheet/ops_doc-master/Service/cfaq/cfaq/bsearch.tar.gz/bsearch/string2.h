#ifdef __STDC__

#include <stddef.h>

extern int stricmp(const char *, const char *);
extern int strnicmp(const char *, const char *, size_t);
extern int strtoi(const char *, char **, int);
extern double strntod(const char *, int, char **);
extern long int strntol(const char *, int, char **, int);
extern char *strsave(const char *);

#endif

extern int stricmp();
extern int strnicmp();
extern int strtoi();
extern double strntod();
extern long int strntol();
extern char *strsave();

#ifndef NULL
#define NULL 0
#endif
