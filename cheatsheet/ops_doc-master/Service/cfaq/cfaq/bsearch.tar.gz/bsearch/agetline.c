/*
 *  Functions for reading arbitrary-length lines
 *  into dynamically-allocated memory.
 *
 *  Steve Summit, scs@eskimo.com
 *
 *  Feel free to reuse these functions however you like.
 *  I'm placing this source file in the Public Domain.
 *
 *  See http://www.eskimo.com/~scs/src (packages bsearch,
 *  shuffle, or sort) for possible updates.
 */

#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include "agetline.h"
#include "defs.h"

#define CHUNK 16

#ifdef VMLIMIT

extern char *lmalloc();
extern char *lrealloc();

#else

#define lmalloc malloc
#define lrealloc realloc

#endif

extern char *progname;

/* agetline1: simplest interface */
/* returns malloc'ed pointer to line, or NULL on EOF/error */

char *
agetline(fp)
FILE *fp;
{
return agetline2(fp, (int *)NULL, (int *)NULL);
}

/* agetline2: also returns length and status */
/* (principal return still malloc'ed pointer) */

char *
agetline2(fp, statusp, lenp)
FILE *fp;
int *statusp;
int *lenp;
{
char *buf = NULL;
int allocated = 0;
int len;
char *newbuf;

len = agetline5(fp, &buf, &allocated, 0, statusp);
newbuf = realloc(buf, (unsigned)(len + 1));	/* hmm, not lrealloc */
if(newbuf != NULL)
	buf = newbuf;
if(len >= 0 && lenp != NULL)
	*lenp = len;
return buf;
}

/* agetline2x: also returns length and status */
/* fancy out-of-memory interlock, for use with sort */

char *
agetline2x(fp, statusp, lenp)
FILE *fp;
int *statusp;
int *lenp;
{
char *base = NULL;
int allocated = 0;
int len = 0;
static char *prevbase = NULL;
static int prevalloc = 0;
static int prevlen = 0;
static FILE *prevfp = NULL;
char *newbase;
int status = 0;

if(prevbase != NULL)
	{
	if(prevfp != fp)
		{
		fprintf(stderr, "%s: agetline: panic: fp mismatch\n",
								progname);
		exit(1);
		}

	base = prevbase;
	allocated = prevalloc;
	len = prevlen;

	prevbase = NULL;
	prevalloc = 0;
	prevlen = 0;
	prevfp = NULL;
	}

len = agetline5(fp, &base, &allocated, len, &status);

if(statusp != NULL)
	*statusp = status;

if(len < 0)
	{
	if(status == AGL_EOF)
		free(base);
	else if(status == AGL_NOMEM)
		{
		prevbase = base;
		prevalloc = allocated;
		prevlen = len;
		prevfp = fp;
		}
	/* else ? */

	return NULL;
	}

newbase = realloc(base, (unsigned)(len + 1));	/* hmm, not lrealloc */
if(newbase != NULL)
	base = newbase;

return base;
}

/* agetline3: manipulates caller-supplied buffer */
/* returns length read or EOF */

int agetline3(fp, bufp, bufszp)
FILE *fp;
char **bufp;
int *bufszp;
{
return agetline4(fp, bufp, bufszp, 0);
}

/* agetline4: manipulates caller-supplied buffer, */
/* allows offset for completing reading of previous partial line */
/* returns length read or EOF */

int agetline4(fp, bufp, bufszp, offset)
FILE *fp;
char **bufp;
int *bufszp;
int offset;
{
return agetline5(fp, bufp, bufszp, offset, (int *)NULL);
}

/* agetline5: master, most-general routine; does the real work */
/* returns length read or EOF */

int agetline5(fp, bufp, bufszp, offset, statusp)
register FILE *fp;
char **bufp;
int *bufszp;
int offset;
int *statusp;
{
char *base = *bufp;
register char *p = base + offset;
int len = offset;
int allocated = *bufszp;
register int c;

while(TRUE)
	{
	if(len >= allocated)
		{
		int newalloc = allocated + CHUNK;
		char *newbase;

		assert(len < newalloc);

#ifndef SAFEREALLOC
		if(base == NULL)
			newbase = lmalloc(newalloc);
		else
#endif
			newbase = lrealloc(base, newalloc);

		if(newbase == NULL)
			{
			*bufp = base;
			*bufszp = allocated;
			if(statusp != NULL)
				*statusp = AGL_NOMEM;
			return EOF;
			}

		allocated = newalloc;
		base = newbase;

		p = &base[len];
		}

	c = getc(fp);

	if(c == EOF && len == 0)
		{
		*bufp = base;		/* probably */
		*bufszp = allocated;	/* redundant */
		if(statusp != NULL)
			*statusp = AGL_EOF;
		return EOF;
		}

	len++;

	if(c == '\n' || c == EOF)
		{
		*p++ = '\0';
		break;
		}

	*p++ = c;
	}

if(statusp != NULL)
	*statusp = AGL_OK;

/* caller reallocs back down if desired */

*bufp = base;
*bufszp = allocated;

return len - 1;		/* our len includes \0 */
}
