/*
 *  plaintext "database" library -- add an index on a certain key
 *
 *  Copyright 1987-2002
 *  Steve Summit, scs@eskimo.com
 *  This code may be freely redistributed and used
 *  so long as the author's name and this notice remain intact,
 *  and any modifications are marked as such.
 */

#include "alloc.h"
#define DEF_DB
#include "db.h"
#include "defs.h"

db_addindex(dbd, nmajkeys, majkeys)
struct db *dbd;
int nmajkeys;
char **majkeys;
{
struct dbindex *ip;
int i, j;

/* oughta check for duplicates */

j = dbd->db_nmajkeys;

dbd->db_nmajkeys += nmajkeys;
dbd->db_majkeys = Srealloc(struct dbindex, dbd->db_majkeys, dbd->db_nmajkeys);

for(i = 0; i < nmajkeys; i++)
	{
	ip = &dbd->db_majkeys[j];
	ip->dbi_key = db_hashkey(dbd, majkeys[i], dbd->db_flags);
	ip->dbi_tree = NULL;

	j++;
	}
}

/* maybe doesn't belong here; used only by dbread/getent */

isindexkey(dbd, key)
struct db *dbd;
char *key;
{
int i;
char *ukey = db_hashkey(dbd, key, DB_NOALLOC);
for(i = 0; i < dbd->db_nmajkeys; i++)
	{
	if(dbd->db_majkeys[i].dbi_key == ukey)
		return TRUE;
	}

return FALSE;
}
