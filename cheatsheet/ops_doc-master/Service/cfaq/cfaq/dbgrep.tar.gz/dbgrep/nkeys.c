/*
 *  plaintext "database" library -- return number of key/value pairs in node
 *
 *  Copyright 1987-2002
 *  Steve Summit, scs@eskimo.com
 *  This code may be freely redistributed and used
 *  so long as the author's name and this notice remain intact,
 *  and any modifications are marked as such.
 */

#define DEF_DB
#include "db.h"

db_nkeys(dbnp)
struct dbnode *dbnp;
{
#ifdef DBN_INTKEYS
if(dbnp->dbn_flags & DBN_INTKEYS)
	{
	/* hardway */

	int i;
	int nk = 0;

	for(i = 0; i <= dbnp->dbn_nkeys; i++)
		{
		if(dbnp->dbn_keys[i].kv_flags & KVF_INTERNAL)
			continue;
		nk++;
		}

	return nk;
	}
#endif

return dbnp->dbn_nkeys;
}
