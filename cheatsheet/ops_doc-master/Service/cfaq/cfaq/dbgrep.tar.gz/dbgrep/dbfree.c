/*
 *  plaintext "database" library -- deallocation functions
 *
 *  Copyright 1987-2002
 *  Steve Summit, scs@eskimo.com
 *  This code may be freely redistributed and used
 *  so long as the author's name and this notice remain intact,
 *  and any modifications are marked as such.
 */

#include <stdlib.h>

#define DEF_DB
#include "db.h"
#include "alloc.h"

#ifdef __STDC__

static hashfree(struct hashtab *);

#endif

static hashfree();

db_free(dbp)
register struct db *dbp;
{
if(dbp == NULL)
	return;

hashfree(&dbp->db_keytab);

/* *** also gotta free indices and node list *** */

free((char *)dbp);
}

static
hashfree(htp)
register struct hashtab *htp;
{
int i;
char **pp;

for(i = 0; i < htp->ht_nbuckets; i++)
	{
	if(htp->ht_buckets[i] != NULL)
		{
		for(pp = htp->ht_buckets[i]; *pp != NULL; pp++)
			free(*pp);

		free((char *)htp->ht_buckets[i]);
		}
	}

free((char *)htp->ht_buckets);
}
