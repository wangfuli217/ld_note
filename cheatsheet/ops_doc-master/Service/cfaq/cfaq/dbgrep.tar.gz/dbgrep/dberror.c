#include <stdio.h>
#ifdef VARARGS
#include <varargs.h>
#else
#include <stdarg.h>
#endif

#define DEF_DB
#include "db.h"

extern char *progname;

/* VARARGS3 */

#ifdef __STDC__
db_error(struct db *dbd, char *what, char *msg, ...)
#else
#ifdef VARARGS
db_error(va_alist)
va_dcl
#else
db_error(dbd, what, msg)
struct db *dbd;
char *what;
char *msg;
#endif
#endif
{
va_list argp;

#ifdef VARARGS

struct db *dbd;
char *what;
char *msg;

va_start(argp);

dbd = va_arg(argp, struct db *);
what = va_arg(argp, char *);
msg = va_arg(argp, char *);

#else

va_start(argp, msg);

#endif

if(progname != NULL)
	fprintf(stderr, "%s: ", progname);

#ifdef notdef

/* to be replaced v. soon with generic dbf hooks */

if(dbd != NULL && dbd->db_dbfd != NULL)
	{
	struct dbfd *dbfd = dbd->db_dbfd;

	if(dbfd->dbf_filename != NULL)
		fprintf(stderr, "%s, ", dbfd->dbf_filename);

	fprintf(stderr, "line %ld: ", dbfd->dbf_lineno);
	}

#endif

if(what != NULL && *what != '\0')
	fprintf(stderr, "%s: ", what);

vfprintf(stderr, msg, argp);

va_end(argp);

fprintf(stderr, "\n");
}
