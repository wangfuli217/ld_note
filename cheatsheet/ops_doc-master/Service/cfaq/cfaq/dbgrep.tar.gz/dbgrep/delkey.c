#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define DEF_DB
#include "db.h"
#include "defs.h"

static char keynotfound[] = "db_delkey: key \"%s\" not found";

#ifdef __STDC__

static int dodelkey(struct db *, struct dbnode *, int, struct dbnode *);

#endif

static int dodelkey();

#ifdef DBRCS
extern struct dbnode *db_gethistnode();
#endif

db_delkey(dbd, dbn, key, flags)
struct db *dbd;
struct dbnode *dbn;
/*
 *  plaintext "database" library -- delete key/val pair from node
 *
 *  Copyright 1992-2002
 *  Steve Summit, scs@eskimo.com
 *  This code may be freely redistributed and used
 *  so long as the author's name and this notice remain intact,
 *  and any modifications are marked as such.
 */

char *key;
int flags;
{
return db_ndelkey(dbd, dbn, key, flags, 0);
}

db_ndelkey(dbd, dbn, key, flags, nth)
struct db *dbd;
struct dbnode *dbn;
char *key;
int flags;
int nth;
{
char *ukey;
register int i;
int foundi = -1;
int nfound = 0;
int gotone = FALSE;	/* could maybe supersede by nfound */
struct dbnode *histdbn = NULL;
int retval = TRUE;

if(dbn->dbn_flags & (DBN_INDEXONLY | DBN_NOTEXT))
	db_regetent(dbd, dbn);

flags |= dbd->db_flags;

#ifdef DBRCS

if((flags & DB_HISTORY) && !(flags & DB_NOHISTORY))
	{
	histdbn = db_gethistnode(dbd, dbn);
	if(histdbn == NULL)
		return FALSE;
	}

#endif

ukey = db_hashkey(dbd, key, flags | DB_NOALLOC);

if(ukey == NULL && key != NULL)
	{
	if(flags & DB_NONEOK)
		return FALSE;

	if(!(flags & DB_CHECKRET))
		{
		db_error(dbd, "fatal error", keynotfound, key);
		exit(1);
		}

	return FALSE;
	}

for(i = 0; i < dbn->dbn_nkeys; )	/* i++ only if keys[i] not deleted */
	{
	if(Keyeq(dbn, dbn->dbn_keys[i].kv_key, ukey) &&
		(!(dbn->dbn_keys[i].kv_flags & KVF_INTERNAL) ||	    /* XOR? */
			(flags & DB_KVINTERNAL)))
		{
		nfound++;

		if(nth != 0)
			{
			if(nth == nfound)
				return dodelkey(dbd, dbn, i, histdbn);
			}
		else if(flags & DB_LAST)
			foundi = i;
		else if(!(dbn->dbn_keys[i].kv_flags & KVF_DUPLICATE) || (flags & (DB_MULTIPLE | DB_FIRST)))
			{
			if(!dodelkey(dbd, dbn, i, histdbn))
				retval = FALSE;

			gotone = TRUE;

			if(flags & DB_FIRST)
				break;

			continue;
			}
		else	{
			db_error(dbd, (flags&DB_CHECKRET) ? "error" : "fatal error",
				"db_delkey: multiple values for \"%s\"", key);

			if(!(flags & DB_CHECKRET))
				exit(1);

			return FALSE;
			}
		}

	i++;
	}

if((flags & DB_LAST) && foundi >= 0)
	return dodelkey(dbd, dbn, foundi, histdbn);

if(!gotone)
	{
	if(!(flags & (DB_NONEOK | DB_CHECKRET)))
		{
		db_error(dbd, "fatal error", keynotfound, key);
		exit(1);
		}

	return FALSE;
	}

return retval;
}

db_idelkey(dbd, dbn, kvi, flags)	/* a certain amount of duplication; unfortunate */
struct db *dbd;
struct dbnode *dbn;
int kvi;
int flags;
{
struct dbnode *histdbn = NULL;

if(dbn->dbn_flags & (DBN_INDEXONLY | DBN_NOTEXT))
	db_regetent(dbd, dbn);

if(!(flags & DB_KVINTERNAL))
	kvi--;		/* make 0-based */

if((dbn->dbn_flags & DBN_INTKEYS) && !(flags & DB_KVINTERNAL))
	{
	/* convert index (user to internal) */

	int kvi2 = -1;
	int i, j = 0;
	for(i = 0; i < dbn->dbn_nkeys; i++)
		{
		if(dbn->dbn_keys[i].kv_flags & KVF_INTERNAL)
			continue;
		if(j == kvi)
			{
			kvi2 = i;
			break;
			}
		j++;
		}

	kvi = kvi2;
	}

flags |= dbd->db_flags;

if(kvi < 0 || kvi >= dbn->dbn_nkeys)
	return FALSE;

#ifdef DBRCS

if((flags & DB_HISTORY) && !(flags & DB_NOHISTORY))
	{
	histdbn = db_gethistnode(dbd, dbn);
	if(histdbn == NULL)
		return FALSE;
	}

#endif

return dodelkey(dbd, dbn, kvi, histdbn);
}

static
dodelkey(dbd, dbn, i, histdbn)
struct db *dbd;
struct dbnode *dbn;
int i;
struct dbnode *histdbn;
{
int j;

#ifdef DBRCS

if(histdbn != NULL)
	{
	int nk = 0;
	for(j = 0; j < i; j++)
		{
		if(!(dbn->dbn_keys[j].kv_flags & KVF_INTERNAL))
			nk++;
		}

	db_stashhist(dbd, histdbn, 'd', dbn->dbn_keys[i].kv_key, nk,
					dbn->dbn_keys[i].kv_value);
	}

#endif

/* if this is the *second* duplicate, the remaining one won't be any more */

if(dbn->dbn_keys[i].kv_flags & KVF_DUPLICATE)
	{
	int nmatch = 0;
	int lastfound;
	for(j = 0; j < dbn->dbn_nkeys; j++)
		{
		if(i != j && dbn->dbn_keys[i].kv_key == dbn->dbn_keys[j].kv_key)
			{
			nmatch++;
			lastfound = j;
			}
		}

	if(nmatch == 1)
		dbn->dbn_keys[lastfound].kv_flags &= ~KVF_DUPLICATE;
	}

#ifdef notyet

for(ii = 0; ii < dbd->db_nmajkeys; ii++)
	{
	if(dbd->db_majkeys[ii].dbi_key == dbn->dbn_keys[i].kv_key)
		{
		tdelete(ukey, nkv->kv_valstring, dbnp, dbd, &dbd->db_majkeys[ii].dbi_tree);

		break;
		}
	}

#endif

#ifndef NTALLOC
if((dbn->dbn_keys[i].kv_flags & (KVF_POINTER | KVF_MALLOCED)) == (KVF_POINTER | KVF_MALLOCED) &&
						dbn->dbn_keys[i].kv_valptr != NULL)
	free(dbn->dbn_keys[i].kv_valptr);	/* XXX assumes kv_valstring and kv_valptr compat. */
#endif

if(dbn->dbn_nkeys - 1 - i > 0)
	{
	memmove((char *)&dbn->dbn_keys[i], (char *)&dbn->dbn_keys[i+1],
			(dbn->dbn_nkeys - 1 - i) * sizeof(struct keyvalue));
	}

dbn->dbn_nkeys--;

dbn->dbn_flags |= DBN_DIRTY;

return TRUE;
}
