/*
 *  plaintext "database" library -- make a second copy of a node
 *
 *  Copyright 1992-2002
 *  Steve Summit, scs@eskimo.com
 *  This code may be freely redistributed and used
 *  so long as the author's name and this notice remain intact,
 *  and any modifications are marked as such.
 */

#include <stdlib.h>
#include <string.h>
#define DEF_DB
#include "alloc.h"
#include "db.h"
#include "defs.h"

struct dbnode *
db_copynode(dbd, dbn)
struct db *dbd;
struct dbnode *dbn;
{
int i;
struct dbnode *newnode = Salloc(struct dbnode);
db_ninit(newnode);
*newnode = *dbn;

newnode->dbn_keys = (struct keyvalue *)alloc(dbn->dbn_nkeys * sizeof(struct keyvalue));
newnode->dbn_next = NULL;

for(i = 0; i < newnode->dbn_nkeys; i++)
	{
	struct keyvalue *nkvp = &newnode->dbn_keys[i], *okvp = &dbn->dbn_keys[i];
	*nkvp = *okvp;
	/* worry about eventual other pointer value types */
	if((okvp->kv_flags & KVF_TYPEMASK) == KVF_STRING && okvp->kv_valstring != NULL)
		{
		if((nkvp->kv_valstring = malloc(strlen(okvp->kv_valstring) + 1)) == NULL)
			return NULL;
		(void)strcpy(nkvp->kv_valstring, okvp->kv_valstring);
		}
	}

return newnode;
}
