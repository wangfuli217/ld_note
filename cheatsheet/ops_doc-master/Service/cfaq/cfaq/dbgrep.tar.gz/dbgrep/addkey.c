/*
 *  plaintext "database" library -- add new key/val pair to node
 *
 *  Copyright 1987-2002
 *  Steve Summit, scs@eskimo.com
 *  This code may be freely redistributed and used
 *  so long as the author's name and this notice remain intact,
 *  and any modifications are marked as such.
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <assert.h>

#define DEF_DB
#include "db.h"
#include "defs.h"

#ifdef notdef
#ifdef __STDC__
#define SAFEREALLOC
#endif
#endif

#ifdef __STDC__

static int db_doaddkey(struct db *, struct dbnode *, struct keyvalue *, int, int);
extern db_tinsert(char *, char *, struct dbnode *, struct db *, struct tree **);

#endif

static int db_doaddkey();

#ifdef VMLIMIT

#ifdef __STDC__

extern char *lmalloc(int);
extern char *lrealloc(char *, int);

#endif

extern char *lmalloc();
extern char *lrealloc();

#else

#define lmalloc malloc
#define lrealloc realloc

#endif

#ifdef NTALLOC

#ifdef __STDC__

extern char *db_ntalloc(struct dbnode *, int);
extern char *db_ntrealloc(struct dbnode *, char *, int);

#endif

extern char *db_ntalloc();
extern char *db_ntrealloc();

#else

#define db_ntalloc(dbnp, n) lmalloc(n)
#define db_ntrealloc(dbnp, p, n) lrealloc(p, n)

#endif

/* returns TRUE if succeeds; FALSE if out of memory */
/* (or, now, FALSE under a few other conditions as well; gotta reconcile) */

db_addkey(dbd, dbnp, key, value, flags)
struct db *dbd;
struct dbnode *dbnp;
char *key, *value;
int flags;		/* remember: these are DB_ flags, not KVF_ flags */
			/* (use db_addfkey() or db_iaddkey() to set KVF_ flags) */
{
struct keyvalue tmpkv;
tmpkv.kv_key = key;
tmpkv.kv_valstring = value;
tmpkv.kv_flags = KVF_POINTER | KVF_STRING;

/*
 *  db_iaddkey calls db_regetent, too, but if it does on our behalf,
 *  the dbnp->dbn_nkeys we use will have been too low
 */

if((dbnp->dbn_flags & (DBN_INDEXONLY | DBN_NOTEXT)) && !(flags & DB_BUILDING))
	db_regetent(dbd, dbnp);

return db_doaddkey(dbd, dbnp, &tmpkv, -1, flags);
}

db_addfkey(dbd, dbnp, key, value, kvflags, dbflags)
struct db *dbd;
struct dbnode *dbnp;
char *key, *value;
int kvflags, dbflags;
{
struct keyvalue tmpkv;
tmpkv.kv_key = key;
tmpkv.kv_valstring = value;
tmpkv.kv_flags = KVF_POINTER | KVF_STRING | kvflags;

/*
 *  db_iaddkey calls db_regetent, too, but if it does on our behalf,
 *  the dbnp->dbn_nkeys we use will have been too low
 */

if((dbnp->dbn_flags & (DBN_INDEXONLY | DBN_NOTEXT)) && !(dbflags & DB_BUILDING))
	db_regetent(dbd, dbnp);

return db_doaddkey(dbd, dbnp, &tmpkv, -1, dbflags);
}

db_iaddkey(dbd, dbnp, nkv, nki, flags)
struct db *dbd;
struct dbnode *dbnp;
struct keyvalue *nkv;
int nki;				/* index of new key */
int flags;
{
if(nki >= 0 && (dbnp->dbn_flags & DBN_INTKEYS))
	{
	/* convert index (user to internal) */

	int nki2 = -1;
	int i, j = 0;
	for(i = 0; i <= dbnp->dbn_nkeys; i++)
		{
		if(i < dbnp->dbn_nkeys && (dbnp->dbn_keys[i].kv_flags & KVF_INTERNAL))
			continue;
		if(j == nki)
			{
			nki2 = i;
			break;
			}
		j++;
		}

	nki = nki2;
	}
	
return db_doaddkey(dbd, dbnp, nkv, nki, flags);
}

static int
db_doaddkey(dbd, dbnp, nkv, nki, flags)
struct db *dbd;
struct dbnode *dbnp;
struct keyvalue *nkv;
int nki;				/* index of new key */
int flags;
{
struct keyvalue *kvp;
char *ukey;
int i;
int nfound = 0;
#ifndef NSQBEHAVIOR	/* XXX only ifdeffed for timing purposes; unifdef soon */
int foundi;
#endif
#ifdef DBRCS
int nbefore = 0;
struct dbnode *histdbn = NULL;
#endif

if((dbnp->dbn_flags & (DBN_INDEXONLY | DBN_NOTEXT)) && !(flags & DB_BUILDING))
	db_regetent(dbd, dbnp);

if(nki == -1)			/* -1 means at end */
	nki = dbnp->dbn_nkeys;

if(nki < 0 || nki > dbnp->dbn_nkeys)
	return FALSE;

#ifdef DBRCS

if((dbd->db_flags & DB_HISTORY) && !(flags & DB_NOHISTORY))
	{
	histdbn = db_gethistnode(dbd, dbnp);
	if(histdbn == NULL)
		return FALSE;
	}

#endif

ukey = db_hashkey(dbd, nkv->kv_key, dbd->db_flags);

/* check for old keys by this tag: */

/*
 *  This loop is responsible for the 2*n**2 behavior which was really
 *  killing e.g. dbgrep when used on mailboxes containing huge messages
 *  (for which, incidentially, there are a *lot* of duplicate null-keyed keys).
 *  Therefore, I'm trying some shortcuts: if we find two matching keys,
 *  it means we've already discovered that they're duplicates, so we can
 *  (a) cut the scan short, and (b) not worry about going back and
 *  setting KVF_DUPLICATE for them (but rather only for the new kv).
 *  (But we do still need to do a potentially full scan to discover nbefore,
 *  but we only need to do that if this db is doing version control.)
 *
 *  (It seems to me I tried this once before and it didn't work,
 *  but here goes anyway.)
 *
 *  An even better scheme would probably be to only do any of this for db's
 *  which care about an accurate notion of KVF_DUPLICATE.  Another possibility
 *  would be to dynamically construct a per-db set of bitmask values
 *  (in conjunction with the key hashtable, of course) which could be used
 *  to immediately detect duplicate keys (and, incidentally, whether a key
 *  was present).
 */
 
for(i = 0; i < dbnp->dbn_nkeys; i++)
	{
	if(Keyeq(dbnp, dbnp->dbn_keys[i].kv_key, ukey))
		{
		nfound++;
#ifndef NSQBEHAVIOR
		foundi = i;
#endif

#ifdef DBRCS
		if(i < nki)
			nbefore++;
#endif
#ifndef NSQBEHAVIOR

		if(nfound >= 2
#ifdef DBRCS
			       && (histdbn == NULL || i >= nki)

#endif
							       )
			break;
#endif

		if(!(dbnp->dbn_keys[i].kv_flags & KVF_DUPLICATE))
			break;		/* pointless optimization */
		}
	}

if(nfound > 0)
	{
	if(flags & DB_CHANGEOK)
		{
		if(nfound > 1)
			{
			db_error(dbd, "error", "db_doaddkey: don't know which one to change");
			return FALSE;
			}

		/* could maybe use db_ichangeval */
		return db_changeval(dbd, dbnp, nkv->kv_key, nkv->kv_value, flags);
		/* XXX should be nkv, not nkv->kv_value */
		}

	if(!((dbd->db_flags | flags) & DB_DUPKEYOK))
		{
		/* could also be error, or fatal error, or db_changeval, or ignore */
		db_error(dbd, "warning", "duplicate key %s", nkv->kv_key);
		}

	/* eventually also check per-key dupok */

#ifndef NSQBEHAVIOR
	if(nfound == 1)
		dbnp->dbn_keys[foundi].kv_flags |= KVF_DUPLICATE;
#else
	for(i = 0; i < dbnp->dbn_nkeys; i++)
		{
		if(Keyeq(dbnp, dbnp->dbn_keys[i].kv_key, ukey))
			dbnp->dbn_keys[i].kv_flags |= KVF_DUPLICATE;
		}
#endif

	nkv->kv_flags |= KVF_DUPLICATE;
	}

if(dbnp->dbn_nkeys >= dbnp->dbn_alkeys)
	{
	struct keyvalue *newkeys;
	int newalkeys;

	if(dbnp->dbn_alkeys < 10)
		newalkeys = 10;
	else	newalkeys = (dbnp->dbn_alkeys / 2) * 3;

#ifndef SAFEREALLOC
	if(dbnp->dbn_keys == NULL)
		{
		newkeys = (struct keyvalue *)
				lmalloc(newalkeys * sizeof(struct keyvalue));
		}
	else
#endif
		{
		newkeys = (struct keyvalue *)lrealloc((char *)dbnp->dbn_keys,
					newalkeys * sizeof(struct keyvalue));
		}

	if(newkeys == NULL && dbnp->dbn_alkeys != 0)
		{
		newalkeys = dbnp->dbn_alkeys + 10;
		newkeys = (struct keyvalue *)lrealloc((char *)dbnp->dbn_keys,
					newalkeys * sizeof(struct keyvalue));
		}

	if(newkeys == NULL)
		return FALSE;

	dbnp->dbn_keys = newkeys;
	dbnp->dbn_alkeys = newalkeys;

	/* hard to know when to shrink back any overallocation */
	}

if(nki < dbnp->dbn_nkeys)
	{
	memmove(&dbnp->dbn_keys[nki+1], &dbnp->dbn_keys[nki], 
		(dbnp->dbn_nkeys - nki) * sizeof(struct keyvalue));
	}

kvp = &dbnp->dbn_keys[nki];

#ifdef PRESERVECAP

if((dbd->db_flags & DB_CASELESS) && nkv->kv_key != NULL && strcmp(nkv->kv_key, ukey) != 0)
	{
	kvp->kv_key = db_hashkey(dbd, nkv->kv_key, (dbd->db_flags & ~DB_CASELESS));
	dbnp->dbn_flags |= DBN_WEIRDCAP;
	}
else
#endif
	{
	kvp->kv_key = ukey;
	}

if(kvp->kv_key == NULL && nkv->kv_key != NULL)
	return FALSE;

kvp->kv_valunion = nkv->kv_valunion;
kvp->kv_flags = nkv->kv_flags;

/* XXX these cases are *not* complete yet! */

/* also, fishiness wrt KVF_POINTER and KVF_MALLOCED bits: */
/* either they should be cleared in kvp->kv_flags after kvp->kv_flags = nkv->kv_flags line, */
/* or the cases below shouldn't re-set them */

/* also, should consistently test either kvp->kv_flags or nkv->kv_flags */

#ifdef STREAMDB

if(flags & DB_CHEATALLOC)
	{
	assert((nkv->kv_flags & KVF_TYPEMASK) == KVF_STRING);
	kvp->kv_valstring = nkv->kv_valstring;		/* that's what CHEATALLOC means! */
	kvp->kv_flags |= KVF_POINTER;
	}
else
#endif
if((nkv->kv_flags & KVF_TYPEMASK) == KVF_STRING && nkv->kv_valstring != NULL)
	{
	if((kvp->kv_valstring = db_ntalloc(dbnp, strlen(nkv->kv_valstring) + 1)) == NULL)
		return FALSE;
	(void)strcpy(kvp->kv_valstring, nkv->kv_valstring);
	kvp->kv_flags |= KVF_POINTER | KVF_MALLOCED;
	}
/* XXX sumpin fishy here */
else if((nkv->kv_flags & KVF_TYPEMASK) == KVF_STRING && nkv->kv_valstring == NULL)
	{
	kvp->kv_valstring = NULL;
	kvp->kv_flags |= KVF_POINTER;
	}
else if((nkv->kv_flags & KVF_TYPEMASK) == KVF_DBNODE)
	{
	kvp->kv_valnode = nkv->kv_valnode;
	kvp->kv_flags |= KVF_POINTER;
	}
else if((kvp->kv_flags & KVF_POINTER) && (nkv->kv_flags & KVF_TYPEMASK) == KVF_OFFSET)
	{
	/* XXX maybe use kv_valoffset one day */
	if((kvp->kv_valptr = db_ntalloc(dbnp, sizeof(off_t))) == NULL)
		return FALSE;
	memmove(kvp->kv_valptr, nkv->kv_valptr, sizeof(off_t));
	kvp->kv_flags |= KVF_POINTER | KVF_MALLOCED;
	}
else	{
	panic("db_doaddkey: unhandled case (%x)", nkv->kv_flags);
	}

dbnp->dbn_nkeys++;

#ifdef DBRCS

if(histdbn != NULL)
	db_stashhist(dbd, histdbn, 'i', kvp->kv_key, nbefore+1,
					(char *)NULL);

#endif

for(i = 0; i < dbd->db_nmajkeys; i++)
	{
	if(dbd->db_majkeys[i].dbi_key == ukey)
		{
		/* gotta worry about out-of-memory here, too */
		db_tinsert(ukey, nkv->kv_valstring, dbnp, dbd, &dbd->db_majkeys[i].dbi_tree);

		break;
		}
	}

if(nkv->kv_flags & KVF_INTERNAL)
	dbnp->dbn_flags |= DBN_INTKEYS;

if(!(flags & DB_BUILDING))
	{
	kvp->kv_flags |= KVF_DIRTY;
	dbnp->dbn_flags |= DBN_DIRTY;
	}

return TRUE;
}

db_kvfinish(dbnp)
struct dbnode *dbnp;
{
/* *not* lrealloc */

/* maybe don't do this if DBN__STREAMTEXT */

struct keyvalue *newkeys = (struct keyvalue *)realloc((char *)dbnp->dbn_keys,
				dbnp->dbn_nkeys * sizeof(struct keyvalue));

if(newkeys != NULL)
	{
	dbnp->dbn_alkeys = dbnp->dbn_nkeys;
	dbnp->dbn_keys = newkeys;
	}
}
