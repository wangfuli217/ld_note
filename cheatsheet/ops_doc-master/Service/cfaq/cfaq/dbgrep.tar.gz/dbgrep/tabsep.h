struct dbtsf
	{
	int dbf_ts_magic;

	int dbf_ts_state;

	char **dbf_ts_colnames;
	int *dbf_sq_starts, *dbf_sq_widths;	/* SQL only */
	int dbf_ts_ncols;
	};

#define DBTSMAGIC 28405
#define DBCSVMAGIC 28407
#define DBSQLMAGIC 28409

extern struct dbnode *dbts_getent();
