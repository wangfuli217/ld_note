/*
 *  plaintext "database" library --
 *  functions for dealing with alternate file formats,
 *  namely tab-separated columns (where first line gives column names)
 *  and also comma-separated values, and
 *  output of various SQL query tools (e.g. sqlplus)
 *
 *  Copyright 2000-2002
 *  Steve Summit, scs@eskimo.com
 *  This code may be freely redistributed and used
 *  so long as the author's name and this notice remain intact,
 *  and any modifications are marked as such.
 */

#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#define DEF_DB
#include "db.h"
#include "tabsep.h"
#include "alloc.h"
#include "defs.h"

#define MAXCOLS 100	/* XXX */

extern char *progname;

extern char *strsave();

static void db_tsdeinit();
struct dbnode *dbts_getent();
int dbts_putent();
int dbsql_putent();

static struct dbiofuncs dbtsfuncs =
	{ NULL, db_tsdeinit, dbts_getent, dbts_putent, NULL };

static do_set_ts();

db_f_ts_set(dbfd)
struct dbfd *dbfd;
{
do_set_ts(dbfd, DBTSMAGIC, &dbtsfuncs);
}

static
do_set_ts(dbfd, magic, funcs)
struct dbfd *dbfd;
int magic;
struct dbiofuncs *funcs;
{
struct dbtsf *dbf2;

dbfd->dbf_funcs = funcs;

dbf2 = dbfd->dbf_fmtspecif = Salloc(struct dbtsf);

dbf2->dbf_ts_magic = magic;

dbf2->dbf_ts_state = 0;

dbf2->dbf_ts_colnames = NULL;
dbf2->dbf_sq_starts = dbf2->dbf_sq_widths = NULL;
dbf2->dbf_ts_ncols = 0;
}

static struct dbiofuncs dbcsvfuncs =
	{ NULL, db_tsdeinit, dbts_getent, dbts_putent, NULL };

db_f_csv_set(dbfd)
struct dbfd *dbfd;
{
do_set_ts(dbfd, DBCSVMAGIC, &dbcsvfuncs);
}

static struct dbiofuncs dbsqlfuncs =
	{ NULL, db_tsdeinit, dbts_getent, dbsql_putent, NULL };

db_f_sql_set(dbfd)
struct dbfd *dbfd;
{
do_set_ts(dbfd, DBSQLMAGIC, &dbsqlfuncs);
}

static void
db_tsdeinit(dbfd)
struct dbfd *dbfd;
{
struct dbtsf *dbf2;
int i;

if((dbf2 = dbfd->dbf_fmtspecif) == NULL ||
	dbf2->dbf_ts_magic != DBTSMAGIC && dbf2->dbf_ts_magic != DBCSVMAGIC &&
		dbf2->dbf_ts_magic != DBSQLMAGIC)
	panic("db_tsdeinit: file type mismatch");

for(i = 0; i < dbf2->dbf_ts_ncols; i++)
	free(dbf2->dbf_ts_colnames[i]);
if(dbf2->dbf_ts_colnames != NULL)
	free(dbf2->dbf_ts_colnames);
if(dbf2->dbf_sq_starts != NULL)
	free(dbf2->dbf_sq_starts);
if(dbf2->dbf_sq_widths != NULL)
	free(dbf2->dbf_sq_widths);
free(dbf2);
dbfd->dbf_fmtspecif = NULL;
}

/* definitely odd object partitioning here */
/* three types -- ts, csv, and sql -- but most code shared in fcns named "ts" */

static int tgetargs();
static int csvgetargs();
static int sqlgetargs();
extern int getargs();

static sqlintuitwidths();
static int sqlheaderline2();
static int sqlalldashes();

struct dbnode *
dbts_getent(dbf, dbd)
struct dbfd *dbf;
struct db *dbd;
{
struct dbtsf *tsp;
dbnode dbnp;
char *av[MAXCOLS];		/* XXX */
int r;
int nc;
int i;
int (*splitfunc)();

if((tsp = dbf->dbf_fmtspecif) == NULL)
	panic("dbts_getent: missing file type specific info");

if(tsp->dbf_ts_magic == DBTSMAGIC)
	splitfunc = tgetargs;
else if(tsp->dbf_ts_magic == DBCSVMAGIC)
	splitfunc = csvgetargs;
else if(tsp->dbf_ts_magic == DBSQLMAGIC)
	splitfunc = sqlgetargs;
else	panic("dbts_getent: unrecognized file type specific info");

while(TRUE)	/* break in middle */
	{
	r = db_getline(dbf);
	if(r == EOF)
		return NULL;

	/* skip blank lines? */

	if(tsp->dbf_ts_magic == DBSQLMAGIC && tsp->dbf_ts_state == 1)
		{
		/* XXX oughta check that line is just "----- --- ----" */
		sqlintuitwidths(tsp, dbf->dbf_lbuf);
		tsp->dbf_ts_state++;
		continue;
		}
	else if(tsp->dbf_ts_state != 0)
		break;

	/* here, we use plain getargs for SQL */

	nc = (*(tsp->dbf_ts_magic == DBSQLMAGIC ? getargs : splitfunc))
						(av, dbf->dbf_lbuf, MAXCOLS);

	tsp->dbf_ts_ncols = nc;
	tsp->dbf_ts_colnames = SNalloc(char *, nc);
	for(i = 0; i < nc; i++)
		tsp->dbf_ts_colnames[i] = strsave(av[i]);
	/* if SQL, prob. oughta lowercaseify the colnames */
	tsp->dbf_ts_state++;
	}

if(splitfunc == sqlgetargs)
	nc = (*splitfunc)(tsp, av, dbf->dbf_lbuf, MAXCOLS);
else	nc = (*splitfunc)(av, dbf->dbf_lbuf, MAXCOLS);

if(tsp->dbf_ts_magic == DBSQLMAGIC)
	{
	/* skip blank lines, and the extra inserted redundant */
	/* header lines sqlplus loves to spit out... */

	/* (could conceivably detect and skip header lines only in pairs...) */

	while(nc == 0 || nc == tsp->dbf_ts_ncols &&
			(sqlheaderline2(av, tsp->dbf_ts_colnames, nc) ||
					sqlalldashes(av, tsp)))
		{
		r = db_getline(dbf);
		if(r == EOF)
			return NULL;
		assert(splitfunc == sqlgetargs);
		nc = (*splitfunc)(tsp, av, dbf->dbf_lbuf, MAXCOLS);
		}
	}

/* skip empty lines? */
if(nc != tsp->dbf_ts_ncols)
	{
	/* maybe complain */
	if(nc > tsp->dbf_ts_ncols)
		nc = tsp->dbf_ts_ncols;
	}

dbnp = db_nalloc();	/* XXX worry about out of memory rot */
/* db_ninit(dbnp); */
dbnp->dbn_parent = dbd;

for(i = 0; i < nc; i++)
	db_addkey(dbd, dbnp, tsp->dbf_ts_colnames[i], av[i], DB_BUILDING | DB_NOHISTORY);
return dbnp;
}

static int
tgetargs(argv, line, maxargs)
char *argv[];
char *line;
int maxargs;
{
return dgetargs(argv, line, maxargs, '\t');
}

static int
csvgetargs(argv, line, maxargs)
char *argv[];
char *line;
int maxargs;
{
return dgetargs(argv, line, maxargs, ',');	/* XXX temporary */
		/* (really need something fancier that handles quoting) */
}

dgetargs(argv, line, maxargs, delim)
char *argv[];
char *line;
int maxargs;
int delim;
{
char *p = line;
int i = 0;

assert(maxargs >= 1);

while(*p != '\0')
	{
	argv[i++] = p;
	if(i >= maxargs)
		break;
	while(*p != delim && *p != '\0')
		p++;
	if(*p == '\0')
		break;
	else	*p++ = '\0';
	}

return i;
}

static int
sqlgetargs(tsp, argv, line, maxargs)
struct dbtsf *tsp;
char *argv[];
char *line;
int maxargs;
{
int i;
int len = strlen(line);

for(i = 0; i < tsp->dbf_ts_ncols; i++)
	{
	char *p2;

	if(tsp->dbf_sq_starts[i] >= len)
		break;
	argv[i] = &line[tsp->dbf_sq_starts[i]];
	if(tsp->dbf_sq_starts[i] + tsp->dbf_sq_widths[i] < len)
		argv[i][tsp->dbf_sq_widths[i]] = '\0';

	/* oughta confirm gutters are nothing but whitespace */

	/* trim leading/trailing spaces */
	while(*argv[i] == ' ')
		argv[i]++;
	for(p2 = argv[i]; *p2 != '\0'; p2++)
		;
	while(p2 > argv[i] && *(p2-1) == ' ')
		*--p2 = '\0';
	}

if(i > 0 && i != tsp->dbf_ts_ncols ||
			len > tsp->dbf_sq_starts[tsp->dbf_ts_ncols-1] +
				tsp->dbf_sq_widths[tsp->dbf_ts_ncols-1])
	fprintf(stderr, "%s: warning: unexpected SQL line...\n", progname);

return i;
}

static
sqlintuitwidths(tsp, line)
struct dbtsf *tsp;
char *line;
{
char *p = line;
int i = 0;

/* mildly odd to be allocating these here... */
if(tsp->dbf_sq_starts == NULL)
	tsp->dbf_sq_starts = SNalloc(int, tsp->dbf_ts_ncols);
if(tsp->dbf_sq_widths == NULL)
	tsp->dbf_sq_widths = SNalloc(int, tsp->dbf_ts_ncols);

while(*p != '\0')
	{
	if(i > tsp->dbf_ts_ncols)
		break;
	while(*p == ' ')
		p++;
	if(*p != '-')
		break;
	tsp->dbf_sq_starts[i] = p - line;
	while(*p == '-')
		p++;
	tsp->dbf_sq_widths[i] = (p - line) - tsp->dbf_sq_starts[i];
	i++;
	}

if(*p != '\0' || i != tsp->dbf_ts_ncols)
	fprintf(stderr, "%s: warning: unexpected SQL hdr 2 chars...\n", progname);
}

static int
sqlheaderline2(av, colnames, nc)
char *av[], *colnames[];
int nc;
{
int i;
for(i = 0; i < nc; i++)
	{
	if(strcmp(av[i], colnames[i]) != 0)	/* stricmp? */
		return FALSE;
	}

return TRUE;
}

static int
sqlalldashes(av, tsp)
char *av[];
struct dbtsf *tsp;
{
int i, j;
char *p;

for(i = 0; i < tsp->dbf_ts_ncols; i++)
	{
	for(j = 0, p = av[i]; j < tsp->dbf_sq_widths[i]; j++, p++)
		{
		if(*p != '-')
			return FALSE;
		}

	if(*p != '\0')
		return FALSE;
	}

return TRUE;
}

dbts_putent(dbfd, dbnp)
struct dbfd *dbfd;
struct dbnode *dbnp;
{
struct dbtsf *tsp;
struct db *dbd = dbnp->dbn_parent;
int i;

if((tsp = dbfd->dbf_fmtspecif) == NULL ||
	     tsp->dbf_ts_magic != DBTSMAGIC && tsp->dbf_ts_magic != DBCSVMAGIC)
	panic("dbts_putent: file type mismatch");

if(dbfd->dbf_mode != 'w' && dbfd->dbf_mode != '?')
	{
	db_error(dbfd->dbf_db, "error", "db_putent: dbfd not open for writing");
	return FALSE;
	}

/* XXX db_regetent stuff was here */

if(tsp->dbf_ts_ncols == 0)
	{
	/* intuit columns from (first) record */

	int nk = db_nkeys(dbnp);

	tsp->dbf_ts_ncols = nk;
	tsp->dbf_ts_colnames = SNalloc(char *, tsp->dbf_ts_ncols);

	for(i = 0; i < nk; i++)
		tsp->dbf_ts_colnames[i] =
			strsave(db_getikv(dbd, dbnp, i+1)->kv_key);
	}

if(tsp->dbf_ts_state == 0)
	{
	for(i = 0; i < tsp->dbf_ts_ncols; i++)
		{
		fprintf(dbfd->dbf_fd, "%s", tsp->dbf_ts_colnames[i]);
		if(i >= tsp->dbf_ts_ncols-1)
			putc('\n', dbfd->dbf_fd);
		else if(tsp->dbf_ts_magic == DBTSMAGIC)
			putc('\t', dbfd->dbf_fd);
		else	putc(',', dbfd->dbf_fd);
		}
	tsp->dbf_ts_state = 1;
	}

for(i = 0; i < tsp->dbf_ts_ncols; i++)
	{
	char *key = tsp->dbf_ts_colnames[i];
	char *val = db_getvalue(dbd, dbnp, key, DB_CHECKRET);
	/* repeated db_getvalue calls are expensive, and require dbd */
	/* (which we do happen to have, but only via backpointer) */
	/* maybe use index map directly into node's dbn_keys[] */
	if(val == NULL)
		val = "";
	fprintf(dbfd->dbf_fd, "%s", val);
	/* XXX worry about quoting */
	if(i >= tsp->dbf_ts_ncols-1)
		putc('\n', dbfd->dbf_fd);
	else if(tsp->dbf_ts_magic == DBTSMAGIC)
		putc('\t', dbfd->dbf_fd);
	else	putc(',', dbfd->dbf_fd);
	}

return TRUE;
}

dbsql_putent(dbfd, dbnp)
struct dbfd *dbfd;
struct dbnode *dbnp;
{
panic("dbsql_putent: not implemented yet");
}

/* XXX probably temporary */

dbts_copycols(dbfd1, dbfd2)
struct dbfd *dbfd1, *dbfd2;
{
struct dbtsf *tsp1;

if((tsp1 = dbfd1->dbf_fmtspecif) == NULL ||
	tsp1->dbf_ts_magic != DBTSMAGIC && tsp1->dbf_ts_magic != DBCSVMAGIC &&
		tsp1->dbf_ts_magic != DBSQLMAGIC)
	panic("dbts_copycols: file type mismatch");

dbts_setcols(dbfd2, tsp1->dbf_ts_colnames, tsp1->dbf_ts_ncols);
}

dbts_setcols(dbfd2, cols, ncols)
struct dbfd *dbfd2;
char **cols;
int ncols;
{
struct dbtsf *tsp2;
int i;

if((tsp2 = dbfd2->dbf_fmtspecif) == NULL ||
	tsp2->dbf_ts_magic != DBTSMAGIC && tsp2->dbf_ts_magic != DBCSVMAGIC &&
		tsp2->dbf_ts_magic != DBSQLMAGIC)
	panic("dbts_setcols: file type mismatch");

tsp2->dbf_ts_ncols = ncols;
tsp2->dbf_ts_colnames = SNalloc(char *, tsp2->dbf_ts_ncols);
for(i = 0; i < ncols; i++)
	tsp2->dbf_ts_colnames[i] = strsave(cols[i]);
}
