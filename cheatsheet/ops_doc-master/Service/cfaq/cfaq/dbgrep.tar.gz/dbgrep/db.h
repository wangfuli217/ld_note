/*
 *  plaintext "database" library -- main header file
 *
 *  Copyright 1987-2002
 *  Steve Summit, scs@eskimo.com
 *  This code may be freely redistributed and used
 *  so long as the author's name and this notice remain intact,
 *  and any modifications are marked as such.
 */

#ifndef DB_H
#define DB_H

#ifdef lint
#define DEF_DB
#endif

#ifndef EOF
#include <stdio.h>
#endif

#include "types.h"	/* for off_t, et al */

struct keyvalue
	{
	char *kv_key;
	union	{
		int kvu_valint;

		char *kvu_valstring;
		struct db *kvu_valdb;
		struct dbnode *kvu_valnode;
#ifdef notyet
		long int kvu_vallong;
		double kvu_valdouble;
		time_t kvu_valtime;
		off_t kvu_valoffset;
#endif
		void *kvu_valptr;	/* to various (long, double, etc.; */
					/* generic makes easier to free) */
		} kv_valunion;

	/* (once had thought of unioning struct of key and */
	/* value union with index and offset...) */

	short kv_flags;		/* encoded below */
	};

#define kv_valstring	kv_valunion.kvu_valstring
#define kv_valint	kv_valunion.kvu_valint
#define kv_vallong	kv_valunion.kvu_vallong
#define kv_valdouble	kv_valunion.kvu_valdouble
#define kv_valtime	kv_valunion.kvu_valtime
#define kv_valoffset	kv_valunion.kvu_valoffset
#define kv_valdb	kv_valunion.kvu_valdb
#define kv_valnode	kv_valunion.kvu_valnode
#define kv_valptr	kv_valunion.kvu_valptr

#define kv_value kv_valstring	/* default; backwards compatibility */

/* values for kv_flags: */

#define KVF_SPECIALNAME	0x01	/* special, not-necessarily-colon key */
				/* (for DB_KEYCHAR db's) */
#define KVF_COLONNAME	0x02	/* name did have colon */
				/* (for non-DB_KEYCHAR/non-DB_KEYBLANK db's) */
#define KVF_INTERNAL	0x04	/* internal maintenance field */
				/* (e.g. disk offset); not user-visible */
#define KVF_COMMENT	0x08	/* preserved comment */

#define	KVF_TYPEMASK	0xf0
#define KVF_STRING	0x00	/* default */
#define KVF_INT		0x10	/* integer */
#define KVF_LONG	0x20	/* long integer */
#define KVF_DOUBLE	0x30	/* double (floating point) */
#define KVF_DATETIME	0x40	/* date/time string */
#define KVF_OFFSET	0x50
#define KVF_DB		0x60	/* recursive database */
#define KVF_DBNODE	0x70
#define KVF_ENUM	0x80	/* enumerated values (per schema) */
#define KVF_INDEX	0x90
#define KVF_TMPNODESTR	0xa0
#define KVF_TMPDBSTR	0xb0
#define KVF_VERSIONS	0xc0	/* node version history structure */
				/* (probably done at higher level, though) */
#define KVF_POINTER	0x100
#define KVF_DUPLICATE	0x200
#define KVF_MALLOCED	0x400	/* if KVF_POINTER, malloc'ed by us */
#define KVF_NOSPACE	0x800	/* didn't have space after colon (fussy) */
#define KVF_DIRTY	0x1000

struct db;
struct dbnode;
struct dbfd;

#ifdef DEF_DB

#ifdef NTALLOC
#define NTBLKSIZE 1024
#endif

struct dbnode
	{
	int dbn_flags;			/* encoded below */
	int dbn_nkeys;			/* # used */
	int dbn_alkeys;			/* # allocated */
	struct keyvalue *dbn_keys;
#ifdef CHECKPOINT
	int dbn_chkp_flags;
	int dbn_chkp_nkeys;
	struct keyvalue *dbn_chkp_keys;
#endif
#ifdef NTALLOC
	char **dbn_txtptrs;
	int dbn_ntxtptrs;
	int dbn_natxtptrs;
	int dbn_ntused;
	int dbn_curblksize;
	int dbn_lastsize;
#ifndef NDEBUG
	char *dbn_lastret;		/* for realloc sanity check */
#endif
#endif

	int dbn_curkvi;			/* details of overallocated */
	int db_ckvlen;			/* kv_value, if DBN_OVERALLOC */
	int db_ckvsz;			/* (only happens with */
	char *db_ckvp;			/*  continuation lines) */

	struct dbnode *dbn_next;
#ifdef notdef
	off_t dbn_off;			/* offset in file */
					/* (currently done with internal ".offset" key) */
	off_t dbn_txtoff;		/* offset of text (untagged) portion */
					/* (currently done with internal ".textoffset" key) */
#endif

#ifdef SPECIALOPS
	void *dbn_special;
#endif

	struct db *dbn_parent;		/* back pointer */
	};

/* values for dbn_flags: */

#define DBN_COMMENT	0x01		/* this node preserves a comment */
#define DBN_WRONGINDICES 0x2		/* some keys have wrong
					 *	lookup key indices */
#define DBN_WEIRDCAP	0x04		/* some keys have nonstandard
					 *	capitalization */
#define DBN_DIRTY	0x10		/* something modified since read */
#define DBN_DELETED	0x20
#define DBN_INTKEYS	0x40		/* KVF_INTERNAL keys exist; */
					/* keyvalue indices won't match caller's perception */
#define DBN_NOTEXT	0x80
#define DBN_INDEXONLY	0x100
#define DBN__HAVETXTOFF	0x200
#define DBN__STREAMTEXT	0x400
#define DBN_OVERALLOC	0x800		/* a kv_value is overallocated; */
					/* dbn_curkvi et al. give details */

#ifdef PRESERVECAP
/* DBN_WEIRDCAP wasn't set unless DB_CASELESS */
#define Keyeq(dbnp, k1, k2) ((k1) == (k2) ||				     \
	((dbnp)->dbn_flags & DBN_WEIRDCAP) && k1 != NULL && k2 != NULL &&    \
							stricmp(k1, k2) == 0)
#else
#define Keyeq(dbnp, k1, k2) ((k1) == (k2))
#endif

struct tree
	{
	struct dbnode *t_item;
	struct tree *t_left, *t_right;
	};

struct dbindex
	{
	char *dbi_key;
	int dbi_keyindex;	/* in dbn_keys, unless DBN_WRONGINDICES */
	struct tree *dbi_tree;
	};

struct keyword
	{
	char *kw_keyword;
	int kw_flags;
	int kw_type;		/* taken from KVF_ set */
	};

#define KW_DUPOK	0x200

struct hashtab
	{
	int ht_nbuckets;
	char ***ht_buckets;	/* array of NULL-terminated lists of strings */
	};

struct db
	{
	int db_flags;		/* encoded below */
	struct dbnode *db_list;
	struct dbnode *db_tail;
	int db_nmajkeys;
	struct dbindex *db_majkeys;
	struct hashtab db_keytab;
	struct dbfd *db_dbfd;		/* backpointer during I/O */
	struct dbnode *db_walkstate;
	char *db_lviterkey;
	int db_lvin;
	int db_gkviterstate;

	int db_nexttag;		/* when assigning tags for load/save node ptrs */
	char *db_tagkey;	/* guaranteed-unique tag for ditto */
	char *db_tagpat;	/* sprintf fmt for assigned unique node tags */
	};

/* (values for db_flags #defined farther down, outside #ifdef DEF_DB) */

struct dbfd
	{
	int dbf_gflags;		/* generic (none defined yet) */
	int dbf_gstate;		/* encoded below */
	char *dbf_filename;
	FILE *dbf_fd;
	char dbf_mode;
	struct db *dbf_db;	/* backpointer */
	long int dbf_lineno;
	off_t dbf_lbeg;		/* offset of beginning of current line */

	int dbf_lballoc;
	char *dbf_lbuf;
	int dbf_llen;
	int dbf_nblank;

	struct dbiofuncs *dbf_funcs;
	void *dbf_fmtspecif;

	int dbf_errcount, dbf_errlimit;

	/* key abbreviations...*/
	/* value formats... */
	/* enum values... */
	/* other schema stuff... */
	};

/* generic dbf flags (dbf_gflags): */

#define DB_INDEXONLY	0x800	/* only read indexed keys */
#define DB_KEYSONLY	0x1000	/* read keys but not values */
#define DB_STREAM	0x2000	/* don't advance fp at all when doing partial reads */
				/* (paves way for funky 1@atime "reread") */
#define DB_STASHOFFSET	0x4000

/* internal state flags (dbf_gstate) */

#define DB__HAVELINE	0x01
#define DB__PIPE	0x02	/* no seek/tell */

struct dbf
	{
	int dbf_magic;		/* paranoia */
	int dbf_fflags;		/* encoded below */
	int dbf_fstate;		/* encoded below */

	int dbf_keychar;	/* usually ':' */
	int dbf_commentchar;	/* usually '#' */
	char *dbf_sepkey;
	char *dbf_textkey;
	};

#define DBFMAGIC 29345		/* random */

struct dbiofuncs
	{
#ifdef __STDC__
	int (*dbf_init)(struct dbfd *);
	void (*dbf_deinit)(struct dbfd *);
	struct dbnode *(*dbf_getent)(struct dbfd *, struct db *);
	int (*dbf_putent)(struct dbfd *, struct dbnode *);
	int (*dbf_regetent)(struct db *, struct dbnode *);
#else
	int (*dbf_init)();
	void (*dbf_deinit)();
	struct dbnode *(*dbf_getent)();
	int (*dbf_putent)();
	int (*dbf_regetent)();
#endif
	};

extern char *db_hashkey();

#endif

/* values for db_flags: */

#define DB_CASELESS	0x01	/* ignore case when matching keys */
#define DB_HISTORY	0x200
#define DB_DUPKEYOK	0x800

/* flags for db_fgetent, db_getvalue, db_delkey: (from same set as db_flags) */

#define DB_FIRST	0x02	/* if multiple values, return/delete first */
				/* for db_getent, just return first line */
#define DB_LAST		0x04	/* if multiple values, return/delete last */
#define DB_CHECKRET	0x08	/* return value checked
				 *	(otherwise key not found is fatal) */
#define DB_NONEOK	0x10	/* okay if no matching keys/values to delete */
#define DB_MULTIPLE	0x20	/* okay to delete multiple keys/values */
#define DB_NOHISTORY	0x400	/* don't keep history */

#define DB_CHANGEOK	0x1000	/* db_addkey: okay to change existing */
#define DB_ADDOK	0x1000	/* db_changeval: okay to add new */
#define DB_STMRD1	0x1000	/* db_read et al.: doing one-kv-at-a-time stream reread */

#define DB_KVINTERNAL	0x40	/* look up internal kv pair */
#define DB_BUILDING	0x2000	/* db_addkey: initial build; don't set DBN_DIRTY */
#define DB_REREAD	0x4000	/* db_read et al.: rereading previous (partial) entry */
#define DB_CHEATALLOC	0x8000	/* db_addkey: don't allocate space for val; */
				/* effectively re-use pointers into dbf_lbuf */
				/* (only for 1@atime stream reread) */

/* values for db_hashkey() flags: (still same set) */

#define DB_NOALLOC	0x80

/* get/read entry flags: (still same set) */

#define DB_QUIET	0x100

/*
 *  XXX
 *  BEWARE: db_fgetent() currently allows DB_NOTEXT and DB_INDEXONLY
 *  to be passed in as flags, but those are dbf_fflags,
 *  so there's a serious potential clash with db_flags DB_HISTORY and DB_DUPKEYOK
 */

/* values for dbf_flags: */

#define DB_KEYCHAR	0x01	/* dbf_keychar separates keys and values */
#define DB_KEYBLANK	0x02	/* whitespace separates keys and values */
				/* (default is either) */
#define DB_KEYNOSTRIP	0x04	/* don't strip extra whitespace between
						 dbf_keychar and value */
#define DB_KEYONESTRIP	0x08	/* strip exactly one space between
						 dbf_keychar and value */

#define DB_BLANKSEP	0x10	/* blank line separates entries */
#define DB_KEYSEP	0x20	/* dbf_sepkey line separates entries */
#define DB_XKEYSEP	0x40	/* " line (no dbf_keychar) separates entries
						(e.g. Unix mailbox files) */
#define DB_RFC822	0x80	/* allow continuation of key/value lines;
					blank line introduces body */
				/*	(usually used with DB_CASELESS) */
#define DB_DEFTEXT	0x100	/* non-dbf_keychar lines are "text" */
				/* (maybe also keyed on dbf_textkey) */
#define DB_NOTEXT	0x200	/* don't read text into memory (yet) */
#define DB_KEEPCOMMENTS	0x400	/* preserve comments */
#define DB_CONTIN	0x1000	/* allow continuation of key/value lines */
#define DB_KYCHINTUIT	0x4000	/* intuited DB_KEYCHAR */

	/* anything for leading/trailing/internal whitespace in keys? */

#ifdef DEF_DB

/* internal state flags (dbf_fstate) */

#define DB__PUTENT	0x02
#define DB__INHDR	0x04	/* for DB_RFC822 files: in header (not curently used) */
#define DB__INBODY	0x08	/* for DB_RFC822 files: in body */
#define DB__INTR	0x10	/* sitting in middle of record due to DB_STREAM DB_NOTEXT */
#define DB__2PASS	0x80	/* encountered forward refs when reading; */
				/* used KVF_TMPNODESTR stuff */
#define DB__BLANKS	0x100	/* returning blanks in text one at a time */
				/* (see db_readent) */

#endif

/* status codes for db_fgetent: */

#define DB_OK		1
#define DB_EOF		2
#define DB_NOMEM	3
#define DB_ERR		4
#define DB_PARTIAL	5	/* partial record (INDEXONLY or NOTEXT) */
#define DB_1ONLY	6	/* (during 1@atime stream reread) */

typedef struct db *dbdesc;
typedef struct dbnode *dbnode;

#ifdef __STDC__
#ifndef NOPROTOTYPES

extern db_addindex(dbdesc, int, char **);
extern int db_addkey(dbdesc, dbnode, char *, char *, int);
extern dbdesc db_alloc(int);
extern int db_changeval(dbdesc, dbnode, char *, char *, int);
extern int db_cmp(dbnode, dbnode);
extern int db_cmpf(dbnode, dbnode, int);
extern dbnode db_copynode(dbdesc, dbnode);
extern int db_delkey(dbdesc, dbnode, char *, int);
extern db_fclose(struct dbfd *);
extern db_fdclose(struct dbfd *);
extern struct dbfd *db_fdopen(FILE *);
extern struct dbfd *db_fopen(char *, char *);
extern db_free(dbdesc);
extern db_fschars(struct dbfd *, int, int);
extern db_f_sepk_set(struct dbfd *, char *);
extern dbnode db_getent(struct dbfd *, dbdesc);
extern struct keyvalue *db_getkv(dbdesc, dbnode);
extern struct keyvalue *db_getikv(dbdesc, dbnode, int);
extern char *db_getvalue(dbdesc, dbnode, char *, int);
extern db_gkvfinish(dbdesc, dbnode);
extern unsigned int db_hash(dbnode);
extern unsigned int db_hashf(dbnode, int);
extern int db_haskey(dbdesc, dbnode, char *);
extern int db_nkeys(dbnode);
extern char *db_listvalues(dbdesc, dbnode, char *);
extern dbnode db_lookup(dbdesc, char *, char *);
extern db_lvfinish(dbdesc);
extern dbnode db_nalloc(void);
extern db_nfree(dbnode);
extern db_ninit(dbnode);
extern int db_nvalues(dbdesc, dbnode, char *);
extern int db_putent(struct dbfd *, dbnode);
extern int db_read(dbdesc, struct dbfd *);
extern db_setopt(dbdesc, int);
extern dbnode db_walk(dbdesc);
extern dbnode db_wnext(dbdesc);
extern db_write(dbdesc, struct dbfd *);

#ifdef DEF_DB

extern int db_addfkey(struct db *, struct dbnode *, char *, char *, int, int);
extern db_error(struct db *, char *, char *, ...);
extern struct dbnode *db_fgetent(struct dbfd *, struct db *, struct dbnode *, int, int *);
extern struct keyvalue *db_gtkv2(struct db *, struct dbnode *, char *, int, int);
extern db_getline(struct dbfd *);
extern char *db_hashkey(struct db *, char *, int);
extern int db_iaddkey(struct db *, struct dbnode *, struct keyvalue *, int, int);
extern int db_ichangeval(struct db *, struct dbnode *, int, char *, int);
extern int db_idelkey(dbdesc, dbnode, int, int);
extern db_kvfinish(struct dbnode *);
extern int db_nchangeval(struct db *, struct dbnode *, char *, char *, int, int);
extern int db_ndelkey(dbdesc, dbnode, char *, int, int);
extern db_purgenode(struct db *, struct dbnode *);
extern int db_regetent(struct db *, struct dbnode *);
extern int db_dbfregetent(struct db *, struct dbnode *);
extern db_ungetline(struct dbfd *, char *);
extern dumpnode(struct dbnode *, FILE *);
extern int isindexkey(struct db *, char *);
extern void db_kvfree(struct keyvalue *, int);
extern struct tree *db_tlookup(struct tree *, char *, char *, struct dbnode *);

#ifdef DBRCS

extern struct dbnode *db_gethistnode(struct db *, struct dbnode *);
extern struct dbnode *db_gethversion(struct db *, struct dbnode *, int vnum);
extern db_rcsnfinish(struct db *, struct dbnode *);
extern db_histfinish(struct db *);
extern db_listversions(struct db *, struct dbnode *);	/* temporary */
extern db_stashhist(struct db *, struct dbnode *, int, char *, int, char *);

#endif
#endif
#endif
#endif

extern dbdesc db_alloc();
extern dbnode db_nalloc();

extern struct dbfd *db_fopen();
extern struct dbfd *db_fdopen();

extern dbnode db_getent();
extern dbnode db_fgetent();

extern dbnode db_lookup();

extern dbnode db_walk();
extern dbnode db_wnext();

extern struct keyvalue *db_getkv();
extern struct keyvalue *db_getikv();

extern char *db_getvalue();
extern char *db_listvalues();

extern int db_putent();

extern unsigned int db_hash();
extern unsigned int db_hashf();

#ifdef DEF_DB
extern void db_kvfree();
extern struct tree *db_tlookup();
extern struct keyvalue *db_gtkv2();
#endif

#ifndef pdp11

/* backwards compat for some earlier (and kinda preferred) names */

#define db_addkeyf db_addfkey
#define db_getkv2 db_gtkv2
#define db_getkvi db_getikv

#define db_fsetflags db_fstflags
#define db_fgetflags db_fgtflags

#define db_fsetdbf db_f_dbf_set
#define db_fsetopt db_f_opt_set
#define db_fsetsepk db_f_sepk_set

#define db_fsetts db_f_ts_set
#define db_fsetcsv db_f_csv_set
#define db_fsetsql db_f_sql_set
#define db_fsethl7 db_f_hl7_set

#define db_checktindex db_chktindx

#endif

#endif
