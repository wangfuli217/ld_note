/*
 *  dbgrep shared definitions
 *
 *  Copyright 1992-2002
 *  Steve Summit, scs@eskimo.com
 *  This code may be freely redistributed and used
 *  so long as the author's name and this notice remain intact,
 *  and any modifications are marked as such.
 */

#ifndef DBGREP_H
#define DBGREP_H

#ifdef POSIXREGEXP
#include <regex.h>
#endif

#define DBGREPVERSION "2.10"	/* arbitrary; 2003-08-06 */

struct evalbase
	{
	int eb_type;
	};

#define e_type e_common.eb_type

/* values for e_type: */

#define AND	1
#define OR	2
#define NOT	3
#define PAT	4
#define SPECIAL	5

/* values for evalpat e_flags: */

#define KEYEXACT	0x10
#define KEYRE		0x20
#define KEYANY		0x30
#define KEYMASK		0xf0
#define PATEXACT	0x01
#define PATRE		0x02
#define PATMATCH	0x03	/* no RE */
#define KEYEXISTS	0x08	/* essentially PATANY */
#define PATMASK		0x0f
#define SPECONLY	0x100	/* call special initialization function only */
				/* (not in addition to makepat) */

struct eval
	{
	struct evalbase e_common;
	};

union pat
	{
	char *p_pat;
#ifdef POSIXREGEXP
	regex_t p_re;
#else
#ifdef HSREGEXP
	struct regexp *p_re;
#else
#endif
#endif
	};

struct evalpat
	{
	struct evalbase e_common;
	int e_flags;
	union pat eu_key;
	union pat eu_pat;
	int e_kn;		/* occurrence indicator (0 for all) */
	int (*e_matchfunc)();
	};

#define e_key	eu_key.p_pat
#define e_keyre	eu_key.p_re
#define e_pat	eu_pat.p_pat
#define e_patre	eu_pat.p_re

struct evalbool
	{
	struct evalbase e_common;
	struct eval *e_left, *e_right;
	};

struct evalother
	{
	struct evalbase e_common;
	int e_flags;
	int (*e_func)();
	char *e_context;
	};

/* values for evalother e_flags: */

#define SPECIALCALL	0x100

/* special context structure passed to SPECINIT/SPECIALCALL functions: */
struct specialctx
	{
	int sc_which;
	struct argd *sc_argd;
	char *sc_ctxp;
	struct evalother *sc_enode;
	};

/* values for sc_which: */

#define SC_INIT		1
#define SC_EVAL		2
#define SC_FINISH	3

/* db file format types: */

#define DBF_DBF		0
#define DBF_TABSEP	1
#define DBF_CSV		2
#define DBF_SQLDUMP	3
#ifdef HL7
#define DBF_HL7		4
#endif

#endif
