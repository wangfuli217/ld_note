/*
 *  dbgrep report generator
 *
 *  Copyright 1997-2002
 *  Steve Summit, scs@eskimo.com
 *  This code may be freely redistributed and used
 *  so long as the author's name and this notice remain intact,
 *  and any modifications are marked as such.
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include <db.h>
#include "dbgrep.h"
#include "defs.h"
#include "alloc.h"
#include "repgen.h"
#include "rgifp.h"

#ifdef EXPR
#ifdef EXPRCOMPILE
#include "expr.h"
#endif
#endif

struct block
	{
	int b_type;	/* B_IF or B_REP */
	union	{
		struct	{
			int bui_suppressout;
			} bu_ifstuff;
		struct	{
			long int bur_begin;
			char *bur_key;
			int bur_kvi;
			} bu_repstuff;
		} b_u;
	};

#define B_IF	1
#define B_REP	2

#define b_suppressout	b_u.bu_ifstuff.bui_suppressout
#define b_blockbegin	b_u.bu_repstuff.bur_begin
#define b_blockkey	b_u.bu_repstuff.bur_key
#define b_kvi		b_u.bu_repstuff.bur_kvi

#define MAXNEST 10

extern FILE *ofd;
extern int multout;

extern char *progname;

#ifdef EXPR
#ifdef EXPRCOMPILE

extern struct code *setupexpr();

#ifdef POLYTYPE
extern struct object *doeval();
#else
extern double deval();
#endif

#endif
#endif

extern struct keyvalue *db_gtkv2();	/* should this be public, or should we not be using it? */

db_repgen(dbd, dbnp, template, ofp)
register dbdesc dbd;
register dbnode dbnp;
char *template;
FILE *ofp;
{
struct rgifp *ifp = rgstrifp(template);
ofd = ofp;					/* XXX */
frepgen(dbd, dbnp, ifp);
rgifree(ifp);
}

repgenpop(dbd, dbnp, ctxp)
register dbdesc dbd;
register dbnode dbnp;
char *ctxp;
{
char *pat = ctxp;

if(multout)
	checkofd(dbd, dbnp);

db_repgen(dbd, dbnp, pat, ofd);		/* XXX ofd/ofp */
putc('\n', ofd);			/* ??? */
}

repgenfop(dbd, dbnp, ctxp)
register dbdesc dbd;
register dbnode dbnp;
char *ctxp;
{
char *filename = ctxp;
static FILE *fp = NULL;		/* XXX */
static struct rgifp *ifp;	/* XXX */

if(fp == NULL)
	{
	fp = fopen(filename, "r");
	if(fp == NULL)
		{
		fprintf(stderr, "%s: can't open report filename %s: %s\n",
			progname, filename, strerror(errno));
		exit(EXIT_FAILURE);
		}

	ifp = rgfpifp(fp);
	}
else	{
	rewind(fp);
	RGrewind(ifp);
	}

if(multout)
	checkofd(dbd, dbnp);

frepgen(dbd, dbnp, ifp);
}

/*
 *  $key	extract key value
 *  ${key}	extract key value (esp. if key name contains spaces)
 *  $$		literal $
 *  \$, \}, \\	literal characters
 *  \\n		(backslash at end of line) eat newline; join line
 *  $?key{...}	conditinally include text only if key has value
 *  $?{key}{...}	ditto
 *  $!key{...}	conditinally include text only if key has no value
 *  $!{key}{...}	ditto
 *  $*key{...}	repeat text once for each of key's multiple values
 *  $*{key}{...}	ditto
 *  $#key	number of key's values
 *  $.		count (i) during $*
#ifdef EXPR
 *  $%{expr}	value of expression
 *  $?%{expr}{...}	conditinally include text only if expression true
#endif
 */

frepgen(dbd, dbnp, ifp)
register dbdesc dbd;
register dbnode dbnp;
struct rgifp *ifp;
{
register int c;
register char *p;
int bsflag = FALSE;
int suppressout = FALSE;
int nestp = 0;
struct block stack[MAXNEST];
int i;

struct block *innerrep = NULL;

while((c = RGgetc(ifp)) != EOF)
	{
	switch(c)
		{
		case '}':
			if(bsflag)
				goto printchar;
			else if(nestp > 0)
				{
				struct block *bp = &stack[nestp-1];
				if(bp->b_type == B_REP)
					{
					bp->b_kvi++;
					if(db_gtkv2(dbd, dbnp, bp->b_blockkey,
							DB_CHECKRET, bp->b_kvi) != NULL)
						{
						RGseek(ifp, bp->b_blockbegin, 0);
						}
					else	{
						free(bp->b_blockkey);
						nestp--;
						/* find next-outer rep block */
						innerrep = NULL;
						for(i = nestp - 1; i >= 0; i--)
							{
							if(stack[i].b_type == B_REP)
								{
								innerrep = &stack[i];
								break;
								}
							}
						}
					break;
					}
				else if(bp->b_type == B_IF)
					{
					nestp--;
					suppressout = bp->b_suppressout;
					break;
					}
				}
			/* else fall through */
		default:
			if(c == '\n' && bsflag)		/* eat \\n */
				break;

			if(bsflag && !suppressout)
				putc('\\', ofd);	/* don't eat random backslashes */
							/* (might wanta warn, though) */
printchar:
			if(!suppressout)
				putc(c, ofd);
			break;

		case '$':
			{
			struct var *vp;
			char tmpbuf[10];

			if(bsflag)
				goto printchar;
			RGungetc(c, ifp); /* push back $ so getvar can find it */
			vp = dogetvar(ifp);
			if(vp == NULL)
				{
				if(!suppressout)
					putc('$', ofd);	/* shrug */
				break;
				}

			if(vp->v_type == V_DOLLAR)
				{
				/* DWIM: $$ => $ */
				if(!suppressout)
					putc('$', ofd);
				break;
				}

			if(vp->v_type == V_DOT)
				{
				if(!suppressout && innerrep != NULL)
					fprintf(ofd, "%d", innerrep->b_kvi);
				break;
				}

			if(vp->v_type == V_IF)
				{
				stack[nestp].b_type = B_IF;
				stack[nestp].b_suppressout = suppressout;
				nestp++;
				if(!suppressout)
					{
					int r;
#ifdef EXPR
					if(vp->v_flags & V_IFEXPR)
						{
#ifndef EXPRCOMPILE
						fprintf(stderr, "not implemented yet\n");
#else
						struct code *codep = setupexpr(vp->v_expr, (char **)NULL);
						setup2expr(dbd, dbnp,
							innerrep == NULL ? 0 : innerrep->b_kvi);
#ifdef POLYTYPE
						r = objtoint(doeval(codep->c_base));
						cleanupexpr();
						freeexpr(codep);
#else
						r = deval(codep->c_base);
#endif
#endif
						}
					else
#endif
						{
						if(innerrep == NULL)
							r = db_haskey(dbd, dbnp, vp->v_name);
						else	r = (db_gtkv2(dbd, dbnp, vp->v_name, DB_CHECKRET,
									innerrep->b_kvi) != NULL);
						}

					suppressout = !r ^ !!(vp->v_flags & V_NEGATED);
					}
				}
			else if(vp->v_type == V_REP)
				{
				struct keyvalue *kvp = NULL;

				if(!suppressout)
					kvp = db_gtkv2(dbd, dbnp, vp->v_name, DB_CHECKRET, 1);

				if(kvp != NULL)
					{
					stack[nestp].b_type = B_REP;
					stack[nestp].b_blockkey = strsave(vp->v_name);
					stack[nestp].b_kvi = 1;
					stack[nestp].b_blockbegin = RGtell(ifp);
					innerrep = &stack[nestp];
					}
				else	{
					/* simulate another if */
					stack[nestp].b_type = B_IF;
					stack[nestp].b_suppressout = suppressout;
					suppressout= TRUE;
					}

				nestp++;
				}
#ifdef EXPR
			else if(vp->v_type == V_EXPR && !suppressout)
				{
				char *fmt2 = NULL;
#ifndef EXPRCOMPILE
				fprintf(stderr, "not implemented yet\n");
#else
				struct code *codep = setupexpr(vp->v_expr, &fmt2);
				/* XXX possible future compat */
				if(fmt2 == NULL)
					fmt2 = vp->v_fmt;
				else if(vp->v_fmt != NULL && *vp->v_fmt != '\0')
					fprintf(stderr, "%s: repgen: oddity: two formats?\n", progname);

				setup2expr(dbd, dbnp, innerrep == NULL ? 0 : innerrep->b_kvi);
#ifdef POLYTYPE
				printfval(ofd, fmt2, doeval(codep->c_base));
				cleanupexpr();
				freeexpr(codep);
#else
				fprintf(ofd, "%g", deval(codep->c_base));	/* XXX not always %g */
 /* (could use fmt2, maybe...*/
#endif
#endif
				}
#endif
			else if(!suppressout)
				{
				struct keyvalue *kvp;

				if(vp->v_type == V_NUM)
					{
					sprintf(tmpbuf, "%d", db_nvalues(dbd, dbnp, vp->v_name));
					p = tmpbuf;
					fputs(p, ofd);
					kvp = NULL;	/* short circuit */
					}
				else if(vp->v_flags & V_SUBSCRIPT)
					{
					kvp = db_gtkv2(dbd, dbnp, vp->v_name,
						DB_CHECKRET, vp->v_subscript);
					}
				else if(innerrep == NULL)
					kvp = db_gtkv2(dbd, dbnp, vp->v_name, DB_CHECKRET, 0);
				else	{
					kvp =
						db_gtkv2(dbd, dbnp, vp->v_name, DB_CHECKRET,
									innerrep->b_kvi);
					}

				if(kvp != NULL)
					db_fmtval(ofd, vp->v_fmt, kvp);
				}

			break;
			}

		case '\\':
			if(bsflag)
				goto printchar;
			bsflag = TRUE;
			continue;		/* skip bsflag reset @ bottom of loop */
		}

	bsflag = FALSE;
	}

while(nestp > 0)
	{
	struct block *bp = &stack[nestp-1];
	fprintf(stderr, "missing '}'\n");	/* XXX (text, progname?) */
	if(bp->b_type == B_REP)
		free(bp->b_blockkey);
	nestp--;
	}

return TRUE;
}
