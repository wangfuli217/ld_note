/*
 *  plaintext "database" library -- file I/O support functions
 *
 *  Copyright 1987-2002
 *  Steve Summit, scs@eskimo.com
 *  This code may be freely redistributed and used
 *  so long as the author's name and this notice remain intact,
 *  and any modifications are marked as such.
 */

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <assert.h>

#define DEF_DB
#include "db.h"
#include "alloc.h"

#ifdef __STDC__
#include "string2.h"
#endif

extern char *strsave();

static struct dbnode *nullgetent();
static int nullputent();

static void db_fdeinit();
extern int db_dbfregetent();

static struct dbiofuncs nullfuncs =
	{ NULL, NULL, nullgetent, nullputent, NULL };

static struct dbiofuncs dbffuncs =
	{ NULL, db_fdeinit, db_getent, db_putent, db_dbfregetent };

struct dbfd *
db_fopen(name, mode)
char *name;
char *mode;
{
FILE *fd;
struct dbfd *dbfd;

if((fd = fopen(name, mode)) == NULL)
	return NULL;

if((dbfd = db_fdopen(fd)) == NULL)
	{
	(void)fclose(fd);
	return NULL;
	}

dbfd->dbf_mode = *mode;
if(dbfd->dbf_mode == 'a')
	dbfd->dbf_mode = 'w';

dbfd->dbf_filename = strsave(name);

return dbfd;
}

struct dbfd *
db_fdopen(fd)
FILE *fd;
{
register struct dbfd *dbfd = Salloc(struct dbfd);

dbfd->dbf_gflags = 0;
dbfd->dbf_gstate = 0;

dbfd->dbf_filename = NULL;
dbfd->dbf_fd = fd;
dbfd->dbf_mode = '?';
dbfd->dbf_lineno = 0;

dbfd->dbf_lballoc = 100;
dbfd->dbf_lbuf = alloc(dbfd->dbf_lballoc);

dbfd->dbf_nblank = 0;

dbfd->dbf_funcs = &nullfuncs;
dbfd->dbf_fmtspecif = NULL;

dbfd->dbf_errcount = 0;
dbfd->dbf_errlimit = 20;

return dbfd;
}

db_f_dbf_set(dbfd, flags)
struct dbfd *dbfd;
int flags;
{
struct dbf *dbf2;

dbfd->dbf_funcs = &dbffuncs;

dbf2 = dbfd->dbf_fmtspecif = Salloc(struct dbf);

dbf2->dbf_magic = DBFMAGIC;

dbf2->dbf_fflags = flags;
dbf2->dbf_fstate = 0;

dbf2->dbf_keychar = ':';
dbf2->dbf_commentchar = '#';
dbf2->dbf_sepkey = NULL;
dbf2->dbf_textkey = NULL;
}

db_f_opt_set(dbfd, flags)
struct dbfd *dbfd;
int flags;
{
dbfd->dbf_gflags |= flags;
}

db_fgtflags(dbfd)
struct dbfd *dbfd;
{
struct dbf *dbf2;
if((dbf2 = dbfd->dbf_fmtspecif) == NULL || dbf2->dbf_magic != DBFMAGIC)
	panic("db_fgtflags: not dbf file");
return dbf2->dbf_fflags;
}

db_fstflags(dbfd, flags)
struct dbfd *dbfd;
int flags;
{
struct dbf *dbf2;
if((dbf2 = dbfd->dbf_fmtspecif) == NULL || dbf2->dbf_magic != DBFMAGIC)
	panic("db_fstflags: not dbf file");
dbf2->dbf_fflags |= flags;	/* if it's this way, also need clearflags... */
}

db_f_sepk_set(dbfd, sepkey)
struct dbfd *dbfd;
char *sepkey;
{
struct dbf *dbf2;
if((dbf2 = dbfd->dbf_fmtspecif) == NULL || dbf2->dbf_magic != DBFMAGIC)
	panic("db_f_sepk_set: not dbf file");
dbf2->dbf_sepkey = strsave(sepkey);
}

db_fschars(dbfd, keychar, commentchar)
struct dbfd *dbfd;
int keychar, commentchar;
{
struct dbf *dbf2;
if((dbf2 = dbfd->dbf_fmtspecif) == NULL || dbf2->dbf_magic != DBFMAGIC)
	panic("db_fschars: not dbf file");
dbf2->dbf_keychar = keychar;
dbf2->dbf_commentchar = commentchar;
}

static void
db_fdeinit(dbfd)
struct dbfd *dbfd;
{
struct dbf *dbf2;
if((dbf2 = dbfd->dbf_fmtspecif) == NULL || dbf2->dbf_magic != DBFMAGIC)
	panic("db_fdeinit: not dbf file");
if(dbf2->dbf_sepkey != NULL)
	free(dbf2->dbf_sepkey);
if(dbf2->dbf_textkey != NULL)
	free(dbf2->dbf_textkey);
free(dbf2);
dbfd->dbf_fmtspecif = NULL;
}

static struct dbnode *
nullgetent(dbfd, dbd)
struct dbfd *dbfd;
struct db *dbd;
{
panic("nullgetent");
}

static int
nullputent(dbfd, dbnp)
struct dbfd *dbfd;
struct dbnode *dbnp;
{
panic("nullputent");
}

db_getline(dbfd)
struct dbfd *dbfd;
{
register char *p;
char *endp;
register int c;

if(dbfd->dbf_gstate & DB__HAVELINE)
	{
	dbfd->dbf_gstate &= ~DB__HAVELINE;
	dbfd->dbf_lineno++;
	return dbfd->dbf_llen;
	}

if(dbfd->dbf_gstate & DB__PIPE)
	{
	/* XXX Unix-specific */
	dbfd->dbf_lbeg += dbfd->dbf_llen + 1;		/* +1 for \n */
	}
else	{
	dbfd->dbf_lbeg = ftell(dbfd->dbf_fd);
	if(dbfd->dbf_lbeg == -1)
		{
		dbfd->dbf_lbeg = 0;
		dbfd->dbf_gstate |= DB__PIPE;
		}
	}

p = dbfd->dbf_lbuf;
endp = dbfd->dbf_lbuf + dbfd->dbf_lballoc;

for(;;)
	{
	if(p >= endp)
		{
		int nread = p - dbfd->dbf_lbuf;
		dbfd->dbf_lballoc += dbfd->dbf_lballoc / 2;
		dbfd->dbf_lbuf = crealloc(dbfd->dbf_lbuf, dbfd->dbf_lballoc);
		p = dbfd->dbf_lbuf + nread;
		endp = dbfd->dbf_lbuf + dbfd->dbf_lballoc;
		}

	c = getc(dbfd->dbf_fd);

	if(c == EOF || c == '\n')
		{
		*p = '\0';
		break;
		}

	*p++ = c;
	}

if(c == EOF && p == dbfd->dbf_lbuf)
	return EOF;

dbfd->dbf_llen = p - dbfd->dbf_lbuf;
dbfd->dbf_lineno++;

return dbfd->dbf_llen;
}

db_ungetline(dbfd, line)
struct dbfd *dbfd;
char *line;
{
if(line != dbfd->dbf_lbuf)
	{
	int len = strlen(line);
	if(len + 1 > dbfd->dbf_lballoc)
		{
		dbfd->dbf_lballoc = len + 1;
		dbfd->dbf_lbuf = crealloc(dbfd->dbf_lbuf, dbfd->dbf_lballoc);
		}

	(void)strcpy(dbfd->dbf_lbuf, line);
	dbfd->dbf_llen = len;
	assert(!(dbfd->dbf_gstate & DB__PIPE));
	}

dbfd->dbf_lineno--;

dbfd->dbf_gstate |= DB__HAVELINE;
}

db_fclose(dbfd)
struct dbfd *dbfd;
{
fclose(dbfd->dbf_fd);
db_fdclose(dbfd);
}

db_fdclose(dbfd)
struct dbfd *dbfd;
{
if(dbfd->dbf_funcs != NULL && dbfd->dbf_funcs->dbf_deinit != NULL)
	(*dbfd->dbf_funcs->dbf_deinit)(dbfd);
if(dbfd->dbf_filename != NULL)
	free(dbfd->dbf_filename);
free(dbfd->dbf_lbuf);
dbfd->dbf_mode = '\0';		/* just in case */
free((char *)dbfd);
}
