/*
 *  dbgrep report generator --
 *  functions for parsing embedded "variables"
 *  and other expressions for interpolation
 *
 *  Copyright 1997-2002
 *  Steve Summit, scs@eskimo.com
 *  This code may be freely redistributed and used
 *  so long as the author's name and this notice remain intact,
 *  and any modifications are marked as such.
 */

#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <assert.h>
#include "defs.h"
#include "alloc.h"
#include "repgen.h"
#include "rgifp.h"

#define NRETBUF 5

struct var *
getvar(fp)
FILE *fp;
{
struct rgifp *ifp = rgfpifp(fp);
struct var *retp = dogetvar(ifp);
rgifree(ifp);
return retp;
}

struct var *
parsevar(buf, endp)
char *buf;
char **endp;
{
struct rgifp *ifp;
struct var *retp;

ifp = rgstrifp(buf);
retp = dogetvar(ifp);
if(endp != NULL)
	*endp = rgstrcur(ifp);
rgifree(ifp);
return retp;
}

/*
 *  $key	extract key value
 *  ${key}	extract key value (esp. if key name contains spaces)
 *  $key[i]	extract key's i'th value
 *  $$		literal $
 *  \$, \}, \\	literal characters
 *  \\n		(backslash at end of line) eat newline; join line
 *  $?key{...}	conditinally include text only if key has value
 *  $?{key}{...}	ditto
 *  $!key{...}	conditinally include text only if key has no value
 *  $!{key}{...}	ditto
 *  $*key{...}	repeat text once for each of key's multiple values
 *  $*{key}{...}	ditto
 *  $#key	number of key's values
 *  $.		count (i) during $*
#ifdef EXPR
 *  $%{expr}	value of expression
 *  $?%{expr}{...}	conditinally include text only if expression true
#endif
 */

struct var *
dogetvar(ifp)
struct rgifp *ifp;
{
int c;
char *p, *p2;
static struct var retbufs[NRETBUF];
static int whichretbuf = 0;
struct var *retp;
int bracketedvar = FALSE;

retp = &retbufs[whichretbuf];
whichretbuf = (whichretbuf + 1) % NRETBUF;

retp->v_type = V_REG;
retp->v_flags = 0;

c = RGgetc(ifp);
assert(c == '$');

c = RGgetc(ifp);

if(c == '$')
	{
	retp->v_type = V_DOLLAR;
	return retp;
	}
else if(c == '.')
	{
	retp->v_type = V_DOT;
	return retp;
	}
else if(c == '?' || c == '!')
	{
	retp->v_type = V_IF;
	if(c == '!')
		retp->v_flags |= V_NEGATED;
	c = RGgetc(ifp);
#ifdef EXPR
	if(!(retp->v_flags & V_NEGATED) && c == '%')
		{
		retp->v_flags |= V_IFEXPR;
		c = RGgetc(ifp);
		}
#endif
	}
else if(c == '*')
	{
	retp->v_type = V_REP;
	c = RGgetc(ifp);
	}
else if(c == '#')
	{
	retp->v_type = V_NUM;
	c = RGgetc(ifp);
	}
#ifdef EXPR
else if(c == '%')
	{
	retp->v_type = V_EXPR;
	c = RGgetc(ifp);
	}
#endif

if(retp->v_namealloc == 0)
	{
	retp->v_namealloc = 20;
	retp->v_name = alloc(retp->v_namealloc);
	}

p = retp->v_name;
p2 = retp->v_fmt;

if(c == '{')
	bracketedvar = TRUE;
else if(c == '@')
	retp->v_flags |= V_NONAME;
else if(isalpha(c))
	{
	/* first char, guaranteed space (by initial alloc above) */
	*p++ = c;
	}
else	{
	fprintf(stderr, "missing variable name\n");	/* XXX (text, progname?)*/
	/* XXX (bsflag?) */
	return NULL;
	}

if(!(retp->v_flags & V_NONAME))
    {
    while((c = RGgetc(ifp)) != EOF)
	{
	if(bracketedvar)
		{
		/*
		 *  Tricky to allow ,fmt after expressions, since
		 *  need to accept , within expressions (in function
		 *  argument lists, if not as comma operators).
		 *  Currently, ,fmt for expressions is handled in a
		 *  completely different place, in setupexpr() in expr.c.
		 */

		if(retp->v_type == V_REG && c == ',')	/* no , in variable names, I guess */
			{
			*p = '\0';
			c = RGgetc(ifp);
			while(c == ' ')
				c = RGgetc(ifp);
			if(c == '%')
				{
				if(retp->v_flags & V_HAVEFMT)
					{
					fprintf(stderr, "already have fmt\n");
					return NULL;
					}
				if(retp->v_flags & V_HAVEREGEXP)
					{
					fprintf(stderr, "can't have fmt and regexp\n");
					return NULL;
					}
				p2 = retp->v_fmt;
				retp->v_flags |= V_HAVEFMT;
				}
			else if(c == '/')
				{
				if(retp->v_flags & V_HAVEREGEXP)
					{
					fprintf(stderr, "already have regexp\n");
					return NULL;
					}
				if(retp->v_flags & V_HAVEFMT)
					{
					fprintf(stderr, "can't have fmt and regexp\n");
					return NULL;
					}
				p2 = retp->v_regexp;
				retp->v_flags |= V_HAVEREGEXP;
				continue;	/* eat leading / */
				}
			else if(c == '}')	/* lone , at end in {} */
				break;
			else	{
				fprintf(stderr, "unrecognized modifier\n");
				return NULL;
				}
			}
		else if(c == '}')
			break;
		}
	else if(!isalnum(c) && c != '_')
		{
		RGungetc(c, ifp);
		break;
		}

	if(retp->v_flags & (V_HAVEFMT | V_HAVEREGEXP))
		*p2++ = c;		/* XXX worry about overflow */
	else	{
		if(p-retp->v_name + 1 >= retp->v_namealloc)
			{
			int o = p - retp->v_name;
			retp->v_namealloc += 10;
			retp->v_name = crealloc(retp->v_name, retp->v_namealloc);
			p = retp->v_name + o;
			}
		*p++ = c;
		}
	}
    }

*p = '\0';
*p2 = '\0';

c = RGgetc(ifp);		/* wish we had RGpeekc() */
if(c == EOF)
	;
else if(c != '[')
	RGungetc(c, ifp);
else	{
	/* ideally would want subexprs here, not just numeric constants */

	int n = 0;

	while((c = RGgetc(ifp)) != EOF)
		{
		if(isdigit(c))
			n = 10 * n + Ctod(c);
		else if(c == ']')
			break;
		else	{
			/* allow whitespace? */
			fprintf(stderr, "subscript syntax error\n");
			return NULL;	/* ? */
			}
		}

	retp->v_subscript = n;
	retp->v_flags |= V_SUBSCRIPT;
	}

if(retp->v_flags & V_HAVEREGEXP)
	{
	p = &retp->v_regexp[strlen(retp->v_regexp)];
	if(p > retp->v_regexp && *(p-1) == '/')
		*(p-1) = '\0';
	}

if((retp->v_flags & V_HAVEFMT) && retp->v_type != V_REG
#ifdef EXPR
						     && retp->v_type != V_EXPR
#endif
									      )
	fprintf(stderr, "fmt ignored\n");

if((retp->v_flags & V_HAVEREGEXP) && retp->v_type != V_REG)
	fprintf(stderr, "regexp ignored\n");

if(retp->v_type == V_IF || retp->v_type == V_REP)
	{
	/* allow whitespace or anything? */

	c = RGgetc(ifp);
	if(c != '{')
		{
		fprintf(stderr, "missing '{'\n");	/* XXX (text, progname?)*/
		return NULL;
		}
	}

if(retp->v_type == V_REG && *retp->v_name == '\0')
	retp->v_flags |= V_NONAME;

return retp;
}
