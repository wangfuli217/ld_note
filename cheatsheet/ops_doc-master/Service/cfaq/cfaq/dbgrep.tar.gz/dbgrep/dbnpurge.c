#define DEF_DB
#include "db.h"

db_purgenode(dbd, dbnp)
struct db *dbd;
struct dbnode *dbnp;
{
int i;

if(dbnp->dbn_flags & DBN_INDEXONLY)
	return;

for(i = 0; i < dbnp->dbn_nkeys; )	/* i++ only if keys[i] not deleted */
	{
	if((dbnp->dbn_keys[i].kv_flags & KVF_INTERNAL) ||
			isindexkey(dbd, dbnp->dbn_keys[i].kv_key))
		{
		i++;
		continue;
		}

	/*
	 *  Beware db_regetent() call in db_idelkey() --
	 *  narrowly averted since we haven't set DBN_INDEXONLY... *yet*
	 */

	db_idelkey(dbd, dbnp, i, DB_KVINTERNAL | DB_NOHISTORY);
	}

db_kvfinish(dbnp);	/* to realloc dbn_keys[] */

dbnp->dbn_flags |= DBN_INDEXONLY;
}
