/*
 *  dbgrep report generator --
 *  code for reading report template from file or memory
 *
 *  Copyright 2001-2002
 *  Steve Summit, scs@eskimo.com
 *  This code may be freely redistributed and used
 *  so long as the author's name and this notice remain intact,
 *  and any modifications are marked as such.
 */

#include <stdio.h>
#include <string.h>
#include "rgifp.h"
#include "alloc.h"

struct rgifp *
rgfpifp(fp)
FILE *fp;
{
struct rgifp *ifp = Salloc(struct rgifp);

ifp->ctx = fp;
ifp->flags = 0;

#ifdef __STDC__

/* ugly casts because we're cheating and, e.g. in RGgetc macro, */
/* calling getc() et al. with void *, not FILE * (ugliness begets ugliness) */

ifp->getfunc = (int (*)(void *))fgetc;
ifp->ungetfunc = (int (*)(int, void *))ungetc;
ifp->tellfunc = (long int (*)(void *))ftell;
ifp->seekfunc = (int (*)(void *, long int, int))fseek;

#else

ifp->getfunc = fgetc;
ifp->ungetfunc = ungetc;
ifp->tellfunc = ftell;
ifp->seekfunc = fseek;

#endif

return ifp;
}

struct strctx
	{
	char *ptr;
	char *base;
	};

#ifdef __STDC__
static int strgetc(void *p);
static int strungetc(int, void *);
static long int strtell(void *);
static int strseek(void *, long int, int);
#endif

static int strgetc();
static int strungetc();
static long int strtell();
static int strseek();

struct rgifp *
rgstrifp(str)
char *str;
{
struct rgifp *ifp = Salloc(struct rgifp);
ifp->ctx = Salloc(struct strctx);
((struct strctx *)ifp->ctx)->base = ((struct strctx *)ifp->ctx)->ptr = str;
ifp->flags = FREECTX;

ifp->getfunc = strgetc;
ifp->ungetfunc = strungetc;
ifp->tellfunc = strtell;
ifp->seekfunc = strseek;

return ifp;
}

char *
rgstrcur(ifp)
struct rgifp *ifp;
{
return ((struct strctx *)ifp->ctx)->ptr;
}

rgifree(ifp)
struct rgifp *ifp;
{
if(ifp->flags & FREECTX)
	free(ifp->ctx);
free(ifp);
}

static int
strgetc(p)
void *p;
{
/* XXX oughta cast back to strctx * */
if(**(char **)p == '\0')
	return EOF;
return *(*(char **)p)++;
}

static int
strungetc(c, p)
int c;
void *p;
{
/* XXX oughta cast back to strctx * */
(*(char **)p)--;
}

static long int
strtell(p)
void *p;
{
struct strctx *sxp = p;
return sxp->ptr - sxp->base;
}

static int
strseek(p, off, whence)
void *p;
long int off;
int whence;
{
struct strctx *sxp = p;

switch(whence)
	{
	case 0:
		sxp->ptr = sxp->base + off;
		break;

	case 1:
		sxp->ptr += off;
		break;

	case 2:
		sxp->ptr = sxp->base + strlen(sxp->base) + off;	/* awk. */
		break;
	}
}
