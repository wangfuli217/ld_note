/*
 *  dbgrep option flag and expression parse
 *
 *  Copyright 1992-2002
 *  Steve Summit, scs@eskimo.com
 *  This code may be freely redistributed and used
 *  so long as the author's name and this notice remain intact,
 *  and any modifications are marked as such.
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <assert.h>
#include "db.h"		/* XXX was <>, but Think C probs */
#include "alloc.h"
#include "argd.h"
#include "defs.h"
#include "dbgrep.h"

int invertflag = FALSE;

extern int foldcase;
extern int keyfoldcase;

int matchflag = FALSE;
int exactflag = FALSE;

extern char *sepkey;

extern int keysepchar;
extern int commentchar;

extern int mailflag;
extern char *mailsepkey;

extern int prsrvindent;
extern int prsrvcomments;
extern int alwaysprint;
extern int appnewline;
extern int countflag;

extern int dbfmoreflags;

extern int ifmt, ofmt;

#ifdef STREAMDB
extern int streamok;
#endif

extern char *outfile;
extern int multout;
extern int multappend;
extern char *ofkey;

extern char *progname;
char *usage = "usage: %s [flags] {pat | expr | -f exprfile} [files]\n";

extern struct eval *evalroot;

static int printedhelp = FALSE;

struct eval *parse1(), *parse2(), *parse3();
char *skipopts();
struct eval *makepat(), *makebool();

static char syntaxerror[] = "%s: expression syntax error%s\n";

int strmatch(), strimatch();

extern char *strsave();

#ifdef EXPR
#ifdef EXPRCOMPILE
extern const char *exprversion();
#endif
#endif

#ifndef MAILFILT

parseargs(argp, argc, argv)
int *argp;
int argc;
char *argv[];
{
struct argd argd;

evalroot = parse1(mkargvd(argc, argv, argp, &argd));

if(evalroot == NULL && !eoargs(&argd))
	{
	/* implicit -e on one pattern (just like grep) */
	evalroot = makepat((char *)NULL, nxtarg(&argd),
			KEYANY | (exactflag ? PATEXACT :
				matchflag ? PATMATCH : PATRE));
#ifdef STREAMDB
	streamok = FALSE;
#endif
	}

if(evalroot == NULL)
	{
	if(printedhelp)
		exit(0);

	fprintf(stderr, usage, progname);
	exit(1);
	}

if(invertflag)
	evalroot = (struct eval *)makebool(evalroot, NOT, (struct eval *)NULL);
}

#endif

/* first parse: handles -o */

struct eval *
parse1(argd)
struct argd *argd;
{
struct eval *lhs, *rhs;
char *arg;

lhs = parse2(argd);

if(lhs == NULL || eoargs(argd))
	return lhs;

while((arg = peekarg(argd)) != NULL && (Streq(arg, "-o") || Streq(arg, "-or")))
	{
	(void)nxtarg(argd);

	if((rhs = parse2(argd)) == NULL)
		{
		fprintf(stderr, syntaxerror, progname, "");
		exit(1);
		}

	lhs = (struct eval *)makebool(lhs, OR, rhs);
	}

return lhs;
}

/* second parse: handles -a */

struct eval *
parse2(argd)
struct argd *argd;
{
struct eval *lhs, *rhs;
char *arg;

lhs = parse3(argd);

if(lhs == NULL || eoargs(argd))
	return lhs;

while(!eoargs(argd))
	{
	int sawdasha = FALSE;	/* "saw dash a" */

	arg = peekarg(argd);

	if(Streq(arg, "-o") || Streq(arg, "-or") || Streq(arg, ")"))
		{
		/* kludge -- need a better lexer */
		return lhs;
		}

	if(Streq(arg, "-a") || Streq(arg, "-and"))
		{
		/* explicit -a is ignored, since "and" is implicit */

		sawdasha = TRUE;

		(void)nxtarg(argd);
		}

	if((rhs = parse3(argd)) == NULL)
		{
		if(!sawdasha)
			return lhs;

		fprintf(stderr, syntaxerror, progname, "");
		exit(1);
		}

	lhs = (struct eval *)makebool(lhs, AND, rhs);
	}

return lhs;
}

static int nostmfunc();
static int kafunc();
static int kxafunc();

static struct pred
	{
	char *p_key;
	int p_flags;
	int (*p_func)();
	} preds[] =
	{
	"-e",	 	KEYANY | PATRE,		nostmfunc,
	"-k", 		KEYEXACT | PATRE,	NULL,
	"-km",	 	KEYEXACT | PATMATCH,	NULL,
	"-kn", 		KEYEXACT | PATRE,	NULL,
	"-kx",	 	KEYEXACT | PATEXACT,	NULL,
	"-ka",	 	SPECONLY,		kafunc,
	"-kxa",	 	SPECONLY,		kxafunc,
	"-kxaf", 	SPECONLY,		kxafunc,
	"-kr", 		KEYRE | PATRE,		NULL,
	"-ke", 		KEYEXACT | KEYEXISTS,	NULL,
	"-ker", 	KEYRE | KEYEXISTS,	NULL,
	"-kre", 	KEYRE | KEYEXISTS,	NULL,
	};

#ifndef MAILFILT

extern int addkeyop();
#ifdef EXPR
extern int addkeyeop();
#endif
extern int delkeyop();
#ifdef RENAMEKEY
extern int rnkeyop();
#endif
#ifdef unix
extern int execop();
#endif
#ifdef EXPR
extern int exprop(), exprpop();
#endif
extern int printop();
extern int writeop();
extern int prkeyop();
extern int prnkeyop();
extern int extrkeyop();
extern int prshkeyop();
#ifdef REPGEN
extern int repgenpop();
extern int repgenfop();
int repgenxop();
#endif
extern int setkeyop();
extern int setkeyaop();
#ifdef EXPR
extern int setkeyeop();
#endif

#define ONESTRVAL	01
#define NODFLTPRINT	02
#define APPNEWLINE	04
#define SPECINIT	0x08
#define TWOSTRVALS	0x10
#define NEEDCTX		0x20	/* e_func needs additional context */
				/*
				 *  Means e_func would like context beyond
				 *  the one (or two?) string vals.
				 *  For now, will get a pointer to a chunk
				 *  of memory of size 5 * sizeof(char *),
				 *  the first two of which are the one
				 *  (or two) str vals, the rest of
				 *  which e_func can use as desired.
				 *  (They're initialized to 0 which,
				 *  hmm, isn't necessarily NULL.
				 *  But this is preliminary.)
				 *
				 *  Eventually, may devise a way for struct act
				 *  to specify how much ctx space needed.
				 *
				 *  Now that this capability exists,
				 *  several existing actions need it,
				 *  e.g. the expression-related ones
				 *  (so can parse expression once),
				 *  the report generation one(s)
				 *  (so can open template once), etc.
				 */

static struct act
	{
	char *a_key;
	int (*a_func)();
	int a_flags;
	} acts[] =
	{
	"-ak", 		addkeyop,	SPECINIT,
#ifdef EXPR
	"-ake", 	addkeyeop,	SPECINIT,
#endif
#ifdef notdef
	/* count handled as option flag, for now */
	"-c", 		NULL,		NODFLTPRINT,
	"-count", 	NULL,		NODFLTPRINT,
#endif
	"-dk", 		delkeyop,	ONESTRVAL,
	"-ek",	 	extrkeyop,	SPECINIT | NODFLTPRINT,
#ifdef unix
	"-exec", 	execop,		ONESTRVAL | NODFLTPRINT,
#endif
#ifdef EXPR
	"-expr", 	exprop,		ONESTRVAL,
	"-exprp", 	exprpop,	ONESTRVAL | NODFLTPRINT,
	"-pexpr", 	exprpop,	ONESTRVAL | NODFLTPRINT,
#endif
	"-pkv",	 	prkeyop,	ONESTRVAL | NODFLTPRINT,
	"-pkvn",	prnkeyop,	TWOSTRVALS | NODFLTPRINT,
	"-pkv2", 	extrkeyop,	SPECINIT | NODFLTPRINT,	/* backwards compat */
	"-pkvsh", 	prshkeyop,	ONESTRVAL | NODFLTPRINT | APPNEWLINE,
	"-print", 	printop,	NODFLTPRINT,
#ifdef RENAMEKEY
	"-rnk", 	rnkeyop,	TWOSTRVALS,
#endif
#ifdef REPGEN
	"-rgp",		repgenpop,	ONESTRVAL | NODFLTPRINT,
	"-rgf",		repgenfop,	ONESTRVAL | NODFLTPRINT,
	"-rg", 		repgenxop,	ONESTRVAL | NODFLTPRINT,
#endif
	"-sk", 		setkeyop,	SPECINIT,
	"-setkey",	setkeyop,	SPECINIT,
	"-ska", 	setkeyaop,	SPECINIT,
#ifdef EXPR
#ifdef EXPRCOMPILE /* XXX no non-compiled set-to-expr yet */
	"-ske", 	setkeyeop,	SPECINIT,
#endif
#endif
	"-true", 	NULL,		0,
	"-writef",	writeop,	ONESTRVAL | NEEDCTX | NODFLTPRINT,
	};

#endif

#define Sizeofarray(array) (sizeof(array) / sizeof(array[0]))

/* third parse: handles primitives */

struct eval *
parse3(argd)
struct argd *argd;
{
char *arg;
char argbuf[10];
char *key = NULL, *pat = NULL;
int i;
struct eval *ep = NULL;
int predflags;
int kn = 0;

arg = skipopts(argd);

if(arg == NULL)
	return NULL;

if(Streq(arg, "!"))
	return makebool(parse3(argd), NOT, (struct eval *)NULL);

if(Streq(arg, "("))
	{
	struct eval *ep;
	ep = parse1(argd);
	if(ep == NULL)
		{
		fprintf(stderr, syntaxerror, progname,
					" (missing subexpression)");
		exit(1);
		}

	arg = skipopts(argd);

	if(arg == NULL || !Streq(arg, ")"))
		{
		if(arg != NULL)
			ungetarg(argd);

		fprintf(stderr, syntaxerror, progname, " (missing ')')");
		exit(1);
		}

	return ep;
	}

if(arg[0] != '-')
	{
	ungetarg(argd);
	return NULL;
	}

#ifndef MAILFILT

for(i = 0; i < Sizeofarray(acts); i++)
	{
	if(Streq(arg, acts[i].a_key))
		break;
	}

if(i < Sizeofarray(acts))
	{
	struct evalother *eop = Salloc(struct evalother);
	eop->e_type = SPECIAL;

	eop->e_func = acts[i].a_func;
	eop->e_flags = 0;
	eop->e_context = NULL;

	/* gotta stash arg so can hold simultaneously with other args */
	assert(strlen(arg) < sizeof(argbuf));
	strcpy(argbuf, arg);
	arg = argbuf;
	/* (repeated below) */

	if(acts[i].a_flags & NEEDCTX)
		{
		eop->e_context = (char *)SNalloc(char *, 5);
		memset(eop->e_context, 0, 5 * sizeof(char *));	/* XXX */
							/* not nec. NULL */
		}

#ifndef TWOSTRVALS
	if(acts[i].a_flags & ONESTRVAL)
#else
	if(acts[i].a_flags & (ONESTRVAL | TWOSTRVALS))
#endif
		{
		char *args[2];

		if(eoargs(argd))
			{
			fprintf(stderr, "%s: missing arg after %s\n",
								progname, arg);
			exit(1);
			}

		args[0] = strsave(nxtarg(argd));

#ifdef TWOSTRVALS
		if(acts[i].a_flags & TWOSTRVALS)
			{
			if(eoargs(argd))
				{
				fprintf(stderr, "%s: missing arg after %s\n",
								progname, arg);
				exit(1);
				}

			args[1] = strsave(nxtarg(argd));
			}
#endif

		if(acts[i].a_flags & NEEDCTX)
			{
			((char **)eop->e_context)[0] = args[0];
#ifdef TWOSTRVALS
			if(acts[i].a_flags & TWOSTRVALS)
				((char **)eop->e_context)[1] = args[1];
#endif
			}
#ifdef TWOSTRVALS
		else if(acts[i].a_flags & TWOSTRVALS)
			{
			eop->e_context = alloc(2 * sizeof(char *));
			((char **)eop->e_context)[0] = args[0];
			((char **)eop->e_context)[1] = args[1];
			}
#endif
		else	{
			eop->e_context = args[0];
			}
		}

	if(acts[i].a_flags & NODFLTPRINT)
		alwaysprint = FALSE;

	if(acts[i].a_flags & APPNEWLINE)
		appnewline = TRUE;

	if(acts[i].a_flags & SPECINIT)
		{
		struct specialctx sctx;
		sctx.sc_which = SC_INIT;
		sctx.sc_argd = argd;
		sctx.sc_enode = eop;
		(*acts[i].a_func)((dbdesc)NULL, (dbnode)NULL, (char *)&sctx);
		eop->e_context = sctx.sc_ctxp;
		eop->e_flags |= SPECIALCALL;
		}

	return (struct eval *)eop;
	}

#endif

for(i = 0; i < Sizeofarray(preds); i++)
	{
	if(Streq(arg, preds[i].p_key))
		break;
	}

if(i >= Sizeofarray(preds))
	{
	fprintf(stderr, "%s: unknown option %s\n", progname, arg);
	return NULL;
	}

/* gotta stash arg so can hold simultaneously with other args */
assert(strlen(arg) < sizeof(argbuf));
strcpy(argbuf, arg);
arg = argbuf;
/* (repeated above) */

predflags = preds[i].p_flags;

/* apply -m or -x to -e, -k */

if((predflags & PATMASK) == PATRE)
	{
	if(exactflag)
		predflags = (predflags & ~PATMASK) | PATEXACT;
	else if(matchflag)
		predflags = (predflags & ~PATMASK) | PATMATCH;
	}	     

if((predflags & KEYMASK) == KEYEXACT || (predflags & KEYMASK) == KEYRE)
	{
	static char *keybuf = NULL;
	static int nkeybuf = 0;

	if(eoargs(argd))
		{
		fprintf(stderr, "%s: missing key after %s\n", progname, arg);
		exit(1);
		}

	/* gotta stash key so can hold simultaneously with pat */

	key = nxtarg(argd);

	if(strlen(key) + 1 > nkeybuf)
		{
		nkeybuf = strlen(key) + 1;
		keybuf = crealloc(keybuf, nkeybuf);
		}

	strcpy(keybuf, key);
	key = keybuf;
	}

if(Streq(arg, "-kn"))
	{
	char *p;

	if(eoargs(argd) || !numeric(p = nxtarg(argd)))
		{
		fprintf(stderr, "%s: missing occurrence indicator after %s\n",
							progname, arg);
		exit(1);
		}

	kn = atoi(p);
	}

if((predflags & PATMASK) == PATEXACT || (predflags & PATMASK) == PATMATCH ||
			(predflags & PATMASK) == PATRE)
	{
	if(eoargs(argd))
		{
		fprintf(stderr, "%s: missing pattern after %s\n",
							progname, arg);
		exit(1);
		}

	pat = nxtarg(argd);
	}

if(!(predflags & SPECONLY))
	{
	ep = makepat(key, pat, predflags);
	((struct evalpat *)ep)->e_kn = kn;
	}

/* dunno if this should precede or follow makepat call */

if(preds[i].p_func != NULL)
	{
	/* XXX arg may become invalid... */
	if(!(*preds[i].p_func)(arg, argd, &ep))
		return NULL;
	}

return ep;
}

static int
nostmfunc(opt, argd, epp)
char *opt;
struct argd *argd;
struct eval **epp;
{
#ifdef STREAMDB
streamok = FALSE;
#endif
return TRUE;
}

/* "lexical analyzer:" skip option flags; return next expression token */

char *
skipopts(argd)
struct argd *argd;
{
char *p;
char *arg;

while((arg = nxtarg(argd)) != NULL)
	{
	if(arg[0] != '-')		/* not an option or pred at all -- */
		return arg;		/* must be "(", ")", "!", or filename */

	if(arg[1] == '\0')		/* means stdin */
		{
		ungetarg(argd);
		return NULL;
		}

	if(Streq(arg, "--"))		/* means end of args */
		return NULL;

	for(p = &arg[1]; *p != '\0'; p++)
		{
		int firstchar = TRUE;

		switch(*p)
		    {
#ifndef MAILFILT
		    case '?':
printhelp:			printf(usage, progname);
			printf("expressions:\n");
			printf("\t-e pat\t\tmatch pat in any field\n");
#ifdef EXPR
			printf("\t-expr e\t\teval expr e and continue if true\n");
#endif
			printf("\t-k key pat\tmatch pat in named field\n");
			printf("\t-km key pat\tmatch pat in named field (no RE)\n");
			printf("\t-kn key n pat\tmatch pat in nth named field\n");
			printf("\t-kx key pat\tmatch pat exactly in named field (no RE)\n");
			printf("\t-ka keys pat ;\tmatch pat in any of a number of fields\n");
			printf("\t-kxa key pats ;\tmatch (exactly) any of pats in named field\n");
			printf("\t-kxaf key file\tmatch (exactly) any pat from file in named field\n");
			printf("\t-kr keypat pat\tmatch pat in fields matching keypat\n");
			printf("\t-ke key\t\ttrue if named field exists\n");
			printf("\t-ker keypat\ttrue if field matching keypat exists\n");
			printf("\t-true\t\talways true\n");
			printf("\t-a, -and\tand (also implied by adjacent expressions)\n");
			printf("\t-o, -or\t\tor\n");
			printf("\t!\t\tnot\n");
			printf("\t( )\t\tgrouping\n");

			printf("processing operations:\n");
			printf("\t-ak key val\tappend key and value\n");
#ifdef EXPR
			printf("\t-ake key expr\tappend key with value of expr\n");
#endif
			printf("\t-c, -count\tprint count of matching records\n");
			printf("\t-dk key\t\tdelete key (and value)\n");
			printf("\t-ek key\t\textract key (and value)\n");
#ifdef unix
			printf("\t-exec cmd\texecute cmd with record as input\n");
#endif
#ifdef EXPR
			printf("\t-exprp e\tprint expr e\n");
#endif
#ifdef notyet
			printf("\t-ik k1 val k2\tinsert k1 and value before k2\n");
			printf("\t-ika k1 val k2\tinsert k1 and value after k2\n");
#endif
			printf("\t-mof filepat\twrite output to multiple numbered files\n");
			printf("\t-mofk fpat key\twrite output to multiple files, per key\n");
			printf("\t-mofka fpat key\tlike -mofk, but append to files\n");
			printf("\t-pkv key\tprint only key's value\n");
			printf("\t-pkvn key n\tprint nth of key's values\n");
			printf("\t-pkvsh key\tprint key=value\n");
			printf("\t-print\t\tprint matching record (default)\n");
#ifdef REPGEN
			printf("\t-rgp pat\tgenerate report from pat\n");
			printf("\t-rgf file\tgenerate report from skeleton in file\n");
#endif
			printf("\t-sk key val\tset (existing) key to value\n");
			printf("\t-ska key val\tset key to value (append key if not present)\n");
#ifdef EXPR
			printf("\t-ske key expr\tset (existing) key to expr\n");
#endif
			printf("\t-writef file\twrite record to file\n");
			printf("options:\n");
			printf("\t-contin, -hc\tallow continuation lines\n");
			printf("\t-cc c\t\tset comment character\n");
			printf("\t-cs\t\tforce colon separator\n");
			printf("\t-f file\t\tread expression from file\n");
			printf("\t-i\t\tignore case\n");
			printf("\t-ifmt f\t\tset input format\n");
			printf("\t-ki\t\tignore case in field keywords\n");
			printf("\t-m\t\tsubstring matches (no RE)\n");
			printf("\t-mail\t\tread mailbox format\n");
			printf("\t-mailh key\tmailbox format, separator key\n");
			printf("\t-of file\twrite output to file\n");
			printf("\t-ofmt f\t\tset output format\n");
			printf("\t-pc\t\tpreserve comments\n");
			printf("\t-pi\t\tpreserve indentation\n");
			printf("\t-s\t\tno output -- exit status only\n");
			printf("\t-sc c\t\tset key separator character\n");
			printf("\t-sepkey key\tset separator key\n");
			printf("\t-ts\t\tforce tab separator (implies -pi)\n");
			printf("\t-v\t\tinvert; print records not matching\n");
			printf("\t-version\tprint %s version number\n",
								progname);
			printf("\t-ws\t\tforce whitespace separator\n");
			printf("\t-x\t\texact matches (no RE)\n");
			printf("\t-?, -help\tprint this message\n");

			printedhelp = TRUE;
			break;

		    case 'c':
			if(*(p+1) == 'c')
				{
				commentchar = mapchar(nxtarg(argd));
				p++;
				break;
				}
			else if(*(p+1) == 's')
				{
				dbfmoreflags |= DB_KEYCHAR;
				p++;
				break;
				}
			else if(Streq(p, "contin"))
				{
				dbfmoreflags |= DB_CONTIN;
				p = "x";	/* short circuit */
				break;
				}
			else if(Streq(p, "count"))
				p = "x";	/* short circuit */

			countflag = TRUE;
			alwaysprint = FALSE;

			break;

		    case 'f':
			{
			char *fname;
			FILE *fd;

			fname = nxtarg(argd);

			/* allow "-" for stdin? */

			fd = fopen(fname, "r");
			if(fd == NULL)
				{
				fprintf(stderr, "%s: can't open %s: ",
							progname, fname);
				perror("");
				exit(2);
				}

			pushargd(argd, mkfiled(fd));

			/* closed when popped */

			break;
			}

		    case 'h':
			if(*(p+1) == 'c')
				{
				dbfmoreflags |= DB_CONTIN;
				p++;
				break;
				}

			/* FALLTHROUGH */

		    case 'H':
			if(stricmp(p, "help") == 0)
				p = "x";	/* short circuit */

			goto printhelp;
#endif /* MAILFILT */
		    case 'i':
#ifndef MAILFILT
			if(Streq(p, "ifmt"))
				{
				ifmt = mapffmt(nxtarg(argd));	/* XXX not much error checking */
				p = "x";	/* short circuit */
				break;
				}
#endif
			foldcase = TRUE;
			break;
#ifndef MAILFILT
		    case 'k':
			if(*(p+1) == 'i')
				{
				keyfoldcase = TRUE;
				p++;
				break;
				}
			goto badopt;
#endif
		    case 'm':
#ifndef MAILFILT
			if(Streq(p, "mail"))
				{
				mailflag = TRUE;
				p = "x";	/* short circuit */
				break;
				}
			else if(Streq(p, "mailh"))
				{
				mailflag = TRUE;
				mailsepkey = nxtarg(argd);
				p = "x";	/* short circuit */
				break;
				}
			else if(Streq(p, "mof"))
				{
				outfile = nxtarg(argd);
				/* check outfile for %d? */
				multout = TRUE;
				p = "x";	/* short circuit */
				break;
				}
			else if(Streq(p, "mofk") || Streq(p, "mofka"))
				{
				outfile = nxtarg(argd);
				/* check outfile for %s? */
				ofkey = nxtarg(argd);
				multout = TRUE;
				if(Streq(p, "mofka"))
					multappend = TRUE;
				p = "x";	/* short circuit */
				break;
				}
#endif
			matchflag = TRUE;
			break;
#ifndef MAILFILT
		    case 'o':
			if(Streq(p, "of"))
				{
				outfile = nxtarg(argd);
				p = "x";	/* short circuit */
				break;
				}
			else if(Streq(p, "ofmt"))
				{
				ofmt = mapffmt(nxtarg(argd));	/* XXX not much error checking */
				p = "x";	/* short circuit */
				break;
				}

			goto badopt;

		    case 'p':
			if(*(p+1) == 'c')
				{
				prsrvcomments = TRUE;
				p++;
				break;
				}
			else if(*(p+1) == 'i')
				{
				prsrvindent = TRUE;
				p++;
				break;
				}

			goto badopt;

		    case 's':
			if(*(p+1) == 'c')
				{
				keysepchar = mapchar(nxtarg(argd));
				dbfmoreflags |= DB_KEYCHAR;
				p++;
				break;
				}
			else if(*(p+1) == 'k')
				goto badopt;	/* actually, goodopt; -sk or variant */
			else if(Streq(p, "setkey"))
				goto badopt;	/* ditto */
			else if(Streq(p, "sepkey"))
				{
				sepkey = strsave(nxtarg(argd));
				p = "x";	/* short circuit */
				break;
				}
			alwaysprint = FALSE;
			break;

		    case 't':
			if(*(p+1) == 's')
				{
				keysepchar = '\t';
				dbfmoreflags |= DB_KEYCHAR;
				prsrvindent = TRUE;
				p++;
				break;
				}

			goto badopt;
#endif
		    case 'v':
#ifndef MAILFILT
			if(strcmp(p, "version") == 0)
				{
printversion:			fprintf(stderr, "%s version %s",
						progname, DBGREPVERSION);
#ifdef EXPR
				fprintf(stderr, " (with secondary expression support)");
#ifdef EXPRCOMPILE
				fprintf(stderr, "\n");
				fprintf(stderr, "%s", exprversion());
#endif
#endif
				fprintf(stderr, "\n");
				p = "x";	/* short circuit */
				printedhelp = TRUE;
				break;
				}
#endif
			invertflag = TRUE;
			break;
#ifndef MAILFILT
		    case 'w':
			if(*(p+1) == 's')
				{
				dbfmoreflags |= DB_KEYBLANK;
				p++;
				break;
				}

			goto badopt;
#endif
		    case 'x':
			exactflag = TRUE;
			break;
#ifndef MAILFILT
		    case '-':
			/* --help, --version */
			if(stricmp(p, "-help") == 0)
				{
				p = "x";    /* short circuit */
				goto printhelp;
				}
			if(strcmp(p, "-version") == 0)
				{
				p = "x";    /* short circuit */
				goto printversion;
				}

			goto badopt;
#endif
		    default:
badopt:			if(firstchar)
				{
				/* no err yet -- it might be a predicate */
				return arg;
				}

			fprintf(stderr, "%s: unknown option -%c\n",
							progname, *p);
		    }

		firstchar = FALSE;
		}
	}

return NULL;
}

mapchar(charstr)
char *charstr;
{
if(Streq(charstr, "none"))
	return EOF;
else if(strlen(charstr) == 1)
	return *charstr;
else if(isdigit(*charstr) || *charstr == '-' && isdigit(charstr[1]))
	return atoi(charstr);
else	{
	fprintf(stderr, "%s: bad character string \"%s\"\n", progname, charstr);
	return *charstr;	/* XXX */
	}
}

mapffmt(fmt)
char *fmt;
{
if(Streq(fmt, "dbf"))
	return DBF_DBF;
else if(Streq(fmt, "ts") || Streq(fmt, "tab") || Streq(fmt, "tabsep"))
	return DBF_TABSEP;
else if(Streq(fmt, "csv"))
	return DBF_CSV;
else if(Streq(fmt, "sql"))
	return DBF_SQLDUMP;
#ifdef HL7
else if(Streq(fmt, "hl7") || Streq(fmt, "HL7"))
	return DBF_HL7;
#endif
else	{
	fprintf(stderr, "%s: unknown format \"%s\"\n", progname, fmt);
	return 0;	/* XXX */
	}
}

struct eval *
makebool(lhs, op, rhs)
struct eval *lhs;
int op;
struct eval *rhs;
{
struct evalbool *ret;

ret = Salloc(struct evalbool);

ret->e_type = op;
ret->e_left = lhs;
ret->e_right = rhs;

return (struct eval *)ret;
}

#ifdef POSIXREGEXP
#include <regex.h>
#else
#ifdef HSREGEXP
#include <regexp.h>
#else
 #error No regexp library specified.
#endif
#endif

#define TMPBUF 500

#ifndef POSIXREGEXP
char *foldre();
#endif

extern int stricmp();

struct eval *
makepat(key, pat, flags)
char *key, *pat;
int flags;
{
struct evalpat *ret;
char tmpbuf[TMPBUF];

ret = Salloc(struct evalpat);
ret->e_type = PAT;
ret->e_flags = flags;
ret->e_kn = 0;

if((flags & KEYMASK) == KEYEXACT)
	ret->e_key = strsave(key);
else if((flags & KEYMASK) == KEYRE)
	{
#ifdef POSIXREGEXP
	if(regcomp(&ret->e_keyre, key,
			REG_NOSUB | (keyfoldcase ? REG_ICASE : 0)) != 0)
#else
#ifdef HSREGEXP
	if(keyfoldcase)
		key = foldre(key, tmpbuf, TMPBUF);

	if((ret->e_keyre = regcomp(key)) == NULL)
#else
#endif
#endif
		{
		fprintf(stderr, "%s: regexp parse error (key)\n", progname);
		exit(1);
		}
	}

if((flags & PATMASK) == PATEXACT || (flags & PATMASK) == PATMATCH)
	{
	ret->e_pat = strsave(pat);
	if((flags & PATMASK) == PATEXACT)
		ret->e_matchfunc = foldcase ? stricmp : strcmp;
	else	ret->e_matchfunc = foldcase ? strimatch : strmatch;
	}
else if((flags & PATMASK) == PATRE)
	{
#ifdef POSIXREGEXP
	if(regcomp(&ret->e_patre, pat,
			REG_NOSUB | (foldcase ? REG_ICASE : 0)) != 0)
#else
#ifdef HSREGEXP
	if(foldcase)
		pat = foldre(pat, tmpbuf, TMPBUF);

	if((ret->e_patre = regcomp(pat)) == NULL)
#else
#endif
#endif
		{
		fprintf(stderr, "%s: regexp parse error (pat)\n", progname);
		exit(1);
		}
	}

return (struct eval *)ret;
}

#ifndef POSIXREGEXP

char *
foldre(pat, buf, buflen)
char *pat;
char *buf;
int buflen;
{
char *sp, *dp;

if(strlen(pat) * 4 >= buflen)
	{
	fprintf(stderr, "%s: warning: pattern \"%s\" too long to fold case\n",
							progname, pat);
	return pat;
	}

sp = pat;
dp = buf;

do	{
	/* hmm... what if []'s already in pat? */

	if(!isalpha(*sp))
		*dp++ = *sp;
	else	{
		*dp++ = '[';
		*dp++ = *sp;
		if(isupper(*sp))
			*dp++ = tolower(*sp);
		if(islower(*sp))
			*dp++ = toupper(*sp);
		*dp++ = ']';
		}

	} while(*sp++ != '\0');

return buf;
}

#endif

struct kactx
	{
	char *thing1;
	char **things;
	int nthings;
	int nathings;
	};

static addkathing();
static int kafunc2();

static int
kafunc(opt, argd, epp)
char *opt;
struct argd *argd;
struct eval **epp;
{
struct evalother *ep = Salloc(struct evalother);
struct kactx *kactxp = Salloc(struct kactx);

kactxp->things = NULL;
kactxp->nthings = kactxp->nathings = 0;

if(eoargs(argd))
	{
	fprintf(stderr, "%s: missing keys after %s\n", progname, opt);
	return FALSE;
	}

/* read keys from cmd line */

while(!eoargs(argd))
	{
	char *p = nxtarg(argd);
	if(p[0] == ';' && p[1] == '\0')
		break;
	addkathing(kactxp, p);
	}

/* could complain if missing ; , but it's not worth it */

if(kactxp->nthings < 2)
	{
	fprintf(stderr, "%s: missing keys or pat after %s\n", progname, opt);
	return FALSE;
	}

kactxp->thing1 = kactxp->things[--kactxp->nthings];

ep->e_type = SPECIAL;
ep->e_flags = 0;
ep->e_func = kafunc2;
ep->e_context = (char *)kactxp;

*epp = (struct eval *)ep;

return TRUE;
}

static
addkathing(kactxp, thing)
struct kactx *kactxp;
char *thing;
{
if(kactxp->nthings >= kactxp->nathings)
	{
	kactxp->nathings += 10;			/* XXX */
	kactxp->things = Srealloc(char *, kactxp->things, kactxp->nathings);
	}

kactxp->things[kactxp->nthings++] = strsave(thing);
}

/* by rights, kafunc2 should be in dbgreval.c, but then I'd have to make struct kactx global... */

static int
kafunc2(dbd, dbnp, ctxp)
register dbdesc dbd;
register dbnode dbnp;
char *ctxp;
{
struct kactx *kactxp = (struct kactx *)ctxp;
struct evalpat tmpnode;
int i;

tmpnode.e_type = PAT;
tmpnode.e_flags = KEYEXACT | PATMATCH;	/* XXX for now */
tmpnode.e_pat = kactxp->thing1;
tmpnode.e_matchfunc = strmatch;		/* XXX for now */

for(i = 0; i < kactxp->nthings; i++)
	{
	tmpnode.e_key= kactxp->things[i];

	if(eval(dbd, dbnp, &tmpnode))
		return TRUE;
	}

return FALSE;
}

static int kxafnc2();
static int pstrcmp();

#define MAXLINE 500

static int
kxafunc(opt, argd, epp)
char *opt;
struct argd *argd;
struct eval **epp;
{
struct evalother *ep = Salloc(struct evalother);
struct kactx *kactxp = Salloc(struct kactx);

kactxp->things = NULL;
kactxp->nthings = kactxp->nathings = 0;

if(eoargs(argd))
	{
	fprintf(stderr, "%s: missing key after %s\n", progname, opt);
	return FALSE;
	}

kactxp->thing1 = strsave(nxtarg(argd));

if(strstr(opt, "af") == NULL)
	{
	/* read pats from cmd line */

	while(!eoargs(argd))
		{
		char *p = nxtarg(argd);
		if(p[0] == ';' && p[1] == '\0')
			break;
		addkathing(kactxp, p);
		}

	/* could complain if missing ; , but it's not worth it */
	/* complain if 0 patterns? */
	}
else	{
	/* read pats from file */

	char *f;
	FILE *fp;
	char line[MAXLINE];

	if(eoargs(argd))
		{
		fprintf(stderr, "%s: missing filename after %s\n", progname, opt);
		return FALSE;
		}

	f = nxtarg(argd);

	if((fp = fopen(f, "r")) == NULL)
		{
		fprintf(stderr, "%s: can't open %s\n", progname, f);
		return FALSE;
		}

	while(getline(fp, line, MAXLINE) != EOF)
		addkathing(kactxp, line);

	(void)fclose(fp);
	}
	
qsort(kactxp->things, kactxp->nthings, sizeof(char *), pstrcmp);

ep->e_type = SPECIAL;
ep->e_flags = 0;
ep->e_func = kxafnc2;
ep->e_context = (char *)kactxp;

*epp = (struct eval *)ep;

return TRUE;
}

/* by rights, kxafnc2 should be in dbgreval.c, but then I'd have to make struct kactx global... */

static int
kxafnc2(dbd, dbnp, ctxp)
register dbdesc dbd;
register dbnode dbnp;
char *ctxp;
{
struct kactx *kactxp = (struct kactx *)ctxp;
char *v;

while((v = db_listvalues(dbd, dbnp, kactxp->thing1)) != NULL)
	{
#ifndef MAILFILT	/* mailfilt has no prsrvindent flag */
	if(prsrvindent)	/* XXX probably a kludge, though other "exact" */
		{		/* matches could arguably also do */
		while(isspace(*v))
			v++;
		}
#endif

	if(bsearch(&v, kactxp->things, kactxp->nthings, sizeof(char *), pstrcmp) != NULL)
		{
		db_lvfinish(dbd);
		return TRUE;
		}
	}

return FALSE;
}

static int
pstrcmp(p1, p2)
const void *p1, *p2;
{
const char *s1 = *(char * const *)p1;
const char *s2 = *(char * const *)p2;
if(*s1 != *s2)
	return *s1 - *s2;
return strcmp(s1, s2);
}

/* wrappers around strstr that have retvals compatible with strcmp */
/* (not sure where they should go, though) */

strmatch(str, pat)
char *str;
char *pat;
{
return strstr(str, pat) == NULL ? 1 : 0;    /* yes, the ? 1 : 0 is redundant */
}

extern char *stristr();

strimatch(str, pat)
char *str;
char *pat;
{
return stristr(str, pat) == NULL ? 1 : 0;   /* ditto */
}

#ifndef MAILFILT
#ifdef REPGEN

repgenxop(dbd, dbnp, ctxp)
register dbdesc dbd;
register dbnode dbnp;
char *ctxp;
{
static int firsttime = TRUE;
if(firsttime)
	{
	/* XXX wrong place/time for this warning */
	fprintf(stderr, "%s: warning: -rg is obsolete; use -rgf\n", progname);
	firsttime = FALSE;
	}
repgenfop(dbd, dbnp, ctxp);
}

#endif
#endif
