#define DEF_DB
#include "db.h"

/*
 *  somewhat preliminary implementation, because -- surprising as
 *  it may seem -- this package lasted for over 10 years without this,
 *  and at this late date I'm not sure what all this should/shouldn't do
 */

db_addnode(dbd, dbnp)
struct db *dbd;
struct dbnode *dbnp;
{
if(dbd->db_list == NULL)
	dbd->db_list = dbnp;

if(dbd->db_tail != NULL)
	dbd->db_tail->dbn_next = dbnp;

dbnp->dbn_next = NULL;
dbd->db_tail = dbnp;

/* XXX also gotta insert in indices, if applicable */

/* (if ever compiled without dbn_parent, do this all the time) */
if(dbnp->dbn_parent != dbd)
	{
	int i;
	for(i = 0; i < dbnp->dbn_nkeys; i++)
		{
		struct keyvalue *kvp = &dbnp->dbn_keys[i];
		if(kvp->kv_flags & KVF_INTERNAL)
			continue;
		kvp->kv_key = db_hashkey(dbd, kvp->kv_key, dbd->db_flags);
		}
	}

dbnp->dbn_flags |= DBN_DIRTY;	/* ? not sure this belongs here... */
}
