/*
 *  plaintext "database" library --
 *  list values (potentially several) stored under key in node
 *
 *  Copyright 1987-2002
 *  Steve Summit, scs@eskimo.com
 *  This code may be freely redistributed and used
 *  so long as the author's name and this notice remain intact,
 *  and any modifications are marked as such.
 */

#include <stdio.h>
#define DEF_DB
#include "db.h"
#include "defs.h"

extern char db_nolvikey;		/* just for unique address */

char *
db_listvalues(dbd, dbn, key)	/* need flags arg? */
struct db *dbd;
struct dbnode *dbn;
char *key;
{
int flags = dbd->db_flags;
char *ukey = db_hashkey(dbd, key, flags | DB_NOALLOC);

if(dbn->dbn_flags & (DBN_INDEXONLY | DBN_NOTEXT))
	db_regetent(dbd, dbn);

/* mebbe strcmp rather than ptr equality */

if(dbd->db_lviterkey != &db_nolvikey && ukey != dbd->db_lviterkey)
	{
	db_error(dbd, "error", "listvalues(%s): already active on \"%s\"",
			key, dbd->db_lviterkey);

	return NULL;	/* exit? */
	}

if(ukey == NULL && key != NULL)
	return NULL;

if(dbd->db_lviterkey == &db_nolvikey)
	{
	dbd->db_lviterkey = ukey;
	dbd->db_lvin = 0;
	}

while(dbd->db_lvin < dbn->dbn_nkeys)
	{
	if(Keyeq(dbn, dbn->dbn_keys[dbd->db_lvin].kv_key, ukey))
		return dbn->dbn_keys[dbd->db_lvin++].kv_value;

	dbd->db_lvin++;		/* repeated */
	}

dbd->db_lviterkey = &db_nolvikey;

return NULL;
}

db_lvfinish(dbd)	/* need dbn, key? */
struct db *dbd;
{
dbd->db_lviterkey = &db_nolvikey;
}
