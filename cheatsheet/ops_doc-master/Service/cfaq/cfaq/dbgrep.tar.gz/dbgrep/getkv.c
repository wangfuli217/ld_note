/*
 *  plaintext "database" library -- iterate over a node's keys and values
 *
 *  Copyright 1987-2002
 *  Steve Summit, scs@eskimo.com
 *  This code may be freely redistributed and used
 *  so long as the author's name and this notice remain intact,
 *  and any modifications are marked as such.
 */

#include <stdio.h>
#define DEF_DB
#include "db.h"
#include "defs.h"

struct keyvalue *
db_getkv(dbd, dbn)
struct db *dbd;
struct dbnode *dbn;
{
if(dbn->dbn_flags & (DBN_INDEXONLY | DBN_NOTEXT))
	db_regetent(dbd, dbn);

if(dbd->db_gkviterstate >= dbn->dbn_nkeys)
	{
	dbd->db_gkviterstate = 0;
	return NULL;
	}

return &dbn->dbn_keys[dbd->db_gkviterstate++];
}

db_gkvfinish(dbd, dbn)
struct db *dbd;
struct dbnode *dbn;
{
dbd->db_gkviterstate = 0;
}
