/*
 *  plaintext "database" library --
 *  checkpoint a node so that changes can be rolled back
 *
 *  Copyright 1998-2002
 *  Steve Summit, scs@eskimo.com
 *  This code may be freely redistributed and used
 *  so long as the author's name and this notice remain intact,
 *  and any modifications are marked as such.
 */

#include <stddef.h>
#include <assert.h>
#define DEF_DB
#include "db.h"
#include "alloc.h"

#ifdef CHECKPOINT

#ifdef NTALLOC

/*
 *  In the NTALLOC case, the checkpointed pointers *are* aliases,
 *  and there's no attempt to clean up afterwards, either after
 *  commit or rollback.  The assumption is that the number of
 *  changes will be small relative to the total node value text;
 *  at any rate, selective free is always impossible under NTALLOC --
 *  we're willing to accept a certain amount of wasted space.
 */

#endif

extern char *strsave();

void
db_ncheckpoint(dbd, dbnp)
struct db *dbd;
struct dbnode *dbnp;
{
int i;

if(dbnp->dbn_chkp_keys != NULL)
	panic("db_ncheckpoint: already checkpointed");

dbnp->dbn_chkp_flags = dbnp->dbn_flags;
dbnp->dbn_chkp_keys = SNalloc(struct keyvalue, dbnp->dbn_nkeys);
dbnp->dbn_chkp_nkeys = dbnp->dbn_nkeys;
for(i = 0; i < dbnp->dbn_nkeys; i++)
	{
	struct keyvalue *kvp = &dbnp->dbn_keys[i];
	dbnp->dbn_chkp_keys[i] = *kvp;
#ifndef NTALLOC
	/* awkward to have to copy the pointers */
	/* would be nice to alias, but too hard to clean up after... */
	if((kvp->kv_flags & (KVF_POINTER | KVF_MALLOCED)) == (KVF_POINTER | KVF_MALLOCED) &&
						kvp->kv_valptr != NULL)
		{
		assert((kvp->kv_flags & KVF_TYPEMASK) == KVF_STRING);
		dbnp->dbn_chkp_keys[i].kv_valptr = strsave(kvp->kv_valptr);
		}
#endif
	}
}

void
db_ncommit(dbd, dbnp)
struct db *dbd;
struct dbnode *dbnp;
{
#ifdef DEBUG2
fprintf(stderr, "*** db_ncommit ***\n");
#endif

if(dbnp->dbn_chkp_keys == NULL)
	panic("db_ncommit: not checkpointed");

#ifndef NTALLOC
db_kvfree(dbnp->dbn_chkp_keys, dbnp->dbn_chkp_nkeys);
#endif
free(dbnp->dbn_chkp_keys);

dbnp->dbn_chkp_flags = 0;
dbnp->dbn_chkp_keys = NULL;
dbnp->dbn_chkp_nkeys = 0;
}

void
db_nrollback(dbd, dbnp)
struct db *dbd;
struct dbnode *dbnp;
{
#ifdef DEBUG2
fprintf(stderr, "*** db_nrollback ***\n");
#endif

if(dbnp->dbn_chkp_keys == NULL)
	panic("db_nrollback: not checkpointed");

#ifndef NTALLOC
db_kvfree(dbnp->dbn_keys, dbnp->dbn_nkeys);
#endif
free(dbnp->dbn_keys);

dbnp->dbn_flags = dbnp->dbn_chkp_flags;
dbnp->dbn_keys = dbnp->dbn_chkp_keys;
dbnp->dbn_nkeys = dbnp->dbn_chkp_nkeys;

dbnp->dbn_chkp_flags = 0;
dbnp->dbn_chkp_keys = NULL;
dbnp->dbn_chkp_nkeys = 0;
}

#endif
