#include <stdio.h>
#include <stdlib.h>
#ifdef VARARGS
#include <varargs.h>
#else
#include <stdarg.h>
#endif
#ifdef __STDC__
#include "error.h"
#endif

extern char *progname;

void
#ifdef __STDC__
panic(char *msg, ...)
#else
#ifndef VARARGS
panic(msg)
char *msg;
#else
panic(va_alist)
va_dcl
#endif
#endif
{
va_list argp;
#ifdef VARARGS
char *msg;
va_start(argp);
msg = va_arg(argp, char *);
#else
va_start(argp, msg);
#endif
if(progname != NULL)
	fprintf(stderr, "%s: ", progname);
fprintf(stderr, "panic: ");
vfprintf(stderr, msg, argp);
fprintf(stderr, "\n");
va_end(argp);
exit(1);
}
