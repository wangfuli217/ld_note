/*
 *  dbgrep secondary expression support
 *
 *  Copyright 1992-2002
 *  Steve Summit, scs@eskimo.com
 *  This code may be freely redistributed and used
 *  so long as the author's name and this notice remain intact,
 *  and any modifications are marked as such.
 */

#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <db.h>
#include "dbgrep.h"
#include "defs.h"

#ifdef EXPRCOMPILE
#include "expr.h"
#endif

#ifndef EXPRCOMPILE

static dbdesc gdbd;
static dbnode gdbnp;

#endif

#ifdef EXPRCOMPILE

/* hopefully temporary */

#ifndef POLYTYPE
datatype consts[MAXCONSTS] = {0., 1., 2.};
int nconsts = 3;
#else
datatype consts[MAXCONSTS];
int nconsts;
#endif

char *vars[26];
datatype vals[26];
int nvars = 0;
int basenvars = 0;

extern int nfound;

struct code *setupexpr();
extern struct code *codealloc();

#ifdef POLYTYPE
extern struct object *makeobj();
extern struct object *makeiobj();
extern struct object *doeval();
#else
extern double deval();
#endif

#endif

extern char *progname;

exprop(dbd, dbnp, ctxp)
register dbdesc dbd;
register dbnode dbnp;
char *ctxp;
{
return doexpr(dbd, dbnp, ctxp, 0);
}

/* would rather not have two of these, but no way to pass in differentiator... */

exprpop(dbd, dbnp, ctxp)
register dbdesc dbd;
register dbnode dbnp;
char *ctxp;
{
return doexpr(dbd, dbnp, ctxp, 1);
}

#ifndef EXPRCOMPILE
static e0();
#endif

doexpr(dbd, dbnp, ctxp, printflag)
register dbdesc dbd;
register dbnode dbnp;
char *ctxp;
int printflag;
{
int r;
#ifdef EXPRCOMPILE
char *p;
int i;
static char *statice = NULL;
static struct code *staticc;
#ifdef POLYTYPE
struct object *o;
#endif
#endif

#ifndef EXPRCOMPILE

/* gunky global dbd and dbnp, bcuz I don't feel like passing 'em down */

gdbd = dbd;
gdbnp = dbnp;

r = e0(&ctxp);

if(printflag)
	{
	printf("%d\n", r);
	r = 1;
	}

#else

if(statice != ctxp)
	{
	if(statice != NULL)
		{
		fprintf(stderr, "only one expression at the moment\n");
		exit(1);
		}

	/* XXX ought to do this at dbgrparse time */

	staticc = setupexpr(ctxp);
	}

setup2expr(dbd, dbnp, 0);

#ifndef POLYTYPE

r = deval(staticc->c_base);

if(printflag)
	{
	printf("%d\n", r);
	r = 1;
	}

#else

o = doeval(staticc->c_base);

if(printflag)
	{
	printval(o, stdout);
	printf("\n");
	r = 1;
	}
else	{
	r = objtoint(o);
	}

cleanupexpr();

#endif

#endif

return r;
}

#ifndef EXPRCOMPILE

/* based, of all things, on i.c, that obfuscated expression evaluator of mine from 1988 */

static e1();
static e2();
static e3();
static w();
static q();

static
e0(s)
char **s;
{
int c, c2;
int r = e1(s);

w(s);

c = *(*s)++;
c2 = **s;

switch(c)
	{
	case '<':
		if(c2 != '=')
			return r < e1(s);
		else	{
			(*s)++;
			return r <= e1(s);
			}

	case '=':
		if(c2 == '=')
			(*s)++;
		return r == e1(s);

	case '>':
		if(c2 != '=')
			return r > e1(s);
		else	{
			(*s)++;
			return r >= e1(s);
			}

	case '!':
		if(c2 != '=')
			{
			/* what to do? */
			(*s)--;
			return r;
			}

		(*s)++;
		return r != e1(s);

	default:
		(*s)--;
		return r;
	}
}

static
e1(s)
char **s;
{
int r = e2(s);

while(TRUE)
	{
	w(s);
	switch(*(*s)++)
		{
		case '+':
			r += e2(s);
			break;

		case '-':
			r -= e2(s);
			break;

		default:
			(*s)--;
			return r;
		}
	}
}

static
e2(s)
char **s;
{
int r = e3(s);

while(TRUE)
	{
	w(s);
	switch(*(*s)++)
		{
		case '*':
			r *= e3(s);
			break;

		case '/':
			r /= e3(s);
			break;

		default:
			(*s)--;
			return r;
		}
	}
}

static
e3(s)
char **s;
{
int c;

w(s);

c = *(*s)++;

if(isdigit(c))
	{
	c -= '0';
	while(isdigit(**s))
		c = 10*c + *(*s)++ - '0';
	return c;
	}
if(isalpha(c))
	{
	char *p;
	char keybuf[30];

	p = keybuf;
	*p++ = c;
	while(isalnum(**s))
		*p++ = *(*s)++;
	*p = '\0';

	p = db_getvalue(gdbd, gdbnp, keybuf, DB_CHECKRET);

	if(p == NULL)
		return 0;
	else	return atoi(p);
	}
else if(c == '-')
	return -e3(s);
else if(c == '(')
	{
	int r = e1(s);
	if(*(*s)++ != ')')
		{
		q();
		(*s)--;
		}
	return r;
	}
else	{
	q();
	return 0;
	}
}

static
w(s)
char **s;
{
while(**s == ' ' || **s == '\t' || **s == '\n')
	(*s)++;
}

static
q()
{
fprintf(stderr, "%s: expression syntax error\n", progname);
}

#endif

#ifdef EXPRCOMPILE

/* XXX should probably be varargs */

void
error(s)
char *s;
{
fprintf(stderr, "%s: expression error: %s\n", progname, s);
}

struct code *
setupexpr(expr, fmtp)
char *expr;
char **fmtp;
{
struct code *codep;
char *p;
int r;

#ifdef POLYTYPE

static int firsttime = TRUE;

if(firsttime)
	{
	consts[1] = makeobj("1");
	consts[2] = makeobj("2");
	nconsts = 3;
	firsttime = FALSE;
	}

#endif

if(fmtp != NULL)
	*fmtp = NULL;

codep = codealloc(0);

r = getexpr(expr, &p, codep);

if(r == OK && *p == ',' && fmtp != NULL)
	{
	/* XXX this is an odd place to be doing this */
	*fmtp = p + 1;
	p = "";
	}

if(r != OK || *p != '\0')
	{
	fprintf(stderr, "%s: expression parse error\n", progname);
	exit(1);
	}

emit('\0', codep);

#ifdef notyet
if(codep->c_nsubsid > 0)
	tallies = TRUE;
#endif

return codep;
}

extern struct keyvalue *db_gtkv2();	/* should this be public, or should we not be using it? */

setup2expr(dbd, dbnp, kvi)
dbdesc dbd;
dbnode dbnp;
int kvi;
{
char *p;
int i;

for(i = basenvars; i < nvars; i++)
	{
	if(kvi == 0)
		p = db_getvalue(dbd, dbnp, vars[i], DB_CHECKRET);
	else	{
		struct keyvalue *kvp = db_gtkv2(dbd, dbnp, vars[i], DB_CHECKRET, kvi);
		p = kvp ? kvp->kv_value : NULL;
		}

	if(p != NULL)
		{
		if(*p == '$' && isdigit(p[1]))	/* a bit of a kludge, or maybe DWIM */
			p++;
#ifndef POLYTYPE
		vals[i] = atof(p);
#else
		vals[i] = makeobj(p);
#endif
		}
	else if(strcmp(vars[i], "n") == 0)
		{
#ifndef POLYTYPE
		vals[i] = nfound + 1;
#else
		vals[i] = makeiobj(nfound + 1);
#endif
		}
	else	{
		vals[i] = 0;
		}
	}
}

cleanupexpr()
{
#ifdef POLYTYPE
int i;
for(i = basenvars; i < nvars; i++)
	objfree(vals[i]);
#endif
}

freeexpr(codep)
struct code *codep;
{
#ifdef POLYTYPE
int i;
for(i = 3; i < nconsts; i++)
	objfree(consts[i]);
nconsts = 3;
#endif

if(codep == NULL)
	return;
if(codep->c_base != NULL)
	free(codep->c_base);
free(codep);
}

#endif
