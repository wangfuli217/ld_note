/*
 *  dbgrep main expression evaluator
 *
 *  Copyright 1992-2002
 *  Steve Summit, scs@eskimo.com
 *  This code may be freely redistributed and used
 *  so long as the author's name and this notice remain intact,
 *  and any modifications are marked as such.
 */

#include <stdio.h>
#include <string.h>
#include <assert.h>

#ifdef POSIXREGEXP
#include <regex.h>
#define REGEXEC(str, pat) (regexec(&pat, str, 0, NULL, 0) == 0)
#else
#ifdef HSREGEXP
#include <regexp.h>
#define REGEXEC(str, pat) regexec(pat, str)
#else
 #error No regexp library specified.
#endif
#endif

#define DEF_DB	/* for dbf_funcs->dbf_putent in putent and execop */
#include "db.h"

#include "dbgrep.h"
#include "argd.h"
#include "alloc.h"
#include "defs.h"

#ifdef SPECIALOPS
char *(*specialget)() = NULL;
int (*specialset)() = NULL;
#endif

extern int multout;

extern char *strsave();

extern char *progname;

eval(dbd, dbnp, ep)
register dbdesc dbd;
register dbnode dbnp;
struct eval *ep;
{
char *p;
struct keyvalue *kv;

#define EBP ((struct evalbool *)ep)
#define EPP ((struct evalpat *)ep)

switch(ep->e_type)
    {
    case AND:
	return eval(dbd, dbnp, EBP->e_left) && eval(dbd, dbnp, EBP->e_right);

    case OR:
	return eval(dbd, dbnp, EBP->e_left) || eval(dbd, dbnp, EBP->e_right);
	
    case NOT:
	return !eval(dbd, dbnp, EBP->e_left);

    case PAT:
	switch(EPP->e_flags)
	    {
	    case KEYANY | PATRE:		/* -e or default */
		while((kv = db_getkv(dbd, dbnp)) != NULL)
			{
			if(REGEXEC(kv->kv_value, EPP->e_patre))
				{
				db_gkvfinish(dbd, dbnp);
				return TRUE;
				}
			}

		return FALSE;

	    case KEYANY | PATMATCH:
	    case KEYANY | PATEXACT:
		while((kv = db_getkv(dbd, dbnp)) != NULL)
			{
			if((*EPP->e_matchfunc)(kv->kv_value, EPP->e_pat) == 0)
				{
				db_gkvfinish(dbd, dbnp);
				return TRUE;
				}
			}

		return FALSE;

	    case KEYEXACT | PATRE:		/* -k */
#ifdef SPECIALOPS
		if(specialget != NULL)
			{
			char *val = (*specialget)(dbd, dbnp, EPP->e_key);
			if(val == NULL)
				return FALSE;
			return REGEXEC(val, EPP->e_patre);
			}
#endif
		if(EPP->e_kn > 0)
			{			/* -kn */
			kv = db_gtkv2(dbd, dbnp, EPP->e_key, DB_CHECKRET,
								EPP->e_kn);
			if(kv == NULL)
				return FALSE;
			return REGEXEC(kv->kv_value, EPP->e_patre);
			}

		while((p = db_listvalues(dbd, dbnp, EPP->e_key)) != NULL)
			{
			if(REGEXEC(p, EPP->e_patre))
				{
				db_lvfinish(dbd);
				return TRUE;
				}
			}

		return FALSE;

	    case KEYEXACT | PATMATCH:		/* -km */
	    case KEYEXACT | PATEXACT:		/* -kx */
#ifdef SPECIALOPS
		if(specialget != NULL)
			{
			char *val = (*specialget)(dbd, dbnp, EPP->e_key);
			if(val == NULL)
				return FALSE;
			return (*EPP->e_matchfunc)(val, EPP->e_pat) == 0;
			}
#endif
		if(EPP->e_kn > 0)
			{
			kv = db_gtkv2(dbd, dbnp, EPP->e_key, DB_CHECKRET,
								EPP->e_kn);
			if(kv == NULL)
				return FALSE;
			return (*EPP->e_matchfunc)(kv->kv_value, EPP->e_pat) == 0;
			}

		while((p = db_listvalues(dbd, dbnp, EPP->e_key)) != NULL)
			{
			if((*EPP->e_matchfunc)(p, EPP->e_pat) == 0)
				{
				db_lvfinish(dbd);
				return TRUE;
				}
			}

		return FALSE;

	    case KEYRE | PATRE:			/* -kr */
		while((kv = db_getkv(dbd, dbnp)) != NULL)
			{
			if(kv->kv_key != NULL &&		/* ??? */
				REGEXEC(kv->kv_key, EPP->e_keyre) &&
					REGEXEC(kv->kv_value, EPP->e_patre))
				{
				db_gkvfinish(dbd, dbnp);
				return TRUE;
				}
			}

		return FALSE;

	    case KEYRE | PATMATCH:
	    case KEYRE | PATEXACT:
		while((kv = db_getkv(dbd, dbnp)) != NULL)
			{
			if(kv->kv_key != NULL &&		/* ??? */
			    REGEXEC(kv->kv_key, EPP->e_keyre) &&
			    (*EPP->e_matchfunc)(kv->kv_value, EPP->e_pat) == 0)
				{
				db_gkvfinish(dbd, dbnp);
				return TRUE;
				}
			}

		return FALSE;

	    case KEYEXACT | KEYEXISTS:		/* -ke */
		return db_haskey(dbd, dbnp, EPP->e_key);

	    case KEYRE | KEYEXISTS:		/* -ker, -kre */
		while((kv = db_getkv(dbd, dbnp)) != NULL)
			{
			if(kv->kv_key != NULL &&		/* ??? */
					REGEXEC(kv->kv_key, EPP->e_keyre))
				{
				db_gkvfinish(dbd, dbnp);
				return TRUE;
				}
			}

		return FALSE;
#ifndef NDEBUG
	    default:
	        fprintf(stderr, "%s: dbgreval: unhandled case 2 (%x)\n",
						       progname, EPP->e_flags);
#endif
	    }
	break;

    case SPECIAL:
	if(((struct evalother *)ep)->e_func == NULL)
		return TRUE;

	if(((struct evalother *)ep)->e_flags & SPECIALCALL)
		{
		struct specialctx sctx;
		sctx.sc_which = SC_EVAL;
		sctx.sc_ctxp = ((struct evalother *)ep)->e_context;
		sctx.sc_enode = (struct evalother *)ep;
		return (*((struct evalother *)ep)->e_func)(dbd, dbnp, (char *)&sctx);
		}

	return (*((struct evalother *)ep)->e_func)(dbd, dbnp,
					((struct evalother *)ep)->e_context);
#ifndef NDEBUG
    default:
        fprintf(stderr, "%s: dbgreval: unhandled case 1 (%d)\n",
						 progname, ep->e_type);
#endif
    }

/* NOTREACHED */

#ifndef NDEBUG
fprintf(stderr, "%s: dbgreval: can't happen\n", progname);
#endif
}

efinish(ep)
struct eval *ep;
{
switch(ep->e_type)
    {
    case AND:
    case OR:
	efinish(EBP->e_left);
	efinish(EBP->e_right);
	break;

    case NOT:
	efinish(EBP->e_left);
	break;

    case SPECIAL:
	if (((struct evalother *)ep)->e_func == NULL)
		break;

	if(((struct evalother *)ep)->e_flags & SPECIALCALL)
		{
		struct specialctx sctx;
		sctx.sc_which = SC_FINISH;
		sctx.sc_ctxp = ((struct evalother *)ep)->e_context;
		sctx.sc_enode = (struct evalother *)ep;
		return (*((struct evalother *)ep)->e_func)(
			(dbdesc)NULL, (dbnode)NULL, (char *)&sctx);
		}
	break;
    }

/* NOTREACHED */
}

#ifndef MAILFILT

extern FILE *ofd;
extern struct dbfd *dbofd;

printop(dbd, dbnp, ctxp)
register dbdesc dbd;
register dbnode dbnp;
char *ctxp;
{
if(multout)
	checkofd(dbd, dbnp);
(*dbofd->dbf_funcs->dbf_putent)(dbofd, dbnp);
fflush(ofd);
return TRUE;
}

struct wropctx
	{
	char *fname;
	char *placeholder;	/* no 2nd str op, but why ask for trouble? */
	FILE *ofd;
	struct dbfd *dbofd;
	};

writeop(dbd, dbnp, ctxp)
register dbdesc dbd;
register dbnode dbnp;
char *ctxp;
{
struct wropctx *wctxp = (struct wropctx *)ctxp;	/* majorly gunky type pun */

if(wctxp->ofd == NULL)		/* XXX was initted to int 0, not NULL */
	{
	/* overlaps w/ checkofd() quite a bit */

	extern int ofmt;
	extern char **ocols;
	extern int nocols;

	wctxp->ofd = fopen(wctxp->fname, "w");
	if(wctxp->ofd == NULL)
		{
		fprintf(stderr, "%s: can't open %s: ", progname, wctxp->fname);
		perror("");
		exit(1);
		}

	wctxp->dbofd = db_fdopen(wctxp->ofd);

	setdbfmt(wctxp->dbofd, ofmt, ocols, nocols);
	}

(*wctxp->dbofd->dbf_funcs->dbf_putent)(wctxp->dbofd, dbnp);
fflush(wctxp->ofd);
return TRUE;
}

struct akctx	/* add key context structure */
	{
	char *ak_key;
	char *ak_val;
#ifdef EXPR
	struct code *ak_code;
#endif
	};

#define AK_ADD	1
#define AK_SET	2
#define AK_EXPR	4

addkeyop(dbd, dbnp, ctxp)
register dbdesc dbd;
register dbnode dbnp;
char *ctxp;
{
return doaddkeyop(dbd, dbnp, ctxp, AK_ADD);
}

#ifdef EXPR
#ifdef EXPRCOMPILE
#include "expr.h"
extern struct code *setupexpr();
#ifdef POLYTYPE
extern struct object *doeval();
#else
extern double deval();
#endif
#endif
#endif

doaddkeyop(dbd, dbnp, ctxp, flags)
register dbdesc dbd;
register dbnode dbnp;
char *ctxp;
int flags;
{
struct specialctx *sctxp = (struct specialctx *)ctxp;
struct akctx *akctxp;
char *newval;

if(sctxp->sc_which == SC_INIT)
	{
	akctxp = Salloc(struct akctx);
	akctxp->ak_key = strsave(nxtarg(sctxp->sc_argd));
#ifdef EXPR
#ifdef EXPRCOMPILE
	if(flags & AK_EXPR)
		akctxp->ak_code = setupexpr(nxtarg(sctxp->sc_argd), (char **)NULL);
	else
#else
	/* XXX no non-compiled set-to-expr yet */
#endif
#endif
		akctxp->ak_val = strsave(nxtarg(sctxp->sc_argd));
	sctxp->sc_ctxp = (char *)akctxp;
	return;
	}

if(sctxp->sc_which != SC_EVAL)
	return;

akctxp = (struct akctx *)sctxp->sc_ctxp;

#ifdef EXPR
#ifdef EXPRCOMPILE
if(flags & AK_EXPR)
	{
	static char fmtbuf[50];
#ifndef POLYTYPE
	double r;
#else
	struct object *o;
#endif
	setup2expr(dbd, dbnp, 0);
#ifndef POLYTYPE
	r = deval(akctxp->ak_code->c_base);
	sprintf(fmtbuf, "%g", r);
#else
	/* XXX should probably use doexpr() ... */
	o = doeval(akctxp->ak_code->c_base);
	fmtval(o, fmtbuf, (int)sizeof(fmtbuf));
#endif
	newval = fmtbuf;
	cleanupexpr();
	}
else
#else
	/* XXX no non-compiled set-to-expr yet */
#endif
#endif
	newval = akctxp->ak_val;

#ifdef SPECIALOPS

if(specialset != NULL)
	{
	(*specialset)(dbd, dbnp, akctxp->ak_key, newval);
	return TRUE;
	}

#endif

if(flags & AK_SET)
	{
	if(db_changeval(dbd, dbnp, akctxp->ak_key, newval, DB_CHECKRET))
		return TRUE;
	}

if(flags & AK_ADD)
	{
	/* XXX kludge: look at first key to decide whether to use colon or not */
	/* (ideally, intuition in db_fgetent would set dbf flag) */
	int kvflags = 0;
	struct keyvalue *kv = db_getikv(dbd, dbnp, 1);
	if(kv != NULL)
		kvflags |= kv->kv_flags & KVF_COLONNAME;

#define MULTILINEKLUDGE
#ifdef MULTILINEKLUDGE
	if(strchr(newval, '\n') != NULL)
		{
		char *p;
		for(p = newval; p != NULL && *p != '\0'; )
			{
			char *p2 = strchr(p, '\n');
			if(p2 != NULL)
				*p2 = '\0';
			db_addfkey(dbd, dbnp, akctxp->ak_key, p, kvflags, 0);
			if(p2 != NULL)
				{
				*p2 = '\n';
				p=p2 + 1;
				}
			else	p = NULL;
			}
		}
	else
#endif
	db_addfkey(dbd, dbnp, akctxp->ak_key, newval, kvflags, 0);
	}

return TRUE;
}

#ifdef EXPR

addkeyeop(dbd, dbnp, ctxp)
register dbdesc dbd;
register dbnode dbnp;
char *ctxp;
{
return doaddkeyop(dbd, dbnp, ctxp, AK_ADD | AK_EXPR);
}

#endif

delkeyop(dbd, dbnp, ctxp)
register dbdesc dbd;
register dbnode dbnp;
char *ctxp;
{
char *fieldname = ctxp;

db_delkey(dbd, dbnp, fieldname, DB_MULTIPLE | DB_NONEOK);

return TRUE;
}

setkeyop(dbd, dbnp, ctxp)
register dbdesc dbd;
register dbnode dbnp;
char *ctxp;
{
return doaddkeyop(dbd, dbnp, ctxp, AK_SET);
}

setkeyaop(dbd, dbnp, ctxp)
register dbdesc dbd;
register dbnode dbnp;
char *ctxp;
{
return doaddkeyop(dbd, dbnp, ctxp, AK_SET | AK_ADD);
}

#ifdef EXPR
#ifdef EXPRCOMPILE /* XXX no non-compiled set-to-expr yet */

setkeyeop(dbd, dbnp, ctxp)
register dbdesc dbd;
register dbnode dbnp;
char *ctxp;
{
return doaddkeyop(dbd, dbnp, ctxp, AK_SET | AK_EXPR);
}

#endif
#endif

prkeyop(dbd, dbnp, ctxp)
register dbdesc dbd;
register dbnode dbnp;
char *ctxp;
{
return doprkeyop(dbd, dbnp, ctxp, 0);
}

prnkeyop(dbd, dbnp, ctxp)
dbdesc dbd;
dbnode dbnp;
char *ctxp;
{
char **args = (char **)ctxp;
return doprkeyop(dbd, dbnp, args[0], atoi(args[1]));
}

doprkeyop(dbd, dbnp, fieldname, kn)
dbdesc dbd;
dbnode dbnp;
char *fieldname;
int kn;
{
char *p;

if(multout)
	checkofd(dbd, dbnp);

/* print blank lines between output from different records? */

#ifdef SPECIALOPS
if(specialget != NULL)
	{
	p = (*specialget)(dbd, dbnp, fieldname);
	if(p != NULL)
		fprintf(ofd, "%s\n", p);
	}
else
#endif
if(kn > 0)
	{
	struct keyvalue *kv = db_gtkv2(dbd, dbnp, fieldname, DB_CHECKRET, kn);
	if(kv != NULL && kv->kv_value != NULL)
		fprintf(ofd, "%s\n", kv->kv_value);
	}
else	{
	/* XXX reindent */
while((p = db_listvalues(dbd, dbnp, fieldname)) != NULL)
	fprintf(ofd, "%s\n", p);
	}

/* need an option to print a blank line if no value */

return TRUE;
}

struct ekctx	/* extract key context structure */
	{
	int ek_nkeys;
	char **ek_keys;
	int ek_nakeys;
	};

extrkeyop(dbd, dbnp, ctxp)
register dbdesc dbd;
register dbnode dbnp;
char *ctxp;
{
char *p;
struct specialctx *sctxp = (struct specialctx *)ctxp;
static struct ekctx *ekctxp = NULL;
dbnode dbnp2;
int i;

if(sctxp->sc_which == SC_INIT)
	{
	/* initial arg parse */

	char *key = nxtarg(sctxp->sc_argd);

	addocol(key);

	/* this is kinda weird */
	/* (this coalescing into one node sorta thing) */
	if(ekctxp != NULL)
		{
		if(ekctxp->ek_nkeys >= ekctxp->ek_nakeys)
			{
			ekctxp->ek_nakeys += 10;
			ekctxp->ek_keys = Srealloc(char *, ekctxp->ek_keys,
							ekctxp->ek_nakeys);
			}

		ekctxp->ek_keys[ekctxp->ek_nkeys++] = strsave(key);

		/* is this OK? */
		sctxp->sc_enode->e_func = NULL;
		return;
		}

	ekctxp = Salloc(struct ekctx);
	ekctxp->ek_nkeys = 0;
	ekctxp->ek_nakeys = 10;
	ekctxp->ek_keys = SNalloc(char *, ekctxp->ek_nakeys);
	ekctxp->ek_keys[ekctxp->ek_nkeys++] = strsave(key);
	sctxp->sc_ctxp = (char *)ekctxp;
	return;
	}

if(sctxp->sc_which != SC_EVAL)
	return;

/* ekctxp = (struct ekctx *)sctxp->sc_ctxp; */

assert(ekctxp != NULL);

if(multout)
	checkofd(dbd, dbnp);

dbnp2 = db_nalloc();
dbnp2->dbn_parent = dbd;	/* XXX who should do this? */

for(i = 0; i < ekctxp->ek_nkeys; i++)
	{
	char *key = ekctxp->ek_keys[i];
	while((p = db_listvalues(dbd, dbnp, key)) != NULL)
		{
		/* looks like DB_CHEATALLOC might be useful here, too */
		db_addkey(dbd, dbnp2, key, p, DB_BUILDING | DB_NOHISTORY);
		}
	}

(*dbofd->dbf_funcs->dbf_putent)(dbofd, dbnp2);

db_nfree(dbnp2);	/* what a waste... */

fflush(ofd);
return TRUE;
}

prshkeyop(dbd, dbnp, ctxp)
register dbdesc dbd;
register dbnode dbnp;
char *ctxp;
{
char *p;
char *fieldname = ctxp;

if(multout)
	checkofd(dbd, dbnp);

while((p = db_listvalues(dbd, dbnp, fieldname)) != NULL)
	{
	char *p2;

	if(strpbrk(fieldname, " \t.-") == NULL)
		fprintf(ofd, "%s=", fieldname);
	else	{
		for(p2 = fieldname; *p2 != '\0'; p2++)
			{
			switch(*p2)
				{
				case ' ':
				case '\t':
				case '.':
				case '-':
					putc('_', ofd);
					break;

				default:
					putc(*p2, ofd);
				}
			}

		putc('=', ofd);
		}

	if(strpbrk(p, " \t\"'\\$`<>|;()") == NULL)
		fprintf(ofd, "%s", p);
	else	{
		putc('"', ofd);

		for(p2 = p; *p2 != '\0'; p2++)
			{
			switch(*p2)
				{
				case '"':
				case '\\':
				case '$': case '`':
					putc('\\', ofd);
					/* FALL THROUGH */

				default:
					putc(*p2, ofd);
				}
			}

		putc('"', ofd);
		}

	fprintf(ofd, "\n");
	}

return TRUE;
}

#ifdef unix

extern FILE *popen();

execop(dbd, dbnp, ctxp)
dbdesc dbd;
dbnode dbnp;
char *ctxp;
{
FILE *ofp2;
struct dbfd *dbofd2;
extern int dbfflags;
extern int ofmt;

ofp2 = popen(ctxp, "w");

if(ofp2 == NULL)
	return FALSE;		/* ??? */

dbofd2 = db_fdopen(ofp2);

if(dbofd2 == NULL)
	{
	pclose(ofp2);
	return FALSE;		/* ??? */
	}

/* XXX gotta figure out a way to centralize this switch... */
switch(ofmt)
	{
	case DBF_DBF:
		db_f_dbf_set(dbofd2, dbfflags);
		break;

	case DBF_TABSEP:
		db_f_ts_set(dbofd2);
		break;

	/* XXX worry about default */
	}

(*dbofd->dbf_funcs->dbf_putent)(dbofd2, dbnp);

db_fdclose(dbofd2);
pclose(ofp2);

return TRUE;	/* or FALSE if command failed? */
}

#endif

#endif
