/*
 *  plaintext "database" library -- change a key's value
 *
 *  Copyright 1992-2002
 *  Steve Summit, scs@eskimo.com
 *  This code may be freely redistributed and used
 *  so long as the author's name and this notice remain intact,
 *  and any modifications are marked as such.
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define DEF_DB
#include "db.h"
#include "defs.h"

#ifdef VMLIMIT
#ifdef __STDC__
extern char *lmalloc(int);
#endif
extern char *lmalloc();
#else
#define lmalloc malloc
#endif

#ifdef NTALLOC
#ifdef __STDC__
extern char *db_ntalloc(struct dbnode *, int);
#endif
extern char *db_ntalloc();
#else
#define db_ntalloc(dbnp, n) lmalloc(n)
#endif

static char keynotfound[] = "db_changeval: key \"%s\" not found";

#ifdef __STDC__

static int dochangeval(struct db *, struct dbnode *, int, int, char *, struct dbnode *);

#endif

static int dochangeval();

db_changeval(dbd, dbn, key, newval, flags)
struct db *dbd;
struct dbnode *dbn;
char *key;
char *newval;
int flags;
{
return db_nchangeval(dbd, dbn, key, newval, flags, 0);
}

db_nchangeval(dbd, dbn, key, newval, flags, nk)
struct db *dbd;
struct dbnode *dbn;
char *key;
char *newval;
int flags;
int nk;
{
char *ukey;
register int i;
int foundi;
int nfound = 0;
int gotone = FALSE;
struct dbnode *histdbn = NULL;

if(dbn->dbn_flags & (DBN_INDEXONLY | DBN_NOTEXT))
	db_regetent(dbd, dbn);

flags |= dbd->db_flags;

#ifdef DBRCS

if((flags & DB_HISTORY) && !(flags & DB_NOHISTORY))
	{
	histdbn = db_gethistnode(dbd, dbn);
	if(histdbn == NULL)
		return FALSE;
	}

#endif

ukey = db_hashkey(dbd, key, flags | DB_NOALLOC);

if(ukey == NULL && key != NULL)
	{
	if(flags & DB_ADDOK)	/* XXX test duplicated below */
		return db_addkey(dbd, dbn, key, newval, flags);

	if(!(flags & DB_CHECKRET))
		{
		db_error(dbd, "fatal error", keynotfound, key);
		exit(1);
		}

	return FALSE;
	}

foundi = -1;

for(i = 0; i < dbn->dbn_nkeys; i++)
	{
	if(Keyeq(dbn, dbn->dbn_keys[i].kv_key, ukey))
		{
		nfound++;

		if((dbn->dbn_keys[i].kv_flags & KVF_DUPLICATE) && nk == 0)
			{
			db_error(dbd,
				 (flags&DB_CHECKRET) ? "error" : "fatal error",
				    "db_changeval: multiple values for \"%s\"",
									key);

			if(!(flags & DB_CHECKRET))
				exit(1);

			return FALSE;
			}

		if(!(dbn->dbn_keys[i].kv_flags & KVF_DUPLICATE) ||
						nk != 0 && nfound == nk)
			{
			foundi = i;
			break;
			}
		}
	}

if(foundi < 0)
	{
	if(flags & DB_ADDOK)	/* XXX test duplicated above */
		return db_addkey(dbd, dbn, key, newval, flags);

	if(!(flags & DB_CHECKRET))
		{
		db_error(dbd, "fatal error", keynotfound, key);
		exit(1);
		}

	return FALSE;
	}

return dochangeval(dbd, dbn, foundi, nfound, newval, histdbn);
}

db_ichangeval(dbd, dbn, kvi, newval, flags)
struct db *dbd;
struct dbnode *dbn;
int kvi;
char *newval;
int flags;
{
int nf = 0;
struct dbnode *histdbn = NULL;

if(dbn->dbn_flags & (DBN_INDEXONLY | DBN_NOTEXT))
	db_regetent(dbd, dbn);

kvi--;		/* make 0-based */

if(dbn->dbn_flags & DBN_INTKEYS)
	{
	/* convert index (user to internal) */

	int kvi2 = -1;
	int i, j = 0;
	for(i = 0; i < dbn->dbn_nkeys; i++)
		{
		if(dbn->dbn_keys[i].kv_flags & KVF_INTERNAL)
			continue;
		if(j == kvi)
			{
			kvi2 = i;
			break;
			}
		j++;
		}

	kvi = kvi2;
	}

flags |= dbd->db_flags;

if(kvi < 0 || kvi >= dbn->dbn_nkeys)
	return FALSE;

#ifdef DBRCS

if((flags & DB_HISTORY) && !(flags & DB_NOHISTORY))
	{
	histdbn = db_gethistnode(dbd, dbn);
	if(histdbn == NULL)
		return FALSE;
	if(!(dbn->dbn_keys[kvi].kv_flags & KVF_DUPLICATE))
		nf = 1;
	else	{
		int i;
		for(i = 0; i <= kvi; i++)
			{
			if(Keyeq(dbn, dbn->dbn_keys[i].kv_key, dbn->dbn_keys[kvi].kv_key))
				nf++;
			}
		}
	}

#endif

return dochangeval(dbd, dbn, kvi, nf, newval, histdbn);
}

static
dochangeval(dbd, dbn, foundi, nfound, newval, histdbn)
struct db *dbd;
struct dbnode *dbn;
int foundi;
int nfound;
char *newval;
struct dbnode *histdbn;
{
struct keyvalue *kvp = &dbn->dbn_keys[foundi];

#ifdef DBRCS

if(histdbn != NULL)
	{
	db_stashhist(dbd, histdbn, 'c', kvp->kv_key, nfound,
					kvp->kv_valstring);
	}

#endif

#ifndef NTALLOC
if((kvp->kv_flags & (KVF_POINTER | KVF_MALLOCED)) == (KVF_POINTER | KVF_MALLOCED) &&
							kvp->kv_valptr != NULL)
	free(kvp->kv_valptr);		/* XXX assumes kv_valstring and kv_valptr compat. */
#endif

kvp->kv_valptr = NULL;

if(newval != NULL)
	{
	if((kvp->kv_valstring = db_ntalloc(dbn, strlen(newval) + 1)) == NULL)
		return FALSE;
	(void)strcpy(kvp->kv_valstring, newval);
	}

/* XXX worry about index */

kvp->kv_flags = kvp->kv_flags & ~KVF_TYPEMASK | KVF_STRING | KVF_POINTER | KVF_MALLOCED | KVF_DIRTY;
dbn->dbn_flags |= DBN_DIRTY;
return TRUE;
}
