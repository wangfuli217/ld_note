#include <ctype.h>
#include "defs.h"

numeric(string)
char *string;
{
if(string == NULL || *string == '\0')
	return FALSE;

while(*string == ' ' || *string == '\t')
	string++;

if(*string == '-')
	string++;

if(!isascii(*string) || !isdigit(*string))
	return FALSE;

string++;

while(isascii(*string) && isdigit(*string))
	string++;

while(*string == ' ' || *string == '\t')
	string++;

if(*string != '\0')
	return FALSE;

return TRUE;
}
