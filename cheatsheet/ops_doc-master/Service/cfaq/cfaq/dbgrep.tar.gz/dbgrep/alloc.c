#include <stdio.h>
#include <stdlib.h>

#include "alloc.h"
#include "defs.h"

#ifdef __STDC__
#define SAFEREALLOC
#endif

extern char *progname;

char *
alloc(size)
int size;
{
char *ret;

ret = malloc((unsigned)size);

if(ret == NULL)
	{
	if(progname != NULL)
		fprintf(stderr, "%s: ", progname);
	fprintf(stderr, "out of memory\n");
	exit(1);
	}

return ret;
}

char *
crealloc(ptr, size)
char *ptr;
int size;
{
char *ret;

#ifndef SAFEREALLOC
if(ptr == NULL)
	ret = malloc((unsigned)size);
else
#endif
	ret = realloc(ptr, (unsigned)size);

if(ret == NULL)
	{
	if(progname != NULL)
		fprintf(stderr, "%s: ", progname);
	fprintf(stderr, "out of memory\n");
	exit(1);
	}

return ret;
}
