#include <string.h>
#include "alloc.h"

#ifdef __STDC__
#include "string2.h"
#endif

char *
strsave(string)
const char *string;
{
char *ret;

if(string == NULL)
	return NULL;

ret = alloc(strlen(string) + 1);

(void)strcpy(ret, string);

return ret;
}
