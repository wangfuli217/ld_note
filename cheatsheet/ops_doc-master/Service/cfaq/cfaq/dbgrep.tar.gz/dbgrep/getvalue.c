/*
 *  plaintext "database" library -- fetch a value (by key name) from a node
 *
 *  Copyright 1987-2002
 *  Steve Summit, scs@eskimo.com
 *  This code may be freely redistributed and used
 *  so long as the author's name and this notice remain intact,
 *  and any modifications are marked as such.
 */

#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#define DEF_DB
#include "db.h"
#include "defs.h"

static char keynotfound[] = "db_getvalue: key \"%s\" not found";

struct keyvalue *db_gtkv2();

char *
db_getvalue(dbd, dbn, key, flags)
struct db *dbd;
struct dbnode *dbn;
char *key;
int flags;
{
struct keyvalue *kvp = db_gtkv2(dbd, dbn, key, flags, 0);
if(kvp != NULL)
	return kvp->kv_value;
else	return NULL;
}

struct keyvalue *
db_gtkv2(dbd, dbn, key, flags, kvi)
struct db *dbd;
struct dbnode *dbn;
char *key;
int flags;
int kvi;
{
char *ukey;
register int i;
struct keyvalue *found = NULL;
int nfound = 0;

/*
 *  !(flags & DB_KVINTERNAL) is to prevent infinite loops when called by db_regetent();
 *  this is probably *not* the right flag or way to do it
 */

if((dbn->dbn_flags & (DBN_INDEXONLY | DBN_NOTEXT)) && !(flags & DB_KVINTERNAL))
	db_regetent(dbd, dbn);

flags |= dbd->db_flags;

ukey = db_hashkey(dbd, key, flags | DB_NOALLOC);

if(ukey == NULL && key != NULL)
	{
	if(!(flags & DB_CHECKRET))
		{
		db_error(dbd, "fatal error", keynotfound, key);
		exit(1);
		}

	return NULL;
	}

for(i = 0; i < dbn->dbn_nkeys; i++)
	{
	if(Keyeq(dbn, dbn->dbn_keys[i].kv_key, ukey) &&
		(!(dbn->dbn_keys[i].kv_flags & KVF_INTERNAL) ||	    /* XOR? */
			(flags & DB_KVINTERNAL)))
		{
		nfound++;

		if(found != NULL)
			{
			if(!(flags & (DB_FIRST | DB_LAST)) && kvi == 0)
				{
				db_error(dbd,
				 (flags&DB_CHECKRET) ? "error" : "fatal error",
	       "db_getvalue: duplicate values for \"%s\": \"%s\" and \"%s\"",
					key, found->kv_value, dbn->dbn_keys[i].kv_value);

				if(!(flags & DB_CHECKRET))
					exit(1);

				return NULL;
				}
			}

		found = &dbn->dbn_keys[i];

		if(flags & DB_FIRST)
			break;

		if(kvi != 0 && kvi == nfound)
			break;
		}
	}

/*
 *  Changed 4/2/1997 to "complain" if requested kvi too high.
 *  Change needed for new "report generator" ($*v{} code),
 *  but there's a chance it'll break something,
 *  in which case we'll need (yet) another option flag.
 */
 
if(kvi != 0 && kvi != nfound)
	found = NULL;

if(found == NULL && !(flags & DB_CHECKRET))
	{
	db_error(dbd, "fatal error", keynotfound, key);
	exit(1);
	}

return found;
}

#ifdef STREAMDB

/*
 *  At the moment, this is called only by db_putent.
 *  Eventually, it should probably be called by several others
 *  (db_getkv, even db_getalue above).
 */

struct keyvalue *
db_specialgetkvi(dbd, dbnp, kvi)
struct db *dbd;
struct dbnode *dbnp;
int kvi;
{
struct dbf *dbf2;

if(kvi < 0)
	return NULL;

if(kvi < dbnp->dbn_nkeys)
	return &dbnp->dbn_keys[kvi];

if(!(dbnp->dbn_flags & DBN__STREAMTEXT))
	return NULL;

if(dbd->db_dbfd == NULL)
	return NULL;

if(!(dbd->db_dbfd->dbf_gflags & DB_STREAM))
	return NULL;

if((dbf2 = dbd->db_dbfd->dbf_fmtspecif) == NULL)
	return NULL;

/* worry about dbf2->dbf_magic, too? */

if(!(dbf2->dbf_fstate & DB__INTR))
	return NULL;

if(db_fgetent(dbd->db_dbfd, dbd, dbnp, DB_STMRD1, (int *)NULL) == NULL)
	{
	return NULL;
	}
else	{
	return &dbnp->dbn_keys[--dbnp->dbn_nkeys];	/* tricky... */
	}
}

#endif
