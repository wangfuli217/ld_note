/*
 *  plaintext "database" library -- allocation functions
 *
 *  Copyright 1987-2002
 *  Steve Summit, scs@eskimo.com
 *  This code may be freely redistributed and used
 *  so long as the author's name and this notice remain intact,
 *  and any modifications are marked as such.
 */

#include <stdlib.h>
#define DEF_DB
#include "alloc.h"
#include "db.h"
#include "defs.h"

#ifdef VMLIMIT

extern char *lmalloc();
extern char *lrealloc();

#else

#define lmalloc malloc
#define lrealloc realloc

#endif

char db_nolvikey;			/* just for unique address */

#ifdef __STDC__

static inithash(struct hashtab *, int nb);

#endif

static inithash();

struct db *
db_alloc(flags)
int flags;
{
struct db *dbp;

dbp = Salloc(struct db);

dbp->db_flags = flags;

dbp->db_nmajkeys = 0;
dbp->db_majkeys = NULL;
dbp->db_list = dbp->db_tail = NULL;

inithash(&dbp->db_keytab, 17);

dbp->db_dbfd = NULL;

dbp->db_walkstate = NULL;
dbp->db_lviterkey = &db_nolvikey;
dbp->db_gkviterstate = 0;

return dbp;
}

db_setopt(dbp, flags)
struct db *dbp;
int flags;
{
dbp->db_flags |= flags;
}

static
inithash(htp, nb)
struct hashtab *htp;
int nb;
{
int i;

htp->ht_nbuckets = nb;
htp->ht_buckets = (char ***)alloc(nb * sizeof(char **));
for(i = 0; i < nb; i++)
	htp->ht_buckets[i] = NULL;
}

struct dbnode *
db_nalloc()
{
register struct dbnode *dbnp = Salloc(struct dbnode);
db_ninit(dbnp);
return dbnp;
}

db_ninit(dbnp)
register struct dbnode *dbnp;
{
dbnp->dbn_flags = 0;
dbnp->dbn_alkeys = dbnp->dbn_nkeys = 0;
dbnp->dbn_keys = NULL;
#ifdef CHECKPOINT
dbnp->dbn_chkp_flags = 0;
dbnp->dbn_chkp_nkeys = 0;
dbnp->dbn_chkp_keys = NULL;
#endif
#ifdef NTALLOC
dbnp->dbn_txtptrs = NULL;
dbnp->dbn_ntxtptrs = 0;
dbnp->dbn_natxtptrs = 0;
dbnp->dbn_ntused = NTBLKSIZE;	/* could make startup marginally easier */
dbnp->dbn_curblksize = 0;
dbnp->dbn_lastsize = 0;
#ifndef NDEBUG
dbnp->dbn_lastret = NULL;
#endif
#endif
dbnp->dbn_next = NULL;
dbnp->dbn_parent = NULL;
}

#ifdef NTALLOC

#include <string.h>
#include <assert.h>

char *
db_ntalloc(dbnp, size)
register struct dbnode *dbnp;
int size;
{
char *ret;

if(size <= NTBLKSIZE - dbnp->dbn_ntused && dbnp->dbn_ntxtptrs > 0)
	{
	ret = &dbnp->dbn_txtptrs[dbnp->dbn_ntxtptrs-1][dbnp->dbn_ntused];
	dbnp->dbn_ntused += size;
	}
else	{
	int na;

	if(dbnp->dbn_ntxtptrs >= dbnp->dbn_natxtptrs)
		{
		int nnaptrs = dbnp->dbn_natxtptrs + 10;
		char **new;
#ifndef SAFEREALLOC
		if(dbnp->dbn_txtptrs == NULL)
			new = (char **)lmalloc(nnaptrs * sizeof(char *));
		else
#endif
			new = (char **)lrealloc(dbnp->dbn_txtptrs, nnaptrs * sizeof(char *));
		if(new == NULL)
			return NULL;
		dbnp->dbn_txtptrs = new;
		dbnp->dbn_natxtptrs = nnaptrs;
		}

	na = Max(size, NTBLKSIZE);
	if((dbnp->dbn_txtptrs[dbnp->dbn_ntxtptrs] = lmalloc(na)) == NULL)
		return NULL;
	dbnp->dbn_curblksize = na;

	ret = dbnp->dbn_txtptrs[dbnp->dbn_ntxtptrs];

#ifdef notdef	/* curses! wholly incompatible with management strategy -- */
		/* block in use must always be last block */
		/* (as enforced by dbn_lastret) */
	if(size > dbnp->dbn_ntused && dbnp->dbn_ntxtptrs > 0)
		{
		/* keep bigger chunk available */
		char *t = dbnp->dbn_txtptrs[dbnp->dbn_ntxtptrs-1];
		dbnp->dbn_txtptrs[dbnp->dbn_ntxtptrs-1] = dbnp->dbn_txtptrs[dbnp->dbn_ntxtptrs];
		dbnp->dbn_txtptrs[dbnp->dbn_ntxtptrs] = t;
		}
	else
#endif

	dbnp->dbn_ntused = size;
	
	dbnp->dbn_ntxtptrs++;
	}

dbnp->dbn_lastsize = size;
#ifndef NDEBUG
dbnp->dbn_lastret = ret;
#endif

return ret;
}

char *
db_ntrealloc(dbnp, oldp, newsize)
register struct dbnode *dbnp;
char *oldp;
int newsize;
{
if(oldp == NULL)
	return db_ntalloc(dbnp, newsize);

assert(oldp == dbnp->dbn_lastret);

if(newsize <= dbnp->dbn_curblksize - (oldp - dbnp->dbn_txtptrs[dbnp->dbn_ntxtptrs-1]))
	{
	dbnp->dbn_ntused = (oldp - dbnp->dbn_txtptrs[dbnp->dbn_ntxtptrs-1]) + newsize;
	dbnp->dbn_lastsize = newsize;
	return oldp;
	}
#ifndef NONTREALLOCFIX
else if(oldp == dbnp->dbn_txtptrs[dbnp->dbn_ntxtptrs-1])
	{
	/* not so hard way (prev chunk accounts for whole block) */
	char *p = dbnp->dbn_txtptrs[dbnp->dbn_ntxtptrs-1];
#ifdef DEBUG2
	fprintf(stderr, "db_ntrealloc: not so hard way\n");
#endif
	p = lrealloc(p, newsize);
	dbnp->dbn_txtptrs[dbnp->dbn_ntxtptrs-1] = p;
	dbnp->dbn_curblksize = newsize;
	dbnp->dbn_ntused = newsize;
	dbnp->dbn_lastsize = newsize;
#ifndef NDEBUG
	dbnp->dbn_lastret = p;
#endif
	return p;
	}
#endif
else	{
	/* hardway */
	int oldsize = dbnp->dbn_lastsize;
	char *newp = db_ntalloc(dbnp, newsize);
#ifdef DEBUG2
	fprintf(stderr, "db_ntrealloc: hardway\n");
#endif
	memmove(newp, oldp, oldsize);
	/* somewhat of a waste */
	return newp;
	}
}

#endif
