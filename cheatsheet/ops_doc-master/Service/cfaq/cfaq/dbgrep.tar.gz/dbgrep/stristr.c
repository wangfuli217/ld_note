/* case-insensitive string search */

#include <ctype.h>

/*
 *  Newer versions of tolower work correctly if their argument
 *  isn't an upper case letter.  Older ones do not, and I don't
 *  mind checking.  Implementations that do check often provide a
 *  "faster" version, that doesn't check, called _tolower.
 */

#ifdef _tolower
#ifdef tolower
#undef tolower
#endif
#define tolower _tolower
#endif

#define NULL 0

char *
stristr(string, search)
char *string;
char *search;
{
register int c1, c2;
register char *p1, *p2;
int strl = strlen(string);
int srchl = strlen(search);
register char *endp;

if(srchl > strl)
	return NULL;

endp = string + strl - srchl + 1;

while(string < endp)
	{
	p1 = string;
	p2 = search;

	do	{
		if(*p2 == '\0')
			return(string);

		c1 = *p1++;
		if(isupper(c1))
			c1 = tolower(c1);

		c2 = *p2++;
		if(isupper(c2))
			c2 = tolower(c2);

		} while(c1 == c2);
		
	string++;
	}

return NULL;
}
