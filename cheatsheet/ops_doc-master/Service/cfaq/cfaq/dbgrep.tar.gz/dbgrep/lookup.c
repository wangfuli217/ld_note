/*
 *  plaintext "database" library -- look up a node by an indexed key
 *
 *  Copyright 1987-2002
 *  Steve Summit, scs@eskimo.com
 *  This code may be freely redistributed and used
 *  so long as the author's name and this notice remain intact,
 *  and any modifications are marked as such.
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define DEF_DB
#include "db.h"
#include "defs.h"

struct dbnode *
db_lookup(dbd, key, value)
struct db *dbd;
char *key;
char *value;
{
char *ukey = db_hashkey(dbd, key, dbd->db_flags);
register int i;
struct tree *tp;

for(i = 0; i < dbd->db_nmajkeys; i++)
	{
	if(dbd->db_majkeys[i].dbi_key == ukey)
		break;
	}

if(i >= dbd->db_nmajkeys)
	{
	db_error(dbd, "error", "lookup: database not keyed on \"%s\"", key);
	return NULL;
	}

tp = db_tlookup(dbd->db_majkeys[i].dbi_tree, ukey, value, NULL);

if(tp == NULL)
	return NULL;

return tp->t_item;
}

struct tree *
db_tlookup(tree, key, value, dbnp2)
struct tree *tree;
char *key, *value;
struct dbnode *dbnp2;
{
struct tree *tp;
register int i;
register struct dbnode *dbnp;
int r;

for(tp = tree; tp != NULL; )
	{
	dbnp = tp->t_item;

	if(dbnp == NULL)
		{
		/* crudely deleted key (not necessarily percolated out) */
		/* unfortunately, can't tell if we should go right or left... */
		struct tree *tp2 = db_tlookup(tp->t_left, key, value, dbnp2);
		if(tp2 != NULL)
			return tp2;
		return db_tlookup(tp->t_right, key, value, dbnp2);
		}

	for(i = 0; i < dbnp->dbn_nkeys; i++)
		{
		if(Keyeq(dbnp, dbnp->dbn_keys[i].kv_key, key))
			break;
		}

	if(i >= dbnp->dbn_nkeys)
		{
		/* (if dbn_parent ever taken back out, may have to pass dbd in to db_tlookup) */
		db_error(dbnp->dbn_parent, "fatal error",
			"lookup: can't find key \"%s\" in node", key);
		exit(1);
		}

	r = strcmp(value, dbnp->dbn_keys[i].kv_value);

	if(r == 0 && (dbnp2 == NULL || dbnp == dbnp2))
		return tp;

	tp = r < 0 ? tp->t_left : tp->t_right;
	}

return NULL;
}
