/*
 *  plaintext "database" library -- write db nodes to file
 *
 *  Copyright 1987-2002
 *  Steve Summit, scs@eskimo.com
 *  This code may be freely redistributed and used
 *  so long as the author's name and this notice remain intact,
 *  and any modifications are marked as such.
 */

#include <stdio.h>
#define DEF_DB
#include "db.h"
#include "defs.h"

db_write(dbd, dbfd)
struct db *dbd;
struct dbfd *dbfd;
{
register struct dbnode *dbnp;

if(dbfd->dbf_mode != 'w' && dbfd->dbf_mode != '?')
	{
	db_error(dbd, "error", "db_write: dbfd not open for reading");
	return FALSE;
	}

for(dbnp = dbd->db_list; dbnp != NULL; dbnp = dbnp->dbn_next)
	{
	int purgeflag = FALSE;
	if(dbnp->dbn_flags & (DBN_INDEXONLY | DBN_NOTEXT))
		{
		db_regetent(dbd, dbnp);
		purgeflag = TRUE;
		}
	db_putent(dbfd, dbnp);
	if(purgeflag)
		db_purgenode(dbd, dbnp);
	}

return TRUE;
}
