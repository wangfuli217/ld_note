/*
 *  plaintext "database" library -- fetch i'th key/value pair from node
 *
 *  Copyright 1987-2002
 *  Steve Summit, scs@eskimo.com
 *  This code may be freely redistributed and used
 *  so long as the author's name and this notice remain intact,
 *  and any modifications are marked as such.
 */

#include <stdio.h>
#define DEF_DB
#include "db.h"
#include "defs.h"

struct keyvalue *
db_getikv(dbd, dbnp, kvi)
struct db *dbd;
struct dbnode *dbnp;
int kvi;
{
if((dbnp->dbn_flags & (DBN_INDEXONLY | DBN_NOTEXT)) && !(dbnp->dbn_flags & DBN__STREAMTEXT))
	db_regetent(dbd, dbnp);

kvi--;		/* make 0-based */

if(dbnp->dbn_flags & DBN_INTKEYS)
	{
	/* convert index (user to internal) */

	int kvi2 = -1;
	int i, j = 0;
	for(i = 0; i < dbnp->dbn_nkeys; i++)
		{
		if(dbnp->dbn_keys[i].kv_flags & KVF_INTERNAL)
			continue;
		if(j == kvi)
			{
			kvi2 = i;
			break;
			}
		j++;
		}

	kvi = kvi2;
	}

if(kvi < 0 || kvi >= dbnp->dbn_nkeys)
	return NULL;

return &dbnp->dbn_keys[kvi];
}
