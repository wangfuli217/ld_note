/*
 *  dbgrep -- a program for searching (and otherwise manipulating)
 *  simple plaintext, flat-file databases of the form
 *
 *	name: cat
 *	genus: felis
 *	species: domesticus
 *	young: kitten
 *
 *	name: dog
 *	genus: canis
 *	species: familiaris
 *	young: puppy
 *
 *	name: horse
 *	genus: equus
 *	species: caballus
 *	young: foal
 *
 *  Uses an underlying library (libdb.a) which manipulates
 *  "database" files in this format.  Has many search modes,
 *  operations, and other options; see "dbgrep -help" for a summary,
 *  or the man page for longer explanations.
 *
 *  Steve Summit 2002-01-13
 *  scs@eskimo.com
 *
 *  Copyright 1992-2002
 *  This code may be freely redistributed and used
 *  so long as the author's name and this notice remain intact,
 *  and any modifications are marked as such.
 */

#include <stdio.h>
#include <string.h>

#ifdef mac
#include <console.h>
#endif

#ifdef THINK_C
#ifdef PROFILE
#include <profile.h>
#endif
#endif

#define DEF_DB		/* XXX so can get to dbn_flags, also dbd->db_dbfd=dbfd */
#include "db.h"		/* XXX was <>, but Think C probs */
#include "tabsep.h"

#include "defs.h"
#include "alloc.h"
#include "dbgrep.h"

FILE *ofd = NULL;
struct dbfd *dbofd;

char *outfile = NULL;
int multout = FALSE;
int multappend = FALSE;
char *ofkey = NULL;

int foldcase = FALSE;
int keyfoldcase = FALSE;

char *sepkey = NULL;

int keysepchar = ':';	/* duplicated in dbfd.c; */
int commentchar = '#';	/* might be nice to inherit somehow */

int mailflag = FALSE;
char *mailsepkey = "From ";

int prsrvindent = FALSE;
int prsrvcomments = FALSE;

int alwaysprint = TRUE;
int appnewline = FALSE;
int countflag = FALSE;

int dbfmoreflags = 0;

#ifdef STREAMDB
int streamok = TRUE;
#endif

int nfound = 0;

struct eval *evalroot = NULL;

int dbfflags = 0;

int ifmt = DBF_DBF;
int ofmt = DBF_DBF;

char **ocols = NULL;
int nocols = 0;
int naocols = 0;

#ifdef SPECIALOPS
extern char *(*specialget)();
extern int (*specialset)();
#endif

extern char *strsave();
extern int strcmp();
extern int stricmp();

char *progname = "dbgrep";

main(argc, argv)
int argc;
char *argv[];
{
int argi;
struct dbfd *dbfd;
dbdesc dbd;

#ifdef THINK_C
#ifdef PROFILE

InitProfile(200, 200);

#endif
#endif

#ifdef mac
argc = ccommand(&argv);
#endif

dbd = db_alloc(DB_DUPKEYOK);

argi = 1;

parseargs(&argi, argc, argv);

/* XXX most of the db file format flags don't apply unless DBF_DBF... */

dbfflags = DB_BLANKSEP;

if(keyfoldcase)
	db_setopt(dbd, DB_CASELESS);

if(sepkey != NULL)
	dbfflags = dbfflags & ~DB_BLANKSEP | DB_KEYSEP;

if(mailflag)
	{
	dbfflags = DB_KEYCHAR | DB_BLANKSEP | DB_XKEYSEP | DB_XKEYSEP |
					DB_RFC822 | DB_DEFTEXT;

#ifdef STREAMDB
	if(streamok)
		dbfflags |= DB_NOTEXT;
#endif

	db_setopt(dbd, DB_CASELESS);
	}

if(prsrvindent)
	dbfflags |= DB_KEYNOSTRIP;

if(prsrvcomments)
	dbfflags |= DB_KEEPCOMMENTS;

dbfflags |= dbfmoreflags;

if(outfile == NULL)
	ofd = stdout;
else if(!multout)
	{
	ofd = fopen(outfile, "w");
	if(ofd == NULL)
		{
		fprintf(stderr, "%s: can't open %s: ", progname, outfile);
		perror("");
		exit(1);
		}
	}

if(!multout)
	{
	dbofd = db_fdopen(ofd);
	setdbfmt(dbofd, ofmt, ocols, nocols);
	}

if(argi >= argc)
	{
	dbfd = db_fdopen(stdin);
	dbd->db_dbfd = dbfd;			/* XXX so rescan will work */
	setdbfmt(dbfd, ifmt, NULL, 0);
	scan(dbd, dbfd);
	}
else	{
	for(; argi < argc; argi++)
		{
		dbfd = db_fopen(argv[argi], "r");

		if(dbfd == NULL)
			{
			fprintf(stderr, "%s: can't open %s: ", progname, argv[argi]);
			perror("");
			/* exit status? */
			continue;
			}

		dbd->db_dbfd = dbfd;		/* XXX so rescan will work */
		setdbfmt(dbfd, ifmt, NULL, 0);
		scan(dbd, dbfd);
		}
	}

efinish(evalroot);

if(countflag)
	printf("%d\n", nfound);

#ifdef THINK_C
#ifdef PROFILE

freopen("profile.out", "w", stdout);	/* redirect profiler output (implicit DumpProfile() in exit()) */

#endif
#endif

if(nfound == 0)
	exit(1);

exit(0);		/* XXX */
}

scan(dbd, dbfd)
dbdesc dbd;
struct dbfd *dbfd;
{
register dbnode dbnp;
int r;

if(sepkey != NULL)
	db_f_sepk_set(dbfd, sepkey);

if(mailflag)
	{
	db_f_sepk_set(dbfd, mailsepkey);
	commentchar = EOF;
	}

if(ifmt == DBF_DBF)
	db_fschars(dbfd, keysepchar, commentchar);

while((dbnp = (*dbfd->dbf_funcs->dbf_getent)(dbfd, dbd)) != NULL)
	{
	/* XXX temporary, though not sure how to do this right */
	static int beenhere = FALSE;
	if(!beenhere && !multout)
		{
		if(ifmt == DBF_DBF && ofmt == DBF_DBF &&
					(db_fgtflags(dbfd) & DB_KYCHINTUIT))
			db_fstflags(dbofd, DB_KEYCHAR);

		if(ifmt == DBF_TABSEP && ofmt == DBF_TABSEP && nocols == 0)
			dbts_copycols(dbfd, dbofd);

		/* XXX need more of these cases for CSV, SQL */

		beenhere = TRUE;
		}

	db_gkvfinish(dbd, dbnp);

	if(prsrvcomments && (dbnp->dbn_flags & DBN_COMMENT))
		{
		(*dbofd->dbf_funcs->dbf_putent)(dbofd, dbnp);
		if(appnewline)
			fprintf(ofd, "\n");
		continue;
		}

	if(eval(dbd, dbnp, evalroot))
		{
		if(multout)
			checkofd(dbd, dbnp);

		nfound++;

		if(alwaysprint)
			(*dbofd->dbf_funcs->dbf_putent)(dbofd, dbnp);

		if(appnewline)
			fprintf(ofd, "\n");

		if(alwaysprint || appnewline)
			fflush(ofd);
		}

	if(multout)
		finishout();

	db_nfree(dbnp);
	}
}

addocol(key)
char *key;
{
if(nocols >= naocols)
	{
	naocols += 10;
	ocols = Srealloc(char *, ocols, naocols);
	}
ocols[nocols++] = strsave(key);
}

checkofd(dbd, dbnp)
dbdesc dbd;
dbnode dbnp;
{
char ofbuf[FILENAME_MAX];		/* XXX */

if(ofd != NULL)
	return;
if(ofkey == NULL)
	sprintf(ofbuf, outfile, nfound + 1);
else	{
	char *p = db_getvalue(dbd, dbnp, ofkey, DB_CHECKRET);
	if(p == NULL)
		{
		fprintf(stderr, "%s: missing %s key for output filename", progname, ofkey);
		exit(1);
		/* continue with no output? */
		}
	sprintf(ofbuf, outfile, p);
	}

ofd = fopen(ofbuf, multappend ? "a" : "w");
if(ofd == NULL)
	{
	fprintf(stderr, "%s: can't open %s: ", progname, ofbuf);
	perror("");
	exit(1);
	}

dbofd = db_fdopen(ofd);

setdbfmt(dbofd, ofmt, ocols, nocols);
}

setdbfmt(dbfd, fmt, cols, ncols)
struct dbfd *dbfd;
int fmt;
char **cols;
int ncols;
{
#ifdef STREAMDB
if(streamok)
	db_f_opt_set(dbfd, DB_STREAM);
#endif

switch(fmt)
	{
	case DBF_DBF:
		db_f_dbf_set(dbfd, dbfflags);
		break;

	case DBF_TABSEP:
		db_f_ts_set(dbfd);
		if(cols != NULL && ncols > 0)
			dbts_setcols(dbfd, cols, ncols);
		break;

	case DBF_CSV:
		db_f_csv_set(dbfd);
		if(cols != NULL && ncols > 0)
			dbts_setcols(dbfd, cols, ncols);
		break;

	case DBF_SQLDUMP:
		db_f_sql_set(dbfd);
		if(cols != NULL && ncols > 0)
			dbts_setcols(dbfd, cols, ncols);
		/* XXX widths? */
		break;
#ifdef HL7
	case DBF_HL7:
		{
		extern char *dbhl7_getval();
		extern dbhl7_setval();

		db_f_hl7_set(dbfd);
		specialget = dbhl7_getval;
		specialset = dbhl7_setval;
		break;
		}
#endif

	/* XXX worry about default */
	}
}

finishout()
{
if(ofd != NULL)
	{
	db_fclose(dbofd);
	ofd = NULL;
	}
}
