/*
 *  plaintext "database" library -- iterate over all nodes in db
 *
 *  Copyright 1987-2002
 *  Steve Summit, scs@eskimo.com
 *  This code may be freely redistributed and used
 *  so long as the author's name and this notice remain intact,
 *  and any modifications are marked as such.
 */

#define DEF_DB
#include "db.h"
#include "defs.h"

/* walk nodes in database */

struct dbnode *
db_walk(dbd)
struct db *dbd;
{
dbd->db_walkstate = dbd->db_list;
return dbd->db_walkstate;
}

struct dbnode *
db_wnext(dbd)
struct db *dbd;
{
if(dbd->db_walkstate == NULL)
	return NULL;
dbd->db_walkstate = dbd->db_walkstate->dbn_next;
return dbd->db_walkstate;
}

