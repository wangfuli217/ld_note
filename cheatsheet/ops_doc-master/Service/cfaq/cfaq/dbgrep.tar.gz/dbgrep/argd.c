/*
 *  dbgrep -- functions for handling options read from command line or file
 *
 *  Copyright 1992-2002
 *  Steve Summit, scs@eskimo.com
 *  This code may be freely redistributed and used
 *  so long as the author's name and this notice remain intact,
 *  and any modifications are marked as such.
 */

#include <stdio.h>
#ifdef __STDC__
#include <stdlib.h>
#endif
#include <ctype.h>
#include "alloc.h"
#include "argd.h"
#include "defs.h"

static readword();

struct argd *
mkargvd(argc, argv, argp, argdbuf)
int argc;
char *argv[];
int *argp;
struct argd *argdbuf;
{
argdbuf->ad_which = AD_ARGV;
argdbuf->ad_argc = argc;
argdbuf->ad_argv = argv;
argdbuf->ad_argp = argp;
argdbuf->ad_next = NULL;

return argdbuf;
}

struct argd *
mkfiled(fd)
FILE *fd;
{
struct argd *argd = Salloc(struct argd);

argd->ad_which = AD_FILE;
argd->ad_fd = fd;
argd->ad_filename = NULL;
argd->ad_flags = 0;
argd->ad_bufsize = 20;
argd->ad_buf = alloc(argd->ad_bufsize);
argd->ad_lineno = 1;
argd->ad_next = NULL;

return argd;
}

eoargs(argd)
struct argd *argd;
{
return (peekarg(argd) == NULL);
}

char *
peekarg(argd)
struct argd *argd;
{
while(TRUE)		/* will loop to pop, if necessary */
	{
	switch(argd->ad_which)
		{
		case AD_ARGV:
			if(*argd->ad_argp >= argd->ad_argc)
				{
				if(!popargd(argd))
					{
					argd->ad_flags |= AD_EOARGS;
					return NULL;
					}

				continue;
				}

			return argd->ad_argv[*argd->ad_argp];

		case AD_FILE:
			if(argd->ad_flags & AD_HAVEARG)
				{
#ifdef DEBUG
				printf("peekarg (file): returning \"%s\"\n",
								argd->ad_buf);
#endif
				return argd->ad_buf;
				}

			if(!readword(argd))
				{
				if(!popargd(argd))
					{
					argd->ad_flags |= AD_EOARGS;
					return NULL;
					}

				continue;
				}

			argd->ad_flags |= AD_HAVEARG;
#ifdef DEBUG
			printf("peekarg (file): returning \"%s\"\n",
								argd->ad_buf);
#endif
			return argd->ad_buf;
		}
	}
}

char *
nxtarg(argd)
struct argd *argd;
{
char *ret = peekarg(argd);

if(ret == NULL)
	return NULL;

switch(argd->ad_which)
	{
	case AD_ARGV:
		(*argd->ad_argp)++;
		break;
	}

argd->ad_flags &= ~AD_HAVEARG;

return ret;
}

ungetarg(argd)
struct argd *argd;
{
switch(argd->ad_which)
	{
	case AD_ARGV:
		(*argd->ad_argp)--;
		break;
	}

argd->ad_flags |= AD_HAVEARG;
argd->ad_flags &= ~AD_EOARGS;
}

static
readword(argd)
struct argd *argd;
{
int c;
char *p = argd->ad_buf;
int nch = 0;
int bsflag = FALSE;	/* handling backslash quoting */
int sqflag = FALSE;	/* handling single quote */
int dqflag = FALSE;	/* handling double quote */
int nullok = FALSE;	/* saw ' or ", so empty arg ('' or "") okay (kludge) */

again:

while((c = getc(argd->ad_fd)) != EOF && isspace(c))
	{
	if(c == '\n')
		argd->ad_lineno++;
	}

if(c == EOF)
	return FALSE;

do	{
	if(!bsflag)
		{
		if(!sqflag && c == '\\')
			{
			bsflag = TRUE;
			goto cont;
			}

		if(!dqflag && c == '\'')
			{
			sqflag = !sqflag;
			nullok = TRUE;
			goto cont;
			}

		if(!sqflag && c == '"')
			{
			dqflag = !dqflag;
			nullok = TRUE;
			goto cont;
			}

		if(!sqflag && !dqflag && c == '#')
			{
			/* comment ('til end of line) */
			while((c = getc(argd->ad_fd)) != '\n' && c != EOF)
				;
			/* aargh! spaghetti code... */
			if(p == argd->ad_buf)
				goto again;
			goto cont2;
			}
		}

	if(nch >= argd->ad_bufsize - 1)	/* -1 for \0 */
		{
		argd->ad_bufsize += 10;
		argd->ad_buf = crealloc(argd->ad_buf, argd->ad_bufsize);
		p = argd->ad_buf + nch;
		}

	*p++ = c;
	nch++;

	bsflag = FALSE;

cont:	c = getc(argd->ad_fd);
cont2:
	if(c != EOF && !bsflag && !sqflag && !dqflag && isspace(c))
		{
		ungetc(c, argd->ad_fd);
		c = EOF;
		}

	if(c == '\n')
		argd->ad_lineno++;

	} while(c != EOF);

if(nch == 0 && !nullok)
	return FALSE;

*p = '\0';

#ifdef DEBUG
printf("readword: returning \"%s\"\n", argd->ad_buf);
#endif

return TRUE;
}

pushargd(oldargd, newargd)
struct argd *newargd, *oldargd;
{
struct argd tmpargd;

/* urk -- gotta play with *oldargd */

tmpargd = *oldargd;
*oldargd = *newargd;
oldargd->ad_next = newargd;
*newargd = tmpargd;
}

popargd(argd)
struct argd *argd;
{
struct argd *tmp;

if(argd->ad_next == NULL)
	return FALSE;

switch(argd->ad_which)
	{
	case AD_FILE:
		if(argd->ad_fd != stdin)
			(void)fclose(argd->ad_fd);
		break;
	}

tmp = argd->ad_next;

*argd = *tmp;

free((char *)tmp);

return TRUE;
}
