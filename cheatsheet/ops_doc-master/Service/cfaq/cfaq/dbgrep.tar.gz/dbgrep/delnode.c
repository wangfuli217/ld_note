#include <assert.h>
#define DEF_DB
#include "db.h"
#include "defs.h"

/* don't use it unless you have to -- it does an expensive, linear search */

db_delnode(dbd, dbnp)
struct db *dbd;
struct dbnode *dbnp;
{
register struct dbnode *lp;
struct dbnode *prev;

for(lp = dbd->db_list, prev = NULL; lp != NULL; prev = lp, lp = lp->dbn_next)
	{
	if(lp == dbnp)
		{
		/* not using **lpp trick because need prev anyway, to update db_tail */
		if(prev != NULL)
			prev->dbn_next = lp->dbn_next;
		else	{
			assert(lp == dbd->db_list);
			dbd->db_list = lp->dbn_next;
			}
		if(lp == dbd->db_tail)
			dbd->db_tail = prev;
		dbnp->dbn_next = NULL;
		return TRUE;
		}
	}

return FALSE;
}

#ifndef NDEBUG

#include <stdio.h>

extern char *progname;

db_checkdelete(dbd, dbnp)
struct db *dbd;
struct dbnode *dbnp;
{
if(db_delnode(dbd, dbnp))
	fprintf(stderr,
		"%s: warning deleted node from main db list (while freeing)\n",
								progname);
}

#endif
