#ifndef REPGEN_H
#define REPGEN_H

struct var
	{
	int v_type;
	char *v_name;
	int v_namealloc;
	char v_fmt[10];
	int v_subscript;
	int v_flags;
	};

#define v_expr v_name
#define v_regexp v_fmt

#define V_DOLLAR	0	/* $$ */
#define V_REG		1	/* $name or ${name} */
#define V_IF		2	/* $? or $! */
#define V_REP		3	/* $* */
#ifdef EXPR
#define V_EXPR		4	/* $% */
#endif
#define V_DOT		5	/* $. */
#define V_NUM		6	/* $# */

#define V_NONAME	0x01	/* $@ */
#define V_HAVEFMT	0x02	/* ${name,%fmt} */
#define V_FMTCOMMA	0x04	/* ${name,comma} */
#define V_HAVEREGEXP	0x08	/* ${name,/re/} */
#define V_NEGATED	0x10	/* $! */
#ifdef EXPR
#define V_IFEXPR	0x20	/* $?% */
#endif
#define V_SUBSCRIPT	0x40	/* $name[i] */

#ifdef __STDC__

extern struct var *getvar(FILE *);
extern struct var *parsevar(char *, char **);
struct rgifp;
extern struct var *dogetvar(struct rgifp *);

#endif

extern struct var *getvar();
extern struct var *parsevar();
extern struct var *dogetvar();

#endif
