/*
 *  plaintext "database" library --
 *  test whether node has (any) value with given key
 *
 *  Copyright 1987-2002
 *  Steve Summit, scs@eskimo.com
 *  This code may be freely redistributed and used
 *  so long as the author's name and this notice remain intact,
 *  and any modifications are marked as such.
 */

#define DEF_DB
#include "db.h"
#include "defs.h"

db_haskey(dbd, dbn, key)	/* need flags arg? */
struct db *dbd;
struct dbnode *dbn;
char *key;
{
int flags = dbd->db_flags;
char *ukey;
register int i;

if(dbn->dbn_flags & (DBN_INDEXONLY | DBN_NOTEXT))
	db_regetent(dbd, dbn);

ukey = db_hashkey(dbd, key, flags | DB_NOALLOC);

if(ukey == NULL && key != NULL)
	return FALSE;

for(i = 0; i < dbn->dbn_nkeys; i++)
	{
	if(Keyeq(dbn, dbn->dbn_keys[i].kv_key, ukey))
		return TRUE;
	}

return FALSE;
}
