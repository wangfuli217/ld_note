/*
 *  plaintext "database" library -- binary tree index functions
 *
 *  Copyright 1987-2002
 *  Steve Summit, scs@eskimo.com
 *  This code may be freely redistributed and used
 *  so long as the author's name and this notice remain intact,
 *  and any modifications are marked as such.
 */

#define DEF_DB
#include "db.h"
#include "defs.h"
#include "alloc.h"		/* on its way out... */

db_tinsert(key, value, dbnp, dbd, treep)
char *key, *value;
struct dbnode *dbnp;
struct db *dbd;
struct tree **treep;
{
register int i;
struct dbnode *dbnp2;
int r;
struct tree *tp;

while(*treep != NULL)
	{
	dbnp2 = (*treep)->t_item;

	if(dbnp2 == NULL)
		{
		/* previously deleted node */
		if((*treep)->t_left != NULL || (*treep)->t_right != NULL)
			panic("db_tinsert: case I can't handle yet");
		(*treep)->t_item = dbnp;
		return;
		}

	for(i = 0; i < dbnp2->dbn_nkeys; i++)
		{
		if(Keyeq(dbnp2, dbnp2->dbn_keys[i].kv_key, key))
			break;
		}

	if(i >= dbnp2->dbn_nkeys)
		{
		db_error(dbd, "fatal error",
			"tinsert: can't find key \"%s\" in previous node",
									key);
		exit(1);
		}

	r = strcmp(value, dbnp2->dbn_keys[i].kv_valstring);

	if(r == 0)
		{
		db_error(dbd, "warning",
	   "tinsert: duplicate values for key \"%s\" (old \"%s\", new \"%s\")",
			key, dbnp2->dbn_keys[i].kv_valstring, value);
		}

	treep = r < 0 ? &(*treep)->t_left : &(*treep)->t_right;
	}

tp = *treep = Salloc(struct tree);

tp->t_item = dbnp;

tp->t_left = tp->t_right = NULL;
}

db_tdelete(key, value, dbnp, dbd, tree)	/* rarely used; could contribute to bloat */
char *key, *value;
struct dbnode *dbnp;
struct db *dbd;
struct tree *tree;
{
char *ukey = db_hashkey(dbd, key, dbd->db_flags);	/* should caller do? */
struct tree *tp = db_tlookup(tree, key, value, dbnp);
if(tp != NULL)
	{
	/* XXX ideally, would percolate down or something */
	tp->t_item = NULL;
	return TRUE;
	}

return FALSE;
}

#ifndef NDEBUG

extern char *progname;

db_chktindx(dbd, dbnp)
struct db *dbd;
struct dbnode *dbnp;
{
int i;
for(i = 0; i < dbd->db_nmajkeys; i++)
	{
	char *key = dbd->db_majkeys[i].dbi_key;
	char *val = db_getvalue(dbd, dbnp, key, DB_CHECKRET);	/* safe? */
	if(db_tdelete(key, val, dbnp, dbd, dbd->db_majkeys[i].dbi_tree))
		fprintf(stderr, "%s: deleted node value %s from index %s\n",
							progname, val, key);
	}
}

#endif
