/*
 *  plaintext "database" library -- write db node to file
 *
 *  Copyright 1987-2002
 *  Steve Summit, scs@eskimo.com
 *  This code may be freely redistributed and used
 *  so long as the author's name and this notice remain intact,
 *  and any modifications are marked as such.
 */

#include <stdio.h>
#include <string.h>
#include <time.h>
#define DEF_DB
#include "db.h"
#include "defs.h"

extern char *progname;

db_putent(dbfd, dbnp)
struct dbfd *dbfd;
struct dbnode *dbnp;
{
struct dbf *dbf2;
register struct keyvalue *kvp;
register int i;

if((dbf2 = dbfd->dbf_fmtspecif) == NULL || dbf2->dbf_magic != DBFMAGIC)
	panic("db_putent: not dbf file");

if(dbfd->dbf_mode != 'w' && dbfd->dbf_mode != '?')
	{
	db_error(dbfd->dbf_db, "error", "db_putent: dbfd not open for reading");
	return FALSE;
	}

if(dbnp->dbn_flags & (DBN_INDEXONLY | DBN_NOTEXT))
	{
	if(dbnp->dbn_parent == NULL && dbnp->dbn_parent->db_dbfd == NULL)
		{
		fprintf(stderr, "db_putent: incomplete node, but don't have dbfd to read from\n");
		return FALSE;
		}

	if(!(dbnp->dbn_flags & DBN__STREAMTEXT))
		db_regetent(dbnp->dbn_parent, dbnp);
	}

#ifdef notdef

/* it was nice to do it this way. but... (see comment below) */

if((dbfd->dbf_flags & DB_BLANKSEP) && (dbf2->dbf_fstate & DB__PUTENT))
	fprintf(dbfd->dbf_fd, "\n");

#endif

/* slightly strange loop, to allow for DB_STREAM / DB_NOTEXT processing */

for(i = 0;; i++)
	{
	int emptyval = FALSE;

	if(i < dbnp->dbn_nkeys)
		kvp = &dbnp->dbn_keys[i];
#ifdef STREAMDB
	else if((dbnp->dbn_flags & DBN_NOTEXT) && (dbnp->dbn_flags & DBN__STREAMTEXT))
		{
		extern struct keyvalue *db_specialgetkvi();
		kvp = db_specialgetkvi(dbnp->dbn_parent, dbnp, i);
		if(kvp == NULL)
			break;
		}
#endif
	else	break;
	
	if(kvp->kv_flags & KVF_INTERNAL &&
		!((dbf2->dbf_fflags & DB_KEEPCOMMENTS) && (kvp->kv_flags & KVF_COMMENT)))
		continue;

	if((kvp->kv_flags & (KVF_POINTER | KVF_TYPEMASK)) ==
						(KVF_POINTER | KVF_STRING) &&
			(kvp->kv_valstring == NULL ||
				*kvp->kv_valstring == '\0'))
		emptyval = TRUE;	/* awk. */

	if(kvp->kv_key != NULL)
		{
		fprintf(dbfd->dbf_fd, "%s", kvp->kv_key);

		if((dbf2->dbf_fflags & DB_XKEYSEP) &&
					(kvp->kv_flags & KVF_SPECIALNAME))
			;
		else if((dbf2->dbf_fflags & (DB_KEYCHAR | DB_KYCHINTUIT)) ||
					(kvp->kv_flags & KVF_COLONNAME))
			{
			fputc(dbf2->dbf_keychar, dbfd->dbf_fd);

			if(!(dbf2->dbf_fflags & DB_KEYNOSTRIP) && !emptyval &&
					!(kvp->kv_flags & KVF_NOSPACE))
				fputc(' ', dbfd->dbf_fd);
			}
		else if(!emptyval)
			{
			fputc(' ', dbfd->dbf_fd);
			}
		}

	db_fmtval(dbfd->dbf_fd, NULL, kvp);

	fprintf(dbfd->dbf_fd, "\n");
	}

/*
 *  It was nice to put out lines only between entries, but having one always
 *  at the end makes concatenating db's (especially mailbox files) easier.
 *  (Pascal vs. C semicolons as separator vs. terminator comes to mind.)
 */

if(dbf2->dbf_fflags & DB_BLANKSEP)
	fprintf(dbfd->dbf_fd, "\n");

dbf2->dbf_fstate |= DB__PUTENT;

return TRUE;
}

/*
 *  Don't really need the full generality of db_fmtval yet (in fact,
 *  as of today, most of the types in kv_valunion are still ifdeffed out),
 *  but today was the day to go ahead and write it anyway.
 */

static char badfmt[] = "%s: fmt mismatch\n";

db_fmtval(fp, fmt, kvp)
FILE *fp;
char *fmt;
struct keyvalue *kvp;
{
void *valp;
int fmtc = EOF;

if(kvp == NULL)
	return;

if(fmt != NULL && *fmt == '\0')
	fmt = NULL;

if(fmt != NULL)
	fmtc = fmt[strlen(fmt)-1];	/* XXX wrong if someone gets clever */
		/* and sends fmt embedded in some surrounding boilerplate */

if(kvp->kv_flags & KVF_POINTER)
	valp = kvp->kv_valptr;
else	valp = &kvp->kv_valunion;

if(valp == NULL)
	return;

switch(kvp->kv_flags & KVF_TYPEMASK)
	{
	case KVF_STRING:
		if(fmt == NULL)
			fmt = "%s";
		else if(fmtc != 's')
			{
			fprintf(stderr, badfmt, progname);
			putc('?', fp);
			break;
			}

		fprintf(fp, fmt, valp);
		break;

	case KVF_INT:
		if(fmt == NULL)
			fmt = "%d";
		else if(strchr("duoxi", fmtc) == NULL)
			{
			fprintf(stderr, badfmt, progname);
			putc('?', fp);
			break;
			}

		fprintf(fp, fmt, *(int *)valp);
		break;

	case KVF_LONG:
	case KVF_OFFSET:
		if(fmt == NULL)
			fmt = "%s";
		else if(strchr("duoxi", fmtc) == NULL)
			{			/* oughta check for 'l', too */
			fprintf(stderr, badfmt, progname);
			putc('?', fp);
			break;
			}

		if((kvp->kv_flags & KVF_TYPEMASK) == KVF_LONG)
			fprintf(fp, fmt, *(long *)valp);
		else
			fprintf(fp, fmt, (unsigned long)(*(off_t *)valp));
		break;

	case KVF_DOUBLE:
		if(fmt == NULL)
			fmt = "%s";
		else if(strchr("efgFG", fmtc) == NULL)
			{
			fprintf(stderr, badfmt, progname);
			putc('?', fp);
			break;
			}

		fprintf(fp, fmt, *(double *)valp);
		break;

	case KVF_DATETIME:
		{
		struct tm *tmp;
		char buf[50];
		if(fmt == NULL)
			fmt = "%c";

		tmp = localtime((time_t *)valp);
		strftime(buf, sizeof(buf), fmt, tmp);
		fprintf(fp, "%s", buf);
		break;
		}

	case KVF_DB:
	case KVF_DBNODE:
	case KVF_ENUM:
	case KVF_INDEX:
	case KVF_TMPNODESTR:
	case KVF_TMPDBSTR:
	case KVF_VERSIONS:
	}
}
