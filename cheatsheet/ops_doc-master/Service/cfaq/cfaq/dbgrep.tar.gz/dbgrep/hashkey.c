/*
 *  plaintext "database" library -- functions for hashing key names
 *
 *  Copyright 1990-2002
 *  Steve Summit, scs@eskimo.com
 *  This code may be freely redistributed and used
 *  so long as the author's name and this notice remain intact,
 *  and any modifications are marked as such.
 */

#include <stdlib.h>
#include <string.h>
#include <ctype.h>

#ifdef _tolower
#ifndef tolower
#define tolower _tolower
#endif
#endif

#ifdef _toupper
#ifndef toupper
#define toupper _toupper
#endif
#endif

#define DEF_DB
#include "db.h"
#include "defs.h"

#ifdef __STDC__
#define SAFEREALLOC
#endif

extern int strcmp();
extern int stricmp();

char *
db_hashkey(dbd, string, flags)
struct db *dbd;
char *string;
int flags;
{
struct hashtab *htp;
unsigned int hash;
register char *p;
char **bucket;
char **pp;
int nstr;
int (*cmpfunc)(
#ifdef __STDC__
#ifndef NOPROTOTYPES
	       const char *, const char *
#endif
#endif
					 ) = strcmp;

/* default dbd->db_flags *not* used -- caller must pass if appropriate */

if(string == NULL)
	return NULL;

htp = &dbd->db_keytab;

hash = 0;

for(p = string; *p != '\0'; p++)
	{
	int c = *p;
	if((flags & DB_CASELESS) && isupper(c))
		c = tolower(c);
	hash += c;
	}

hash %= htp->ht_nbuckets;

bucket = htp->ht_buckets[hash];

nstr = 0;

if(flags & DB_CASELESS)
	cmpfunc = stricmp;

if(bucket != NULL)
	{
	for(pp = bucket; *pp != NULL; pp++)
		{
		if((*cmpfunc)(*pp, string) == 0)
			return *pp;
		}

	nstr = pp - bucket;
	}

if(flags & DB_NOALLOC)
	return NULL;


#ifndef SAFEREALLOC
if(bucket == NULL)
	bucket = (char **)malloc((nstr + 1 + 1) * sizeof(char *));
else
#endif
	{
	bucket = (char **)realloc((char *)bucket,
					(nstr + 1 + 1) * sizeof(char *));
	}

if(bucket == NULL)
	return NULL;

htp->ht_buckets[hash] = bucket;

if((bucket[nstr] = malloc(strlen(string) + 1)) == NULL)
	return NULL;

(void)strcpy(bucket[nstr], string);

bucket[nstr + 1] = NULL;

return bucket[nstr];
}
