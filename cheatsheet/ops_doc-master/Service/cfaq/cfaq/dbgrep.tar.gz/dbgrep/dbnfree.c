/*
 *  plaintext "database" library -- deallocation functions
 *
 *  Copyright 1987-2002
 *  Steve Summit, scs@eskimo.com
 *  This code may be freely redistributed and used
 *  so long as the author's name and this notice remain intact,
 *  and any modifications are marked as such.
 */

#include <stdlib.h>

#define DEF_DB
#include "db.h"

db_nfree(dbnp)
struct dbnode *dbnp;
{
#ifdef NTALLOC
register int i;
#endif

if(dbnp == NULL)
	return;

#ifndef NDEBUG
if(dbnp->dbn_parent != NULL)
	{
	db_checkdelete(dbnp->dbn_parent, dbnp);
	db_chktindx(dbnp->dbn_parent, dbnp);
	}
#endif

#ifdef NTALLOC

for(i = 0; i < dbnp->dbn_ntxtptrs; i++)
	free(dbnp->dbn_txtptrs[i]);
free(dbnp->dbn_txtptrs);

#else

db_kvfree(dbnp->dbn_keys, dbnp->dbn_nkeys);

#ifdef CHECKPOINT
if(dbnp->dbn_chkp_keys != NULL)
	db_kvfree(dbnp->dbn_chkp_keys, dbnp->dbn_chkp_nkeys);
#endif

#endif

if(dbnp->dbn_keys != NULL)
	free((char *)dbnp->dbn_keys);

free((char *)dbnp);
}

void
db_kvfree(keys, nkeys)
struct keyvalue *keys;
int nkeys;
{
register struct keyvalue *kvp;
register struct keyvalue *endkvp = &keys[nkeys];

for(kvp = keys; kvp < endkvp; kvp++)
	{
	if((kvp->kv_flags & (KVF_POINTER | KVF_MALLOCED)) == (KVF_POINTER | KVF_MALLOCED) &&
						kvp->kv_valptr != NULL)
		free(kvp->kv_valptr);	/* XXX assumes all kv_valptrs compat. */
	}
}
