/*
 *  plaintext "database" library -- read db nodes from file
 *
 *  Copyright 1987-2002
 *  Steve Summit, scs@eskimo.com
 *  This code may be freely redistributed and used
 *  so long as the author's name and this notice remain intact,
 *  and any modifications are marked as such.
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <assert.h>

#define DEF_DB
#include "db.h"
#include "defs.h"

#define iswhite(c)  ((c) == ' ' || (c) == '\t')

#ifdef __STDC__

static stashoffset(struct dbfd *, struct db *, struct dbnode *dbnp, char *);
static dbgeoom(struct dbfd *, int *);
static int xstrcmp(char *, char *);

#endif

static stashoffset();
static dbgeoom();
static int xstrcmp();

#ifdef VMLIMIT

#ifdef __STDC__

extern char *lmalloc(int);
extern char *lrealloc(char *, int);

#endif

extern char *lmalloc();
extern char *lrealloc();

#else

#define lmalloc malloc
#define lrealloc realloc

#endif

#ifdef NTALLOC

#ifdef __STDC__

extern char *db_ntalloc(struct dbnode *, int);
extern char *db_ntrealloc(struct dbnode *, char *, int);

#endif

extern char *db_ntalloc();
extern char *db_ntrealloc();

#else

#define db_ntalloc(dbnp, n) lmalloc(n)
#define db_ntrealloc(dbnp, p, n) lrealloc(p, n)

#endif

#ifdef __STDC__
extern void panic(char *, ...);
#endif

db_read(dbd, dbfd)
struct db *dbd;
struct dbfd *dbfd;
{
struct dbnode **prevp;
register struct dbnode *dbnp;
struct dbfd *prevfd = dbd->db_dbfd;

if(dbfd->dbf_mode != 'r' && dbfd->dbf_mode != '?')
	{
	db_error(dbd, "error", "db_read: dbfd not open for reading");
	return FALSE;
	}

dbd->db_dbfd = dbfd;

prevp = &dbd->db_list;

while((dbnp = db_fgetent(dbfd, dbd, (struct dbnode *) NULL, 0, (int *)NULL)) != NULL)
	{
	*prevp = dbnp;
	prevp = &dbnp->dbn_next;
	dbd->db_tail = dbnp;
	}

dbd->db_dbfd = prevfd;

return TRUE;
}

struct dbnode *
db_getent(dbfd, dbd)
struct dbfd *dbfd;
struct db *dbd;
{
struct dbnode *ret;
struct dbfd *prevfd = dbd->db_dbfd;
dbd->db_dbfd = dbfd;	/* awkward to have to do this every time */
ret = db_fgetent(dbfd, dbd, (struct dbnode *)NULL, 0, (int *)NULL);
dbd->db_dbfd = prevfd;
return ret;
}

extern struct keyvalue *db_gtkv2();

db_dbfregetent(dbd, dbnp)
struct db *dbd;
struct dbnode *dbnp;
{
struct keyvalue *kvp;

#ifdef STREAMDB
if(dbnp->dbn_flags & DBN__STREAMTEXT)	/* ? or dbf_flags DB_STREAM? */
	return FALSE;
else
#endif
     if(dbnp->dbn_flags & DBN_INDEXONLY)
	kvp = db_gtkv2(dbd, dbnp, ".offset", DB_CHECKRET | DB_KVINTERNAL, 0);
else if(dbnp->dbn_flags & DBN_NOTEXT)
	kvp = db_gtkv2(dbd, dbnp, ".textoffset", DB_CHECKRET | DB_KVINTERNAL, 0);
else	return TRUE;

if(kvp == NULL)
	return FALSE;

if(dbd->db_dbfd == NULL)
	return FALSE;

/* XXX worry that kv isn't ptr to offset */

fseek(dbd->db_dbfd->dbf_fd, *(off_t *)kvp->kv_valptr, 0);
if(db_fgetent(dbd->db_dbfd, dbd, dbnp, DB_REREAD, (int *)NULL) == NULL)
	return FALSE;

dbnp->dbn_flags &= ~(DBN_INDEXONLY | DBN_NOTEXT);	/* XXX might not always wanna turn off both */

/* now delete offset? (would make later reloading after purging much harder) */

return TRUE;
}

struct dbnode *
db_fgetent(dbfd, dbd, dbnp, flags, statusp)
register struct dbfd *dbfd;
struct db *dbd;
register struct dbnode *dbnp;
int flags;
int *statusp;
{
struct dbf *dbf2;
int newone = TRUE;			/* assumes we're called at the beginning of the file, */
					/* or with the fp positioned at the beginning of a record. */
					/* If that's not true (if we're rereading in the middle */
					/* of a record, for whatever reason) it'll get reset to */
					/* FALSE before we start reading.  (It's also reset */
					/* to FALSE after each trip through the main loop.) */

static struct dbnode *savedbnp = NULL;	/* partial dbnp from last time, */
					/* if we ran out of memory halfway through */
					/* (should probably be in dbd or dbfd, not static) */
register char *p;
char *key;
char *sep;
int r;
int kvflags = 0;
int kvi = 0;
int addkflags = DB_BUILDING | DB_NOHISTORY;
int status = DB_OK;
#ifdef DEBUG
int reusing = FALSE;
#endif

if((dbf2 = dbfd->dbf_fmtspecif) == NULL || dbf2->dbf_magic != DBFMAGIC)
	panic("db_fgetent: not dbf file");

if(dbfd->dbf_mode != 'r' && dbfd->dbf_mode != '?')
	{
	db_error(dbd, "error", "db_fgetent: dbfd not open for reading");
	return NULL;
	}

if(savedbnp != NULL)
	{
	assert(dbnp == NULL);

	fprintf(stderr, "warning: the out-of-memory restart code has been merged\n");
	fprintf(stderr, "too many times to be trustworthy, and needs testing\n");
	/* there!  *that* should remind me... */

#ifdef DEBUG
	fprintf(stderr, "db_fgetent: reusing ");
	if(savedbnp->dbn_nkeys > 0)
		fprintf(stderr, "%s: %s", savedbnp->dbn_keys[0].kv_key,
					savedbnp->dbn_keys[0].kv_value);
	else	fprintf(stderr, "[0]");
	fprintf(stderr, "\n");
#endif

	dbnp = savedbnp;
	savedbnp = NULL;
	newone = FALSE;
#ifdef DEBUG
	reusing = TRUE;
#endif
	}

if(flags & DB_REREAD)
	{
	assert(dbnp != NULL);
	newone = FALSE;
	}

#ifdef STREAMDB

if(flags & DB_STMRD1)
	{
	assert(dbnp != NULL);
	addkflags |= DB_CHEATALLOC;
	newone = FALSE;
	}
else if(dbf2->dbf_fstate & DB__INTR)
	{
	/* (means it never got reread, so we'll skip it first) */
	assert(dbnp == NULL);
	newone = FALSE;
	}

if((dbfd->dbf_gflags & DB_STREAM) && (flags & DB_STMRD1) && (dbf2->dbf_fstate & DB__BLANKS))
	{
	assert(dbnp != NULL);
	/* XXX is kvflags appropriately set?  should we just pass 0? */
	if(!db_addfkey(dbd, dbnp, (char *)NULL, "", kvflags, addkflags))
		panic("dbread: out of memory (inopportune addkey failure)");
	dbfd->dbf_nblank--;
	if(dbfd->dbf_nblank <= 0)
		dbf2->dbf_fstate &= ~DB__BLANKS;
	if(statusp != NULL)
		*statusp = DB_1ONLY;
	return dbnp;
	}

#endif

/*
 *  Overall algorithm:
 *  Step 1: characterize line just read
 *  Step 2: finish partitioning key & value; check (most) new node cases
 *  Step 3: actually stash k/v pair
 */
 
while((r = db_getline(dbfd)) != EOF)
	{
	char *cp = NULL;
	char sepc;

	/*
	 *  Step 1: characterize line just read
	 *	1A: first check for blank lines
	 *	1B: then continuation lines
	 *	1C: then comments
	 *	1D: then xkeysep (e.g. "From ")
	 *	1E: then implicit text
	 *	1F: then regular key/value pairs
	 *	1G: then junk fall-through
	 */

	p = dbfd->dbf_lbuf;

	if(!(dbf2->dbf_fflags & (DB_CONTIN | DB_RFC822)))
		{
		/* skip leading whitespace: */

		for(; iswhite(*p); p++)
			;

		/* maybe also warn, at least under some conditions */
		}

	/* 1A: blank line */

	if(*p == '\0')
		{
		if((dbf2->dbf_fflags & DB_BLANKSEP) &&
			!(dbf2->dbf_fflags & (DB_KEYSEP | DB_XKEYSEP)) &&
				dbnp != NULL)
			{
			db_kvfinish(dbnp);
#ifdef STREAMDB
			dbf2->dbf_fstate &= ~DB__INTR;	/* XXX awk. repetition */
#endif
			if(statusp != NULL)
				*statusp = status;

#ifdef STREAMDB

			if(flags & DB_STMRD1)
				return NULL;
#endif

#ifdef DEBUG
			if(reusing)
				{
				fprintf(stderr, "db_fgetent (case 1) returning:\n");
				dumpnode(dbnp, stderr);
				}
#endif
			return dbnp;
			}

		if(dbf2->dbf_fflags & DB_RFC822)
			{
			/* might be header separator, might be within text, might be between msgs */

			if(dbnp != NULL && !(dbf2->dbf_fstate & DB__INBODY))
				{
				/* (this case is probably untested) */
				dbf2->dbf_fstate |= DB__INBODY;
				/* XXX flags | dbf2->dbf_flags */
				if(((flags | dbf2->dbf_fflags) & DB_NOTEXT) &&
				    !(flags & (DB_REREAD | DB_STMRD1)))
					{
#ifdef STREAMDB
					if((dbfd->dbf_gflags & DB_STREAM) && dbnp != NULL)
						{
						db_ungetline(dbfd, dbfd->dbf_lbuf);
						dbnp->dbn_flags |= DBN_NOTEXT | DBN__STREAMTEXT;
						dbf2->dbf_fstate |= DB__INTR;
						status = DB_PARTIAL;
#ifdef DEBUG
						fprintf(stderr, "db_fgetent early stream text return (RFC822)\n");
						dumpnode(dbnp, stderr);
#endif
						break;
						}
#endif
					stashoffset(dbfd, dbd, dbnp, ".textoffset");
					dbnp->dbn_flags |= DBN_NOTEXT | DBN__HAVETXTOFF;
					}
				}

			/* XXX worry about multiple separators being returned vs. not returned, */
			/* esp. in stream case */

			dbfd->dbf_nblank++;
			}

		continue;
		}

	/* 1B: continuation lines */

	if(((dbf2->dbf_fflags & DB_CONTIN) ||
		((dbf2->dbf_fflags & DB_RFC822) && !(dbf2->dbf_fstate & DB__INBODY))) &&
								iswhite(*p))
		{
		/* header continuation line */

		struct keyvalue *kvp;
		int oldlen;
		int oldsize;
		int newlen;

#ifdef STREAMDB

		if(dbf2->dbf_fstate & DB__INTR)
			continue;
#endif

		if(dbnp == NULL || dbnp->dbn_nkeys == 0)
			{
			/* should use dbfd if dbd->db_dbfd NULL */
			db_error(dbd, "error",
				"impossible header continuation line \"%s\"",
							dbfd->dbf_lbuf);
#ifdef notdef
			muck with dbf_errcount
#endif
			continue;
			}

		kvp = &dbnp->dbn_keys[dbnp->dbn_nkeys - 1];

		oldlen = -1;

		if(dbnp->dbn_flags & DBN_OVERALLOC)
			{
#ifdef notdef
			assert(dbnp->db_ckvp == kvp->kv_value);
#endif
			if(dbnp->dbn_curkvi == dbnp->dbn_nkeys - 1)
				{
				oldlen = dbnp->db_ckvlen;
				oldsize = dbnp->db_ckvsz;
				}
			else	{
				kvp->kv_value =
					db_ntrealloc(dbnp, kvp->kv_value,
							dbnp->db_ckvlen + 1);
				assert(kvp->kv_value != NULL);
				dbnp->dbn_flags &= ~DBN_OVERALLOC;
				}
			}

		if(oldlen < 0)
			{
			oldlen = strlen(kvp->kv_value);
			oldsize = oldlen + 1;
			}

		newlen = oldlen + 1 + strlen(p);

		/* strange.  this used to be newlen >= oldsize, */
		/* and that still looks right, but there was an */
		/* obscure bug here, and adding one seems to fix it... */

		if(newlen + 1 >= oldsize)
			{
			char *newval;
#ifdef DBREAD_CONTIN_REALLOC_OLDWAY
			int newsize = newlen + 1;
#else
			int newsize = oldsize * 2;
			if(newsize < 50)
				newsize = 50;
			if(newsize < newlen + 1)
				newsize = newlen + 1;
#endif

#ifdef DEBUG2
			fprintf(stderr, "*** realloc for contin (%d) ***\n", newsize);
#endif

			newval = db_ntrealloc(dbnp, kvp->kv_value, newsize);

#ifndef DBREAD_CONTIN_REALLOC_OLDWAY

			if(newval == NULL)
				{
				/* back off */
				if(newsize > newlen + 1)
					{
					newsize = newlen + 1;
					newval = db_ntrealloc(dbnp,
						kvp->kv_value, newsize);
					}
				}

#endif

			if(newval == NULL)
				{
				dbgeoom(dbfd, statusp);
				savedbnp = dbnp;
				return NULL;
				}

			dbnp->db_ckvsz = newsize;

			kvp->kv_value = newval;
			}

		kvp->kv_value[oldlen] = '\n';

		strcpy(&kvp->kv_value[oldlen + 1], p);

#ifndef DBREAD_CONTIN_REALLOC_OLDWAY

		if(dbnp->db_ckvsz <= newlen + 1)
			dbnp->dbn_flags &= ~DBN_OVERALLOC;
		else	{
			dbnp->dbn_curkvi = dbnp->dbn_nkeys - 1;
			dbnp->db_ckvlen = newlen;
#ifdef notdef
			dbnp->db_ckvp = kvp->kv_value;		/* needed? */
#endif
			dbnp->dbn_flags |= DBN_OVERALLOC;
			}

#endif

		continue;
		}

#ifndef DBREAD_CONTIN_REALLOC_OLDWAY

	/* next test is imperfect -- if contin line is last in record, we'll never trim back */
	if(dbnp != NULL && dbnp->dbn_flags & DBN_OVERALLOC)
		{
		struct keyvalue *kvp2 = &dbnp->dbn_keys[dbnp->dbn_curkvi];
#ifdef notdef
		assert(dbnp->db_ckvp == kvp2->kv_value);
#endif
		kvp2->kv_value = db_ntrealloc(dbnp, kvp2->kv_value,
					dbnp->db_ckvlen + 1);
		assert(kvp2->kv_value != NULL);
		dbnp->dbn_flags &= ~DBN_OVERALLOC;
		}

#endif

	key = p;
	kvflags = 0;
	sep = NULL;

	/*
	 *  XXX case 1E should probably come before 1C.
	 *  ("But it doesn't matter", you say, "because if there's any
	 *  any implicit text, surely we won't have a comment character
	 *  specified."  Right.  But dbf_commentchar used to be a char,
	 *  meaning that when we "disabled" it by setting it to -1,
	 *  we stripped lines beginning with �...)
	 */

	/* 1C: comments */

#ifdef pdp11
	if(*p == dbf2->dbf_commentchar)		/* XXX */
#else
	if(*(unsigned char *)p == dbf2->dbf_commentchar)
#endif
		{
		if(!(dbf2->dbf_fflags & DB_KEEPCOMMENTS))
			continue;

		kvflags |= KVF_COMMENT | KVF_INTERNAL;
		}
	else

	/* 1D: xkeysep (e.g. "From ") */

	/* look for xkeysep if on first line or if preceding blank line */
	/* or if don't require DB_BLANKSEP */

	if((!(dbf2->dbf_fflags & DB_BLANKSEP) || dbfd->dbf_nblank > 0 ||
						dbfd->dbf_lineno <= 1) &&
			(dbf2->dbf_fflags & DB_XKEYSEP) &&
					xstrcmp(p, dbf2->dbf_sepkey) == 0)
		{
		/*
		 *  Can't \0-separate key in dbfd->dbf_lbuf, so use
		 *  dbfd->dbf_sepkey for key, and use KVF_SPECIALNAME
		 *  to turn off \0-termination below
		 */

		key = dbf2->dbf_sepkey;
		sep = p + strlen(dbf2->dbf_sepkey);
		newone = TRUE;
		kvflags |= KVF_SPECIALNAME;
		/* more initialization (i.e. turning off RFC822 DB__INBODY) */
		/* in common newone code below */
		}

	/* 1E: implicit text */

	/* (this should probably come before most of the rest of the cases, */
	/* in particular, before 1C) */

	/* (used to be a dbnp != NULL test here, too...) */

	else if((dbf2->dbf_fflags & DB_RFC822) &&
					(dbf2->dbf_fstate & DB__INBODY))
		{
		/* regular text line */
#ifdef STREAMDB
		if((dbf2->dbf_fstate & DB__INTR) && !(flags & DB_STMRD1))
			{
			dbfd->dbf_nblank = 0;
			continue;
			}
#endif

		assert(dbnp != NULL);	/* should maybe just be a "funny line" warning... */

		/* XXX flags | dbf2->dbf_flags */
		if(((flags | dbf2->dbf_fflags) & DB_NOTEXT) && !(flags & DB_REREAD))
			{
#ifdef STREAMDB
			if(dbfd->dbf_gflags & DB_STREAM)
				{
				assert(flags & DB_STMRD1);
				if(dbfd->dbf_nblank > 0)
					{
					db_ungetline(dbfd, dbfd->dbf_lbuf);
					if(!db_addfkey(dbd, dbnp, (char *)NULL, "", kvflags, addkflags))
						panic("dbread: out of memory (inopportune addkey failure)");
					dbfd->dbf_nblank--;
					if(dbfd->dbf_nblank > 0)
						dbf2->dbf_fstate |= DB__BLANKS;
					}
				else	{
					/* duplicates 2nd db_addfkey call below */
					if(!db_addfkey(dbd, dbnp, (char *)NULL, p, kvflags, addkflags))
						panic("dbread: out of memory (inopportune addkey failure)");
					}
				status = DB_1ONLY;
				break;
				}
#endif
			/* else non-stream, NOTEXT case */

			continue;
			}

		while(dbfd->dbf_nblank > 0)
			{
			if(!db_addfkey(dbd, dbnp, (char *)NULL, "", kvflags, addkflags))
				{
				/* TODO: make sure nblank cached right */
				dbgeoom(dbfd, statusp);
				savedbnp = dbnp;
				return NULL;
				}

			dbfd->dbf_nblank--;
			}

		if(!db_addfkey(dbd, dbnp, (char *)NULL, p, kvflags, addkflags))
			{
			dbgeoom(dbfd, statusp);
			savedbnp = dbnp;
			return NULL;
			}

		continue;
		}

	/* 1F: regular key/value pairs */

	else if((dbf2->dbf_fflags & DB_KEYCHAR))
		{
		sep = strchr(p, dbf2->dbf_keychar);
		}
	else	{
		for(sep = p; *sep != '\0'; sep++)
			{
			if(iswhite(*sep))
				break;

			/* if neither DB_KEYCHAR nor DB_KEYBLANK, */
			/* intuit whether whitespace or dbf_keychar separates */

			if(!(dbf2->dbf_fflags & DB_KEYBLANK))
				{
				if(*sep == dbf2->dbf_keychar)
					{
					kvflags |= KVF_COLONNAME;
					/* probably oughta be on dbn, not kv */
					if(!(dbf2->dbf_fflags & DB_KEYCHAR))
					     dbf2->dbf_fflags |= DB_KYCHINTUIT;
					break;
					}
				}
			}

		if(*sep == '\0')
			sep = NULL;
		}

	/* 1G: junk fall-through */

	/* sep is now value */

	if(sep == NULL)
		{
		if((dbf2->dbf_fflags & DB_DEFTEXT) ||
				(dbf2->dbf_fflags & DB_KEEPCOMMENTS) && (kvflags & KVF_COMMENT))
			{
			key = NULL;
			sep = p;
			}
		else	{
			/* should use dbfd if dbd->db_dbfd NULL */
			db_error(dbd, "error", "funny line \"%s\"",
				    			dbfd->dbf_lbuf);
#ifdef notyet
			if(++dbfd->dbf_errcount >= dbfd->dbf_errlimit)
				{
				db_error(dbd, "error",
						"too many errors; aborting");
				status = DB_ERR;
				break;
				}
#endif
			continue;
			}
		}

	/* Step 2: finish partitioning key & value; check (most) new node cases */

	if(key != NULL)
		{
		if(!((dbf2->dbf_fflags & DB_XKEYSEP) &&
				(kvflags & KVF_SPECIALNAME)))
			{
			sepc = *sep;
			cp = sep++;
			*cp = '\0';
			}

		if(dbf2->dbf_fflags & DB_KEYONESTRIP)
			{
			if(*sep == ' ')
				sep++;
			else	{
				/* warn? */
				kvflags |= KVF_NOSPACE;
				}
			}
		else if(!(dbf2->dbf_fflags & DB_KEYNOSTRIP))
			{
			/* if(!iswhite(*sep)), set KVF_NOSPACE? */
			while(iswhite(*sep))
				sep++;
			}
		}

	/* main new node test: */

	if(dbf2->dbf_sepkey != NULL && !(dbf2->dbf_fflags & DB_XKEYSEP))
		{
		if((!(dbf2->dbf_fflags & DB_BLANKSEP) || dbfd->dbf_nblank > 0 ||
						dbfd->dbf_lineno <= 1) &&
				strcmp(key, dbf2->dbf_sepkey) == 0)
			newone = TRUE;
		}

	if(dbnp != NULL && (dbnp->dbn_flags & DBN_COMMENT) && !(kvflags & KVF_COMMENT))
		newone = TRUE;

	/*
	 *  new node discriminator: distinguish between
	 *  (1) start of first node we've seen, namely the node we're to read
	 *  (2) start of *next* node, which terminates the one we've been reading
	 *
	 *  Simplistically:
	 *  If dbnp is not null, we've been reading a node,
	 *  so we've just seen the start of the next node,
	 *  so ungetline and return.
	 *  If dbnp is null, we haven't read anything yet,
	 *  so allocate new node & proceed.
	 *
	 *  There had been a bunch of gory exceptions here
	 *  (involving comments, DB_REREAD, and reusing after oom)
	 *  to that simple rule (which is why this comment sounds
	 *  as if it was going to get longwinded), but they were
	 *  far too complicated for me to even understand,
	 *  let alone describe, so I've moved them elsewhere
	 *  (where they probably belonged all along).
	 */

	if(newone && dbnp != NULL)
		{
		/* finish off old node & return */
		if(cp != NULL)
			*cp = sepc;
		db_ungetline(dbfd, dbfd->dbf_lbuf);
		db_kvfinish(dbnp);

#ifdef STREAMDB
		dbf2->dbf_fstate &= ~DB__INTR;	/* XXX awk. repetition */
#endif

		if(statusp != NULL)
			*statusp = status;

#ifdef STREAMDB

		if(flags & DB_STMRD1)
			return NULL;
#endif

#ifdef DEBUG
		if(reusing)
			{
			fprintf(stderr, "db_fgetent (case 2) returning:\n");
			dumpnode(dbnp, stderr);
			}
#endif
		return dbnp;
		}

	/* else continue existing node, or start new one */

	if(newone)
		{
		dbf2->dbf_fstate &= ~DB__INBODY;
		dbfd->dbf_nblank = 0;
#ifdef STREAMDB
		dbf2->dbf_fstate &= ~DB__INTR;
#endif
		}

	if(dbnp == NULL && !(dbf2->dbf_fstate & DB__INTR))
		{
		/* start new node */

		/* (can't use db_nalloc, because it calls alloc and so panics if out of memory) */

		dbnp = (struct dbnode *)lmalloc(sizeof(struct dbnode));

		if(dbnp == NULL)
			{
			if(cp != NULL)
				*cp = sepc;
			dbgeoom(dbfd, statusp);
			return NULL;
			}

		db_ninit(dbnp);
		dbnp->dbn_parent = dbd;

		if(dbfd->dbf_gflags & (DB_INDEXONLY | DB_STASHOFFSET))
			{
			stashoffset(dbfd, dbd, dbnp, ".offset");
			if(dbfd->dbf_gflags & DB_INDEXONLY)
				dbnp->dbn_flags |= DBN_INDEXONLY;
			}

		if((dbf2->dbf_fflags & DB_KEEPCOMMENTS) && (kvflags & KVF_COMMENT))
			dbnp->dbn_flags |= DBN_COMMENT;
		}

	/* Step 3: finally actually stash k/v pair */

	kvi++;

	if(dbfd->dbf_gflags & DB_KEYSONLY)
		(void)db_hashkey(dbd, key, dbd->db_flags);

	if((dbfd->dbf_gflags & (DB_INDEXONLY|DB_KEYSONLY)) && !(flags & DB_REREAD) && !isindexkey(dbd, key))
		/* do nothing */ ;
	else if((flags & DB_REREAD) && isindexkey(dbd, key))
		/* do nothing */ ;
#ifdef STREAMDB
	else if(dbf2->dbf_fstate & DB__INTR)
		;
#endif
	/* XXX flags | dbf2->dbf_flags */
	else if((key == NULL || *key == '\0') && ((flags | dbf2->dbf_fflags) & DB_NOTEXT) &&
			!(flags & (DB_REREAD | DB_STMRD1)))
		{
#ifdef STREAMDB
		if(dbfd->dbf_gflags & DB_STREAM)
			{
			db_ungetline(dbfd, dbfd->dbf_lbuf);
			dbnp->dbn_flags |= DBN_NOTEXT | DBN__STREAMTEXT;
			dbf2->dbf_fstate |= DB__INTR;
			status = DB_PARTIAL;
#ifdef DEBUG
			fprintf(stderr, "db_fgetent early stream text return (normal text)\n");
			dumpnode(dbnp, stderr);
#endif
			break;
			}
		else
#endif
		if(!(dbnp->dbn_flags & DBN__HAVETXTOFF))	/* or maybe db_haskey()? */
			{
			stashoffset(dbfd, dbd, dbnp, ".textoffset");
			dbnp->dbn_flags |= DBN_NOTEXT | DBN__HAVETXTOFF;
			}
		}
	else	{
		int r2;
		if(!(flags & DB_REREAD))
			r2 = db_addfkey(dbd, dbnp, key, sep, kvflags, addkflags);
		else	{
			struct keyvalue tmpkv;
			tmpkv.kv_key = key;
			tmpkv.kv_valstring = sep;
			tmpkv.kv_flags = KVF_POINTER | KVF_STRING | kvflags;
			r2 = db_iaddkey(dbd, dbnp, &tmpkv, kvi-1, addkflags);
			}	

		if(!r2)
			{
			if(cp != NULL)
				*cp = sepc;
			dbgeoom(dbfd, statusp);
			savedbnp = dbnp;
			return NULL;
			}
		}

	if(cp != NULL)
		*cp = sepc;

#ifdef STREAMDB

	if(flags & DB_STMRD1)
		{
		status = DB_1ONLY;
		break;
		}

#endif

	newone = FALSE;
	}

if((flags & DB_REREAD) && kvi == 0)
	{
	db_error(dbd, "error", "db_fgetent: premature EOF");
	status = DB_ERR;
	}

if(dbnp != NULL)
	db_kvfinish(dbnp);
else if(status != DB_OK)
	;
else if(ferror(dbfd->dbf_fd))
	status = DB_ERR;
else	status = DB_EOF;

#ifdef STREAMDB
if(status != DB_PARTIAL && status != DB_1ONLY && (flags & DB_STMRD1))
	dbf2->dbf_fstate &= ~DB__INTR;	/* XXX awk. repetition */
#endif

if(statusp != NULL)
	*statusp = status;

#ifdef STREAMDB

if(status != DB_PARTIAL && status != DB_1ONLY && (flags & DB_STMRD1))
	return NULL;

#endif

#ifdef DEBUG
if(reusing)
	{
	fprintf(stderr, "db_fgetent (case 3) returning:\n");
	dumpnode(dbnp, stderr);
	}
#endif

return dbnp;
}

static
stashoffset(dbfd, dbd, dbnp, key)
register struct dbfd *dbfd;
struct db *dbd;
register struct dbnode *dbnp;
char *key;
{
struct keyvalue tmpkv;
tmpkv.kv_key = key;
tmpkv.kv_valptr = &dbfd->dbf_lbeg;
tmpkv.kv_flags = KVF_POINTER | KVF_OFFSET | KVF_INTERNAL;
if(!db_iaddkey(dbd, dbnp, &tmpkv, -1, DB_BUILDING | DB_NOHISTORY))
	panic("dbread: out of memory (inopportune addkey failure)");
}

/* db get entry out of memory handler */

static
dbgeoom(dbfd, statusp)
struct dbfd *dbfd;
int *statusp;
{
if(statusp == NULL)		/* odd test */
	{
	/* XXX Aargh! no dbd */
	db_error((struct db *)NULL, "error", "db_getent: out of memory");
	exit(1);
	}

#ifdef DEBUG
fprintf(stderr, "dbgeoom: unget \"%s\"\n", dbfd->dbf_lbuf);
#endif

db_ungetline(dbfd, dbfd->dbf_lbuf);

*statusp = DB_NOMEM;
}

static int
xstrcmp(s1, s2)
char *s1, *s2;
{
/* XXX pretty inefficient to call strlen every time... */
return strncmp(s1, s2, strlen(s2));
}
