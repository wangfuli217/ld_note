#ifndef RGIFP_H
#define RGIFP_H

struct rgifp
	{
	void *ctx;
	int flags;
#ifdef __STDC__
	int (*getfunc)(void *);
	int (*ungetfunc)(int, void *);
	long int (*tellfunc)(void *);
	int (*seekfunc)(void *, long int, int);
#else
	int (*getfunc)();
	int (*ungetfunc)();
	long int (*tellfunc)();
	int (*seekfunc)();
#endif
	};

/* flag values: */

#define FREECTX 0x01

#define RGgetc(ifp)	(*ifp->getfunc)(ifp->ctx)
#define RGungetc(c, ifp) (*ifp->ungetfunc)(c, ifp->ctx)
#define RGtell(ifp)	(*ifp->tellfunc)(ifp->ctx)
#define RGseek(ifp, o, w) (*ifp->seekfunc)(ifp->ctx, o, w)
#define RGrewind(ifp)	(*ifp->seekfunc)(ifp->ctx, 0L, 0)

#ifdef __STDC__

extern struct rgifp *rgfpifp(FILE *);
extern struct rgifp *rgstrifp(char *);
extern char *rgstrcur(struct rgifp *);

#endif

extern struct rgifp *rgfpifp();
extern struct rgifp *rgstrifp();
extern char *rgstrcur();

#endif
