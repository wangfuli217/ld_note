#ifndef ARGD_H
#define ARGD_H

struct argd	/* descriptor for args read from argv or -f file */
	{
	int ad_which;
	int ad_flags;
	union	{
		struct	{
			int adu_argc;
			char **adu_argv;
			int *adu_argp;
			} adu_av;
		struct	{
			FILE *adu_fd;
			char *adu_fname;	/* if known */
			char *adu_buf;
			int adu_bufsize;
			int adu_lineno;
			} adu_file;
		} ad_u;

	struct argd *ad_next;		/* when stacked */
	};

#define ad_argc		ad_u.adu_av.adu_argc
#define ad_argv		ad_u.adu_av.adu_argv
#define ad_argp		ad_u.adu_av.adu_argp

#define ad_fd		ad_u.adu_file.adu_fd
#define ad_filename	ad_u.adu_file.adu_fname
#define ad_buf		ad_u.adu_file.adu_buf
#define ad_bufsize	ad_u.adu_file.adu_bufsize
#define ad_lineno	ad_u.adu_file.adu_lineno

#define AD_ARGV		1
#define AD_FILE		2

#define AD_HAVEARG	01
#define AD_EOARGS	02

extern struct argd *mkargvd();
extern struct argd *mkfiled();

extern char *peekarg();
extern char *nxtarg();

#endif
