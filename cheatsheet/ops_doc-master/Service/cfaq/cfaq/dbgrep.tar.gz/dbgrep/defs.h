#ifndef DEFS_H
#define DEFS_H

#define TRUE 1
#define FALSE 0

#ifndef NULL
#define NULL 0
#endif

#define Min(a, b) ((a) < (b) ? (a) : (b))
#define Max(a, b) ((a) > (b) ? (a) : (b))

#define Streq(s1, s2) (strcmp(s1, s2) == 0)

#define Ctod(c) ((c) - '0')

#endif
