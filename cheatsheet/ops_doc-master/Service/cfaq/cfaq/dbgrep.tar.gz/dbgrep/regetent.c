/*
 *  plaintext "database" library --
 *  finish fetching node's contents (if only partially read)
 *
 *  Copyright 1998-2002
 *  Steve Summit, scs@eskimo.com
 *  This code may be freely redistributed and used
 *  so long as the author's name and this notice remain intact,
 *  and any modifications are marked as such.
 */

#include <stddef.h>
#define DEF_DB
#include "db.h"
#include "error.h"

db_regetent(dbd, dbnp)
struct db *dbd;
struct dbnode *dbnp;
{
if(dbd->db_dbfd == NULL)
	panic("db_regetent: db_dbfd NULL");
if(dbd->db_dbfd->dbf_funcs == NULL || dbd->db_dbfd->dbf_funcs->dbf_regetent == NULL)
	panic("db_regetent: no dbf regetent func");
return (*dbd->db_dbfd->dbf_funcs->dbf_regetent)(dbd, dbnp);
}
