/*
 * ba_create.c -- create an empty set
 *
 * Part of publib.  See man page for more information
 * "@(#)publib-bitarr:ba_create.c,v 1.3 1994/07/16 15:28:27 liw Exp"
 */

#include <stdlib.h>
#include "publib/bitarr.h"
#include "publib/errormsg.h"

Bitarr *ba_create(void) {
	Bitarr *u;

	u = malloc(sizeof(Bitarr));
	if (u == NULL) {
		__publib_error("malloc failed");
		return NULL;
	}

	u->w = NULL;
	u->rnglen = 0;

	return u;
}
