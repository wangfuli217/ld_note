/*
 * ba_not.c -- complement a set
 *
 * Part of publib.  See man page for more information
 * "@(#)publib-bitarr:ba_not.c,v 1.1.1.1 1993/11/20 17:00:34 liw Exp"
 */

#include <assert.h>
#include "publib/bitarr.h"

void ba_not(Bitarr *u) {
	size_t i, size;

	assert(u != NULL);
	assert(u->rnglen == 0 || u->w != NULL);

	size = ba_num2word(u->rnglen);
	for (i = 0; i < size; ++i)
		u->w[i] = ~u->w[i];
}
