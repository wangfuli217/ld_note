/*
 * ba_clear_all.c -- make set empty
 *
 * Part of publib.  See man page for more information
 * "@(#)publib-bitarr:ba_clear_all.c,v 1.1.1.1 1993/11/20 17:00:34 liw Exp"
 */

#include <assert.h>
#include <string.h>
#include "publib/bitarr.h"

void ba_clear_all(Bitarr *u) {
	assert(u != NULL);
	assert(u->rnglen == 0 || u->w != NULL);

	if (u->rnglen > 0)
		memset(u->w, 0, ba_num2word(u->rnglen));
}
