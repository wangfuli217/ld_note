/*
 * strrev.c -- reverse a string in place
 *
 * Part of publib.  See man page for more information
 * "@(#)publib-strutil:strrev.c,v 1.1.1.1 1994/02/03 17:25:30 liw Exp"
 */

#include <assert.h>
#include "publib/strutil.h"

char *strrev(char *s) {
	char c, *t, *origs = s;

	assert(s != NULL);

	for (t = s+strlen(s); s < t; ++s, --t) {
		c = *s;
		*s = *t;
		*t = c;
	}
	return origs;
}
