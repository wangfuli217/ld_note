/*
 * xmalloc.c -- error checking malloc
 *
 * Part of publib.  See man page for more information
 * "@(#)publib-alloc:xmalloc.c,v 1.2 1994/02/06 09:42:33 liw Exp"
 */

#include <assert.h>
#include <stdlib.h>
#include "publib/alloc.h"
#include "publib/errormsg.h"

void *xmalloc(size_t n) {
	char *q;

	assert(n > 0);
	q = malloc(n);
	if (q == NULL)
		__publib_error("malloc failed");
	return q;
}
