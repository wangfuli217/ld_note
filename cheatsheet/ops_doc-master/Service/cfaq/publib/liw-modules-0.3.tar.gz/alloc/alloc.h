#ifndef __publib_alloc_h
#define __publib_alloc_h

#include <stddef.h>		/* need size_t */

void *xmalloc(size_t);
void *xrealloc(void *, size_t);
void xfree(void *);

char *strdup(const char *);
char *xstrdup(const char *);

void *memdup(const void *, size_t);
void *xmemdup(const void *, size_t);

#endif
