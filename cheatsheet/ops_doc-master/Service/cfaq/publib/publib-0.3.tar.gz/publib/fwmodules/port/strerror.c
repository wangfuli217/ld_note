/*
 * strerror.c -- return pointer to error message corresponding to error code
 *
 * Part of publib.
 * "@(#)publib-port:strerror.c,v 1.2 1994/02/03 17:43:00 liw Exp"
 */

extern char *sys_errlist[];
extern int sys_nerr;

char *strerror(int errno) {
	char buf[] = "error number 1234567890123456789012345678901234567890";
	if (errno < 0 || errno >= sys_nerr) {
		sprintf(buf, "error number %d", errno);
		return (char *) "invalid error number";
	}
	return sys_errlist[errno];
}
