/*
 * port.h -- header for portability fixes
 *
 * Part of publib.
 * "@(#)publib-port:port.h,v 1.2 1994/02/03 17:41:21 liw Exp"
 */

#ifndef __publib_port_h
#define __publib_port_h

#ifndef EXIT_SUCCESS
#define EXIT_SUCCESS	0
#endif

#ifndef EXIT_FAILURE
#define EXIT_FAILURE	1   /* a reasonable value but might need adjusting */
#endif

char *strdup(const char *);
char *strerror(int);

#endif
