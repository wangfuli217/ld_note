#!/bin/bash
sh version.sh
make -j
