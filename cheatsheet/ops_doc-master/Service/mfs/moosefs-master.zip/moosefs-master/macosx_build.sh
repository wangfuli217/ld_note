#!/usr/bin/env bash

./configure --prefix=/usr/local --sysconfdir=/private/etc
make
