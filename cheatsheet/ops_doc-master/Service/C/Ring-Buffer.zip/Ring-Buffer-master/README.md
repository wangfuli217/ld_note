Ring-Buffer
===========

A simple ring buffer (circular buffer) designed for embedded systems.
