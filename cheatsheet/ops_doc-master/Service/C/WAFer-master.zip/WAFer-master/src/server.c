#include "wafer.h"
#include "waferapi.h"

void server(Request * request, Response * response)
{
    /*Your code goes here */
}
