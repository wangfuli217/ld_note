/* this sends a TCP packet to the target of your choice
 * to compile: gcc -Wall tcp_spoof.c -o tcp_spoof
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define __USE_BSD
#include <sys/socket.h>
#include <netinet/in.h>
#include <netinet/ip.h>
#include <arpa/inet.h>
#define __FAVOR_BSD
#include <netinet/tcp.h>
#include <unistd.h>

/* define the spoofed addresses and port numbers here */
#define src_ip "127.0.0.1"
#define dst_ip "127.0.0.1" /* isis */
#define src_port 111
#define dst_port 1434
#define ack 100920
#define seq 100921
#define offset 0

typedef struct ip ip_header;
typedef struct tcphdr tcp_header;

int sockfd;
int on = 1;
char payload[] = "hey man, just kocking on the door";		/* this is our packet payload. */
char packet[sizeof (struct ip) + sizeof(struct tcphdr) + sizeof(payload) ];


int main (int argc, char** argv){
  struct sockaddr_in sinaddr;
  ip_header *ipptr;
  tcp_header *tcpptr;

  /* typecast the packet so that ipptr points to the right place in the packet
   * so that we can fill in proper values at proper place
   */
  ipptr = (ip_header*) packet;

  /* after ip headers follow the tcp headers, do the same there */
  /* notice how this process is quite the reverse of what we did when we
   * wrote the sniffer
   */
  tcpptr = (tcp_header*) (packet + sizeof(ip_header));

  memset((char *)ipptr, '\0', sizeof(ip_header));
  memset((char *)tcpptr, '\0', sizeof(tcp_header));
  strcat ((packet + sizeof(tcp_header) + sizeof(ip_header) ), payload);

  /* unlike normal connection sockets we need a raw socket so that we can write
   * raw packet data into the wire by passing the OS network stack */
  if((sockfd = socket (AF_INET, SOCK_RAW, IPPROTO_RAW)) < 0){
    perror("socket");
    exit(1);
  }
	
  /* IP_HDRINCL tells the kernel header is already included and not to over 
   * write those values
   */
  if((setsockopt(sockfd, IPPROTO_IP, IP_HDRINCL, &on, sizeof(on) ) == -1)){
    perror("setsockopt");
    exit(1);
  }

  /* prepare the packet so that we can send it */

  /* used by sendto() below */
  sinaddr.sin_family = AF_INET;
  sinaddr.sin_port = htons (dst_port);	/* destination port. */
  sinaddr.sin_addr.s_addr = inet_addr (dst_ip);	/* ip of destination host. */

  /* fill in the ip header values */
  ipptr->ip_hl = 5;	/* default header length */
  ipptr->ip_v = 4;	/* ip version */
  ipptr->ip_tos = 0;	/* normal tos */
  ipptr->ip_len = sizeof (ip_header) + sizeof (tcp_header) + sizeof (payload);	/* total size of packet. */
  ipptr->ip_id = htonl (1234); /* id is for reassembly of fragmented packets */
  ipptr->ip_off = 0;	/* do not fragment our packet */
  ipptr->ip_ttl = 64;	/* ttl */
  ipptr->ip_p = IPPROTO_TCP;	/* transport layer protocol tcp */
  ipptr->ip_sum = 0;	/* kernel should fill in the values */
  ipptr->ip_src.s_addr = inet_addr (src_ip);	/* spoofed source IP */
  ipptr->ip_dst.s_addr = inet_addr(dst_ip);	/* destination IP  */
	
  /* fill in the tcp headers */
  tcpptr->th_sport = htons (src_port);	/* source port.*/
  tcpptr->th_dport = htons (dst_port);	/* destination port. port 7 (echo) in this case. */
  tcpptr->th_seq = htonl(seq);
  tcpptr->th_ack = htonl(ack);
  tcpptr->th_off=  htons(offset);
  tcpptr->th_flags= TH_FIN; /* see netinet/in.h */
  tcpptr->th_sum = 0; /* kernel should fill in the correct checksum during transmission. */
  
	
  if (sendto (sockfd, packet, sizeof (packet), 0, (struct sockaddr *) &sinaddr, sizeof (sinaddr) ) != sizeof (packet) ){
    fprintf (stderr, "error sending packet...\n");
    exit(1);
  }
  
  fprintf(stdout, "%s: a packet sent to %s\n", argv[0], dst_ip);

  return 0;
}
