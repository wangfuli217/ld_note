#include <scheduler.h>

sche *sptr;

void pcap_callback (u_char *argc, const struct pcap_pkthdr *pkt_header, const u_char *pkt){


  if((sptr= (sche *)argc) == NULL){
    fprintf(stderr, "scheduler struct is NULL\n");
    return;
  }

  /* call the packet scheduler */
  pkt_scheduler(sptr, pkt_header, pkt); 

  return;
}

void pkt_scheduler(sche *s, const struct pcap_pkthdr *h, const u_char *p){

  register int i;

  /* until we have different filters ... */
  for(i=0; i < s->n; ++i)
    /* eval the filter, if true (!=0) then do something, otherwise move to next one */
    if(bpf_filter(s->fcode[i].bf_insns, (u_char *)p, h->len, h->caplen) != 0)
      fprintf(stderr, "caught a packet for filter: %s\n", s->fexpr[i]);
}
