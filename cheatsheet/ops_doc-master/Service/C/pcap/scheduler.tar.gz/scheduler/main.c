#include <scheduler.h>

int main(int argc, char** argv){

  register int i=0;
  sche p;
  char *dev;
  char errbuf[PCAP_ERRBUF_SIZE];
  pcap_t *descr;
  struct bpf_program prg;
  bpf_u_int32 nmask, lnet;
  int codesize=0;

  if(argc < 2){
    fprintf(stderr, "usage: %s <filter1> <filter2> ...\n", argv[0]);
    exit(0);
  }

  memset(&p, 0, sizeof(sche));
  /* read in the filter experssions */
  for(i=1; (i < argc && i < MAX_FILTERS); ++i)
    memcpy(p.fexpr[i-1], argv[i], strlen(argv[i]));

  p.n= (i < MAX_FILTERS)? argc-1: MAX_FILTERS;

  if((dev = pcap_lookupdev (errbuf))==NULL){
    fprintf(stderr, "%s: pcap_lookupdev: %s\n", argv[0], errbuf);
    exit(-1);
  }

  if((descr = pcap_open_live (dev, BUFSIZ, 0, -1, errbuf))==NULL){
      fprintf (stderr, "%s: pcap_open_live: %s\n", argv[0], errbuf);
      exit (-1);
  }

  (void) setgid(getgid());
  (void) setuid(getuid());

  lnet=0, nmask=0;
  if(pcap_lookupnet(dev, &lnet, &nmask, errbuf) == -1){ 
    fprintf(stderr, "crapped out while trying to find netmasks\n"); 
    return -1; 
  }
 
  /* compile experssions */
  for(i=0; i < argc; ++i){
    if(pcap_compile(descr, &prg, p.fexpr[i], 1, nmask) < 0){
      fprintf(stderr, "crapped out when compiling filter: %s\n", p.fexpr[i]);
      return -1;
    }

    codesize= sizeof(* prg.bf_insns) * prg.bf_len;
    if((p.fcode[i].bf_insns=(struct bpf_insn *)malloc(codesize))==NULL){
      fprintf(stderr, "crapped out when allocating bfp code base for: %s\n", p.fexpr[i]);
      return -1; 
    }

    memcpy(p.fcode[i].bf_insns, prg.bf_insns, codesize);
    p.fcode->bf_len= prg.bf_len;
  }

  fprintf(stdout, "capture results\n");
  pcap_loop(descr, -1, pcap_callback, (void *)&p);

  return 0;
}
