#ifndef SCHEDULER_H
#define SCHEDULER_H

#define MAX_FILTERS 16

/* system includes */
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <signal.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <pcap.h>

typedef struct __sche{
  struct bpf_program fcode[MAX_FILTERS];
  char   fexpr[MAX_FILTERS][256]; 
  int n; 
}sche;

void pcap_callback (u_char *, const struct pcap_pkthdr *, const u_char *);
void pkt_scheduler(sche *, const struct pcap_pkthdr* , const u_char *);

#endif
