#include <capture.h>

int main (int argc, char **argv){
  
  char *dev;
  char errbuf[PCAP_ERRBUF_SIZE];
  pcap_t *descr;
  int howmany= -1; /* loop for ever */
  
  if (argc > 2){
      fprintf (stderr, "Usage: %s no_packets\nno_packets: number of packets to grab before quit sniffing\n",argv[0]);
      exit(-1);
  }

  /* how many packets to grab */
  if(argc == 2)
    howmany= atoi(argv[1]);
  
  if((dev = pcap_lookupdev (errbuf))==NULL){
    fprintf(stderr, "%s: pcap_lookupdev: %s\n", argv[0], errbuf);
    exit(-1);
  }
  
  if((descr = pcap_open_live (dev, BUFSIZ, 0, -1, errbuf))==NULL){
      fprintf (stderr, "%s: pcap_open_live: %s\n", argv[0], errbuf);
      exit (-1);
  }

  (void) setgid(getgid());
  (void) setuid(getuid());
 
  fprintf(stdout, "URL list:\n");
  pcap_loop(descr, howmany, pcap_callback, NULL);
 
  return 0;
}



