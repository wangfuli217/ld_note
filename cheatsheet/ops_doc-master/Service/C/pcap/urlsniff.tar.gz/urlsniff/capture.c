#include <capture.h>

void pcap_callback(u_char * arg, const struct pcap_pkthdr *pkthdr, const u_char * packet){

  /* variables for packets we sniff, better make them staticis folks. 
   * i'll leave that to you
   */
  ethernet_header *eptr; /* pointer to the structure that represents ethernet header */
  ip_header *ipptr; /* pointer to the structure that represents ip header */
  tcp_header *tcpptr; /* pointer to the structure that represents tcp header */
  unsigned int size_of_ehdr= sizeof(ethernet_header);  /* size of the ethernet header */
  unsigned int size_of_iphdr= sizeof(ip_header); /* size of the ip header */
  unsigned int size_of_tcphdr= sizeof(tcp_header); /* size of the tcp header */
  struct in_addr ipaddr;
  u_char *payload;
  char* ptr;

  eptr = (ethernet_header *) packet;	/* ethernet header of current packet */

  if(ntohs(eptr->ether_type) == ETHERTYPE_IP){
    ipptr = (ip_header *) (packet + size_of_ehdr);

    if((pkthdr->len - size_of_ehdr) < size_of_iphdr){
      fprintf (stderr, "not a valid IP packet\n");
      return;
    }

    /* if it is TCP lets decode it and print out the URL */
    if(ipptr->protocol == IPPROTO_TCP){
      tcpptr = (tcp_header *) (packet + size_of_ehdr + size_of_iphdr);

      /* check if traffic is going to a webserver */
      if(ntohs (tcpptr->dest) == 80){
        /* parse and print the url to stdout */
        payload = (u_char *) (packet + size_of_ehdr + size_of_iphdr + size_of_tcphdr);
	
        /* if a packet has GET we need to parse it */
        if((ptr = strstr (payload, "GET ")) != NULL){ /* take me to GET */
          while(*ptr != ' ') ++ptr; /* get passes GET */
          ++ptr; /* skip the space following GET */
	  /* now ptr point to the first char of the url */
	  /* lets also print who accessed the page, i.e: src, dst ip adrresses */
          ipaddr.s_addr= (unsigned long int)ipptr->saddr;
	  fprintf(stdout, "%s --->", inet_ntoa(ipaddr)); /* source address */
	  ipaddr.s_addr= (unsigned long int)ipptr->daddr;
	  fprintf(stdout, " %s : ", inet_ntoa(ipaddr));

	  /* now just print the url */
          while (*ptr != ' ')
	    fprintf (stdout, "%c", *ptr++);
	  fprintf(stdout, "\n");
	}/* if no GET then nothing to do */
      }
    }
  }
}
