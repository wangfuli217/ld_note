# inSecure-SHell
A telnet like client/server application using pseudo-terminals (pty) that runs a Bash shell session on the remote server. [fork,forkpty,select,epoll,ipv6] [ssl,tls,s2n]
