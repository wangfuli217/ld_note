class ProgramDoesNotExist(Exception):
    pass

class EmptyManpage(Exception):
    pass
