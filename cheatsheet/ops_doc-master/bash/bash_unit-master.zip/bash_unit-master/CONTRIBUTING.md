Be aware that bash_unit version information is extracted from git tags.
If you need to deliver a versionned copy of bash_unit, you will have to
activate the appropriate filters so that version information is up to
date.

To do so, run the following command on your system :

$> git config --local include.path ../.gitconfig
