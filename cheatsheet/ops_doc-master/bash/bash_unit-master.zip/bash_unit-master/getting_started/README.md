This is a sample project to get started with bash_unit.

To try it:

    git clone https://github.com/pgrange/bash_unit.git
    cd bash_unit/getting_started
    ./bash_unit tests/test_*
