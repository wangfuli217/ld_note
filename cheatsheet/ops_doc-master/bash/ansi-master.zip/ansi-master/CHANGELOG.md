Changelog
=========


1.0.0 - 2016-09-21
----------------

* First tagged release.
