#!/usr/bin/env bash

cd "${0%/*}"
../mo --help
