## Testing with [Bats](https://github.com/sstephenson/bats#installing-bats-from-source)
```
bats test/{lib,plugins}
```
