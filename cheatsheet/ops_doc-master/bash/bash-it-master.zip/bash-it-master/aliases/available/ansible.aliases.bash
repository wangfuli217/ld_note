cite 'about-alias'
about-alias 'ansible abbreviations'

alias ans=ansible
alias ap=ansible-playbook
