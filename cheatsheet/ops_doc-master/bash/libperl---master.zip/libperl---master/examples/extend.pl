#! /usr/bin/perl

use strict;
use warnings;

use Extend qw/hello/;

hello('World!');
