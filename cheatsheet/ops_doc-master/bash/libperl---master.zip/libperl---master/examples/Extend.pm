package Extend;

use strict;
use warnings;

use Exporter 5.57 qw/import/;
our @EXPORT_OK = qw/hello/;

use Perlpp::Extend;

1;
