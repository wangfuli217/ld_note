#ifndef __MAIN_SERVER_H__
#define __MAIN_SERVER_H__

#include "semi_generic_llist.h"
#define DATABASE "./database"
/*
typedef struct{
	char name[10];
	char passwd[20];
}info_t;
*/

#endif //__MAIN_SERVER_H__
