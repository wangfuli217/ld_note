## Pesticide Paradox

> “Every method you use to prevent or find bugs leaves a residue of subtler bugs against which those methods are ineffectual.”

Boris Beizer, Software Testing Techniques. Second edition. 1990
