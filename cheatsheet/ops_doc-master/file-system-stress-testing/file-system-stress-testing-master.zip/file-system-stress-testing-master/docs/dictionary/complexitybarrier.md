## Complexity Barrier

> "Software complexity(and therefore that of bugs) grows to the limits of our ability to manage that complexity."

Boris Beizer, Software Testing Techniques. Second edition. 1990
