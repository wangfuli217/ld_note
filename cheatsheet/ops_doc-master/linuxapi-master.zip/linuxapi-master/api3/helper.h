/*
 * helper.h
 *
 *  Created on: Jun 28, 2016
 *      Author: ahnmh-vw
 */

#ifndef HELPER_H_
#define HELPER_H_

void errexit(char *msg);

#endif /* HELPER_H_ */
