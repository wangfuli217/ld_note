/*
 * gcc_extension.h
 *
 *  Created on: Jul 28, 2016
 *      Author: ahnmh-vw
 */

#ifndef GCC_EXTENSION_H_
#define GCC_EXTENSION_H_


#endif /* GCC_EXTENSION_H_ */
