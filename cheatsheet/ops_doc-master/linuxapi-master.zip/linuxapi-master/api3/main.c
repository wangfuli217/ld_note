/*
 * main.c
 *
 *  Created on: Jun 24, 2016
 *      Author: ahnmh-vw
 */

//#include "fileio.h"
//#include "process_manage.h"
//#include "pthread_example.h"
//#include "file_directory.h"
//#include "mem.h"
//#include "signal_example.h"
#include "time_timer.h"

int main(int argc, char *argv[])
{
//	fileio_read_write(argc, argv);

//	select_sample();
//	pselect_sample();
//	poll_sample();
//	epoll_sample();

//	fileio_stdio_read();
//	fileio_stdio_write();
//	fileio_stdio_write_lock();

//	fileio_readv_writev();

//	mmap_sample(argc, argv);

//	fileio_aio_write();
//	get_inode();
//	get_physical_block_number();

//	fork_exec_wait();
//	system_sample();
//	make_daemon();

//	nice_control();
//	priority_control();
//	affinity_control();
//	sched_control();
//	limit_control();

//	create();
//	exit_cancel();
//	mutex_example();
//	mutex_cond_example();

//	get_stat(argc, argv);
//	chn_access(argc, argv);
//	chn_owner(argc, argv);
//	working_diretory();
//	make_directory();
//	traversal_directory(argc, argv);
//	ioctl_example(argc, argv);
//	inotify_example(argc, argv);

//	mem_alloc();
//	mem_anonymous_mmap();
//	mem_alloc_control();
//	mem_alloca(argc, argv);
//	mem_variable_len_array(argc, argv);
//	mem_handle_sample(argc, argv);
//	mlock_sample();

//	signal_legacy();
//	signal_send();
//	signal_helper();
//	signal_block();
//	signal_suspend();
//	signal_sigaction();

//	get_time();
//	set_time();
//	time_format();
//	time_sleep();
//	time_clock_nanosleep();
//	timer_example_alarm();
//	timer_example_setitimer();
//	timer_example_settime_signal();
//	timer_example_settime_thread();
	gcc_extension();

	return 0;
}
