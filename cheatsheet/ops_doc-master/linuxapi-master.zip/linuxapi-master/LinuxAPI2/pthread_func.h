/*
 * pthread_func.h
 *
 *  Created on: May 15, 2016
 *      Author: ahnmh
 */

#ifndef PTHREAD_FUNC_H_
#define PTHREAD_FUNC_H_

void pthread_introduce();
void pthread_sync();
void pthread_sync_error_checking_mutex();
void pthread_cond_var();
void pthread_safe();
void pthread_cancellation();
void pthread_signal();

#endif /* PTHREAD_FUNC_H_ */
