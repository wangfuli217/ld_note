/*
 * alt_io_sample.h
 *
 *  Created on: Jun 21, 2016
 *      Author: ahnmh-vw
 */

#ifndef ALT_IO_SAMPLE_H_
#define ALT_IO_SAMPLE_H_

void alt_io_select();
void alt_io_poll();
void alt_io_signal();
void alt_io_epoll();

#endif /* ALT_IO_SAMPLE_H_ */
