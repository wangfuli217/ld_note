/*
 * file_lock.h
 *
 *  Created on: Jun 2, 2016
 *      Author: ahnmh-vw
 */

#ifndef FILE_LOCK_H_
#define FILE_LOCK_H_

void file_lock_flock(int argc, char *argv[]);
void file_lock_region(int argc, char *argv[]);


#endif /* FILE_LOCK_H_ */
