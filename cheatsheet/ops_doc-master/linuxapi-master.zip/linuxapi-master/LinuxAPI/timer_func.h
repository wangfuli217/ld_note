/*
 * timer_func.h
 *
 *  Created on: Apr 24, 2016
 *      Author: ahnmh
 */

#ifndef TIMER_FUNC_H_
#define TIMER_FUNC_H_

void timer_func();
void timer_sync_expire();
void timer_sleep();
void timer_clock_gettime();

#endif /* TIMER_FUNC_H_ */
