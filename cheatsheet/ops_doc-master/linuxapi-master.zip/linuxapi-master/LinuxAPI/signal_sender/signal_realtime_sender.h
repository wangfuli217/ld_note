/*
 * signal_realtime_sender.h
 *
 *  Created on: Apr 22, 2016
 *      Author: ahnmh
 */

#ifndef SIGNAL_REALTIME_SENDER_H_
#define SIGNAL_REALTIME_SENDER_H_

void signal_sender(int pid, int sig);

#endif /* SIGNAL_REALTIME_SENDER_H_ */
