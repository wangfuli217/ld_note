/*
 * get_limit.h
 *
 *  Created on: Apr 11, 2016
 *      Author: ahnmh
 */

#ifndef GET_LIMIT_H_
#define GET_LIMIT_H_


void get_limit();

#endif /* GET_LIMIT_H_ */
