/*
 * directory_link.h
 *
 *  Created on: Apr 17, 2016
 *      Author: ahnmh
 */

#ifndef DIRECTORY_LINK_H_
#define DIRECTORY_LINK_H_

void directory_link();

#endif /* DIRECTORY_LINK_H_ */
