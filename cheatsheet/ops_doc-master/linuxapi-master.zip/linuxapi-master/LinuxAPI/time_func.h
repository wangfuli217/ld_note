/*
 * time_func.h
 *
 *  Created on: Apr 7, 2016
 *      Author: root
 */

#ifndef TIME_FUNC_H_
#define TIME_FUNC_H_

void time_related_func();

#endif /* TIME_FUNC_H_ */
