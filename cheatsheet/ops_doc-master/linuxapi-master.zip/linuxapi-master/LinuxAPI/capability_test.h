/*
 * capability.h
 *
 *  Created on: May 12, 2016
 *      Author: ahnmh
 */

#ifndef CAPABILITY_TEST_H_
#define CAPABILITY_TEST_H_

void set_capability();

#endif /* CAPABILITY_TEST_H_ */
