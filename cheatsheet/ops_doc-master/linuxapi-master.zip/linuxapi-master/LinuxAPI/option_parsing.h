/*
 * option_parsing.h
 *
 *  Created on: May 15, 2016
 *      Author: ahnmh
 */

#ifndef OPTION_PARSING_H_
#define OPTION_PARSING_H_

void option_parsing();

#endif /* OPTION_PARSING_H_ */
