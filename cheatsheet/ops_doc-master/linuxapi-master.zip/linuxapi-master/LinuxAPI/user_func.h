/*
 * user_group.h
 *
 *  Created on: Apr 7, 2016
 *      Author: root
 */

#ifndef USER_FUNC_H_
#define USER_FUNC_H_

void user_group();
void user_getuserid();
void user_setuserid();

#endif /* USER_FUNC_H_ */
