/*
 * syslog_test.h
 *
 *  Created on: May 11, 2016
 *      Author: ahnmh
 */

#ifndef SYSLOG_TEST_H_
#define SYSLOG_TEST_H_

void syslog_test();

#endif /* SYSLOG_TEST_H_ */
