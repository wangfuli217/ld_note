/*
 * process_env.h
 *
 *  Created on: Apr 5, 2016
 *      Author: ahnmh
 */

#ifndef PROCESS_ENV_H_
#define PROCESS_ENV_H_

int get_enviorn();

#endif /* PROCESS_ENV_H_ */
