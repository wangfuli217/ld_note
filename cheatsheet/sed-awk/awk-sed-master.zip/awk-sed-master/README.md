## 学习 Sed & Awk 

----

### 推荐阅读

- [Sed & Awk 笔记](https://github.com/renchunxiao/awk-sed/wiki)

### shell 练习

- [awk](https://github.com/renchunxiao/awk-sed/tree/master/awk)
- [sed](https://github.com/renchunxiao/awk-sed/tree/master/sed)
