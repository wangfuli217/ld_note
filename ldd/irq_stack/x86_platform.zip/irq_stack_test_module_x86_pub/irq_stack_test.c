#include <linux/module.h>
#include <linux/moduleparam.h>
#include <linux/init.h>

#include <linux/kernel.h>	/* printk() to debug*/
#include <linux/slab.h>		/* kmalloc() */
#include <linux/fs.h>		/* everything... */
#include <linux/errno.h>	/* error codes */
#include <linux/types.h>	/* size_t */
#include <linux/fcntl.h>	/* O_ACCMODE */
#include <linux/cdev.h>		/* char driver */
#include <asm/system.h>		/* cli(), *_flags */
#include <asm/uaccess.h>	/* copy_*_user */
#include "irq_stack_test.h"		/* local definitions */
#include <linux/sched.h>
//#include <plat/irqs.h>
#include <linux/irq.h>
#include <linux/interrupt.h>
#include <linux/gpio.h>

/*
 * Our parameters which can be set at load time.
 */
int irq_stack_major = IRQ_STACK_MAJOR;
int irq_stack_minor = 0;

module_param(irq_stack_major, int, S_IRUGO);
module_param(irq_stack_minor, int, S_IRUGO);

struct irq_stack_dev *irq_stack_devices;	/* allocated in irq_stack_init */

irqreturn_t rst_rec_interrupt(int irq, void *dev_id)
{
	int test_point;

	printk("\n%s-PID:%d-kernel_stack@0x%p-to-%lx\ntest_point@0x%lx\n", 
			current->comm, current->pid, current->stack, ((unsigned long)current->stack)+THREAD_SIZE,
			(unsigned long)(&test_point));

	return IRQ_HANDLED;
}
EXPORT_SYMBOL_GPL(rst_rec_interrupt);

/*
 * Finally, the module stuff
 */

/*
 * The cleanup function is used to handle initialization failures as well.
 * Thefore, it must be careful to work correctly even if some of the items
 * have not been initialized
 */
void irq_stack_cleanup(void)
{
//	int i;
	dev_t devno = MKDEV(irq_stack_major, irq_stack_minor);

	/* Get rid of our char dev entries */
	if (irq_stack_devices) {
		free_irq(irq_stack_devices->irq, (void *)irq_stack_devices);
		cdev_del(&irq_stack_devices->cdev);
		kfree(irq_stack_devices);
	}

	/* cleanup_module is never called if registering failed */
	unregister_chrdev_region(devno, 1);
}

struct file_operations irq_stack_fops = {
	.owner =    THIS_MODULE,
};

/*
 * Set up the char_dev structure for this device.
 */
static void irq_stack_setup_cdev(struct irq_stack_dev *dev, int index)
{
	int err, devno = MKDEV(irq_stack_major, irq_stack_minor + index);
    
	cdev_init(&dev->cdev, &irq_stack_fops);
	dev->cdev.owner = THIS_MODULE;
	err = cdev_add (&dev->cdev, devno, 1);
	/* Fail gracefully if need be */
	if (err)
		printk(KERN_NOTICE "Error %d adding irq_stack%d", err, index);

	dev->irq = IRQ_FOR_TEST;
}

int __init irq_stack_init(void)
{
	int result;
	dev_t dev = 0;

/*
 * Get a range of minor numbers to work with, asking for a dynamic
 * major unless directed otherwise at load time.
 */
	if (irq_stack_major) {
		dev = MKDEV(irq_stack_major, irq_stack_minor);
		result = register_chrdev_region(dev, 1, "irq_stack");
	} else {
		result = alloc_chrdev_region(&dev, irq_stack_minor, 1, "irq_stack");
		irq_stack_major = MAJOR(dev);
	}
	if (result < 0) {
		printk(KERN_WARNING "irq_stack: can't get major %d\n", irq_stack_major);
		return result;
	}

    /* 
	 * allocate the devices -- we can't have them static, as the number
	 * can be specified at load time
	 */
	irq_stack_devices = kmalloc(sizeof(struct irq_stack_dev), GFP_KERNEL);
	if (!irq_stack_devices) {
		result = -ENOMEM;
		goto fail;  /* Make this more graceful */
	}
	memset(irq_stack_devices, 0, sizeof(struct irq_stack_dev));

    /* Initialize each device. */
	irq_stack_setup_cdev(irq_stack_devices, 0);

	result = request_irq(irq_stack_devices->irq, rst_rec_interrupt, (IRQF_SHARED),
			  "irq_stack", (void *)irq_stack_devices);
	if (result) {
		printk(KERN_WARNING "irq_stack: can't get irq!\n");
		goto fail;
	}


	return 0; /* succeed */

  fail:
	irq_stack_cleanup();
	return result;
}

module_init(irq_stack_init);
module_exit(irq_stack_cleanup);

MODULE_DESCRIPTION("irq stack test module");
MODULE_VERSION("v1.0");
MODULE_AUTHOR("Tekkaman Ninja");
MODULE_LICENSE("Dual BSD/GPL");
