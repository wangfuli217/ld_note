#include <linux/module.h>
#include <linux/moduleparam.h>
#include <linux/init.h>

#include <linux/kernel.h>	/* printk() to debug*/
#include <linux/slab.h>		/* kmalloc() */
#include <linux/fs.h>		/* everything... */
#include <linux/errno.h>	/* error codes */
#include <linux/types.h>	/* size_t */
#include <linux/fcntl.h>	/* O_ACCMODE */
#include <linux/cdev.h>		/* char driver */
#include <asm/system.h>		/* cli(), *_flags */
#include <asm/uaccess.h>	/* copy_*_user */
#include "irq_stack_test.h"		/* local definitions */
#include <linux/sched.h>
#include <plat/irqs.h>
#include <linux/irq.h>
#include <linux/interrupt.h>
#include <linux/gpio.h>

irqreturn_t rst_rec_interrupt(int irq, void *dev_id)
{
	int test_point;

	printk("\n%s-PID:%d-kernel_stack@0x%p-to-%lx\ntest_point@0x%lx\n", 
			current->comm, current->pid, current->stack, ((unsigned long)current->stack)+(THREAD_SIZE),
			(unsigned long)(&test_point));

	return IRQ_HANDLED;
}
EXPORT_SYMBOL_GPL(rst_rec_interrupt);

/*
 * Finally, the module stuff
 */

/*
 * The cleanup function is used to handle initialization failures as well.
 * Thefore, it must be careful to work correctly even if some of the items
 * have not been initialized
 */
void irq_stack_cleanup(void)
{
		free_irq(TEST_IRQ_NUM , NULL);
}

int __init irq_stack_init(void)
{
	int result;

	result = request_irq(TEST_IRQ_NUM , rst_rec_interrupt, (IRQF_TRIGGER_FALLING | IRQF_TRIGGER_RISING),
			  "irq_stack", NULL);
	if (result) {
		printk(KERN_WARNING "irq_stack: can't get irq!\n");
		goto fail;
	}

	return 0; /* succeed */

  fail:
	irq_stack_cleanup();
	return result;
}

module_init(irq_stack_init);
module_exit(irq_stack_cleanup);

MODULE_DESCRIPTION("irq stack test module");
MODULE_VERSION("v1.0");
MODULE_AUTHOR("Tekkaman Ninja");
MODULE_LICENSE("Dual BSD/GPL");
