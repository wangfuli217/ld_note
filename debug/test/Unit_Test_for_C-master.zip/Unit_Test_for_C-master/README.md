Unit_Test_for_C
===============

C unit test template</br>

fork from http://sourceforge.net/projects/cutest/

Need to be more <b>automatic</b> and <b>elegant</b></br>

