#include <stdio.h>

void RunAllTests(void);

int main(int argc, char* argv[])
{
	RunAllTests();
	return 0;
}
