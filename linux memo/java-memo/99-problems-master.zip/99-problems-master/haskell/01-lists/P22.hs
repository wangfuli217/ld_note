module P22 where
-- (*) Create a list containing all integers within a given range

range :: Int -> Int -> [Int]
range start end = [start..end]
