package com.shekhargulati.ninetynine_problems._02_arithmetic

/**
  * (*) Compare the two methods of calculating Euler's totient function.
  * Check P41Test.
  */
object P41 {

}
