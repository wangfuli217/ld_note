#ifndef _SYS_PARAM_H
# define _SYS_PARAM_H

# define HZ	60
# define NOFILE	60
# define PATHSIZE	1024

#endif
