
#include <sys/types.h>

getgid()
{
  
  return 20;
  
}
