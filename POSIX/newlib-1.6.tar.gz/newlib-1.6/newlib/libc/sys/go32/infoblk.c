#include "go32.h"

Go32_Info_Block _go32_info_block = { sizeof(Go32_Info_Block) };

