umask()
{
  return 0644;
}
