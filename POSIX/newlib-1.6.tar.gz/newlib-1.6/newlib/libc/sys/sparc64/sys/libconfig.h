#define _FLOAT_ARG double
#define _FLOAT_RET float




