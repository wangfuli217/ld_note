/* This is the same as sys/fcntl.h for now.  */

#include <sys/fcntl.h>
