char *sbrk();


char *malloc(int s)
{
  return sbrk(s);
}


free(char *s)
{
  
}
