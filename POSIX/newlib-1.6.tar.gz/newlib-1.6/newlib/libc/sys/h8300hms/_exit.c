/* FIXME: which one? */

_exit()
{
  asm("sleep");
}

__exit()
{
  asm("sleep");
}
