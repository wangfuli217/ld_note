/* NetWare version of environ.  This is the wrong way to implement
   this.  We should return the environment area somehow.  */

static char *environ_array[] = { "" };

char **environ = environ_array;
