/* connector for sbrk */
#include <unistd.h>

extern char *_sbrk(size_t);

void *
sbrk (_incr)
     size_t _incr;
{
  return _sbrk(_incr);
}
