/* connector for kill */
int
kill (_pid, _sig)
     int _pid;
     int _sig;
{
  return _kill(_pid, _sig);
}
