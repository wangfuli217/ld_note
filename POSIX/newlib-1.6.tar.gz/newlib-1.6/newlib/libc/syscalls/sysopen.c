/* connector for open */
#include <fcntl.h>

int open(_file, _flags, _mode)
     const char *_file;
     int _flags;
     int _mode;
{
  return _open(_file, _flags, _mode);
}
