/* connector for fork */
int
fork ()
{
  return _fork();
}
