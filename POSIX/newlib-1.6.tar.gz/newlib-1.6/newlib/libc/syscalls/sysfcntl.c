/* connector for fcntl */
/* only called from stdio/fdopen.c, so arg can be int. */
int
fcntl (_fd, _flag, _arg)
     int _fd;
     int _flag;
     int _arg;
{
  return _fcntl(_fd, _flag, _arg);
}
