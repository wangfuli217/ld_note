/* connector for read */
#include <unistd.h>

int
read (_fd, _buf, _cnt)
     int _fd;
     void*_buf;
     size_t _cnt;
{
  return _read(_fd, _buf, _cnt);
}
