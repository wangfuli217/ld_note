/* connector for lseek */
#include <unistd.h>

off_t
lseek (_fd, _pos, _whence)
     int _fd;
     off_t _pos;
     int _whence;
{
  return _lseek(_fd, _pos, _whence);
}
