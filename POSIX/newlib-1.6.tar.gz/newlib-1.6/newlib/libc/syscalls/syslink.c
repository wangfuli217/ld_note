/* connector for link */
int
link (_old, _new)
     char *_old;
     char *_new;
{
  return _link(_old, _new);
}
