/* connector for write */
#include <unistd.h>

int
write (_fd, _buf, _cnt)
     int _fd;
     const void *_buf;
     size_t _cnt;
{
  return _write(_fd, _buf, _cnt);
}
