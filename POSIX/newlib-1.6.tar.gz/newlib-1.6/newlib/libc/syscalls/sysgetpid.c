/* connector for getpid */
int
getpid ()
{
  return _getpid();
}
