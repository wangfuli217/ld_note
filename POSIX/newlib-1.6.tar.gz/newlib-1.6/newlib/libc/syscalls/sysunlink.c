/* connector for unlink */
int
unlink (_file)
     char *_file;
{
  return _unlink(_file);
}
