/* connector for fstat */
#include <unistd.h>

int
fstat (_fd, _pstat)
     int _fd;
     struct stat *_pstat;
{
  return _fstat(_fd, _pstat);
}
