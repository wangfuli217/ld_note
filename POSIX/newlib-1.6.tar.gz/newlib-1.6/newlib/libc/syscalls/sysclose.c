/* connector for close */
int close(_fd)
     int _fd;
{
  return _close(_fd);
}
