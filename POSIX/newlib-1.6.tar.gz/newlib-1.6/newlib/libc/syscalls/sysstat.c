/* connector for stat */
#include <unistd.h>

int
stat (_file, _pstat)
     char *_file;
     struct stat *_pstat;
{
  return _stat(_file, _pstat);
}
