/* connector for wait */
int
wait (_status)
     int *_status;
{
  return _wait(_status);
}
