/* Misc. local definitions for libc/stdlib */

#ifndef _LOCAL_H_
#define _LOCAL_H_

char *	_EXFUN(_gcvt,(struct _reent *, double , int , char *, char, int));

#endif
